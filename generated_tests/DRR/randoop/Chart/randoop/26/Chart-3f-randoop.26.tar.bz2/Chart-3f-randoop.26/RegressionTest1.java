import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.String str19 = timeSeries3.getRangeDescription();
        timeSeries3.removeAgedItems(true);
        long long22 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int27 = timeSeries26.getMaximumItemCount();
        java.lang.Comparable comparable28 = timeSeries26.getKey();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        org.jfree.data.time.Year year31 = month29.getYear();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date37 = fixedMillisecond36.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
        boolean boolean39 = year33.equals((java.lang.Object) date37);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month29, (org.jfree.data.time.RegularTimePeriod) year33);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month29, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 1.0d + "'", comparable28.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(timeSeries40);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(regularTimePeriod16, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int23 = timeSeries22.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        java.lang.Class<?> wildcardClass31 = year29.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean40 = timeSeries37.equals((java.lang.Object) fixedMillisecond39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 0);
        timeSeries22.setRangeDescription("1");
        java.lang.String str46 = timeSeries22.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeriesDataItem50.getPeriod();
        java.util.Calendar calendar52 = null;
        long long53 = regularTimePeriod51.getMiddleMillisecond(calendar52);
        java.lang.Number number54 = timeSeries22.getValue(regularTimePeriod51);
        try {
            org.jfree.data.time.TimeSeries timeSeries55 = timeSeries3.addAndOrUpdate(timeSeries22);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 32L + "'", long53 == 32L);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 0 + "'", number54.equals(0));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        boolean boolean20 = timeSeriesDataItem14.equals((java.lang.Object) regularTimePeriod19);
        java.lang.Class<?> wildcardClass21 = timeSeriesDataItem14.getClass();
        java.lang.Object obj22 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(obj22);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
//        java.lang.Class<?> wildcardClass4 = year2.getClass();
//        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.lang.String str7 = day0.toString();
//        java.util.Date date8 = day0.getStart();
//        long long9 = day0.getSerialIndex();
//        int int10 = day0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getMonth();
        int int3 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        timeSeries3.removeAgedItems(0L, false);
        java.lang.String str21 = timeSeries3.getRangeDescription();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean23 = timeSeries20.equals((java.lang.Object) fixedMillisecond22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        long long25 = fixedMillisecond22.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1));
        boolean boolean28 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        int int8 = day7.getYear();
        boolean boolean10 = day7.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries3.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        java.lang.Class<?> wildcardClass40 = year38.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 0.0f);
        java.lang.String str43 = timeSeries36.getDomainDescription();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) (-1.0d));
        java.lang.Object obj52 = timeSeriesDataItem51.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ", seriesChangeInfo2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
//        java.lang.Class<?> wildcardClass11 = year9.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0f);
//        java.lang.String str14 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
//        java.lang.Class<?> wildcardClass22 = year20.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.previous();
//        int int34 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
//        timeSeries7.addChangeListener(seriesChangeListener35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean43 = timeSeries40.equals((java.lang.Object) fixedMillisecond42);
//        java.util.Collection collection44 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        java.util.Collection collection45 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean48 = day46.equals((java.lang.Object) (-9999));
//        long long49 = day46.getFirstMillisecond();
//        long long50 = day46.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.next();
//        java.lang.Class<?> wildcardClass58 = year56.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean67 = timeSeries64.equals((java.lang.Object) fixedMillisecond66);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year75.next();
//        java.lang.Class<?> wildcardClass77 = year75.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year75, (java.lang.Number) 0.0f);
//        timeSeries73.setDescription("0");
//        timeSeries73.removeAgedItems(false);
//        long long84 = timeSeries73.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries3.addAndOrUpdate(timeSeries73);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560150000000L + "'", long49 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertNull(timeSeriesDataItem79);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 9223372036854775807L + "'", long84 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries85);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10);
        int int2 = timeSeries1.getMaximumItemCount();
        boolean boolean3 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean23 = timeSeries20.equals((java.lang.Object) fixedMillisecond22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        long long25 = fixedMillisecond22.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1));
        long long28 = fixedMillisecond22.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 32L + "'", long25 == 32L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        timeSeries1.removeAgedItems(1560185516002L, false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        java.util.Collection collection41 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.next();
        java.lang.Class<?> wildcardClass49 = year47.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 0.0f);
        java.lang.String str52 = timeSeries45.getDomainDescription();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year54, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year62.next();
        java.lang.Class<?> wildcardClass64 = year62.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year62, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean73 = timeSeries70.equals((java.lang.Object) fixedMillisecond72);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries60.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
        boolean boolean75 = timeSeriesDataItem74.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries45.addOrUpdate(timeSeriesDataItem74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries3.addOrUpdate(timeSeriesDataItem74);
        java.util.Collection collection78 = timeSeries3.getTimePeriods();
        timeSeries3.setDomainDescription("November 1");
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(collection78);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        java.lang.String str25 = timeSeries18.getDomainDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
        java.lang.Class<?> wildcardClass39 = year37.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) 0.0f);
        java.lang.String str42 = timeSeries35.getDomainDescription();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year44.previous();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries3.createCopy(regularTimePeriod31, regularTimePeriod47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date51 = fixedMillisecond50.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date51);
        timeSeries3.setKey((java.lang.Comparable) month53);
        long long55 = month53.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-2649600000L) + "'", long55 == (-2649600000L));
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        int int3 = day0.getMonth();
//        long long4 = day0.getSerialIndex();
//        int int5 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.String str19 = timeSeries3.getRangeDescription();
        long long20 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        java.lang.Number number25 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.lang.Class<?> wildcardClass29 = year27.getClass();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long36 = timeSeries35.getMaximumItemAge();
        timeSeries35.clear();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        java.lang.Class<?> wildcardClass41 = year39.getClass();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (byte) 1);
        int int44 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
        java.lang.Class class45 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year47 = org.jfree.data.time.Year.parseYear("1");
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        java.lang.Class<?> wildcardClass55 = year53.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean64 = timeSeries61.equals((java.lang.Object) fixedMillisecond63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        boolean boolean66 = timeSeriesDataItem65.isSelected();
        java.lang.Object obj67 = null;
        int int68 = timeSeriesDataItem65.compareTo(obj67);
        boolean boolean69 = year47.equals((java.lang.Object) timeSeriesDataItem65);
        long long70 = year47.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class75 = timeSeries74.getTimePeriodClass();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj78 = null;
        boolean boolean79 = year77.equals(obj78);
        boolean boolean81 = year77.equals((java.lang.Object) (-1));
        timeSeries74.add((org.jfree.data.time.RegularTimePeriod) year77, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year77, (double) 1969);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = year77.next();
        int int88 = year47.compareTo((java.lang.Object) year77);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year47);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0f + "'", number25.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-62135740800000L) + "'", long70 == (-62135740800000L));
        org.junit.Assert.assertNull(class75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem89);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean21 = timeSeries18.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Collection collection23 = timeSeries8.getTimePeriods();
        java.lang.String str24 = timeSeries8.getRangeDescription();
        long long25 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        java.lang.Number number30 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        java.lang.Class<?> wildcardClass34 = year32.getClass();
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long41 = timeSeries40.getMaximumItemAge();
        timeSeries40.clear();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.next();
        java.lang.Class<?> wildcardClass46 = year44.getClass();
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) (byte) 1);
        int int49 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        long long52 = month51.getSerialIndex();
        java.lang.String str53 = month51.toString();
        org.jfree.data.time.Year year54 = month51.getYear();
        long long55 = month51.getSerialIndex();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (short) 1, false);
        java.util.Calendar calendar59 = null;
        try {
            long long60 = month51.getFirstMillisecond(calendar59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0f + "'", number30.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 24234L + "'", long52 == 24234L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 24234L + "'", long55 == 24234L);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        boolean boolean18 = timeSeriesDataItem17.isSelected();
        java.lang.Object obj19 = null;
        int int20 = timeSeriesDataItem17.compareTo(obj19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        long long22 = month21.getSerialIndex();
        java.lang.String str23 = month21.toString();
        org.jfree.data.time.Year year24 = month21.getYear();
        long long25 = month21.getLastMillisecond();
        long long26 = month21.getSerialIndex();
        boolean boolean27 = timeSeriesDataItem17.equals((java.lang.Object) long26);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        int int10 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        boolean boolean5 = year1.equals((java.lang.Object) (-1));
        java.util.Date date6 = year1.getEnd();
        java.util.Date date7 = year1.getStart();
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        int int5 = day0.getDayOfMonth();
//        long long6 = day0.getLastMillisecond();
//        int int7 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 32L, false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long20 = timeSeries19.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.next();
        java.lang.Class<?> wildcardClass28 = year26.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 0.0f);
        java.lang.String str31 = timeSeries24.getDomainDescription();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.previous();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year33, (double) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year33.previous();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries3.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj35 = null;
        boolean boolean36 = year34.equals(obj35);
        boolean boolean38 = year34.equals((java.lang.Object) (-1));
        java.util.Date date39 = year34.getEnd();
        java.util.Date date40 = year34.getStart();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date40);
        timeSeries3.setKey((java.lang.Comparable) date40);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(7, (int) ' ');
        int int46 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
//        java.lang.Class<?> wildcardClass16 = year14.getClass();
//        int int17 = day12.compareTo((java.lang.Object) wildcardClass16);
//        boolean boolean19 = day12.equals((java.lang.Object) (byte) 0);
//        int int20 = day12.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.next();
//        java.lang.Class<?> wildcardClass28 = year26.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 0.0f);
//        int int31 = day12.compareTo((java.lang.Object) year26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        java.lang.String str33 = timeSeries3.getRangeDescription();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getLastMillisecond();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        java.lang.String str10 = timeSeries3.getDomainDescription();
//        java.lang.Object obj11 = timeSeries3.clone();
//        timeSeries3.setNotify(true);
//        timeSeries3.setRangeDescription("");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        java.lang.Class<?> wildcardClass20 = year18.getClass();
//        int int21 = day16.compareTo((java.lang.Object) wildcardClass20);
//        org.jfree.data.time.SerialDate serialDate22 = day16.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
//        java.lang.Class<?> wildcardClass31 = year29.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 0.0f);
//        timeSeries27.removeAgedItems(false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries27.getNextTimePeriod();
//        boolean boolean37 = day23.equals((java.lang.Object) regularTimePeriod36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day23);
//        long long39 = day23.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43626L + "'", long39 == 43626L);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        int int5 = day0.getYear();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int4 = month0.getMonth();
        int int6 = month0.compareTo((java.lang.Object) (-1.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(6, year2);
        long long5 = month4.getLastMillisecond();
        org.jfree.data.time.Year year7 = org.jfree.data.time.Year.parseYear("1");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (short) 1);
        int int10 = month4.compareTo((java.lang.Object) timeSeriesDataItem9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62120102400001L) + "'", long5 == (-62120102400001L));
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.Year year3 = month0.getYear();
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        int int6 = month0.getMonth();
        long long7 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
//        java.lang.Class<?> wildcardClass11 = year9.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0f);
//        java.lang.String str14 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
//        java.lang.Class<?> wildcardClass22 = year20.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.previous();
//        int int34 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
//        timeSeries7.addChangeListener(seriesChangeListener35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean43 = timeSeries40.equals((java.lang.Object) fixedMillisecond42);
//        java.util.Collection collection44 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        java.util.Collection collection45 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean48 = day46.equals((java.lang.Object) (-9999));
//        long long49 = day46.getFirstMillisecond();
//        long long50 = day46.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.next();
//        java.lang.Class<?> wildcardClass58 = year56.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean67 = timeSeries64.equals((java.lang.Object) fixedMillisecond66);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond66.next();
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond66);
//        java.beans.PropertyChangeListener propertyChangeListener72 = null;
//        timeSeries71.removePropertyChangeListener(propertyChangeListener72);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560150000000L + "'", long49 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        int int5 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) (-9999));
//        long long9 = day6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.next();
//        int int14 = day6.compareTo((java.lang.Object) regularTimePeriod13);
//        int int15 = day6.getDayOfMonth();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) (-9999));
//        long long19 = day16.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.previous();
//        int int21 = day16.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) day16);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560150000000L + "'", long19 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(timeSeries22);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.String str7 = timePeriodFormatException5.toString();
//        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("10-June-2019");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) seriesException9);
//        java.lang.String str11 = timePeriodFormatException5.toString();
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException5.getSuppressed();
//        int int13 = day2.compareTo((java.lang.Object) timePeriodFormatException5);
//        int int14 = month0.compareTo((java.lang.Object) int13);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
//        java.lang.Class<?> wildcardClass23 = year21.getClass();
//        int int24 = day19.compareTo((java.lang.Object) wildcardClass23);
//        boolean boolean26 = day19.equals((java.lang.Object) (byte) 0);
//        int int27 = day19.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
//        java.lang.Class<?> wildcardClass35 = year33.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 0.0f);
//        int int38 = day19.compareTo((java.lang.Object) year33);
//        timeSeries3.setKey((java.lang.Comparable) int38);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
//        java.lang.Class<?> wildcardClass47 = year45.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean56 = timeSeries53.equals((java.lang.Object) fixedMillisecond55);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
//        java.util.Collection collection58 = timeSeries43.getTimePeriods();
//        java.lang.String str59 = timeSeries43.getRangeDescription();
//        long long60 = timeSeries43.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        java.util.Date date63 = fixedMillisecond62.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
//        java.lang.Number number65 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond64.next();
//        java.util.Date date67 = regularTimePeriod66.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date67);
//        int int69 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//        long long70 = fixedMillisecond68.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 0.0f + "'", number65.equals(0.0f));
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 33L + "'", long70 == 33L);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Class<?> wildcardClass13 = year11.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean22 = timeSeries19.equals((java.lang.Object) fixedMillisecond21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        java.lang.Object obj26 = timeSeriesDataItem23.clone();
        boolean boolean27 = fixedMillisecond1.equals((java.lang.Object) timeSeriesDataItem23);
        long long28 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        java.lang.Object obj41 = timeSeries3.clone();
        java.lang.String str42 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj45 = null;
        boolean boolean46 = year44.equals(obj45);
        long long47 = year44.getSerialIndex();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
        java.lang.Class<?> wildcardClass52 = year50.getClass();
        int int53 = day48.compareTo((java.lang.Object) wildcardClass52);
        org.jfree.data.time.SerialDate serialDate54 = day48.getSerialDate();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        int int56 = year44.compareTo((java.lang.Object) day55);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year44, "Mon Jun 10 09:51:43 PDT 2019", "Mon Jun 10 09:51:43 PDT 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year44.previous();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 0 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj7 = null;
        boolean boolean8 = year6.equals(obj7);
        boolean boolean10 = year6.equals((java.lang.Object) (-1));
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 1, false);
        boolean boolean14 = timeSeries3.isEmpty();
        timeSeries3.setNotify(true);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        java.lang.Class<?> wildcardClass21 = year19.getClass();
        int int22 = day17.compareTo((java.lang.Object) wildcardClass21);
        org.jfree.data.time.SerialDate serialDate23 = day17.getSerialDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        java.lang.Class<?> wildcardClass32 = year30.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 0.0f);
        timeSeries28.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries28.getNextTimePeriod();
        boolean boolean38 = day24.equals((java.lang.Object) regularTimePeriod37);
        java.lang.Object obj39 = null;
        int int40 = day24.compareTo(obj39);
        boolean boolean41 = timeSeries3.equals(obj39);
        try {
            timeSeries3.delete(2, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        java.util.Date date7 = year5.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        int int10 = day0.compareTo((java.lang.Object) month8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        java.lang.Object obj35 = timeSeriesDataItem34.clone();
        boolean boolean36 = timeSeriesDataItem34.isSelected();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        timeSeries3.setDomainDescription("");
        boolean boolean17 = timeSeries3.isEmpty();
        long long18 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Class<?> wildcardClass3 = seriesException1.getClass();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str4.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) (short) 100);
        java.lang.String str3 = month0.toString();
        int int4 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mon Jun 10 09:52:40 PDT 2019" + "'", str1.equals("Mon Jun 10 09:52:40 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560185560268L + "'", long2 == 1560185560268L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(6, year37);
        int int40 = timeSeriesDataItem34.compareTo((java.lang.Object) month39);
        long long41 = month39.getFirstMillisecond();
        long long42 = month39.getLastMillisecond();
        java.util.Calendar calendar43 = null;
        try {
            long long44 = month39.getFirstMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62154230400000L) + "'", long41 == (-62154230400000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62120102400001L) + "'", long42 == (-62120102400001L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        java.util.Collection collection41 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.next();
        java.lang.Class<?> wildcardClass49 = year47.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 0.0f);
        java.lang.String str52 = timeSeries45.getDomainDescription();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year54, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year62.next();
        java.lang.Class<?> wildcardClass64 = year62.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year62, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean73 = timeSeries70.equals((java.lang.Object) fixedMillisecond72);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries60.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
        boolean boolean75 = timeSeriesDataItem74.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries45.addOrUpdate(timeSeriesDataItem74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries3.addOrUpdate(timeSeriesDataItem74);
        boolean boolean78 = timeSeriesDataItem74.isSelected();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list11 = timeSeries10.getItems();
        boolean boolean12 = year6.equals((java.lang.Object) list11);
        boolean boolean13 = timeSeries3.equals((java.lang.Object) boolean12);
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries3.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        java.lang.Class<?> wildcardClass23 = year21.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj28 = null;
        boolean boolean29 = year27.equals(obj28);
        boolean boolean31 = year27.equals((java.lang.Object) (-1));
        java.util.Date date32 = year27.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(6, year37);
        long long40 = month39.getLastMillisecond();
        org.jfree.data.time.Year year42 = org.jfree.data.time.Year.parseYear("1");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (short) 1);
        int int45 = month39.compareTo((java.lang.Object) timeSeriesDataItem44);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62120102400001L) + "'", long40 == (-62120102400001L));
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        int int3 = day0.getYear();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.Class<?> wildcardClass10 = year8.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0.0f);
        java.lang.String str13 = timeSeries6.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year15, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        long long30 = month29.getSerialIndex();
        java.lang.String str31 = month29.toString();
        org.jfree.data.time.Year year32 = month29.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month29, (double) (byte) 10);
        int int35 = month29.getMonth();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 24234L + "'", long30 == 24234L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        double double11 = timeSeries3.getMinY();
        java.lang.String str12 = timeSeries3.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
//        java.lang.Object obj7 = null;
//        boolean boolean8 = year6.equals(obj7);
//        boolean boolean10 = year6.equals((java.lang.Object) (-1));
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 1, false);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
//        java.lang.Class<?> wildcardClass21 = year19.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean30 = timeSeries27.equals((java.lang.Object) fixedMillisecond29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond29);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        boolean boolean37 = fixedMillisecond29.equals((java.lang.Object) day35);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        long long5 = regularTimePeriod4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560279599999L + "'", long5 == 1560279599999L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long9 = timeSeries8.getMaximumItemAge();
        timeSeries8.clear();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 1);
        int int17 = timeSeries8.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 0.0f);
        java.lang.String str28 = timeSeries21.getDomainDescription();
        java.util.Collection collection29 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long33 = timeSeries32.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        java.lang.Class<?> wildcardClass41 = year39.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 0.0f);
        java.lang.String str44 = timeSeries37.getDomainDescription();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year46, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year46.previous();
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year46, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean58 = timeSeries55.equals((java.lang.Object) fixedMillisecond57);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.addAndOrUpdate(timeSeries55);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries59.removeChangeListener(seriesChangeListener60);
        java.util.Collection collection62 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries59);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year65.next();
        java.lang.Class<?> wildcardClass67 = year65.getClass();
        int int68 = day63.compareTo((java.lang.Object) wildcardClass67);
        org.jfree.data.time.SerialDate serialDate69 = day63.getSerialDate();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(serialDate69);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year76.next();
        java.lang.Class<?> wildcardClass78 = year76.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year76, (java.lang.Number) 0.0f);
        timeSeries74.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = timeSeries74.getNextTimePeriod();
        boolean boolean84 = day70.equals((java.lang.Object) regularTimePeriod83);
        timeSeries59.delete((org.jfree.data.time.RegularTimePeriod) day70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day70);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(collection62);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem86);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries3.getNotify();
        java.util.Collection collection15 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent4.getSummary();
        java.lang.Object obj6 = seriesChangeEvent4.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent4.getSummary();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(seriesChangeInfo7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(regularTimePeriod16, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        java.lang.Class<?> wildcardClass26 = year24.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean35 = timeSeries32.equals((java.lang.Object) fixedMillisecond34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        boolean boolean37 = timeSeriesDataItem36.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long43 = timeSeries42.getMaximumItemAge();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        java.lang.Class<?> wildcardClass47 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list50 = timeSeries49.getItems();
        boolean boolean51 = year45.equals((java.lang.Object) list50);
        boolean boolean52 = timeSeries42.equals((java.lang.Object) boolean51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long55 = fixedMillisecond54.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.next();
        java.lang.Class<?> wildcardClass63 = year61.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) 0.0f);
        java.lang.String str66 = timeSeries59.getDomainDescription();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year68, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
        boolean boolean72 = fixedMillisecond54.equals((java.lang.Object) regularTimePeriod71);
        timeSeries42.add(regularTimePeriod71, (double) (short) 1, false);
        int int76 = timeSeriesDataItem36.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries3.addOrUpdate(timeSeriesDataItem36);
        java.lang.String str78 = timeSeries3.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries81 = timeSeries3.createCopy((int) '4', 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 32L + "'", long55 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long10 = timeSeries9.getMaximumItemAge();
        timeSeries9.clear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        java.lang.Class<?> wildcardClass15 = year13.getClass();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (byte) 1);
        int int18 = timeSeries9.getItemCount();
        double double19 = timeSeries9.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.setNotify(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0d + "'", comparable5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        java.lang.String str10 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
//        java.lang.Class<?> wildcardClass22 = year20.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        boolean boolean33 = timeSeriesDataItem32.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
//        java.lang.String str35 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        int int38 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day36);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener39);
//        timeSeries3.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        int int5 = day0.getYear();
//        long long6 = day0.getLastMillisecond();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0, seriesChangeInfo7);
//        int int9 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Date date3 = fixedMillisecond1.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries3.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean39 = timeSeries36.equals((java.lang.Object) fixedMillisecond38);
        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.next();
        java.lang.Class<?> wildcardClass50 = year48.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 0.0f);
        java.lang.String str53 = timeSeries46.getDomainDescription();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (double) 1);
        timeSeriesDataItem57.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeriesDataItem57.getPeriod();
        try {
            timeSeries3.add(timeSeriesDataItem57, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 0 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Object obj3 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int7 = timeSeries6.getMaximumItemCount();
        java.lang.Comparable comparable8 = timeSeries6.getKey();
        java.lang.Class<?> wildcardClass9 = comparable8.getClass();
        boolean boolean10 = timeSeries1.equals((java.lang.Object) comparable8);
        timeSeries1.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 1.0d + "'", comparable8.equals(1.0d));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.String str19 = timeSeries3.getRangeDescription();
        long long20 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        java.lang.Number number25 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        java.util.Date date27 = regularTimePeriod26.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
        java.util.TimeZone timeZone29 = null;
        try {
            org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date27, timeZone29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0f + "'", number25.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
        long long6 = fixedMillisecond3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        java.util.Collection collection41 = timeSeries3.getTimePeriods();
        java.lang.Comparable comparable42 = timeSeries3.getKey();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        org.jfree.data.time.SerialDate serialDate45 = day43.getSerialDate();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        java.lang.Class<?> wildcardClass55 = year53.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 0.0f);
        java.lang.String str58 = timeSeries51.getDomainDescription();
        java.lang.Object obj59 = timeSeries51.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries51.addChangeListener(seriesChangeListener60);
        boolean boolean62 = timeSeries51.getNotify();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        java.lang.Class<?> wildcardClass70 = year68.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year68, (java.lang.Number) 0.0f);
        java.lang.String str73 = timeSeries66.getDomainDescription();
        java.lang.Object obj74 = timeSeries66.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener75 = null;
        timeSeries66.addChangeListener(seriesChangeListener75);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries51.addAndOrUpdate(timeSeries66);
        java.util.Collection collection78 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries77);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = timeSeries3.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 1.0d + "'", comparable42.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "hi!" + "'", str73.equals("hi!"));
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertNotNull(collection78);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        timeSeries3.setRangeDescription("");
        timeSeries3.setMaximumItemCount(9);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date5, seriesChangeInfo8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.Class<?> wildcardClass10 = year8.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0.0f);
        java.lang.String str13 = timeSeries6.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year15, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries24);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.removeChangeListener(seriesChangeListener29);
        java.lang.Object obj31 = timeSeries28.clone();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        int int37 = timeSeries35.getMaximumItemCount();
        java.lang.Object obj38 = timeSeries35.clone();
        java.util.Collection collection39 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        java.lang.Class<?> wildcardClass47 = year45.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean56 = timeSeries53.equals((java.lang.Object) fixedMillisecond55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        java.util.Collection collection58 = timeSeries43.getTimePeriods();
        long long59 = timeSeries43.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries35.addAndOrUpdate(timeSeries43);
        java.util.List list61 = timeSeries35.getItems();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(list61);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setMaximumItemAge((long) 3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj7 = null;
        boolean boolean8 = year6.equals(obj7);
        boolean boolean10 = year6.equals((java.lang.Object) (-1));
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        java.lang.Class<?> wildcardClass21 = year19.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean30 = timeSeries27.equals((java.lang.Object) fixedMillisecond29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond29.getMiddleMillisecond(calendar34);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond29.getMiddleMillisecond(calendar36);
        org.jfree.data.time.Year year39 = org.jfree.data.time.Year.parseYear("1");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) (short) 1);
        int int42 = fixedMillisecond29.compareTo((java.lang.Object) year39);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond29, "Mon Jun 10 09:51:43 PDT 2019", "Mon Jun 10 09:51:43 PDT 2019");
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 32L + "'", long35 == 32L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 32L + "'", long37 == 32L);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.Class<?> wildcardClass10 = year8.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0.0f);
        java.lang.String str13 = timeSeries6.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year15, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries24);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.removeChangeListener(seriesChangeListener29);
        java.lang.Object obj31 = timeSeries28.clone();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        int int37 = timeSeries35.getMaximumItemCount();
        java.lang.Object obj38 = timeSeries35.clone();
        java.util.Collection collection39 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        java.lang.Class<?> wildcardClass47 = year45.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean56 = timeSeries53.equals((java.lang.Object) fixedMillisecond55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        java.util.Collection collection58 = timeSeries43.getTimePeriods();
        long long59 = timeSeries43.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries35.addAndOrUpdate(timeSeries43);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeries43.getTimePeriod((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 9223372036854775807L + "'", long59 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries60);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        boolean boolean20 = timeSeriesDataItem14.equals((java.lang.Object) regularTimePeriod19);
        java.lang.Class<?> wildcardClass21 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem14.getPeriod();
        timeSeriesDataItem14.setSelected(false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        int int3 = day0.getMonth();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.lang.String str5 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
//        java.lang.Class<?> wildcardClass13 = year11.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0f);
//        java.lang.String str16 = timeSeries9.getDomainDescription();
//        java.lang.Object obj17 = timeSeries9.clone();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries9.addChangeListener(seriesChangeListener18);
//        int int20 = day0.compareTo((java.lang.Object) timeSeries9);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener21);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        boolean boolean16 = year10.equals((java.lang.Object) date14);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year10);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timeSeries17.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0d + "'", comparable5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
//        java.lang.Class<?> wildcardClass23 = year21.getClass();
//        int int24 = day19.compareTo((java.lang.Object) wildcardClass23);
//        boolean boolean26 = day19.equals((java.lang.Object) (byte) 0);
//        int int27 = day19.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
//        java.lang.Class<?> wildcardClass35 = year33.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 0.0f);
//        int int38 = day19.compareTo((java.lang.Object) year33);
//        timeSeries3.setKey((java.lang.Comparable) int38);
//        try {
//            timeSeries3.update(10, (java.lang.Number) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Class<?> wildcardClass13 = year11.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean22 = timeSeries19.equals((java.lang.Object) fixedMillisecond21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        java.lang.Object obj26 = timeSeriesDataItem23.clone();
        boolean boolean27 = fixedMillisecond1.equals((java.lang.Object) timeSeriesDataItem23);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        java.lang.Class<?> wildcardClass35 = year33.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 0.0f);
        timeSeries31.removeAgedItems(false);
        java.lang.Object obj40 = timeSeries31.clone();
        boolean boolean41 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class46 = timeSeries45.getTimePeriodClass();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj49 = null;
        boolean boolean50 = year48.equals(obj49);
        boolean boolean52 = year48.equals((java.lang.Object) (-1));
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year48, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (double) 1969);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 2);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year62.next();
        java.lang.Class<?> wildcardClass64 = year62.getClass();
        int int65 = day60.compareTo((java.lang.Object) wildcardClass64);
        org.jfree.data.time.SerialDate serialDate66 = day60.getSerialDate();
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(serialDate66);
        int int68 = day67.getYear();
        org.jfree.data.time.SerialDate serialDate69 = day67.getSerialDate();
        boolean boolean70 = timeSeriesDataItem59.equals((java.lang.Object) day67);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int2 = day0.getYear();
        int int4 = day0.compareTo((java.lang.Object) "Mon Jun 10 09:51:43 PDT 2019");
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj10 = null;
        boolean boolean11 = year9.equals(obj10);
        boolean boolean13 = year9.equals((java.lang.Object) (-1));
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year9, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        java.lang.Class<?> wildcardClass24 = year22.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean33 = timeSeries30.equals((java.lang.Object) fixedMillisecond32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        double double37 = timeSeries6.getMinY();
        java.util.Collection collection38 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        timeSeries6.setNotify(false);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(collection38);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.String str19 = timeSeries3.getRangeDescription();
        long long20 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        java.lang.Number number25 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.lang.Class<?> wildcardClass29 = year27.getClass();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) 12);
        java.lang.Object obj34 = timeSeriesDataItem33.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0f + "'", number25.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date5 = fixedMillisecond4.getTime();
        java.util.Calendar calendar6 = null;
        fixedMillisecond4.peg(calendar6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem11.getPeriod();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) ' ');
        int int15 = timeSeriesDataItem11.compareTo((java.lang.Object) year14);
        boolean boolean16 = fixedMillisecond4.equals((java.lang.Object) timeSeriesDataItem11);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, "org.jfree.data.time.TimePeriodFormatException: ", "");
        java.util.Calendar calendar20 = null;
        fixedMillisecond4.peg(calendar20);
        int int22 = year1.compareTo((java.lang.Object) fixedMillisecond4);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
//        java.lang.String str5 = timePeriodFormatException3.toString();
//        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("10-June-2019");
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException7);
//        java.lang.String str9 = timePeriodFormatException3.toString();
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException3.getSuppressed();
//        int int11 = day0.compareTo((java.lang.Object) timePeriodFormatException3);
//        int int12 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        timeSeries3.removeAgedItems(0L, false);
        long long21 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries3.getNextTimePeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.Class<?> wildcardClass3 = year1.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list6 = timeSeries5.getItems();
        boolean boolean7 = year1.equals((java.lang.Object) list6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560236399999L);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj20 = null;
        boolean boolean21 = year19.equals(obj20);
        boolean boolean23 = year19.equals((java.lang.Object) (-1));
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1, false);
        java.lang.Object obj27 = null;
        boolean boolean28 = year19.equals(obj27);
        long long29 = year19.getLastMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (byte) 1, year19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, 0.0d);
        boolean boolean33 = year1.equals((java.lang.Object) timeSeriesDataItem32);
        java.lang.Number number34 = timeSeriesDataItem32.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62104204800001L) + "'", long29 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0.0d + "'", number34.equals(0.0d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.Class<?> wildcardClass3 = year1.getClass();
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date4, timeZone5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        long long19 = timeSeries3.getMaximumItemAge();
        double double20 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        boolean boolean6 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
//        java.lang.Class<?> wildcardClass4 = year2.getClass();
//        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
//        boolean boolean7 = day0.equals((java.lang.Object) (byte) 0);
//        int int8 = day0.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
//        java.lang.Class<?> wildcardClass16 = year14.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 0.0f);
//        int int19 = day0.compareTo((java.lang.Object) year14);
//        long long20 = year14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.next();
//        java.lang.Class<?> wildcardClass28 = year26.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 0.0f);
//        java.lang.String str31 = timeSeries24.getDomainDescription();
//        java.lang.Object obj32 = timeSeries24.clone();
//        timeSeries24.setNotify(true);
//        timeSeries24.setRangeDescription("");
//        int int37 = year14.compareTo((java.lang.Object) timeSeries24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62167363200000L) + "'", long20 == (-62167363200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 0.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.lang.Class<?> wildcardClass9 = year7.getClass();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) (byte) 1);
        int int12 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        java.lang.Class<?> wildcardClass20 = year18.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 0.0f);
        java.lang.String str23 = timeSeries16.getDomainDescription();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long28 = timeSeries27.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.next();
        java.lang.Class<?> wildcardClass36 = year34.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) 0.0f);
        java.lang.String str39 = timeSeries32.getDomainDescription();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year41, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year41.previous();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year41, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean53 = timeSeries50.equals((java.lang.Object) fixedMillisecond52);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries27.addAndOrUpdate(timeSeries50);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries54.removeChangeListener(seriesChangeListener55);
        java.util.Collection collection57 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long60 = fixedMillisecond59.getMiddleMillisecond();
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond59.getMiddleMillisecond(calendar61);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year71.next();
        java.lang.Class<?> wildcardClass73 = year71.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 0.0f);
        timeSeries69.removeAgedItems(false);
        timeSeries69.setKey((java.lang.Comparable) (-62167363200000L));
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries3.addAndOrUpdate(timeSeries69);
        int int81 = timeSeries69.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 32L + "'", long60 == 32L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 32L + "'", long62 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2147483647 + "'", int81 == 2147483647);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        double double11 = timeSeries3.getMinY();
        timeSeries3.removeAgedItems(0L, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries3.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean17 = timeSeries14.equals((java.lang.Object) fixedMillisecond16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.Collection collection19 = timeSeries4.getTimePeriods();
        java.lang.String str20 = timeSeries4.getRangeDescription();
        long long21 = timeSeries4.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date24 = fixedMillisecond23.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
        java.lang.Number number26 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
        java.util.Date date28 = regularTimePeriod27.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date28, timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0f + "'", number26.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.lang.Class<?> wildcardClass9 = year7.getClass();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) (byte) 1);
        java.lang.String str12 = year7.toString();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year7.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) (-9999));
//        long long8 = day5.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
//        java.lang.Class<?> wildcardClass22 = year20.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
//        java.lang.String str25 = timeSeries18.getDomainDescription();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (double) 1);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
//        java.lang.Class<?> wildcardClass37 = year35.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean46 = timeSeries43.equals((java.lang.Object) fixedMillisecond45);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        boolean boolean48 = timeSeriesDataItem47.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate(timeSeriesDataItem47);
//        timeSeries13.add(timeSeriesDataItem47);
//        java.lang.Object obj51 = timeSeries13.clone();
//        java.lang.String str52 = timeSeries13.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries3.addAndOrUpdate(timeSeries13);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries53);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = year7.equals(obj8);
        boolean boolean11 = year7.equals((java.lang.Object) (-1));
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1, false);
        java.lang.Object obj15 = null;
        boolean boolean16 = year7.equals(obj15);
        long long17 = year7.getLastMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long19 = year7.getSerialIndex();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62104204800001L) + "'", long17 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries3.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year34, (double) 3, true);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        boolean boolean16 = year10.equals((java.lang.Object) date14);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year10);
        java.util.Date date18 = month6.getStart();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        long long20 = month19.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0d + "'", comparable5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getFirstMillisecond();
        long long5 = month0.getLastMillisecond();
        java.lang.Object obj6 = null;
        boolean boolean7 = month0.equals(obj6);
        long long8 = month0.getFirstMillisecond();
        java.lang.Object obj9 = null;
        boolean boolean10 = month0.equals(obj9);
        java.lang.String str11 = month0.toString();
        int int12 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.lang.String str18 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        double double5 = timeSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
//        java.lang.Class<?> wildcardClass4 = year2.getClass();
//        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
//        boolean boolean7 = day0.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        int int9 = day0.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1.0d);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
//        java.lang.Class<?> wildcardClass16 = year14.getClass();
//        int int17 = day12.compareTo((java.lang.Object) wildcardClass16);
//        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
//        java.lang.String str19 = day12.toString();
//        java.util.Date date20 = day12.getStart();
//        boolean boolean21 = day0.equals((java.lang.Object) day12);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean21 = timeSeries18.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 0);
        java.util.Date date25 = fixedMillisecond20.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        int int34 = year27.compareTo((java.lang.Object) fixedMillisecond31);
        java.util.Calendar calendar35 = null;
        fixedMillisecond31.peg(calendar35);
        java.util.Date date37 = fixedMillisecond31.getTime();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        boolean boolean39 = fixedMillisecond20.equals((java.lang.Object) day38);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 32L + "'", long33 == 32L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        int int5 = month4.getYearValue();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        java.util.Date date22 = year18.getStart();
        long long23 = year18.getSerialIndex();
        java.util.Calendar calendar24 = null;
        try {
            year18.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        long long4 = year1.getSerialIndex();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.lang.Class<?> wildcardClass9 = year7.getClass();
        int int10 = day5.compareTo((java.lang.Object) wildcardClass9);
        org.jfree.data.time.SerialDate serialDate11 = day5.getSerialDate();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        int int13 = year1.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "Mon Jun 10 09:51:43 PDT 2019", "Mon Jun 10 09:51:43 PDT 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year1.previous();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod17);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        seriesChangeEvent18.setSummary(seriesChangeInfo19);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = seriesChangeEvent18.getSummary();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(seriesChangeInfo21);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
//        java.lang.Class<?> wildcardClass4 = year2.getClass();
//        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
//        boolean boolean7 = day0.equals((java.lang.Object) (byte) 0);
//        long long8 = day0.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
        java.lang.Class<?> wildcardClass42 = year40.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 0.0f);
        java.lang.String str45 = timeSeries38.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year51.next();
        java.lang.Class<?> wildcardClass53 = year51.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean62 = timeSeries59.equals((java.lang.Object) fixedMillisecond61);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond61.previous();
        int int65 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        java.util.Calendar calendar66 = null;
        long long67 = fixedMillisecond61.getMiddleMillisecond(calendar66);
        java.util.Date date68 = fixedMillisecond61.getStart();
        java.lang.Class<?> wildcardClass69 = fixedMillisecond61.getClass();
        java.util.Calendar calendar70 = null;
        long long71 = fixedMillisecond61.getLastMillisecond(calendar70);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 32L + "'", long67 == 32L);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 32L + "'", long71 == 32L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        timeSeries3.fireSeriesChanged();
        java.lang.String str36 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries37 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries38 = timeSeries3.addAndOrUpdate(timeSeries37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        java.lang.String str25 = timeSeries18.getDomainDescription();
        java.lang.Object obj26 = timeSeries18.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries18.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries18);
        java.lang.Number number31 = timeSeries29.getValue(0);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj39 = null;
        boolean boolean40 = year38.equals(obj39);
        boolean boolean42 = year38.equals((java.lang.Object) (-1));
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) year38, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year51.next();
        java.lang.Class<?> wildcardClass53 = year51.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year51, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean62 = timeSeries59.equals((java.lang.Object) fixedMillisecond61);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond61.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        java.util.Calendar calendar66 = null;
        long long67 = fixedMillisecond61.getMiddleMillisecond(calendar66);
        java.util.Calendar calendar68 = null;
        long long69 = fixedMillisecond61.getMiddleMillisecond(calendar68);
        org.jfree.data.time.Year year71 = org.jfree.data.time.Year.parseYear("1");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year71, (double) (short) 1);
        int int74 = fixedMillisecond61.compareTo((java.lang.Object) year71);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year80.next();
        java.lang.Class<?> wildcardClass82 = year80.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries78.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year80, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year80.previous();
        boolean boolean86 = fixedMillisecond61.equals((java.lang.Object) year80);
        timeSeries29.update((org.jfree.data.time.RegularTimePeriod) year80, (java.lang.Number) (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.0f + "'", number31.equals(0.0f));
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 32L + "'", long67 == 32L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 32L + "'", long69 == 32L);
        org.junit.Assert.assertNotNull(year71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNull(timeSeriesDataItem84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.setRangeDescription("");
        java.util.Collection collection7 = timeSeries3.getTimePeriods();
        timeSeries3.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        java.lang.Class<?> wildcardClass17 = year15.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean26 = timeSeries23.equals((java.lang.Object) fixedMillisecond25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        long long28 = fixedMillisecond25.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond25.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 10);
        java.util.Date date32 = fixedMillisecond25.getTime();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
        java.lang.Class<?> wildcardClass44 = year42.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date47 = fixedMillisecond46.getTime();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date47, timeZone48);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date47);
        long long51 = month50.getSerialIndex();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 6);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year59.next();
        java.lang.Class<?> wildcardClass61 = year59.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year59, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean70 = timeSeries67.equals((java.lang.Object) fixedMillisecond69);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
        java.util.Collection collection72 = timeSeries57.getTimePeriods();
        java.lang.String str73 = timeSeries57.getRangeDescription();
        long long74 = timeSeries57.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date77 = fixedMillisecond76.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond(date77);
        java.lang.Number number79 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond78);
        java.util.Collection collection80 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries57);
        java.util.List list81 = timeSeries3.getItems();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 23640L + "'", long51 == 23640L);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
        org.junit.Assert.assertNotNull(collection72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "hi!" + "'", str73.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 9223372036854775807L + "'", long74 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0.0f + "'", number79.equals(0.0f));
        org.junit.Assert.assertNotNull(collection80);
        org.junit.Assert.assertNotNull(list81);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getSerialIndex();
        java.lang.String str17 = month15.toString();
        org.jfree.data.time.Year year18 = month15.getYear();
        long long19 = month15.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month15.next();
        java.lang.Object obj21 = null;
        boolean boolean22 = month15.equals(obj21);
        long long23 = month15.getFirstMillisecond();
        int int24 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month15.next();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int7 = timeSeries6.getMaximumItemCount();
        java.lang.Comparable comparable8 = timeSeries6.getKey();
        java.lang.Class<?> wildcardClass9 = comparable8.getClass();
        boolean boolean10 = timeSeries1.equals((java.lang.Object) comparable8);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        int int21 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.Object obj22 = timeSeries1.clone();
        java.lang.Comparable comparable23 = timeSeries1.getKey();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 1.0d + "'", comparable8.equals(1.0d));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        boolean boolean8 = day6.equals((java.lang.Object) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) -1);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, (double) 1560236399999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0d + "'", comparable5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond15.next();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond15.getLastMillisecond(calendar21);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 32L + "'", long19 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 32L + "'", long22 == 32L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(regularTimePeriod16, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        java.lang.Class<?> wildcardClass26 = year24.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean35 = timeSeries32.equals((java.lang.Object) fixedMillisecond34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        boolean boolean37 = timeSeriesDataItem36.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long43 = timeSeries42.getMaximumItemAge();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        java.lang.Class<?> wildcardClass47 = year45.getClass();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list50 = timeSeries49.getItems();
        boolean boolean51 = year45.equals((java.lang.Object) list50);
        boolean boolean52 = timeSeries42.equals((java.lang.Object) boolean51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long55 = fixedMillisecond54.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.next();
        java.lang.Class<?> wildcardClass63 = year61.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) 0.0f);
        java.lang.String str66 = timeSeries59.getDomainDescription();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year68, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = year68.previous();
        boolean boolean72 = fixedMillisecond54.equals((java.lang.Object) regularTimePeriod71);
        timeSeries42.add(regularTimePeriod71, (double) (short) 1, false);
        int int76 = timeSeriesDataItem36.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries3.addOrUpdate(timeSeriesDataItem36);
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem77, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 32L + "'", long55 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        long long20 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        boolean boolean22 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj30 = null;
        boolean boolean31 = year29.equals(obj30);
        boolean boolean33 = year29.equals((java.lang.Object) (-1));
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year29, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.next();
        java.lang.Class<?> wildcardClass44 = year42.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean53 = timeSeries50.equals((java.lang.Object) fixedMillisecond52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond52.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries26.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond52.getMiddleMillisecond(calendar57);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond52.getMiddleMillisecond(calendar59);
        org.jfree.data.time.Year year62 = org.jfree.data.time.Year.parseYear("1");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year62, (double) (short) 1);
        int int65 = fixedMillisecond52.compareTo((java.lang.Object) year62);
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year71.next();
        java.lang.Class<?> wildcardClass73 = year71.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year71.previous();
        boolean boolean77 = fixedMillisecond52.equals((java.lang.Object) year71);
        java.lang.Number number78 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year71, number78);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 32L + "'", long58 == 32L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 32L + "'", long60 == 32L);
        org.junit.Assert.assertNotNull(year62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem79);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long7 = fixedMillisecond6.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getMiddleMillisecond(calendar8);
        long long10 = fixedMillisecond6.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        java.lang.Object obj30 = timeSeriesDataItem28.clone();
        java.lang.Object obj31 = timeSeriesDataItem28.clone();
        boolean boolean32 = fixedMillisecond6.equals((java.lang.Object) timeSeriesDataItem28);
        int int33 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem28);
        java.lang.Object obj34 = timeSeriesDataItem28.clone();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.Class<?> wildcardClass10 = year8.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0.0f);
        java.lang.String str13 = timeSeries6.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
        boolean boolean19 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int24 = timeSeries23.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        java.lang.Class<?> wildcardClass32 = year30.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean41 = timeSeries38.equals((java.lang.Object) fixedMillisecond40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0);
        timeSeries23.setRangeDescription("1");
        java.lang.String str47 = timeSeries23.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = timeSeriesDataItem51.getPeriod();
        java.util.Calendar calendar53 = null;
        long long54 = regularTimePeriod52.getMiddleMillisecond(calendar53);
        java.lang.Number number55 = timeSeries23.getValue(regularTimePeriod52);
        int int56 = fixedMillisecond1.compareTo((java.lang.Object) regularTimePeriod52);
        java.util.Date date57 = regularTimePeriod52.getEnd();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 32L + "'", long54 == 32L);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 0 + "'", number55.equals(0));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(date57);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getSerialIndex();
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj7 = null;
        boolean boolean8 = year6.equals(obj7);
        boolean boolean10 = year6.equals((java.lang.Object) (-1));
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        java.lang.Class<?> wildcardClass21 = year19.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean30 = timeSeries27.equals((java.lang.Object) fixedMillisecond29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond29.getMiddleMillisecond(calendar34);
        long long36 = fixedMillisecond29.getLastMillisecond();
        java.util.Date date37 = fixedMillisecond29.getTime();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 32L + "'", long35 == 32L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 32L + "'", long36 == 32L);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list2 = timeSeries1.getItems();
        java.lang.Object obj3 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        java.lang.Class<?> wildcardClass11 = year9.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean20 = timeSeries17.equals((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        java.lang.Class<?> wildcardClass23 = timeSeries7.getClass();
        timeSeries7.setNotify(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries7.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj31 = null;
        boolean boolean32 = year30.equals(obj31);
        boolean boolean34 = year30.equals((java.lang.Object) (-1));
        java.util.Date date35 = year30.getEnd();
        java.util.Date date36 = year30.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem38.getPeriod();
        try {
            org.jfree.data.time.TimeSeries timeSeries40 = timeSeries1.createCopy(regularTimePeriod28, regularTimePeriod39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        int int5 = day0.getDayOfMonth();
//        long long6 = day0.getLastMillisecond();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
//        java.lang.Class<?> wildcardClass4 = year2.getClass();
//        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.lang.String str7 = day0.toString();
//        java.util.Date date8 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem34, seriesChangeInfo35);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
        seriesChangeEvent36.setSummary(seriesChangeInfo37);
        java.lang.Object obj39 = seriesChangeEvent36.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
        seriesChangeEvent36.setSummary(seriesChangeInfo40);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        int int10 = year5.getYear();
        java.lang.String str11 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year5.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int30);
        java.lang.Object obj32 = seriesChangeEvent31.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + obj32 + "' != '" + 0 + "'", obj32.equals(0));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        java.lang.Class<?> wildcardClass6 = comparable5.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        java.lang.Class<?> wildcardClass14 = year12.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 0.0f);
        java.lang.String str17 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean34 = timeSeries31.equals((java.lang.Object) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.previous();
        int int37 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond33.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond33.getStart();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date40, timeZone41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date40);
        java.lang.String str44 = fixedMillisecond43.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0d + "'", comparable5.equals(1.0d));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 32L + "'", long39 == 32L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str44.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        long long19 = timeSeries3.getMaximumItemAge();
        try {
            java.lang.Number number21 = timeSeries3.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj7 = null;
        boolean boolean8 = year6.equals(obj7);
        boolean boolean10 = year6.equals((java.lang.Object) (-1));
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 1, false);
        java.lang.String str14 = year6.toString();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        int int8 = year1.compareTo((java.lang.Object) fixedMillisecond5);
        java.util.Calendar calendar9 = null;
        fixedMillisecond5.peg(calendar9);
        java.util.Date date11 = fixedMillisecond5.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        int int13 = day12.getDayOfMonth();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        int int4 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
//        java.lang.Class<?> wildcardClass12 = year10.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean21 = timeSeries18.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 0);
//        timeSeries3.setRangeDescription("1");
//        java.lang.String str27 = timeSeries3.getDescription();
//        int int28 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
//        java.lang.Class<?> wildcardClass33 = year31.getClass();
//        int int34 = day29.compareTo((java.lang.Object) wildcardClass33);
//        int int35 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long36 = day29.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.lang.Class<?> wildcardClass9 = year7.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean18 = timeSeries15.equals((java.lang.Object) fixedMillisecond17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        java.lang.Object obj21 = null;
        int int22 = timeSeriesDataItem19.compareTo(obj21);
        boolean boolean23 = year1.equals((java.lang.Object) timeSeriesDataItem19);
        java.lang.String str24 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year1.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        timeSeries3.setDescription("1");
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries34.addChangeListener(seriesChangeListener35);
        timeSeries34.fireSeriesChanged();
        java.util.Collection collection38 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(collection38);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        timeSeriesDataItem37.setSelected(false);
        java.lang.Object obj43 = timeSeriesDataItem37.clone();
        timeSeriesDataItem37.setValue((java.lang.Number) 0.0f);
        timeSeriesDataItem37.setSelected(true);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(obj43);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) (-9999));
//        long long3 = day0.getFirstMillisecond();
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        boolean boolean5 = year1.equals((java.lang.Object) (-1));
        java.util.Date date6 = year1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.previous();
        java.lang.String str8 = year1.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) 'a', 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        boolean boolean20 = timeSeriesDataItem14.equals((java.lang.Object) regularTimePeriod19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        java.lang.Class<?> wildcardClass33 = year31.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 0.0f);
        java.lang.String str36 = timeSeries29.getDomainDescription();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.next();
        java.lang.Class<?> wildcardClass48 = year46.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year46, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean57 = timeSeries54.equals((java.lang.Object) fixedMillisecond56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
        boolean boolean59 = timeSeriesDataItem58.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries29.addOrUpdate(timeSeriesDataItem58);
        timeSeries24.add(timeSeriesDataItem58);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year63.next();
        java.lang.Class<?> wildcardClass65 = year63.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date68 = fixedMillisecond67.getTime();
        java.util.TimeZone timeZone69 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date68, timeZone69);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date68);
        long long72 = month71.getSerialIndex();
        timeSeries24.update((org.jfree.data.time.RegularTimePeriod) month71, (java.lang.Number) 6);
        boolean boolean75 = timeSeriesDataItem14.equals((java.lang.Object) month71);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 23640L + "'", long72 == 23640L);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond26.getMiddleMillisecond(calendar31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        java.lang.Class<?> wildcardClass40 = year38.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean49 = timeSeries46.equals((java.lang.Object) fixedMillisecond48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Collection collection51 = timeSeries36.getTimePeriods();
        timeSeries36.removeAgedItems(false);
        java.lang.String str54 = timeSeries36.getDescription();
        timeSeries36.fireSeriesChanged();
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        long long57 = month56.getSerialIndex();
        java.lang.String str58 = month56.toString();
        org.jfree.data.time.Year year59 = month56.getYear();
        long long60 = month56.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month56.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month56.previous();
        java.lang.Number number63 = timeSeries36.getValue(regularTimePeriod62);
        boolean boolean64 = fixedMillisecond26.equals((java.lang.Object) regularTimePeriod62);
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond26.getFirstMillisecond(calendar65);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 32L + "'", long32 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(collection51);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 24234L + "'", long57 == 24234L);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
        org.junit.Assert.assertNotNull(year59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1561964399999L + "'", long60 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 0.0f + "'", number63.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 32L + "'", long66 == 32L);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        java.lang.String str10 = timeSeries3.getDomainDescription();
//        double double11 = timeSeries3.getMinY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str13 = fixedMillisecond12.toString();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Mon Jun 10 09:52:50 PDT 2019" + "'", str13.equals("Mon Jun 10 09:52:50 PDT 2019"));
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.addOrUpdate(regularTimePeriod3, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.lang.Class<?> wildcardClass4 = year2.getClass();
        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) day0);
        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
//        java.lang.String str5 = timePeriodFormatException3.toString();
//        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("10-June-2019");
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException7);
//        java.lang.String str9 = timePeriodFormatException3.toString();
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException3.getSuppressed();
//        int int11 = day0.compareTo((java.lang.Object) timePeriodFormatException3);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = day0.equals(obj12);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj7 = null;
        boolean boolean8 = year6.equals(obj7);
        boolean boolean10 = year6.equals((java.lang.Object) (-1));
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        java.lang.Class<?> wildcardClass21 = year19.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean30 = timeSeries27.equals((java.lang.Object) fixedMillisecond29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        double double34 = timeSeries3.getMinY();
        boolean boolean35 = timeSeries3.getNotify();
        int int36 = timeSeries3.getMaximumItemCount();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        timeSeries3.setRangeDescription("");
        java.lang.String str16 = timeSeries3.getRangeDescription();
        java.lang.String str17 = timeSeries3.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries3.getTimePeriod(0);
        int int20 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean21 = timeSeries18.equals((java.lang.Object) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Collection collection23 = timeSeries8.getTimePeriods();
        java.lang.String str24 = timeSeries8.getRangeDescription();
        long long25 = timeSeries8.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        java.lang.Number number30 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        java.lang.Class<?> wildcardClass34 = year32.getClass();
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10L);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long41 = timeSeries40.getMaximumItemAge();
        timeSeries40.clear();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.next();
        java.lang.Class<?> wildcardClass46 = year44.getClass();
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) (byte) 1);
        int int49 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year44);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener51);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0f + "'", number30.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        java.util.Collection collection41 = timeSeries3.getTimePeriods();
        java.lang.Comparable comparable42 = timeSeries3.getKey();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        org.jfree.data.time.SerialDate serialDate45 = day43.getSerialDate();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        java.lang.Class<?> wildcardClass55 = year53.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 0.0f);
        java.lang.String str58 = timeSeries51.getDomainDescription();
        java.lang.Object obj59 = timeSeries51.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries51.addChangeListener(seriesChangeListener60);
        boolean boolean62 = timeSeries51.getNotify();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        java.lang.Class<?> wildcardClass70 = year68.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year68, (java.lang.Number) 0.0f);
        java.lang.String str73 = timeSeries66.getDomainDescription();
        java.lang.Object obj74 = timeSeries66.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener75 = null;
        timeSeries66.addChangeListener(seriesChangeListener75);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries51.addAndOrUpdate(timeSeries66);
        java.util.Collection collection78 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries77);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year79);
        java.util.Date date81 = year79.getEnd();
        timeSeries77.add((org.jfree.data.time.RegularTimePeriod) year79, (java.lang.Number) (-1.0f));
        java.util.Collection collection84 = timeSeries77.getTimePeriods();
        try {
            timeSeries77.setMaximumItemAge((long) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 1.0d + "'", comparable42.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "hi!" + "'", str73.equals("hi!"));
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertNotNull(collection78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(collection84);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.String str5 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str7 = seriesException1.toString();
        java.lang.String str8 = seriesException1.toString();
        java.lang.String str9 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str7.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str8.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str9.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
//        java.lang.Class<?> wildcardClass4 = year2.getClass();
//        int int5 = day0.compareTo((java.lang.Object) wildcardClass4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        int int8 = day7.getYear();
//        int int9 = day7.getDayOfMonth();
//        java.util.Date date10 = day7.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        long long2 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.Class<?> wildcardClass10 = year8.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0.0f);
        java.lang.String str13 = timeSeries6.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year15, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.addAndOrUpdate(timeSeries24);
        int int29 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.setRangeDescription("");
        java.util.Collection collection7 = timeSeries3.getTimePeriods();
        timeSeries3.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        java.lang.Class<?> wildcardClass17 = year15.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean26 = timeSeries23.equals((java.lang.Object) fixedMillisecond25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        long long28 = fixedMillisecond25.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond25.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 10);
        java.lang.Object obj32 = timeSeries3.clone();
        try {
            java.lang.Number number34 = timeSeries3.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        java.lang.Class<?> wildcardClass11 = year9.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0f);
        java.lang.String str14 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        java.lang.Class<?> wildcardClass26 = year24.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean35 = timeSeries32.equals((java.lang.Object) fixedMillisecond34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        boolean boolean37 = timeSeriesDataItem36.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate(timeSeriesDataItem36);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo39 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem38, seriesChangeInfo39);
        int int42 = timeSeriesDataItem38.compareTo((java.lang.Object) (short) 1);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int42);
        int int44 = month0.compareTo((java.lang.Object) seriesChangeEvent43);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        java.util.Collection collection41 = timeSeries3.getTimePeriods();
        java.lang.Comparable comparable42 = timeSeries3.getKey();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        org.jfree.data.time.SerialDate serialDate45 = day43.getSerialDate();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        java.lang.Class<?> wildcardClass55 = year53.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 0.0f);
        java.lang.String str58 = timeSeries51.getDomainDescription();
        java.lang.Object obj59 = timeSeries51.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries51.addChangeListener(seriesChangeListener60);
        boolean boolean62 = timeSeries51.getNotify();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        java.lang.Class<?> wildcardClass70 = year68.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year68, (java.lang.Number) 0.0f);
        java.lang.String str73 = timeSeries66.getDomainDescription();
        java.lang.Object obj74 = timeSeries66.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener75 = null;
        timeSeries66.addChangeListener(seriesChangeListener75);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries51.addAndOrUpdate(timeSeries66);
        java.util.Collection collection78 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries77);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year79);
        java.util.Date date81 = year79.getEnd();
        timeSeries77.add((org.jfree.data.time.RegularTimePeriod) year79, (java.lang.Number) (-1.0f));
        timeSeries77.removeAgedItems(24234L, true);
        double double87 = timeSeries77.getMinY();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 1.0d + "'", comparable42.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "hi!" + "'", str73.equals("hi!"));
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertNotNull(collection78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + (-1.0d) + "'", double87 == (-1.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.lang.Class<?> wildcardClass9 = year7.getClass();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) (byte) 1);
        int int12 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        java.lang.Class<?> wildcardClass20 = year18.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 0.0f);
        java.lang.String str23 = timeSeries16.getDomainDescription();
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        try {
            java.lang.Number number26 = timeSeries3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(collection24);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) (-9999));
//        long long15 = day12.getFirstMillisecond();
//        long long16 = day12.getLastMillisecond();
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day12);
//        int int18 = day12.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, "Mon Jun 10 09:51:43 PDT 2019", "Mon Jun 10 09:52:40 PDT 2019");
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.Year year3 = month0.getYear();
        int int4 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(6, year37);
        int int40 = timeSeriesDataItem34.compareTo((java.lang.Object) month39);
        java.lang.Number number41 = timeSeriesDataItem34.getValue();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem34, "", "");
        timeSeriesDataItem34.setValue((java.lang.Number) 23640L);
        java.lang.Object obj47 = timeSeriesDataItem34.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1.0d + "'", number41.equals(1.0d));
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.Class<?> wildcardClass19 = timeSeries3.getClass();
        timeSeries3.setNotify(true);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj24 = null;
        boolean boolean25 = year23.equals(obj24);
        long long26 = year23.getSerialIndex();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        java.lang.Class<?> wildcardClass31 = year29.getClass();
        int int32 = day27.compareTo((java.lang.Object) wildcardClass31);
        org.jfree.data.time.SerialDate serialDate33 = day27.getSerialDate();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate33);
        int int35 = year23.compareTo((java.lang.Object) day34);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem38.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = year7.equals(obj8);
        boolean boolean11 = year7.equals((java.lang.Object) (-1));
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year7, (double) (byte) 1, false);
        java.lang.Object obj15 = null;
        boolean boolean16 = year7.equals(obj15);
        long long17 = year7.getLastMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, year7);
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int24 = timeSeries23.getMaximumItemCount();
        java.lang.Comparable comparable25 = timeSeries23.getKey();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long30 = timeSeries29.getMaximumItemAge();
        timeSeries29.clear();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        java.lang.Class<?> wildcardClass35 = year33.getClass();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) (byte) 1);
        int int38 = timeSeries29.getItemCount();
        double double39 = timeSeries29.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries23.addAndOrUpdate(timeSeries29);
        boolean boolean41 = month18.equals((java.lang.Object) timeSeries29);
        long long42 = month18.getSerialIndex();
        java.lang.String str43 = month18.toString();
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62104204800001L) + "'", long17 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62167363200000L) + "'", long19 == (-62167363200000L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 1.0d + "'", comparable25.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "January 0" + "'", str43.equals("January 0"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        int int10 = timeSeries3.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list13 = timeSeries12.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj21 = null;
        boolean boolean22 = year20.equals(obj21);
        boolean boolean24 = year20.equals((java.lang.Object) (-1));
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year20, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        java.lang.Class<?> wildcardClass35 = year33.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean44 = timeSeries41.equals((java.lang.Object) fixedMillisecond43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond43.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        double double48 = timeSeries17.getMinY();
        java.util.Collection collection49 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.next();
        java.lang.Class<?> wildcardClass57 = year55.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean66 = timeSeries63.equals((java.lang.Object) fixedMillisecond65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
        long long68 = fixedMillisecond65.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond65.next();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year75.next();
        java.lang.Class<?> wildcardClass77 = year75.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year75, (java.lang.Number) 0.0f);
        java.lang.String str80 = timeSeries73.getDomainDescription();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year82, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year82.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = year82.previous();
        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries17.createCopy(regularTimePeriod69, regularTimePeriod86);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries3.addOrUpdate(regularTimePeriod86, (java.lang.Number) 5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 32L + "'", long68 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "hi!" + "'", str80.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(timeSeries87);
        org.junit.Assert.assertNull(timeSeriesDataItem89);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
//        java.lang.Class<?> wildcardClass11 = year9.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 0.0f);
//        java.lang.String str14 = timeSeries7.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
//        java.lang.Class<?> wildcardClass22 = year20.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.previous();
//        int int34 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
//        timeSeries7.addChangeListener(seriesChangeListener35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean43 = timeSeries40.equals((java.lang.Object) fixedMillisecond42);
//        java.util.Collection collection44 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        java.util.Collection collection45 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean48 = day46.equals((java.lang.Object) (-9999));
//        long long49 = day46.getFirstMillisecond();
//        long long50 = day46.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.next();
//        java.lang.Class<?> wildcardClass58 = year56.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean67 = timeSeries64.equals((java.lang.Object) fixedMillisecond66);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond66.next();
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond66);
//        long long72 = fixedMillisecond66.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560150000000L + "'", long49 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem68);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 32L + "'", long72 == 32L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.lang.Class<?> wildcardClass9 = year7.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 0.0f);
        java.lang.String str12 = timeSeries5.getDomainDescription();
        java.lang.Object obj13 = timeSeries5.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries5.addChangeListener(seriesChangeListener14);
        boolean boolean16 = timeSeries5.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries5.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
        java.lang.Class<?> wildcardClass25 = year23.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj30 = null;
        boolean boolean31 = year29.equals(obj30);
        boolean boolean33 = year29.equals((java.lang.Object) (-1));
        java.util.Date date34 = year29.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) year35);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries3.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        java.lang.Class<?> wildcardClass23 = year21.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 0.0f);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj28 = null;
        boolean boolean29 = year27.equals(obj28);
        boolean boolean31 = year27.equals((java.lang.Object) (-1));
        java.util.Date date32 = year27.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) year33);
        java.lang.String str35 = year33.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1" + "'", str35.equals("1"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        timeSeries3.removeAgedItems(0L, false);
        java.lang.String str21 = timeSeries3.getRangeDescription();
        java.lang.Number number23 = timeSeries3.getValue((int) (short) 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0f + "'", number23.equals(0.0f));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.Class<?> wildcardClass19 = timeSeries3.getClass();
        timeSeries3.setNotify(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries3.getNextTimePeriod();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod22);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = null;
        seriesChangeEvent23.setSummary(seriesChangeInfo24);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.Year year3 = month0.getYear();
        int int4 = month0.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            month0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj10 = null;
        boolean boolean11 = year9.equals(obj10);
        boolean boolean13 = year9.equals((java.lang.Object) (-1));
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year9, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        java.lang.Class<?> wildcardClass24 = year22.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean33 = timeSeries30.equals((java.lang.Object) fixedMillisecond32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        double double37 = timeSeries6.getMinY();
        java.util.Collection collection38 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries6);
        java.lang.String str39 = timeSeries6.getRangeDescription();
        int int40 = timeSeries6.getItemCount();
        timeSeries6.setMaximumItemCount((int) 'a');
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.Class<?> wildcardClass19 = timeSeries3.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.Year year3 = month0.getYear();
        long long4 = month0.getSerialIndex();
        int int5 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        java.lang.String str25 = timeSeries18.getDomainDescription();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
        java.lang.Class<?> wildcardClass39 = year37.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) 0.0f);
        java.lang.String str42 = timeSeries35.getDomainDescription();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year44, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year44.previous();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries3.createCopy(regularTimePeriod31, regularTimePeriod47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date51 = fixedMillisecond50.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date51);
        timeSeries3.setKey((java.lang.Comparable) month53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month53.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year5.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        boolean boolean16 = year10.equals((java.lang.Object) date14);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries17.setMaximumItemCount((int) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        java.lang.String str30 = timeSeries23.getDomainDescription();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 1);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        long long40 = year38.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
        java.lang.Number number42 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year38);
        timeSeries17.removeAgedItems(false);
        try {
            org.jfree.data.time.TimeSeries timeSeries47 = timeSeries17.createCopy((int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0d + "'", comparable5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(number42);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        int int5 = year1.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.Class<?> wildcardClass12 = year10.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        java.lang.String str15 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year17, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        java.lang.Class<?> wildcardClass27 = year25.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean36 = timeSeries33.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        boolean boolean38 = timeSeriesDataItem37.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries8.addOrUpdate(timeSeriesDataItem37);
        timeSeries3.add(timeSeriesDataItem37);
        java.util.Collection collection41 = timeSeries3.getTimePeriods();
        java.lang.Comparable comparable42 = timeSeries3.getKey();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.next();
        org.jfree.data.time.SerialDate serialDate45 = day43.getSerialDate();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        java.lang.Class<?> wildcardClass55 = year53.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 0.0f);
        java.lang.String str58 = timeSeries51.getDomainDescription();
        java.lang.Object obj59 = timeSeries51.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries51.addChangeListener(seriesChangeListener60);
        boolean boolean62 = timeSeries51.getNotify();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.next();
        java.lang.Class<?> wildcardClass70 = year68.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year68, (java.lang.Number) 0.0f);
        java.lang.String str73 = timeSeries66.getDomainDescription();
        java.lang.Object obj74 = timeSeries66.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener75 = null;
        timeSeries66.addChangeListener(seriesChangeListener75);
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries51.addAndOrUpdate(timeSeries66);
        java.util.Collection collection78 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries77);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj81 = null;
        boolean boolean82 = year80.equals(obj81);
        boolean boolean84 = year80.equals((java.lang.Object) (-1));
        java.util.Date date85 = year80.getEnd();
        java.util.Date date86 = year80.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year80, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = timeSeriesDataItem88.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries77.addOrUpdate(timeSeriesDataItem88);
        java.lang.Object obj91 = null;
        int int92 = timeSeriesDataItem90.compareTo(obj91);
        java.lang.Object obj93 = timeSeriesDataItem90.clone();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 1.0d + "'", comparable42.equals(1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "hi!" + "'", str73.equals("hi!"));
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertNotNull(collection78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(timeSeriesDataItem90);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(obj93);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj2 = null;
        boolean boolean3 = year1.equals(obj2);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        long long10 = timeSeries9.getMaximumItemAge();
        timeSeries9.clear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        java.lang.Class<?> wildcardClass15 = year13.getClass();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (byte) 1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 10, year13);
        boolean boolean19 = year1.equals((java.lang.Object) month18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem34, seriesChangeInfo35);
        java.lang.String str37 = seriesChangeEvent36.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo38 = seriesChangeEvent36.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo39 = seriesChangeEvent36.getSummary();
        java.lang.String str40 = seriesChangeEvent36.toString();
        java.lang.String str41 = seriesChangeEvent36.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo42 = seriesChangeEvent36.getSummary();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNull(seriesChangeInfo38);
        org.junit.Assert.assertNull(seriesChangeInfo39);
        org.junit.Assert.assertNull(seriesChangeInfo42);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        java.lang.Class<?> wildcardClass21 = year19.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0.0f);
        java.lang.String str24 = timeSeries17.getDomainDescription();
        java.lang.Object obj25 = timeSeries17.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries17.addChangeListener(seriesChangeListener26);
        boolean boolean28 = timeSeries17.getNotify();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries17.getNextTimePeriod();
        int int30 = timeSeries3.getIndex(regularTimePeriod29);
        double double31 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-2) + "'", int30 == (-2));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        java.lang.Class<?> wildcardClass22 = year20.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean31 = timeSeries28.equals((java.lang.Object) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(timeSeriesDataItem32);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
        java.lang.Class<?> wildcardClass42 = year40.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 0.0f);
        java.lang.String str45 = timeSeries38.getDomainDescription();
        java.lang.Object obj46 = timeSeries38.clone();
        timeSeries38.setNotify(true);
        timeSeries38.setRangeDescription("");
        java.lang.String str51 = timeSeries38.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean58 = timeSeries55.equals((java.lang.Object) fixedMillisecond57);
        java.util.Date date59 = fixedMillisecond57.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond57.next();
        boolean boolean61 = timeSeries38.equals((java.lang.Object) fixedMillisecond57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (double) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
        boolean boolean20 = timeSeriesDataItem14.equals((java.lang.Object) regularTimePeriod19);
        java.lang.Class<?> wildcardClass21 = timeSeriesDataItem14.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj25 = null;
        boolean boolean26 = year24.equals(obj25);
        boolean boolean28 = year24.equals((java.lang.Object) (-1));
        java.util.Date date29 = year24.getEnd();
        java.util.Date date30 = year24.getStart();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year33);
        java.util.Date date35 = year33.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date35, timeZone37);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date35, "Mon Jun 10 09:51:56 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: ");
        double double42 = timeSeries41.getMaxY();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean16 = timeSeries13.equals((java.lang.Object) fixedMillisecond15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        java.lang.String str19 = timeSeries3.getRangeDescription();
        long long20 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        java.lang.Number number25 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0f + "'", number25.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        java.lang.Object obj11 = timeSeries3.clone();
        timeSeries3.setNotify(true);
        timeSeries3.setRangeDescription("");
        java.lang.String str16 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        java.lang.Class<?> wildcardClass20 = year18.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list23 = timeSeries22.getItems();
        boolean boolean24 = year18.equals((java.lang.Object) list23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (byte) 0);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: June 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
//        java.lang.Class<?> wildcardClass7 = year5.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) (-9999));
//        long long15 = day12.getFirstMillisecond();
//        long long16 = day12.getLastMillisecond();
//        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Object obj18 = timeSeries3.clone();
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(obj18);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.Class<?> wildcardClass3 = year1.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.util.List list6 = timeSeries5.getItems();
        boolean boolean7 = year1.equals((java.lang.Object) list6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (byte) 0);
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        boolean boolean16 = year10.equals((java.lang.Object) date14);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year10);
        timeSeries17.setMaximumItemCount((int) (short) 10);
        java.lang.String str20 = timeSeries17.getDomainDescription();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getLastMillisecond(calendar27);
        int int29 = year22.compareTo((java.lang.Object) fixedMillisecond26);
        java.util.Calendar calendar30 = null;
        fixedMillisecond26.peg(calendar30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1559372400000L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 1.0d + "'", comparable5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 32L + "'", long28 == 32L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.lang.Class<?> wildcardClass7 = year5.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 0.0f);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Class<?> wildcardClass18 = year16.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean27 = timeSeries24.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries3.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj35 = null;
        boolean boolean36 = year34.equals(obj35);
        boolean boolean38 = year34.equals((java.lang.Object) (-1));
        java.util.Date date39 = year34.getEnd();
        java.util.Date date40 = year34.getStart();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date40);
        timeSeries3.setKey((java.lang.Comparable) date40);
        java.util.TimeZone timeZone43 = null;
        try {
            org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date40, timeZone43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        java.lang.Class<?> wildcardClass13 = year11.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        boolean boolean22 = timeSeries19.equals((java.lang.Object) fixedMillisecond21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        java.lang.Object obj26 = timeSeriesDataItem23.clone();
        boolean boolean27 = fixedMillisecond1.equals((java.lang.Object) timeSeriesDataItem23);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.next();
        java.lang.Class<?> wildcardClass35 = year33.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 0.0f);
        timeSeries31.removeAgedItems(false);
        java.lang.Object obj40 = timeSeries31.clone();
        boolean boolean41 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        java.lang.Class class46 = timeSeries45.getTimePeriodClass();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj49 = null;
        boolean boolean50 = year48.equals(obj49);
        boolean boolean52 = year48.equals((java.lang.Object) (-1));
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year48, (double) (byte) 1, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (double) 1969);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 2);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 2);
        java.lang.String str61 = seriesChangeEvent60.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(class46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=2]" + "'", str61.equals("org.jfree.data.event.SeriesChangeEvent[source=2]"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        java.lang.Class<?> wildcardClass8 = year6.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 0.0f);
        java.lang.String str11 = timeSeries4.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (double) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
        boolean boolean21 = timeSeriesDataItem15.equals((java.lang.Object) regularTimePeriod20);
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem15.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) (byte) 0);
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        boolean boolean29 = year25.equals((java.lang.Object) (-1));
        java.util.Date date30 = year25.getEnd();
        java.util.Date date31 = year25.getStart();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date31, timeZone32);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        java.lang.Class<?> wildcardClass41 = year39.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) 0.0f);
        java.lang.String str44 = timeSeries37.getDomainDescription();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year46, (double) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeriesDataItem52.getPeriod();
        boolean boolean54 = timeSeriesDataItem48.equals((java.lang.Object) regularTimePeriod53);
        java.lang.Class<?> wildcardClass55 = timeSeriesDataItem48.getClass();
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year((int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year58.next();
        java.lang.Class<?> wildcardClass60 = year58.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) ' ');
        java.util.Date date63 = fixedMillisecond62.getTime();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date63, timeZone64);
        java.util.TimeZone timeZone66 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date63, timeZone66);
        java.util.TimeZone timeZone68 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date63, timeZone68);
        java.util.TimeZone timeZone70 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date63, timeZone70);
        java.util.TimeZone timeZone72 = null;
        try {
            org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date63, timeZone72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getLastMillisecond();
        java.lang.Class<?> wildcardClass3 = month0.getClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
//        java.lang.Class<?> wildcardClass12 = year10.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        boolean boolean21 = timeSeries18.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.util.Collection collection23 = timeSeries8.getTimePeriods();
//        java.lang.String str24 = timeSeries8.getRangeDescription();
//        long long25 = timeSeries8.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        java.lang.Number number30 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        java.lang.Class<?> wildcardClass34 = year32.getClass();
//        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 10L);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        long long41 = timeSeries40.getMaximumItemAge();
//        timeSeries40.clear();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.next();
//        java.lang.Class<?> wildcardClass46 = year44.getClass();
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) (byte) 1);
//        int int49 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) year44);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year44);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        boolean boolean53 = day51.equals((java.lang.Object) (-9999));
//        long long54 = day51.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day51.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond57.next();
//        int int59 = day51.compareTo((java.lang.Object) regularTimePeriod58);
//        int int60 = day51.getYear();
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "hi!", "hi!");
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year66.next();
//        java.lang.Class<?> wildcardClass68 = year66.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) 0.0f);
//        java.lang.String str71 = timeSeries64.getDomainDescription();
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries64.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year73, (double) 1);
//        timeSeries64.setDomainDescription("");
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year((int) (byte) 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = year79.next();
//        long long81 = year79.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries64.getDataItem((org.jfree.data.time.RegularTimePeriod) year79);
//        long long83 = year79.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) year79);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0f + "'", number30.equals(0.0f));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "hi!" + "'", str71.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem75);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem82);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
//        org.junit.Assert.assertNotNull(timeSeries84);
//    }
//}

