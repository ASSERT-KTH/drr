import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot30.getRenderer();
        java.awt.Stroke stroke33 = xYPlot30.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = dateAxis34.isInverted();
        java.awt.Paint paint36 = dateAxis34.getAxisLinePaint();
        xYPlot30.setDomainCrosshairPaint(paint36);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Color color5 = java.awt.Color.getColor("Pie Plot", 8);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        java.awt.Color color8 = java.awt.Color.getColor("", color7);
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        float[] floatArray10 = null;
        float[] floatArray11 = color5.getColorComponents(colorSpace9, floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB(1, 0, (int) (short) 10, floatArray10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str2 = rectangleConstraint1.toString();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double5 = dateRange3.constrain(102.0d);
        java.lang.String str6 = dateRange3.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint1.toRangeHeight((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange3, (double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge10);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.NONE;
        boolean boolean13 = rectangleEdge10.equals((java.lang.Object) lengthConstraintType12);
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) (byte) 0);
        double double18 = range17.getUpperBound();
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range17, 0.0d, 0.025d);
        java.lang.String str22 = range21.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, (org.jfree.data.Range) dateRange3, lengthConstraintType12, (double) (-1), range21, lengthConstraintType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(rectangleConstraint7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,0.0]" + "'", str22.equals("Range[0.0,0.0]"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.lang.String str8 = ringPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot5, (java.lang.Integer) 10, plotRenderingInfo10);
        java.awt.Paint paint12 = ringPlot0.getLabelLinkPaint();
        java.lang.String str13 = ringPlot0.getNoDataMessage();
        boolean boolean14 = ringPlot0.getSimpleLabels();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot0.setDataset(waferMapDataset5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        int int32 = ringPlot31.getBackgroundImageAlignment();
        boolean boolean33 = ringPlot31.getIgnoreNullValues();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        ringPlot31.setLabelLinkPaint((java.awt.Paint) color34);
        java.awt.Color color36 = color34.darker();
        int int37 = color34.getBlue();
        xYPlot30.setRangeZeroBaselinePaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        int int40 = xYPlot30.getIndexOf(xYItemRenderer39);
        boolean boolean41 = xYPlot30.isRangeGridlinesVisible();
        int int42 = xYPlot30.getDomainAxisCount();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot0.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = color8.darker();
        java.awt.Stroke stroke10 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color6, stroke7, (java.awt.Paint) color8, stroke10, (float) 1);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1, stroke7);
        ringPlot0.setSectionOutlinesVisible(false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor16 = ringPlot0.getLabelDistributor();
        ringPlot0.setSimpleLabels(true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getBackgroundImageAlignment();
        double double2 = ringPlot0.getStartAngle();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.YELLOW;
        java.awt.Color color7 = color6.darker();
        java.awt.Stroke stroke8 = null;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color4, stroke5, (java.awt.Paint) color6, stroke8, (float) 1);
        ringPlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        ringPlot0.setURLGenerator(pieURLGenerator12);
        java.awt.Shape shape14 = ringPlot0.getLegendItemShape();
        float float15 = ringPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D7, (float) 100, (float) ' ', textAnchor10, 0.025d, (float) 10, (float) 2);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.TOP_LEFT", graphics2D1, (float) '#', (-1.0f), textAnchor4, (double) (byte) 1, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        float float4 = ringPlot0.getBackgroundAlpha();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color7 = color5.brighter();
        int int8 = color7.getBlue();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        blockContainer1.setFrame(blockFrame4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.lang.String str7 = textTitle6.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle6.getHorizontalAlignment();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot9.getLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        ringPlot9.setInsets(rectangleInsets12);
        blockContainer1.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) ringPlot9);
        double double16 = ringPlot9.getExplodePercent((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = flowArrangement0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        boolean boolean10 = valueMarker7.equals((java.lang.Object) textTitle9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot11);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = ringPlot11.getLabelGenerator();
        java.awt.Paint paint14 = ringPlot11.getBackgroundPaint();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color19 = java.awt.Color.YELLOW;
        java.awt.Color color20 = color19.darker();
        java.awt.Stroke stroke21 = null;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color17, stroke18, (java.awt.Paint) color19, stroke21, (float) 1);
        ringPlot11.setSectionOutlineStroke((java.lang.Comparable) 1, stroke18);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot25);
        java.awt.Paint paint27 = ringPlot25.getNoDataMessagePaint();
        ringPlot11.setParent((org.jfree.chart.plot.Plot) ringPlot25);
        valueMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot11);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat31 = dateAxis30.getDateFormatOverride();
        dateAxis30.setLabelURL("");
        dateAxis30.setUpperBound((double) 0.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date37 = dateAxis30.calculateLowestVisibleTickValue(dateTickUnit36);
        boolean boolean38 = valueMarker7.equals((java.lang.Object) dateTickUnit36);
        java.awt.Stroke stroke39 = valueMarker7.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        valueMarker7.setLabelAnchor(rectangleAnchor40);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(dateFormat31);
        org.junit.Assert.assertNotNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        dateAxis0.setUpperBound((double) 0.0f);
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = color10.darker();
        java.awt.Stroke stroke12 = null;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color8, stroke9, (java.awt.Paint) color10, stroke12, (float) 1);
        dateAxis0.setLabelPaint((java.awt.Paint) color10);
        boolean boolean16 = dateAxis0.isVerticalTickLabels();
        dateAxis0.setNegativeArrowVisible(false);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.Color color1 = color0.brighter();
        int int2 = color0.getRed();
        int int3 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.title.LegendTitle legendTitle6 = jFreeChart4.getLegend((int) ' ');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        try {
            jFreeChart4.handleClick(2, 10, chartRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNull(legendTitle6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.TOP", "java.awt.Color[r=255,g=255,b=255]");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        chartEntity5.setURLText("ChartChangeEventType.NEW_DATASET");
        java.lang.Object obj9 = chartEntity5.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0,0,2,-2,2,2,2,2" + "'", str6.equals("0,0,2,-2,2,2,2,2"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        boolean boolean3 = dateAxis0.isVisible();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setPieIndex((int) (short) 0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        ringPlot4.datasetChanged(datasetChangeEvent7);
        boolean boolean9 = ringPlot4.getLabelLinksVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(paint12);
        ringPlot4.setLabelLinkPaint(paint12);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) ringPlot4);
        dateAxis0.setRange(0.08d, 0.5249999999999999d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange(0.025d);
        java.awt.Stroke stroke3 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot4);
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        ringPlot4.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color9);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) ringPlot4);
        ringPlot4.setLabelLinkMargin(0.0d);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot14);
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Color color19 = java.awt.Color.getColor("", color18);
        ringPlot14.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        ringPlot14.axisChanged(axisChangeEvent21);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        ringPlot14.datasetChanged(datasetChangeEvent23);
        ringPlot14.setLabelGap((double) ' ');
        ringPlot4.setParent((org.jfree.chart.plot.Plot) ringPlot14);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = null;
        try {
            ringPlot0.setLabelPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        dateAxis0.setUpperBound((double) 0.0f);
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = color10.darker();
        java.awt.Stroke stroke12 = null;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color8, stroke9, (java.awt.Paint) color10, stroke12, (float) 1);
        dateAxis0.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = ringPlot16.getLabelGenerator();
        java.awt.Font font19 = ringPlot16.getNoDataMessageFont();
        dateAxis0.setTickLabelFont(font19);
        dateAxis0.setTickLabelsVisible(false);
        org.jfree.data.Range range23 = dateAxis0.getDefaultAutoRange();
        float float24 = dateAxis0.getTickMarkInsideLength();
        double double25 = dateAxis0.getLowerMargin();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke8, rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        int int5 = jFreeChart4.getSubtitleCount();
        java.awt.RenderingHints renderingHints6 = null;
        try {
            jFreeChart4.setRenderingHints(renderingHints6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis2.setStandardTickUnits(tickUnitSource4);
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        java.lang.String str7 = dateAxis0.getLabelToolTip();
        boolean boolean8 = dateAxis0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("");
        textLine0.removeFragment(textFragment2);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.awt.Font font8 = ringPlot5.getNoDataMessageFont();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = java.awt.Color.getColor("", color10);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color11, (float) (byte) 100);
        java.lang.String str14 = textFragment13.getText();
        textLine0.addFragment(textFragment13);
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean17 = textFragment13.equals((java.lang.Object) flowArrangement16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        java.lang.Object obj2 = textTitle0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Paint paint3 = ringPlot1.getNoDataMessagePaint();
        ringPlot1.setIgnoreZeroValues(false);
        boolean boolean6 = objectList0.equals((java.lang.Object) false);
        java.lang.Object obj8 = objectList0.get(0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        java.lang.Object obj3 = null;
        boolean boolean4 = ringPlot0.equals(obj3);
        ringPlot0.setMinimumArcAngleToDraw((double) '4');
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        ringPlot0.setLabelOutlineStroke(stroke7);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape10 = defaultDrawingSupplier9.getNextShape();
        java.awt.Shape shape11 = defaultDrawingSupplier9.getNextShape();
        ringPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        java.awt.Paint paint3 = paintMap0.getPaint((java.lang.Comparable) "Pie 3D Plot");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ClassContext");
        double double2 = numberAxis1.getUpperMargin();
        numberAxis1.setAutoRangeIncludesZero(false);
        try {
            numberAxis1.zoomRange((double) 10, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        ringPlot0.setIgnoreZeroValues(false);
        java.awt.Paint paint5 = ringPlot0.getLabelOutlinePaint();
        ringPlot0.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        boolean boolean44 = xYPlot30.isSubplot();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat47 = dateAxis46.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis46.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat50 = dateAxis49.getDateFormatOverride();
        boolean boolean51 = dateAxis49.isInverted();
        dateAxis49.setNegativeArrowVisible(false);
        boolean boolean54 = dateAxis49.isAutoTickUnitSelection();
        java.awt.Shape shape55 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis49.setDownArrow(shape55);
        dateAxis46.setRightArrow(shape55);
        java.lang.String str58 = dateAxis46.getLabel();
        xYPlot30.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis46, true);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(dateFormat47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNull(dateFormat50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace34 = xYPlot30.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace35, false);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(axisSpace34);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color35 = java.awt.Color.YELLOW;
        java.awt.Color color36 = color35.darker();
        java.awt.Stroke stroke37 = null;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color33, stroke34, (java.awt.Paint) color35, stroke37, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker39.getLabelAnchor();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker39.setOutlineStroke(stroke41);
        xYPlot30.setDomainGridlineStroke(stroke41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        xYPlot30.zoomRangeAxes((double) 8, plotRenderingInfo45, point2D48, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = xYPlot30.getOrientation();
        xYPlot30.setDomainCrosshairValue(100.0d, true);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(plotOrientation51);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot0.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = color8.darker();
        java.awt.Stroke stroke10 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color6, stroke7, (java.awt.Paint) color8, stroke10, (float) 1);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1, stroke7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = ringPlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(pieSectionLabelGenerator14);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        valueMarker7.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker7.setLabelAnchor(rectangleAnchor11);
        java.awt.Font font13 = valueMarker7.getLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot14);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = ringPlot14.getLabelGenerator();
        java.awt.Paint paint17 = ringPlot14.getBackgroundPaint();
        valueMarker7.setLabelPaint(paint17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.lang.String str20 = color19.toString();
        valueMarker7.setPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=128,b=255]" + "'", str20.equals("java.awt.Color[r=255,g=128,b=255]"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot0.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = color8.darker();
        java.awt.Stroke stroke10 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color6, stroke7, (java.awt.Paint) color8, stroke10, (float) 1);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1, stroke7);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        ringPlot14.setPieIndex((int) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = ringPlot17.getLabelPadding();
        double double20 = rectangleInsets18.calculateRightInset((double) '#');
        ringPlot14.setSimpleLabelOffset(rectangleInsets18);
        ringPlot0.setLabelPadding(rectangleInsets18);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        ringPlot0.setOutlineStroke(stroke23);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat4 = dateAxis3.getDateFormatOverride();
        boolean boolean5 = dateAxis3.isInverted();
        dateAxis3.setNegativeArrowVisible(false);
        boolean boolean8 = dateAxis3.isAutoTickUnitSelection();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis3.setDownArrow(shape9);
        dateAxis0.setRightArrow(shape9);
        double double12 = dateAxis0.getLabelAngle();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str2 = verticalAlignment1.toString();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 0, (double) 0.0f);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment6, (double) 1, 100.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str2.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(verticalAlignment6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        dateAxis0.setUpperBound((double) 0.0f);
        dateAxis0.setVerticalTickLabels(true);
        java.util.Date date8 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot30.getRangeAxisEdge();
        java.awt.Paint paint36 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        boolean boolean37 = rectangleEdge35.equals((java.lang.Object) paint36);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.lang.Object obj2 = blockContainer1.clone();
        double double3 = blockContainer1.getWidth();
        java.util.List list4 = blockContainer1.getBlocks();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (-1), 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, 100.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource46 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis44.setStandardTickUnits(tickUnitSource46);
        int int48 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        boolean boolean49 = xYPlot30.isRangeZoomable();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(tickUnitSource46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 255);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ThreadContext", "ThreadContext");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ThreadContext" + "'", str3.equals("ThreadContext"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        valueMarker7.setAlpha(0.0f);
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) valueMarker7);
        valueMarker7.setValue((double) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        boolean boolean36 = xYPlot30.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot30.getDomainAxisEdge();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot0.getBackgroundPaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        ringPlot0.datasetChanged(datasetChangeEvent4);
        ringPlot0.setInteriorGap((double) 0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = ringPlot0.getLabelDistributor();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        boolean boolean10 = valueMarker7.equals((java.lang.Object) textTitle9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot11);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = ringPlot11.getLabelGenerator();
        java.awt.Paint paint14 = ringPlot11.getBackgroundPaint();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color19 = java.awt.Color.YELLOW;
        java.awt.Color color20 = color19.darker();
        java.awt.Stroke stroke21 = null;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color17, stroke18, (java.awt.Paint) color19, stroke21, (float) 1);
        ringPlot11.setSectionOutlineStroke((java.lang.Comparable) 1, stroke18);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot25);
        java.awt.Paint paint27 = ringPlot25.getNoDataMessagePaint();
        ringPlot11.setParent((org.jfree.chart.plot.Plot) ringPlot25);
        valueMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot11);
        float float30 = valueMarker7.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle1.getFrame();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.String str4 = textTitle3.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle3.getHorizontalAlignment();
        textTitle1.setTextAlignment(horizontalAlignment5);
        boolean boolean7 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource2);
        dateAxis0.setUpperBound((double) 1.0f);
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (byte) 0);
        double double9 = range8.getUpperBound();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range8, 0.0d, 0.025d);
        double double14 = range8.constrain((double) 8);
        double double15 = range8.getLowerBound();
        dateAxis0.setRangeWithMargins(range8, false, true);
        dateAxis0.configure();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot30.getRangeAxisLocation();
        xYPlot30.setOutlineVisible(true);
        xYPlot30.setDomainZeroBaselineVisible(false);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color45 = java.awt.Color.YELLOW;
        java.awt.Color color46 = color45.darker();
        java.awt.Stroke stroke47 = null;
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color43, stroke44, (java.awt.Paint) color45, stroke47, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = valueMarker49.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle();
        boolean boolean52 = valueMarker49.equals((java.lang.Object) textTitle51);
        org.jfree.chart.plot.RingPlot ringPlot53 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent54 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot53);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator55 = ringPlot53.getLabelGenerator();
        java.awt.Paint paint56 = ringPlot53.getBackgroundPaint();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color61 = java.awt.Color.YELLOW;
        java.awt.Color color62 = color61.darker();
        java.awt.Stroke stroke63 = null;
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color59, stroke60, (java.awt.Paint) color61, stroke63, (float) 1);
        ringPlot53.setSectionOutlineStroke((java.lang.Comparable) 1, stroke60);
        org.jfree.chart.plot.RingPlot ringPlot67 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent68 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot67);
        java.awt.Paint paint69 = ringPlot67.getNoDataMessagePaint();
        ringPlot53.setParent((org.jfree.chart.plot.Plot) ringPlot67);
        valueMarker49.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot53);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = valueMarker49.getLabelOffset();
        java.awt.Color color74 = java.awt.Color.YELLOW;
        java.awt.Color color75 = java.awt.Color.getColor("", color74);
        valueMarker49.setOutlinePaint((java.awt.Paint) color75);
        org.jfree.chart.util.Layer layer77 = null;
        try {
            boolean boolean78 = xYPlot30.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker49, layer77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(color75);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) 0);
        double double4 = piePlot3D1.getMinimumArcAngleToDraw();
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D1.equals(obj5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 255);
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot0.getDataset();
        java.lang.String str4 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        int int4 = ringPlot3.getBackgroundImageAlignment();
        ringPlot1.setParent((org.jfree.chart.plot.Plot) ringPlot3);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) ringPlot1);
        java.awt.Stroke stroke7 = ringPlot1.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.lang.String str8 = ringPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot5, (java.lang.Integer) 10, plotRenderingInfo10);
        int int12 = ringPlot0.getPieIndex();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = null;
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.lang.String str8 = ringPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot5, (java.lang.Integer) 10, plotRenderingInfo10);
        java.awt.Paint paint12 = ringPlot0.getLabelLinkPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = ringPlot0.getDrawingSupplier();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = ringPlot0.getSimpleLabelOffset();
        double double15 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setShadowXOffset((double) 10.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color36 = java.awt.Color.YELLOW;
        java.awt.Color color37 = color36.darker();
        java.awt.Stroke stroke38 = null;
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color34, stroke35, (java.awt.Paint) color36, stroke38, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = valueMarker40.getLabelAnchor();
        java.awt.Stroke stroke42 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker40.setOutlineStroke(stroke42);
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        valueMarker40.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot44);
        org.jfree.chart.util.Layer layer46 = null;
        try {
            boolean boolean47 = xYPlot30.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker40, layer46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setPieIndex((int) (short) 0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        ringPlot0.datasetChanged(datasetChangeEvent3);
        boolean boolean5 = ringPlot0.getLabelLinksVisible();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = dateAxis6.isInverted();
        java.awt.Paint paint8 = dateAxis6.getAxisLinePaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(paint8);
        ringPlot0.setLabelLinkPaint(paint8);
        int int11 = ringPlot0.getBackgroundImageAlignment();
        java.lang.Object obj12 = ringPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        java.awt.Color color1 = color0.darker();
        java.awt.Color color2 = color1.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.title.LegendTitle legendTitle6 = jFreeChart4.getLegend((int) ' ');
        java.awt.image.BufferedImage bufferedImage9 = jFreeChart4.createBufferedImage(500, (int) (short) 1);
        java.awt.Paint paint10 = jFreeChart4.getBorderPaint();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNull(legendTitle6);
        org.junit.Assert.assertNotNull(bufferedImage9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand1);
        java.text.NumberFormat numberFormat3 = numberAxis3D0.getNumberFormatOverride();
        boolean boolean4 = numberAxis3D0.getAutoRangeStickyZero();
        org.jfree.data.RangeType rangeType5 = numberAxis3D0.getRangeType();
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        dateAxis0.setTickMarkOutsideLength(0.0f);
        double double5 = dateAxis0.getUpperMargin();
        dateAxis0.configure();
        dateAxis0.setFixedAutoRange((double) 8);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource46 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis44.setStandardTickUnits(tickUnitSource46);
        int int48 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = xYPlot30.getRenderer();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent50 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot30);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = xYPlot30.getInsets();
        java.awt.Paint paint52 = xYPlot30.getDomainGridlinePaint();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(tickUnitSource46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Paint[] paintArray1 = null;
        java.awt.Color color2 = java.awt.Color.pink;
        java.awt.Color color3 = color2.brighter();
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color3 };
        java.awt.Stroke[] strokeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Paint[] paintArray6 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Color color8 = java.awt.Color.pink;
        java.awt.Color color9 = color8.brighter();
        int int10 = color8.getRed();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int12 = color11.getGreen();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color8, color11, color13, color14 };
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat18 = dateAxis17.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = dateAxis17.getTickLabelInsets();
        float float20 = dateAxis17.getTickMarkOutsideLength();
        java.awt.Stroke stroke21 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.centerRange(0.025d);
        java.awt.Stroke stroke25 = dateAxis22.getAxisLineStroke();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat29 = dateAxis28.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = dateAxis28.getTickLabelInsets();
        float float31 = dateAxis28.getTickMarkOutsideLength();
        java.awt.Stroke stroke32 = dateAxis28.getAxisLineStroke();
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] { stroke16, stroke21, stroke25, stroke26, stroke27, stroke32 };
        java.awt.Stroke[] strokeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat36 = dateAxis35.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = dateAxis35.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat39 = dateAxis38.getDateFormatOverride();
        boolean boolean40 = dateAxis38.isInverted();
        dateAxis38.setNegativeArrowVisible(false);
        boolean boolean43 = dateAxis38.isAutoTickUnitSelection();
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setDownArrow(shape44);
        dateAxis35.setRightArrow(shape44);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat48 = dateAxis47.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = dateAxis47.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat51 = dateAxis50.getDateFormatOverride();
        boolean boolean52 = dateAxis50.isInverted();
        dateAxis50.setNegativeArrowVisible(false);
        boolean boolean55 = dateAxis50.isAutoTickUnitSelection();
        java.awt.Shape shape56 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis50.setDownArrow(shape56);
        dateAxis47.setRightArrow(shape56);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis();
        boolean boolean60 = dateAxis59.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource61 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis59.setStandardTickUnits(tickUnitSource61);
        dateAxis59.setUpperBound((double) 1.0f);
        java.awt.Shape shape65 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis59.setRightArrow(shape65);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis();
        boolean boolean68 = dateAxis67.isInverted();
        java.awt.Shape shape69 = dateAxis67.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity72 = new org.jfree.chart.entity.ChartEntity(shape69, "RectangleEdge.TOP", "java.awt.Color[r=255,g=255,b=255]");
        java.awt.Shape[] shapeArray73 = new java.awt.Shape[] { shape44, shape56, shape65, shape69 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier74 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray7, paintArray15, strokeArray33, strokeArray34, shapeArray73);
        java.awt.Shape[] shapeArray75 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier76 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray4, strokeArray5, strokeArray34, shapeArray75);
        boolean boolean77 = textBlockAnchor0.equals((java.lang.Object) shapeArray75);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(dateFormat18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(dateFormat29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNull(dateFormat36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNull(dateFormat39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNull(dateFormat48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNull(dateFormat51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(tickUnitSource61);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(shapeArray73);
        org.junit.Assert.assertNotNull(shapeArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        double double2 = textTitle0.getWidth();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        dateAxis2.setLabelURL("");
        dateAxis2.setUpperBound((double) 0.0f);
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Color color13 = color12.darker();
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12, stroke14, (float) 1);
        dateAxis2.setLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot18);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot18.getLabelGenerator();
        java.awt.Font font21 = ringPlot18.getNoDataMessageFont();
        dateAxis2.setTickLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font21);
        java.awt.Color color24 = java.awt.Color.pink;
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font21, (java.awt.Paint) color24, (float) (-1), (int) (byte) 0, textMeasurer27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str31 = verticalAlignment30.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, 0.0d, 0.025d);
        textBlock28.setLineAlignment(horizontalAlignment29);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.Size2D size2D37 = textBlock28.calculateDimensions(graphics2D36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = null;
        textBlock28.draw(graphics2D38, (float) 'a', (float) 2, textBlockAnchor41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor46 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock28.draw(graphics2D43, (float) (byte) -1, (-1.0f), textBlockAnchor46);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.util.Size2D size2D49 = textBlock28.calculateDimensions(graphics2D48);
        java.lang.Object obj50 = size2D49.clone();
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str31.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(textBlockAnchor46);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0E-5d, (short) 10, 0L, (byte) 10, 100.0f, 0.4d };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.RELATIVE", "RectangleEdge.LEFT", numberArray9);
        try {
            org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.lang.Object obj1 = null;
        boolean boolean2 = lineBorder0.equals(obj1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        waferMapPlot4.rendererChanged(rendererChangeEvent5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement8);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame12 = textTitle11.getFrame();
        blockContainer9.setFrame(blockFrame12);
        java.awt.geom.Rectangle2D rectangle2D14 = blockContainer9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        waferMapPlot4.draw(graphics2D7, rectangle2D14, point2D17, plotState18, plotRenderingInfo19);
        lineBorder0.draw(graphics2D3, rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(blockFrame12);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(point2D17);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        int int3 = ringPlot2.getBackgroundImageAlignment();
        ringPlot0.setParent((org.jfree.chart.plot.Plot) ringPlot2);
        java.awt.Shape shape5 = ringPlot0.getLegendItemShape();
        boolean boolean6 = ringPlot0.isCircular();
        java.awt.Stroke stroke7 = ringPlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange(0.025d);
        java.awt.Stroke stroke3 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot4);
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        ringPlot4.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color9);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) ringPlot4);
        java.util.Date date12 = dateAxis0.getMaximumDate();
        java.awt.Stroke stroke13 = dateAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setAxisLineVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis3D0.getTickUnit();
        numberAxis3D0.setFixedDimension((double) 10);
        org.jfree.data.Range range8 = new org.jfree.data.Range((double) (-1), 0.0d);
        boolean boolean10 = range8.contains((double) (short) 10);
        numberAxis3D0.setDefaultAutoRange(range8);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        xYPlot30.setRangeAxis(1, valueAxis34, true);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textLine0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.ui.Contributor contributor6 = new org.jfree.chart.ui.Contributor("RectangleEdge.TOP", "RectangleEdge.TOP");
        boolean boolean7 = textLine0.equals((java.lang.Object) contributor6);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        java.awt.Font font2 = textTitle0.getFont();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle0.draw(graphics2D3, rectangle2D4);
        textTitle0.setText("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot30.getRangeMarkers(layer31);
        java.awt.geom.Point2D point2D33 = xYPlot30.getQuadrantOrigin();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color37 = java.awt.Color.YELLOW;
        java.awt.Color color38 = color37.darker();
        java.awt.Stroke stroke39 = null;
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color35, stroke36, (java.awt.Paint) color37, stroke39, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = valueMarker41.getLabelAnchor();
        valueMarker41.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker41.setLabelAnchor(rectangleAnchor45);
        java.awt.Font font47 = valueMarker41.getLabelFont();
        org.jfree.chart.plot.RingPlot ringPlot48 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot48);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator50 = ringPlot48.getLabelGenerator();
        java.awt.Paint paint51 = ringPlot48.getBackgroundPaint();
        valueMarker41.setLabelPaint(paint51);
        xYPlot30.setRangeCrosshairPaint(paint51);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color58 = java.awt.Color.YELLOW;
        java.awt.Color color59 = color58.darker();
        java.awt.Stroke stroke60 = null;
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color56, stroke57, (java.awt.Paint) color58, stroke60, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = valueMarker62.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle();
        boolean boolean65 = valueMarker62.equals((java.lang.Object) textTitle64);
        java.awt.Stroke stroke66 = valueMarker62.getStroke();
        java.lang.String str67 = valueMarker62.getLabel();
        org.jfree.chart.util.Layer layer68 = null;
        try {
            xYPlot30.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker62, layer68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNull(str67);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        dateAxis0.setTickMarkOutsideLength(0.0f);
        double double5 = dateAxis0.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        dateAxis0.setTickLabelInsets(rectangleInsets6);
        dateAxis0.resizeRange((double) (byte) 10, 0.0d);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        blockParams0.setTranslateY(0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        java.awt.Paint paint35 = xYPlot30.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot30.getAxisOffset();
        xYPlot30.mapDatasetToRangeAxis((int) (short) 10, (int) 'a');
        org.jfree.chart.annotations.XYAnnotation xYAnnotation40 = null;
        try {
            xYPlot30.addAnnotation(xYAnnotation40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange(0.025d);
        java.awt.Paint paint3 = dateAxis0.getAxisLinePaint();
        java.lang.String str4 = dateAxis0.getLabel();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textLine1, jFreeChart2, chartChangeEventType3);
        boolean boolean5 = plotOrientation0.equals((java.lang.Object) textLine1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = textLine1.calculateDimensions(graphics2D6);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(size2D7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean2 = dateAxis0.isInverted();
        dateAxis0.setNegativeArrowVisible(false);
        boolean boolean5 = dateAxis0.isAutoTickUnitSelection();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot6);
        java.awt.Paint paint8 = ringPlot6.getNoDataMessagePaint();
        java.lang.Object obj9 = null;
        boolean boolean10 = ringPlot6.equals(obj9);
        ringPlot6.setMinimumArcAngleToDraw((double) '4');
        java.awt.Font font13 = ringPlot6.getLabelFont();
        dateAxis0.setLabelFont(font13);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.LEFT");
        java.text.AttributedString attributedString3 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(8, attributedString3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        double double4 = ringPlot0.getLabelGap();
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        double double6 = ringPlot0.getSectionDepth();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(rotation5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "TextBlockAnchor.TOP_LEFT", "WMAP_Plot", image3, "ThreadContext", "RectangleEdge.LEFT", "");
        java.lang.String str8 = projectInfo7.getInfo();
        java.lang.String str9 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "WMAP_Plot" + "'", str8.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = xYPlot30.getRendererForDataset(xYDataset33);
        xYPlot30.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNull(xYItemRenderer34);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getBackgroundPaint();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Color color3 = java.awt.Color.lightGray;
        textTitle0.setBackgroundPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot17);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = ringPlot17.getLabelGenerator();
        java.awt.Font font20 = ringPlot17.getNoDataMessageFont();
        dateAxis1.setTickLabelFont(font20);
        dateAxis1.setTickLabelsVisible(false);
        boolean boolean24 = dateAxis1.isVerticalTickLabels();
        int int25 = objectList0.indexOf((java.lang.Object) dateAxis1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis1.getTickUnit();
        org.jfree.data.Range range27 = dateAxis1.getDefaultAutoRange();
        double double28 = range27.getLength();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        dateAxis0.setTickMarkOutsideLength(0.0f);
        double double5 = dateAxis0.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        dateAxis0.setTickLabelInsets(rectangleInsets6);
        double double9 = rectangleInsets6.getRight();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) 0);
        piePlot3D1.setDarkerSides(true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        piePlot3D1.setDepthFactor((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = color4.darker();
        java.awt.Stroke stroke6 = null;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color2, stroke3, (java.awt.Paint) color4, stroke6, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = valueMarker8.getLabelAnchor();
        valueMarker8.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker8.setLabelAnchor(rectangleAnchor12);
        java.awt.Font font14 = valueMarker8.getLabelFont();
        java.awt.Font font15 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        valueMarker8.setLabelFont(font15);
        numberAxis0.setLabelFont(font15);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat20 = dateAxis19.getDateFormatOverride();
        dateAxis19.setLabelURL("");
        dateAxis19.setUpperBound((double) 0.0f);
        java.awt.Paint paint25 = dateAxis19.getAxisLinePaint();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color29 = java.awt.Color.YELLOW;
        java.awt.Color color30 = color29.darker();
        java.awt.Stroke stroke31 = null;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color27, stroke28, (java.awt.Paint) color29, stroke31, (float) 1);
        dateAxis19.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.centerRange(0.025d);
        java.awt.Stroke stroke38 = dateAxis35.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot39);
        java.awt.Color color43 = java.awt.Color.YELLOW;
        java.awt.Color color44 = java.awt.Color.getColor("", color43);
        ringPlot39.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color44);
        dateAxis35.setPlot((org.jfree.chart.plot.Plot) ringPlot39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        xYPlot48.setRangeAxisLocation((int) (short) 1, axisLocation50, false);
        java.awt.Paint paint53 = xYPlot48.getDomainTickBandPaint();
        org.jfree.chart.plot.RingPlot ringPlot54 = new org.jfree.chart.plot.RingPlot();
        int int55 = ringPlot54.getBackgroundImageAlignment();
        boolean boolean56 = ringPlot54.getIgnoreNullValues();
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        ringPlot54.setLabelLinkPaint((java.awt.Paint) color57);
        java.awt.Color color59 = color57.darker();
        int int60 = color57.getBlue();
        xYPlot48.setDomainGridlinePaint((java.awt.Paint) color57);
        boolean boolean62 = numberAxis0.hasListener((java.util.EventListener) xYPlot48);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        xYPlot48.datasetChanged(datasetChangeEvent63);
        org.jfree.chart.LegendItemCollection legendItemCollection65 = xYPlot48.getLegendItems();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(dateFormat20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 15 + "'", int55 == 15);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 255 + "'", int60 == 255);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(legendItemCollection65);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 1.0E-5d, (short) 10, 0L, (byte) 10, 100.0f, 0.4d };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.RELATIVE", "RectangleEdge.LEFT", numberArray9);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset10);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean2 = dateAxis0.isInverted();
        dateAxis0.setNegativeArrowVisible(false);
        dateAxis0.setFixedDimension(0.025d);
        org.jfree.chart.axis.Timeline timeline7 = dateAxis0.getTimeline();
        double double8 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot0.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = color8.darker();
        java.awt.Stroke stroke10 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color6, stroke7, (java.awt.Paint) color8, stroke10, (float) 1);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1, stroke7);
        java.awt.Image image14 = ringPlot0.getBackgroundImage();
        boolean boolean15 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot2);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = ringPlot2.getLabelGenerator();
        java.awt.Font font5 = ringPlot2.getNoDataMessageFont();
        java.awt.Color color7 = java.awt.Color.YELLOW;
        java.awt.Color color8 = java.awt.Color.getColor("", color7);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("hi!", font5, (java.awt.Paint) color8, (float) (byte) 100);
        java.awt.Font font11 = textFragment10.getFont();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("UnitType.RELATIVE", font11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement2);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame6 = textTitle5.getFrame();
        blockContainer3.setFrame(blockFrame6);
        textTitle0.setFrame(blockFrame6);
        java.awt.Font font9 = textTitle0.getFont();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        boolean boolean10 = valueMarker7.equals((java.lang.Object) textTitle9);
        java.lang.String str11 = textTitle9.getToolTipText();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = textTitle9.getMargin();
        double double13 = rectangleInsets12.getBottom();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke4 = categoryAxis3.getTickMarkStroke();
        categoryAxis3.setAxisLineVisible(false);
        java.awt.Paint paint8 = null;
        categoryAxis3.setTickLabelPaint((java.lang.Comparable) "Pie Plot", paint8);
        boolean boolean10 = textTitle0.equals((java.lang.Object) "Pie Plot");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color35 = java.awt.Color.YELLOW;
        java.awt.Color color36 = color35.darker();
        java.awt.Stroke stroke37 = null;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color33, stroke34, (java.awt.Paint) color35, stroke37, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker39.getLabelAnchor();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker39.setOutlineStroke(stroke41);
        xYPlot30.setDomainGridlineStroke(stroke41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        xYPlot30.zoomRangeAxes((double) 8, plotRenderingInfo45, point2D48, false);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat52 = dateAxis51.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = dateAxis51.getTickLabelInsets();
        dateAxis51.setTickMarkOutsideLength(0.0f);
        double double56 = dateAxis51.getUpperMargin();
        java.awt.Stroke stroke57 = dateAxis51.getAxisLineStroke();
        xYPlot30.setRangeGridlineStroke(stroke57);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNull(dateFormat52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        valueMarker7.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker7.setLabelAnchor(rectangleAnchor11);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = valueMarker7.getLabelOffsetType();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        java.awt.Font font2 = textTitle0.getFont();
        textTitle0.setText("ClassContext");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str6 = horizontalAlignment5.toString();
        textTitle0.setTextAlignment(horizontalAlignment5);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str6.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        java.awt.Paint paint35 = xYPlot30.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot30.getAxisOffset();
        xYPlot30.mapDatasetToRangeAxis((int) (short) 10, (int) 'a');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        xYPlot30.setRenderer(0, xYItemRenderer41, true);
        xYPlot30.setDomainCrosshairVisible(true);
        xYPlot30.mapDatasetToDomainAxis((-1), 255);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = null;
        java.awt.geom.Point2D point2D51 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D49, rectangleAnchor50);
        xYPlot30.setQuadrantOrigin(point2D51);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.centerRange(0.025d);
        java.awt.Stroke stroke3 = dateAxis0.getAxisLineStroke();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis0.setMaximumDate(date4);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.centerRange(0.025d);
        java.awt.Stroke stroke5 = dateAxis2.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot6);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = java.awt.Color.getColor("", color10);
        ringPlot6.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color11);
        dateAxis2.setPlot((org.jfree.chart.plot.Plot) ringPlot6);
        java.util.Date date14 = dateAxis2.getMaximumDate();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) date14);
        java.lang.Object obj16 = categoryAxis0.clone();
        java.lang.Comparable comparable17 = null;
        try {
            java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint(comparable17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (-1));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        ringPlot0.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        ringPlot0.axisChanged(axisChangeEvent7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        ringPlot0.datasetChanged(datasetChangeEvent9);
        double double11 = ringPlot0.getMaximumLabelWidth();
        org.jfree.chart.plot.Plot plot12 = ringPlot0.getRootPlot();
        java.awt.Stroke stroke13 = ringPlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.14d + "'", double11 == 0.14d);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getRangeTickBandPaint();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle0.equals(obj3);
        java.lang.String str5 = textTitle0.getToolTipText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        textTitle0.setID("Pie Plot");
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.CENTER;
        textTitle0.setVerticalAlignment(verticalAlignment9);
        java.lang.String str11 = verticalAlignment9.toString();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "VerticalAlignment.CENTER" + "'", str11.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot1.getLabelGenerator();
        java.awt.Font font4 = ringPlot1.getNoDataMessageFont();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("hi!", font4, (java.awt.Paint) color7, (float) (byte) 100);
        int int10 = color7.getGreen();
        float[] floatArray14 = null;
        float[] floatArray15 = java.awt.Color.RGBtoHSB(15, (int) ' ', (int) ' ', floatArray14);
        float[] floatArray16 = color7.getComponents(floatArray14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color9);
        valueMarker7.setLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        valueMarker7.notifyListeners(markerChangeEvent13);
        java.awt.Color color15 = java.awt.Color.CYAN;
        valueMarker7.setLabelPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot30.getRangeAxisEdge();
        boolean boolean36 = xYPlot30.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot30.getRangeAxisEdge();
        xYPlot30.setRangeGridlinesVisible(false);
        java.awt.Paint paint40 = xYPlot30.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        xYPlot30.zoomRangeAxes(4.0d, plotRenderingInfo42, point2D43, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color50 = java.awt.Color.YELLOW;
        java.awt.Color color51 = color50.darker();
        java.awt.Stroke stroke52 = null;
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color48, stroke49, (java.awt.Paint) color50, stroke52, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = valueMarker54.getLabelAnchor();
        valueMarker54.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker54.setLabelAnchor(rectangleAnchor58);
        java.awt.Font font60 = valueMarker54.getLabelFont();
        org.jfree.chart.util.Layer layer61 = null;
        try {
            xYPlot30.addDomainMarker(8, (org.jfree.chart.plot.Marker) valueMarker54, layer61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(font60);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame3 = textTitle2.getFrame();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setPieIndex((int) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = ringPlot7.getLabelPadding();
        double double10 = rectangleInsets8.calculateRightInset((double) '#');
        ringPlot4.setSimpleLabelOffset(rectangleInsets8);
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) ringPlot4);
        textTitle2.setExpandToFitSpace(false);
        textTitle2.setMargin((double) 100, 0.05d, (double) (short) 1, (double) 0.0f);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYPlot30.rendererChanged(rendererChangeEvent35);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color41 = java.awt.Color.YELLOW;
        java.awt.Color color42 = color41.darker();
        java.awt.Stroke stroke43 = null;
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color39, stroke40, (java.awt.Paint) color41, stroke43, (float) 1);
        java.awt.Paint paint46 = valueMarker45.getPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = null;
        valueMarker45.notifyListeners(markerChangeEvent47);
        org.jfree.chart.util.Layer layer49 = null;
        try {
            xYPlot30.addDomainMarker(1, (org.jfree.chart.plot.Marker) valueMarker45, layer49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot0.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = color8.darker();
        java.awt.Stroke stroke10 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color6, stroke7, (java.awt.Paint) color8, stroke10, (float) 1);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1, stroke7);
        java.awt.Paint paint14 = ringPlot0.getLabelLinkPaint();
        ringPlot0.setCircular(true, true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        dateAxis0.setUpperBound((double) 0.0f);
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        try {
            dateAxis0.zoomRange(0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-1.0) <= upper (-2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "TextBlockAnchor.TOP_LEFT", "WMAP_Plot", image3, "ThreadContext", "RectangleEdge.LEFT", "");
        java.lang.String str8 = projectInfo7.getInfo();
        projectInfo7.setLicenceText("RectangleEdge.TOP");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "WMAP_Plot" + "'", str8.equals("WMAP_Plot"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis3D5.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = dateAxis8.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource12);
        dateAxis8.setStandardTickUnits(tickUnitSource12);
        java.lang.String str15 = dateAxis8.getLabelToolTip();
        boolean boolean16 = numberAxis3D5.equals((java.lang.Object) str15);
        numberAxis3D5.setRangeAboutValue(1.0d, (double) 2);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        waferMapPlot21.rendererChanged(rendererChangeEvent22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement25 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement25);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame29 = textTitle28.getFrame();
        blockContainer26.setFrame(blockFrame29);
        java.awt.geom.Rectangle2D rectangle2D31 = blockContainer26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        waferMapPlot21.draw(graphics2D24, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        java.lang.String str39 = textTitle38.getID();
        java.awt.Font font40 = textTitle38.getFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = textTitle38.getPosition();
        double double42 = numberAxis3D5.valueToJava2D((double) '4', rectangle2D31, rectangleEdge41);
        org.jfree.chart.block.ColumnArrangement columnArrangement43 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer44 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement43);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame47 = textTitle46.getFrame();
        blockContainer44.setFrame(blockFrame47);
        java.awt.geom.Rectangle2D rectangle2D49 = blockContainer44.getBounds();
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot50);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator52 = ringPlot50.getLabelGenerator();
        java.awt.Paint paint53 = ringPlot50.getBackgroundPaint();
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color58 = java.awt.Color.YELLOW;
        java.awt.Color color59 = color58.darker();
        java.awt.Stroke stroke60 = null;
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color56, stroke57, (java.awt.Paint) color58, stroke60, (float) 1);
        ringPlot50.setSectionOutlineStroke((java.lang.Comparable) 1, stroke57);
        org.jfree.chart.plot.RingPlot ringPlot64 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent65 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot64);
        java.awt.Paint paint66 = ringPlot64.getNoDataMessagePaint();
        ringPlot50.setParent((org.jfree.chart.plot.Plot) ringPlot64);
        org.jfree.chart.title.LegendTitle legendTitle68 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot64);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = legendTitle68.getItemLabelPadding();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor70 = legendTitle68.getLegendItemGraphicAnchor();
        java.awt.geom.Point2D point2D71 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D49, rectangleAnchor70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean73 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge72);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType74 = org.jfree.chart.block.LengthConstraintType.NONE;
        boolean boolean75 = rectangleEdge72.equals((java.lang.Object) lengthConstraintType74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        try {
            org.jfree.chart.axis.AxisState axisState77 = categoryAxis3D0.draw(graphics2D3, (double) (byte) 100, rectangle2D31, rectangle2D49, rectangleEdge72, plotRenderingInfo76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(tickUnitSource12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(blockFrame29);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame47);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(rectangleAnchor70);
        org.junit.Assert.assertNotNull(point2D71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(lengthConstraintType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = xYPlot30.getRendererForDataset(xYDataset33);
        boolean boolean35 = xYPlot30.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNull(xYItemRenderer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        int int3 = ringPlot2.getBackgroundImageAlignment();
        ringPlot0.setParent((org.jfree.chart.plot.Plot) ringPlot2);
        java.awt.Shape shape5 = ringPlot0.getLegendItemShape();
        java.lang.String str6 = ringPlot0.getPlotType();
        boolean boolean7 = ringPlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie Plot" + "'", str6.equals("Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener5 = null;
        jFreeChart4.removeProgressListener(chartProgressListener5);
        jFreeChart4.clearSubtitles();
        java.lang.Object obj8 = jFreeChart4.clone();
        java.awt.Stroke stroke9 = jFreeChart4.getBorderStroke();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Color color4 = java.awt.Color.getColor("Pie Plot", 8);
        java.awt.Color color6 = java.awt.Color.YELLOW;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        float[] floatArray9 = null;
        float[] floatArray10 = color4.getColorComponents(colorSpace8, floatArray9);
        java.awt.Color color13 = java.awt.Color.getColor("Pie Plot", 8);
        java.awt.Color color15 = java.awt.Color.YELLOW;
        java.awt.Color color16 = java.awt.Color.getColor("", color15);
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        float[] floatArray18 = null;
        float[] floatArray19 = color13.getColorComponents(colorSpace17, floatArray18);
        float[] floatArray20 = color0.getColorComponents(colorSpace8, floatArray19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.junit.Assert.assertNull(chartChangeEventType4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        boolean boolean3 = dateAxis0.isVisible();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setPieIndex((int) (short) 0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        ringPlot4.datasetChanged(datasetChangeEvent7);
        boolean boolean9 = ringPlot4.getLabelLinksVisible();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = dateAxis10.isInverted();
        java.awt.Paint paint12 = dateAxis10.getAxisLinePaint();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(paint12);
        ringPlot4.setLabelLinkPaint(paint12);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) ringPlot4);
        java.lang.Object obj16 = ringPlot4.clone();
        boolean boolean17 = ringPlot4.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        boolean boolean4 = dateAxis0.isAutoTickUnitSelection();
        double double5 = dateAxis0.getLowerMargin();
        dateAxis0.setVerticalTickLabels(false);
        double double8 = dateAxis0.getUpperBound();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        boolean boolean36 = xYPlot30.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = null;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor40);
        xYPlot30.zoomRangeAxes((double) (byte) 0, plotRenderingInfo38, point2D41, false);
        xYPlot30.clearDomainMarkers();
        double double45 = xYPlot30.getRangeCrosshairValue();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYPlot30.rendererChanged(rendererChangeEvent35);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        boolean boolean39 = dateAxis37.isInverted();
        dateAxis37.setNegativeArrowVisible(false);
        dateAxis37.setFixedDimension(0.025d);
        boolean boolean44 = dateAxis37.isPositiveArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis37.setTickUnit(dateTickUnit45);
        int int47 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTickUnit45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit2);
        dateAxis0.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.lang.String str8 = ringPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot5, (java.lang.Integer) 10, plotRenderingInfo10);
        java.awt.Paint paint12 = ringPlot0.getLabelLinkPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = ringPlot0.getDrawingSupplier();
        float float14 = ringPlot0.getForegroundAlpha();
        int int15 = ringPlot0.getBackgroundImageAlignment();
        ringPlot0.setCircular(false, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        double double20 = categoryAxis19.getCategoryMargin();
        boolean boolean21 = categoryAxis19.isAxisLineVisible();
        categoryAxis19.setCategoryMargin((double) 100);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = dateAxis24.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource26 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis24.setStandardTickUnits(tickUnitSource26);
        dateAxis24.setRange((-4.0d), (double) (short) -1);
        java.util.Date date31 = dateAxis24.getMinimumDate();
        java.lang.Number[] numberArray41 = new java.lang.Number[] { 1.0E-5d, (short) 10, 0L, (byte) 10, 100.0f, 0.4d };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.RELATIVE", "RectangleEdge.LEFT", numberArray42);
        org.jfree.chart.block.ColumnArrangement columnArrangement45 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer46 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement45);
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame49 = textTitle48.getFrame();
        blockContainer46.setFrame(blockFrame49);
        java.awt.geom.Rectangle2D rectangle2D51 = blockContainer46.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.TOP;
        double double53 = categoryAxis19.getCategorySeriesMiddle((java.lang.Comparable) date31, (java.lang.Comparable) 0.14d, categoryDataset43, (-4.0d), rectangle2D51, rectangleEdge52);
        java.awt.Paint paint54 = ringPlot0.getSectionPaint((java.lang.Comparable) 0.14d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(tickUnitSource26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNotNull(blockFrame49);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(paint54);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getBackgroundImageAlignment();
        ringPlot0.setBackgroundImageAlignment((int) 'a');
        boolean boolean4 = ringPlot0.isCircular();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("UnitType.RELATIVE", "VerticalAlignment.CENTER", "Multiple Pie Plot", "java.awt.Color[r=255,g=128,b=255]");
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle0.equals(obj3);
        java.lang.String str5 = textTitle0.getToolTipText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        textTitle0.setID("Pie Plot");
        boolean boolean9 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        xYPlot30.setWeight(0);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement48 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement48);
        org.jfree.chart.block.Arrangement arrangement50 = blockContainer49.getArrangement();
        boolean boolean51 = blockContainer49.isEmpty();
        java.util.List list52 = blockContainer49.getBlocks();
        xYPlot30.drawDomainTickBands(graphics2D46, rectangle2D47, list52);
        xYPlot30.setDomainCrosshairValue(2.0d, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent57 = null;
        xYPlot30.datasetChanged(datasetChangeEvent57);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertNotNull(arrangement50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(list52);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis3D0.getTickUnit();
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame9 = textTitle8.getFrame();
        blockContainer6.setFrame(blockFrame9);
        java.awt.geom.Rectangle2D rectangle2D11 = blockContainer6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double13 = numberAxis3D0.valueToJava2D((double) 10, rectangle2D11, rectangleEdge12);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(blockFrame9);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        boolean boolean3 = dateAxis2.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis2.setStandardTickUnits(tickUnitSource4);
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        java.lang.String str7 = dateAxis0.getLabelToolTip();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape9 = defaultDrawingSupplier8.getNextShape();
        dateAxis0.setRightArrow(shape9);
        org.jfree.chart.util.ObjectList objectList11 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat13 = dateAxis12.getDateFormatOverride();
        dateAxis12.setLabelURL("");
        dateAxis12.setUpperBound((double) 0.0f);
        java.awt.Paint paint18 = dateAxis12.getAxisLinePaint();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color22 = java.awt.Color.YELLOW;
        java.awt.Color color23 = color22.darker();
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color20, stroke21, (java.awt.Paint) color22, stroke24, (float) 1);
        dateAxis12.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot28);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator30 = ringPlot28.getLabelGenerator();
        java.awt.Font font31 = ringPlot28.getNoDataMessageFont();
        dateAxis12.setTickLabelFont(font31);
        dateAxis12.setTickLabelsVisible(false);
        boolean boolean35 = dateAxis12.isVerticalTickLabels();
        int int36 = objectList11.indexOf((java.lang.Object) dateAxis12);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = dateAxis37.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat41 = dateAxis40.getDateFormatOverride();
        boolean boolean42 = dateAxis40.isInverted();
        dateAxis40.setNegativeArrowVisible(false);
        boolean boolean45 = dateAxis40.isAutoTickUnitSelection();
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis40.setDownArrow(shape46);
        dateAxis37.setRightArrow(shape46);
        dateAxis12.setLeftArrow(shape46);
        dateAxis0.setRightArrow(shape46);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(dateFormat13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNull(dateFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        java.awt.Paint paint3 = ringPlot0.getBackgroundPaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        java.awt.Color color9 = color8.darker();
        java.awt.Stroke stroke10 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color6, stroke7, (java.awt.Paint) color8, stroke10, (float) 1);
        ringPlot0.setSectionOutlineStroke((java.lang.Comparable) 1, stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = ringPlot0.getInsets();
        ringPlot0.setStartAngle((double) 15);
        double double17 = ringPlot0.getLabelLinkMargin();
        java.awt.Paint paint18 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        dateAxis0.setUpperBound((double) 0.0f);
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = color10.darker();
        java.awt.Stroke stroke12 = null;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color8, stroke9, (java.awt.Paint) color10, stroke12, (float) 1);
        dateAxis0.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = ringPlot16.getLabelGenerator();
        java.awt.Font font19 = ringPlot16.getNoDataMessageFont();
        dateAxis0.setTickLabelFont(font19);
        dateAxis0.setTickLabelsVisible(false);
        org.jfree.data.Range range23 = dateAxis0.getDefaultAutoRange();
        java.awt.Font font24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis0.setTickLabelFont(font24);
        dateAxis0.zoomRange((double) (-1L), (double) (byte) 1);
        dateAxis0.setLabelURL("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean2 = dateAxis0.isInverted();
        dateAxis0.setNegativeArrowVisible(false);
        dateAxis0.setFixedDimension(0.025d);
        org.jfree.chart.axis.Timeline timeline7 = dateAxis0.getTimeline();
        boolean boolean8 = dateAxis0.isAutoRange();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot0.setRenderer(waferMapRenderer3);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot0.setDataset(waferMapDataset5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = waferMapPlot0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot30.getRangeAxisEdge();
        boolean boolean36 = xYPlot30.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot30.getRangeAxisEdge();
        java.awt.Paint paint38 = xYPlot30.getRangeTickBandPaint();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color42 = java.awt.Color.YELLOW;
        java.awt.Color color43 = color42.darker();
        java.awt.Stroke stroke44 = null;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color40, stroke41, (java.awt.Paint) color42, stroke44, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = valueMarker46.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle48 = new org.jfree.chart.title.TextTitle();
        boolean boolean49 = valueMarker46.equals((java.lang.Object) textTitle48);
        java.awt.Stroke stroke50 = valueMarker46.getStroke();
        java.lang.String str51 = valueMarker46.getLabel();
        org.jfree.chart.util.Layer layer52 = null;
        try {
            boolean boolean53 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker46, layer52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(str51);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        ringPlot0.setSectionDepth(2.0d);
        try {
            ringPlot0.setInteriorGap((double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit2);
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) (byte) 0);
        double double7 = range6.getUpperBound();
        org.jfree.data.Range range10 = org.jfree.data.Range.expand(range6, 0.0d, 0.025d);
        dateAxis0.setRangeWithMargins(range10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        boolean boolean44 = xYPlot30.isSubplot();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean44);
        org.jfree.chart.JFreeChart jFreeChart46 = chartChangeEvent45.getChart();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(jFreeChart46);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot1.getLabelGenerator();
        java.awt.Font font4 = ringPlot1.getNoDataMessageFont();
        java.awt.Color color6 = java.awt.Color.YELLOW;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("hi!", font4, (java.awt.Paint) color7, (float) (byte) 100);
        java.lang.String str10 = textFragment9.getText();
        java.lang.String str11 = textFragment9.getText();
        java.awt.Paint paint12 = textFragment9.getPaint();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        int int3 = ringPlot2.getBackgroundImageAlignment();
        ringPlot0.setParent((org.jfree.chart.plot.Plot) ringPlot2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot2.getURLGenerator();
        ringPlot2.setSeparatorsVisible(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        java.awt.Color color1 = color0.darker();
        java.awt.Color color2 = color0.brighter();
        java.awt.Color color3 = color0.brighter();
        try {
            java.lang.Object obj4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) color0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getUpperMargin();
        boolean boolean3 = strokeMap0.equals((java.lang.Object) categoryAxis1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.configure();
        categoryAxis4.setCategoryMargin(4.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getUpperMargin();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis8.setTickMarkStroke(stroke10);
        categoryAxis4.setAxisLineStroke(stroke10);
        java.awt.Paint paint14 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) 102.0d);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.String str18 = standardPieSectionLabelGenerator15.generateSectionLabel(pieDataset16, (java.lang.Comparable) date17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat20 = dateAxis19.getDateFormatOverride();
        dateAxis19.setLabelURL("");
        boolean boolean23 = dateAxis19.isAutoTickUnitSelection();
        java.lang.String str24 = dateAxis19.getLabelToolTip();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource25);
        java.awt.Color color29 = java.awt.Color.getColor("Pie Plot", 8);
        java.awt.Color color31 = java.awt.Color.YELLOW;
        java.awt.Color color32 = java.awt.Color.getColor("", color31);
        java.awt.color.ColorSpace colorSpace33 = color32.getColorSpace();
        float[] floatArray34 = null;
        float[] floatArray35 = color29.getColorComponents(colorSpace33, floatArray34);
        dateAxis19.setLabelPaint((java.awt.Paint) color29);
        categoryAxis4.setTickLabelPaint((java.lang.Comparable) date17, (java.awt.Paint) color29);
        java.awt.Stroke stroke38 = strokeMap0.getStroke((java.lang.Comparable) date17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(dateFormat20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNull(stroke38);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Rotation.CLOCKWISE", graphics2D1, (float) (byte) 1, (float) '4', (double) (short) 100, (float) (short) 10, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource2);
        dateAxis0.setRange((-4.0d), (double) (short) -1);
        java.util.Date date7 = dateAxis0.getMinimumDate();
        dateAxis0.resizeRange((double) (byte) 0, (double) 10L);
        java.awt.Color color11 = java.awt.Color.white;
        dateAxis0.setAxisLinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToRangeAxis(8, (int) (short) 1);
        categoryPlot0.clearDomainAxes();
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle0.draw(graphics2D2, rectangle2D3);
        java.lang.String str5 = textTitle0.getText();
        java.awt.Paint paint6 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot17);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = ringPlot17.getLabelGenerator();
        java.awt.Font font20 = ringPlot17.getNoDataMessageFont();
        dateAxis1.setTickLabelFont(font20);
        dateAxis1.setTickLabelsVisible(false);
        boolean boolean24 = dateAxis1.isVerticalTickLabels();
        int int25 = objectList0.indexOf((java.lang.Object) dateAxis1);
        java.lang.String str26 = dateAxis1.getLabel();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getBackgroundImageAlignment();
        double double2 = ringPlot0.getStartAngle();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.YELLOW;
        java.awt.Color color7 = color6.darker();
        java.awt.Stroke stroke8 = null;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color4, stroke5, (java.awt.Paint) color6, stroke8, (float) 1);
        ringPlot0.setLabelLinkStroke(stroke5);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        ringPlot0.setURLGenerator(pieURLGenerator12);
        java.awt.Paint paint14 = ringPlot0.getLabelOutlinePaint();
        java.lang.Object obj15 = null;
        boolean boolean16 = ringPlot0.equals(obj15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        dateAxis2.setLabelURL("");
        dateAxis2.setUpperBound((double) 0.0f);
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Color color13 = color12.darker();
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12, stroke14, (float) 1);
        dateAxis2.setLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot18);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot18.getLabelGenerator();
        java.awt.Font font21 = ringPlot18.getNoDataMessageFont();
        dateAxis2.setTickLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font21);
        java.awt.Color color24 = java.awt.Color.pink;
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font21, (java.awt.Paint) color24, (float) (-1), (int) (byte) 0, textMeasurer27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str31 = verticalAlignment30.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, 0.0d, 0.025d);
        textBlock28.setLineAlignment(horizontalAlignment29);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.Size2D size2D37 = textBlock28.calculateDimensions(graphics2D36);
        java.util.List list38 = textBlock28.getLines();
        org.jfree.chart.text.TextLine textLine39 = null;
        textBlock28.addLine(textLine39);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str31.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        boolean boolean10 = valueMarker7.equals((java.lang.Object) textTitle9);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot11);
        java.awt.Paint paint13 = ringPlot11.getNoDataMessagePaint();
        ringPlot11.setIgnoreZeroValues(false);
        ringPlot11.setSimpleLabels(true);
        valueMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot11);
        valueMarker7.setLabel("Rotation.CLOCKWISE");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToRangeAxis(8, (int) (short) 1);
        int int4 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        blockContainer1.setFrame(blockFrame4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.lang.String str7 = textTitle6.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle6.getHorizontalAlignment();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot9.getLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        ringPlot9.setInsets(rectangleInsets12);
        blockContainer1.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) ringPlot9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment15, verticalAlignment16, (double) 0, (double) '4');
        blockContainer1.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.awt.Font font23 = textTitle22.getFont();
        textTitle22.setHeight(1.0d);
        blockContainer1.add((org.jfree.chart.block.Block) textTitle22, (java.lang.Object) (-1.0d));
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double30 = rectangleInsets29.getTop();
        double double31 = rectangleInsets29.getRight();
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame36 = textTitle35.getFrame();
        blockContainer33.setFrame(blockFrame36);
        java.awt.geom.Rectangle2D rectangle2D38 = blockContainer33.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets29.createOutsetRectangle(rectangle2D38, false, true);
        try {
            blockContainer1.draw(graphics2D28, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertNotNull(blockFrame36);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        dateAxis1.setVerticalTickLabels(true);
        java.util.TimeZone timeZone9 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("VerticalAlignment.CENTER", timeZone9);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        double double4 = numberAxis0.getLowerMargin();
        numberAxis0.centerRange((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        ringPlot0.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        ringPlot0.axisChanged(axisChangeEvent7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        ringPlot0.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            ringPlot0.setInsets(rectangleInsets11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        boolean boolean36 = xYPlot30.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = null;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor40);
        xYPlot30.zoomRangeAxes((double) (byte) 0, plotRenderingInfo38, point2D41, false);
        int int44 = xYPlot30.getSeriesCount();
        int int45 = xYPlot30.getDatasetCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        xYPlot30.rendererChanged(rendererChangeEvent46);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat49 = dateAxis48.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = dateAxis48.getTickLabelInsets();
        xYPlot30.setAxisOffset(rectangleInsets50);
        java.awt.Paint paint52 = xYPlot30.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNull(dateFormat49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle1.getVerticalAlignment();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.lang.String str5 = textTitle4.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle4.getHorizontalAlignment();
        java.lang.Object obj7 = null;
        boolean boolean8 = textTitle4.equals(obj7);
        java.lang.String str9 = textTitle4.getToolTipText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle4);
        textTitle4.setID("Pie Plot");
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot13);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = ringPlot13.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = ringPlot13.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot13);
        int int18 = jFreeChart17.getSubtitleCount();
        textTitle4.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) jFreeChart17);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        xYPlot30.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 100, (double) 3, 0.4d, (java.awt.Paint) color4);
        int int6 = color4.getRed();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 192 + "'", int6 == 192);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean2 = dateAxis0.isInverted();
        dateAxis0.setNegativeArrowVisible(false);
        boolean boolean5 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setDownArrow(shape6);
        org.jfree.data.Range range8 = null;
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude(range8, (double) (byte) 0);
        double double11 = range10.getUpperBound();
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range10, 0.0d, 0.025d);
        dateAxis0.setRange(range14, true, true);
        org.jfree.data.Range range18 = dateAxis0.getDefaultAutoRange();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("");
        textLine0.removeFragment(textFragment2);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.awt.Font font8 = ringPlot5.getNoDataMessageFont();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = java.awt.Color.getColor("", color10);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color11, (float) (byte) 100);
        textLine0.addFragment(textFragment13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot5 = jFreeChart4.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.RingPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        java.awt.Paint paint35 = xYPlot30.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot30.getAxisOffset();
        java.awt.Stroke stroke37 = xYPlot30.getRangeGridlineStroke();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        blockContainer1.setFrame(blockFrame4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.lang.String str7 = textTitle6.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle6.getHorizontalAlignment();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot9.getLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        ringPlot9.setInsets(rectangleInsets12);
        blockContainer1.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) ringPlot9);
        blockContainer1.setID("ClassContext");
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean18 = blockContainer1.equals((java.lang.Object) rectangleEdge17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat21 = dateAxis20.getDateFormatOverride();
        dateAxis20.setLabelURL("");
        dateAxis20.setUpperBound((double) 0.0f);
        java.awt.Paint paint26 = dateAxis20.getAxisLinePaint();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color30 = java.awt.Color.YELLOW;
        java.awt.Color color31 = color30.darker();
        java.awt.Stroke stroke32 = null;
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color28, stroke29, (java.awt.Paint) color30, stroke32, (float) 1);
        dateAxis20.setLabelPaint((java.awt.Paint) color30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.centerRange(0.025d);
        java.awt.Stroke stroke39 = dateAxis36.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot40 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot40);
        java.awt.Color color44 = java.awt.Color.YELLOW;
        java.awt.Color color45 = java.awt.Color.getColor("", color44);
        ringPlot40.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color45);
        dateAxis36.setPlot((org.jfree.chart.plot.Plot) ringPlot40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = xYPlot49.getAxisOffset();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color54 = java.awt.Color.YELLOW;
        java.awt.Color color55 = color54.darker();
        java.awt.Stroke stroke56 = null;
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color52, stroke53, (java.awt.Paint) color54, stroke56, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = valueMarker58.getLabelAnchor();
        java.awt.Stroke stroke60 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker58.setOutlineStroke(stroke60);
        xYPlot49.setDomainGridlineStroke(stroke60);
        boolean boolean63 = blockContainer1.equals((java.lang.Object) xYPlot49);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(dateFormat21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle0.equals(obj3);
        java.lang.String str5 = textTitle0.getURLText();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace34 = xYPlot30.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat40 = dateAxis39.getDateFormatOverride();
        dateAxis39.setLabelURL("");
        dateAxis39.setUpperBound((double) 0.0f);
        java.awt.Paint paint45 = dateAxis39.getAxisLinePaint();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color49 = java.awt.Color.YELLOW;
        java.awt.Color color50 = color49.darker();
        java.awt.Stroke stroke51 = null;
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color47, stroke48, (java.awt.Paint) color49, stroke51, (float) 1);
        dateAxis39.setLabelPaint((java.awt.Paint) color49);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        dateAxis55.centerRange(0.025d);
        java.awt.Stroke stroke58 = dateAxis55.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot59 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent60 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot59);
        java.awt.Color color63 = java.awt.Color.YELLOW;
        java.awt.Color color64 = java.awt.Color.getColor("", color63);
        ringPlot59.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color64);
        dateAxis55.setPlot((org.jfree.chart.plot.Plot) ringPlot59);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis55, xYItemRenderer67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = xYPlot68.getAxisOffset();
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke72 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color73 = java.awt.Color.YELLOW;
        java.awt.Color color74 = color73.darker();
        java.awt.Stroke stroke75 = null;
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color71, stroke72, (java.awt.Paint) color73, stroke75, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = valueMarker77.getLabelAnchor();
        java.awt.Stroke stroke79 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker77.setOutlineStroke(stroke79);
        xYPlot68.setDomainGridlineStroke(stroke79);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo83 = null;
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = null;
        java.awt.geom.Point2D point2D86 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D84, rectangleAnchor85);
        xYPlot68.zoomRangeAxes((double) 8, plotRenderingInfo83, point2D86, false);
        try {
            xYPlot30.zoomDomainAxes(0.12d, (double) 0, plotRenderingInfo37, point2D86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertNull(dateFormat40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(rectangleAnchor78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(point2D86);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        float float3 = dateAxis0.getTickMarkOutsideLength();
        java.awt.Stroke stroke4 = dateAxis0.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart9.setTitle(textTitle10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart9, chartChangeEventType12);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        int int32 = ringPlot31.getBackgroundImageAlignment();
        boolean boolean33 = ringPlot31.getIgnoreNullValues();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        ringPlot31.setLabelLinkPaint((java.awt.Paint) color34);
        java.awt.Color color36 = color34.darker();
        int int37 = color34.getBlue();
        xYPlot30.setRangeZeroBaselinePaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        int int40 = xYPlot30.getIndexOf(xYItemRenderer39);
        boolean boolean41 = xYPlot30.isRangeGridlinesVisible();
        org.jfree.chart.plot.Plot plot42 = null;
        xYPlot30.setParent(plot42);
        boolean boolean44 = xYPlot30.isDomainGridlinesVisible();
        xYPlot30.setDomainCrosshairValue((double) 3, true);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        double double4 = ringPlot0.getLabelGap();
        java.awt.Stroke stroke5 = ringPlot0.getLabelLinkStroke();
        ringPlot0.setLabelLinksVisible(false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToRangeAxis(8, (int) (short) 1);
        categoryPlot0.clearAnnotations();
        java.util.List list5 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = color10.darker();
        java.awt.Stroke stroke12 = null;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color8, stroke9, (java.awt.Paint) color10, stroke12, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = valueMarker14.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        boolean boolean17 = valueMarker14.equals((java.lang.Object) textTitle16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot18);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot18.getLabelGenerator();
        java.awt.Paint paint21 = ringPlot18.getBackgroundPaint();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Color color27 = color26.darker();
        java.awt.Stroke stroke28 = null;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color24, stroke25, (java.awt.Paint) color26, stroke28, (float) 1);
        ringPlot18.setSectionOutlineStroke((java.lang.Comparable) 1, stroke25);
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot32);
        java.awt.Paint paint34 = ringPlot32.getNoDataMessagePaint();
        ringPlot18.setParent((org.jfree.chart.plot.Plot) ringPlot32);
        valueMarker14.addChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot18);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = valueMarker14.getLabelOffset();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot17);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = ringPlot17.getLabelGenerator();
        java.awt.Font font20 = ringPlot17.getNoDataMessageFont();
        dateAxis1.setTickLabelFont(font20);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font20);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.TextAnchor textAnchor26 = null;
        try {
            textLine22.draw(graphics2D23, (float) (byte) 1, 0.0f, textAnchor26, 0.0f, 0.0f, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        boolean boolean2 = blockContainer1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        dateAxis2.setLabelURL("");
        dateAxis2.setUpperBound((double) 0.0f);
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Color color13 = color12.darker();
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12, stroke14, (float) 1);
        dateAxis2.setLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot18);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot18.getLabelGenerator();
        java.awt.Font font21 = ringPlot18.getNoDataMessageFont();
        dateAxis2.setTickLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font21);
        java.awt.Color color24 = java.awt.Color.pink;
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font21, (java.awt.Paint) color24, (float) (-1), (int) (byte) 0, textMeasurer27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str31 = verticalAlignment30.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, 0.0d, 0.025d);
        textBlock28.setLineAlignment(horizontalAlignment29);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.Size2D size2D37 = textBlock28.calculateDimensions(graphics2D36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor41 = null;
        textBlock28.draw(graphics2D38, (float) 'a', (float) 2, textBlockAnchor41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor46 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock28.draw(graphics2D43, (float) (byte) -1, (-1.0f), textBlockAnchor46);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock28.setLineAlignment(horizontalAlignment48);
        org.jfree.chart.text.TextLine textLine50 = textBlock28.getLastLine();
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str31.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertNotNull(textBlockAnchor46);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNull(textLine50);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color35 = java.awt.Color.YELLOW;
        java.awt.Color color36 = color35.darker();
        java.awt.Stroke stroke37 = null;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color33, stroke34, (java.awt.Paint) color35, stroke37, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker39.getLabelAnchor();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker39.setOutlineStroke(stroke41);
        xYPlot30.setDomainGridlineStroke(stroke41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        xYPlot30.zoomRangeAxes((double) 8, plotRenderingInfo45, point2D48, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = xYPlot30.getOrientation();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        xYPlot30.rendererChanged(rendererChangeEvent52);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(plotOrientation51);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        double double2 = blockParams0.getTranslateY();
        blockParams0.setTranslateX(0.0d);
        double double5 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "ThreadContext", "ClassContext");
        basicProjectInfo4.setCopyright("ThreadContext");
        java.lang.String str7 = basicProjectInfo4.getInfo();
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ClassContext" + "'", str7.equals("ClassContext"));
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.lang.Object obj2 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color43 = java.awt.Color.YELLOW;
        java.awt.Color color44 = color43.darker();
        java.awt.Stroke stroke45 = null;
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color41, stroke42, (java.awt.Paint) color43, stroke45, (float) 1);
        java.awt.Paint paint48 = valueMarker47.getPaint();
        boolean boolean49 = blockBorder39.equals((java.lang.Object) valueMarker47);
        double double50 = valueMarker47.getValue();
        org.jfree.chart.util.Layer layer51 = null;
        try {
            xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker47, layer51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.0d + "'", double50 == 100.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToRangeAxis(8, (int) (short) 1);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment6, (double) 'a', (double) 100L);
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.block.Arrangement arrangement12 = blockContainer11.getArrangement();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0, (org.jfree.chart.block.Arrangement) columnArrangement9, arrangement12);
        org.junit.Assert.assertNotNull(arrangement12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        xYPlot30.setRangeAxisLocation((int) (short) 1, axisLocation32, false);
        java.awt.Paint paint35 = xYPlot30.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot30.getAxisOffset();
        xYPlot30.mapDatasetToRangeAxis((int) (short) 10, (int) 'a');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        xYPlot30.setRenderer(0, xYItemRenderer41, true);
        xYPlot30.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace46 = xYPlot30.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNull(axisSpace46);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.lang.String str8 = ringPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot5, (java.lang.Integer) 10, plotRenderingInfo10);
        double double13 = ringPlot0.getExplodePercent((java.lang.Comparable) 15);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = null;
        ringPlot0.setURLGenerator(pieURLGenerator14);
        ringPlot0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        multiplePiePlot0.setLimit((double) 255);
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot0.getDataset();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.lang.String str5 = textTitle4.getID();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame10 = textTitle9.getFrame();
        blockContainer7.setFrame(blockFrame10);
        textTitle4.setFrame(blockFrame10);
        java.awt.Paint paint13 = textTitle4.getBackgroundPaint();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot15);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = ringPlot15.getLabelGenerator();
        java.awt.Font font18 = ringPlot15.getNoDataMessageFont();
        java.awt.Color color19 = java.awt.Color.YELLOW;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19, jFreeChart20);
        int int22 = color19.getBlue();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge23);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.NONE;
        boolean boolean26 = rectangleEdge23.equals((java.lang.Object) lengthConstraintType25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str28 = horizontalAlignment27.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str30 = verticalAlignment29.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("ClassContext", font18, (java.awt.Paint) color19, rectangleEdge23, horizontalAlignment27, verticalAlignment29, rectangleInsets31);
        textTitle4.setFont(font18);
        multiplePiePlot0.setNoDataMessageFont(font18);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(blockFrame10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str28.equals("HorizontalAlignment.RIGHT"));
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str30.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = color3.darker();
        java.awt.Stroke stroke5 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke5, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        boolean boolean10 = valueMarker7.equals((java.lang.Object) textTitle9);
        java.awt.Paint paint11 = valueMarker7.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Other");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Other, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource46 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis44.setStandardTickUnits(tickUnitSource46);
        int int48 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = xYPlot30.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot30.getRangeAxis((int) (byte) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier52 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint53 = defaultDrawingSupplier52.getNextFillPaint();
        java.awt.Paint paint54 = defaultDrawingSupplier52.getNextFillPaint();
        xYPlot30.setDomainTickBandPaint(paint54);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(tickUnitSource46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer49);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getUpperMargin();
        boolean boolean3 = strokeMap0.equals((java.lang.Object) categoryAxis1);
        int int4 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "VerticalAlignment.BOTTOM", "0,0,2,-2,2,2,2,2", image3, "ThreadContext", "java.awt.Color[r=255,g=255,b=255]", "RectangleEdge.LEFT");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.lang.String str9 = projectInfo7.toString();
        java.lang.String str10 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleEdge.LEFT" + "'", str8.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=255,g=255,b=255] version VerticalAlignment.BOTTOM.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:0,0,2,-2,2,2,2,2\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY java.awt.Color[r=255,g=255,b=255]:None\njava.awt.Color[r=255,g=255,b=255] LICENCE TERMS:\nRectangleEdge.LEFT" + "'", str9.equals("java.awt.Color[r=255,g=255,b=255] version VerticalAlignment.BOTTOM.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:0,0,2,-2,2,2,2,2\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY java.awt.Color[r=255,g=255,b=255]:None\njava.awt.Color[r=255,g=255,b=255] LICENCE TERMS:\nRectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=255,b=255] version VerticalAlignment.BOTTOM.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:0,0,2,-2,2,2,2,2\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY java.awt.Color[r=255,g=255,b=255]:None\njava.awt.Color[r=255,g=255,b=255] LICENCE TERMS:\nRectangleEdge.LEFT" + "'", str10.equals("java.awt.Color[r=255,g=255,b=255] version VerticalAlignment.BOTTOM.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:0,0,2,-2,2,2,2,2\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY java.awt.Color[r=255,g=255,b=255]:None\njava.awt.Color[r=255,g=255,b=255] LICENCE TERMS:\nRectangleEdge.LEFT"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getCategoryMargin();
        java.lang.Object obj2 = categoryAxis3D0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        double double3 = range2.getUpperBound();
        org.jfree.data.Range range6 = org.jfree.data.Range.expand(range2, 0.0d, 0.025d);
        double double8 = range2.constrain((double) 8);
        org.jfree.data.Range range11 = new org.jfree.data.Range((double) (-1), 0.0d);
        boolean boolean13 = range11.contains(2.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range2, range11);
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.Size2D size2D16 = rectangleConstraint14.calculateConstrainedSize(size2D15);
        size2D16.setWidth((double) 2.0f);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(size2D16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        int int3 = ringPlot2.getBackgroundImageAlignment();
        ringPlot0.setParent((org.jfree.chart.plot.Plot) ringPlot2);
        java.awt.Stroke stroke5 = ringPlot2.getLabelLinkStroke();
        double double6 = ringPlot2.getInnerSeparatorExtension();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets7.getTop();
        double double9 = rectangleInsets7.getRight();
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame14 = textTitle13.getFrame();
        blockContainer11.setFrame(blockFrame14);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets7.createOutsetRectangle(rectangle2D16, false, true);
        ringPlot2.setLabelPadding(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(blockFrame14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "ThreadContext");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ThreadContext" + "'", str4.equals("ThreadContext"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D0.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        int int3 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartChangeEventType.NEW_DATASET");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat4 = dateAxis3.getDateFormatOverride();
        dateAxis3.setLabelURL("");
        dateAxis3.setUpperBound((double) 0.0f);
        java.awt.Paint paint9 = dateAxis3.getAxisLinePaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color13 = java.awt.Color.YELLOW;
        java.awt.Color color14 = color13.darker();
        java.awt.Stroke stroke15 = null;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color11, stroke12, (java.awt.Paint) color13, stroke15, (float) 1);
        dateAxis3.setLabelPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot19);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = ringPlot19.getLabelGenerator();
        java.awt.Font font22 = ringPlot19.getNoDataMessageFont();
        dateAxis3.setTickLabelFont(font22);
        java.awt.Paint paint24 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer26 = null;
        org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("", font22, paint24, (float) 500, textMeasurer26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str32 = textBlockAnchor31.toString();
        textBlock27.draw(graphics2D28, 1.0f, (float) 1L, textBlockAnchor31);
        boolean boolean34 = standardPieSectionLabelGenerator1.equals((java.lang.Object) textBlockAnchor31);
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textBlock27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str32.equals("TextBlockAnchor.TOP_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color35 = java.awt.Color.YELLOW;
        java.awt.Color color36 = color35.darker();
        java.awt.Stroke stroke37 = null;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color33, stroke34, (java.awt.Paint) color35, stroke37, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker39.getLabelAnchor();
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker39.setOutlineStroke(stroke41);
        xYPlot30.setDomainGridlineStroke(stroke41);
        xYPlot30.clearDomainMarkers((int) (byte) 1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        int int32 = ringPlot31.getBackgroundImageAlignment();
        boolean boolean33 = ringPlot31.getIgnoreNullValues();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        ringPlot31.setLabelLinkPaint((java.awt.Paint) color34);
        java.awt.Color color36 = color34.darker();
        int int37 = color34.getBlue();
        xYPlot30.setRangeZeroBaselinePaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        int int40 = xYPlot30.getIndexOf(xYItemRenderer39);
        boolean boolean41 = xYPlot30.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat43 = dateAxis42.getDateFormatOverride();
        boolean boolean44 = dateAxis42.isInverted();
        dateAxis42.setNegativeArrowVisible(false);
        dateAxis42.setFixedDimension(0.025d);
        boolean boolean49 = dateAxis42.isPositiveArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis42.setTickUnit(dateTickUnit50);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        boolean boolean53 = dateAxis52.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        boolean boolean55 = dateAxis54.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis54.setStandardTickUnits(tickUnitSource56);
        dateAxis52.setStandardTickUnits(tickUnitSource56);
        java.lang.String str59 = dateAxis52.getLabelToolTip();
        boolean boolean61 = dateAxis52.isHiddenValue((long) 15);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { dateAxis42, dateAxis52 };
        xYPlot30.setRangeAxes(valueAxisArray62);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis65 = xYPlot30.getRangeAxisForDataset(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 15 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(dateFormat43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateTickUnit50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(valueAxisArray62);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double[] doubleArray8 = new double[] { 2.0d, 100.0d, 10, 500, 0.12d, 10.0d };
        double[] doubleArray15 = new double[] { 2.0d, 100.0d, 10, 500, 0.12d, 10.0d };
        double[] doubleArray22 = new double[] { 2.0d, 100.0d, 10, 500, 0.12d, 10.0d };
        double[][] doubleArray23 = new double[][] { doubleArray8, doubleArray15, doubleArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie 3D Plot", "TextBlockAnchor.TOP_LEFT", doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        dateAxis2.setLabelURL("");
        dateAxis2.setUpperBound((double) 0.0f);
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Color color13 = color12.darker();
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12, stroke14, (float) 1);
        dateAxis2.setLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot18);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot18.getLabelGenerator();
        java.awt.Font font21 = ringPlot18.getNoDataMessageFont();
        dateAxis2.setTickLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("ChartChangeEventType.NEW_DATASET", font21);
        java.awt.Color color24 = java.awt.Color.pink;
        org.jfree.chart.text.TextMeasurer textMeasurer27 = null;
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("", font21, (java.awt.Paint) color24, (float) (-1), (int) (byte) 0, textMeasurer27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str31 = verticalAlignment30.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, 0.0d, 0.025d);
        textBlock28.setLineAlignment(horizontalAlignment29);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.util.Size2D size2D37 = textBlock28.calculateDimensions(graphics2D36);
        double double38 = size2D37.height;
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color44 = java.awt.Color.YELLOW;
        java.awt.Color color45 = color44.darker();
        java.awt.Stroke stroke46 = null;
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color42, stroke43, (java.awt.Paint) color44, stroke46, (float) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = valueMarker48.getLabelAnchor();
        valueMarker48.setAlpha(0.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker48.setLabelAnchor(rectangleAnchor52);
        double double54 = valueMarker48.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = valueMarker48.getLabelAnchor();
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D37, (double) 15, (double) 100L, rectangleAnchor55);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str31.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(size2D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.0d + "'", double54 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setCategoryMargin((double) 100);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        boolean boolean6 = dateAxis5.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis5.setStandardTickUnits(tickUnitSource7);
        dateAxis5.setRange((-4.0d), (double) (short) -1);
        java.util.Date date12 = dateAxis5.getMinimumDate();
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0E-5d, (short) 10, 0L, (byte) 10, 100.0f, 0.4d };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.RELATIVE", "RectangleEdge.LEFT", numberArray23);
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame30 = textTitle29.getFrame();
        blockContainer27.setFrame(blockFrame30);
        java.awt.geom.Rectangle2D rectangle2D32 = blockContainer27.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.TOP;
        double double34 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) date12, (java.lang.Comparable) 0.14d, categoryDataset24, (-4.0d), rectangle2D32, rectangleEdge33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset24);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(blockFrame30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        ringPlot5.setPieIndex((int) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = ringPlot8.getLabelPadding();
        double double11 = rectangleInsets9.calculateRightInset((double) '#');
        ringPlot5.setSimpleLabelOffset(rectangleInsets9);
        flowArrangement1.add((org.jfree.chart.block.Block) textTitle3, (java.lang.Object) ringPlot5);
        java.awt.Paint paint14 = textTitle3.getBackgroundPaint();
        org.jfree.chart.block.BlockFrame blockFrame15 = textTitle3.getFrame();
        textTitle3.setText("");
        boolean boolean18 = lineBorder0.equals((java.lang.Object) textTitle3);
        java.awt.Stroke stroke19 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        dateAxis2.setLabelURL("");
        dateAxis2.setUpperBound((double) 0.0f);
        java.awt.Paint paint8 = dateAxis2.getAxisLinePaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        java.awt.Color color13 = color12.darker();
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12, stroke14, (float) 1);
        dateAxis2.setLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.centerRange(0.025d);
        java.awt.Stroke stroke21 = dateAxis18.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot22);
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Color color27 = java.awt.Color.getColor("", color26);
        ringPlot22.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color27);
        dateAxis18.setPlot((org.jfree.chart.plot.Plot) ringPlot22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = xYPlot31.getAxisOffset();
        java.awt.Paint paint33 = xYPlot31.getDomainTickBandPaint();
        java.awt.Paint paint34 = xYPlot31.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot31.getDomainMarkers(layer35);
        java.awt.Paint paint37 = xYPlot31.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat39 = dateAxis38.getDateFormatOverride();
        dateAxis38.setLabelURL("");
        dateAxis38.setUpperBound((double) 0.0f);
        xYPlot31.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis38);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis38, polarItemRenderer45);
        java.lang.Object obj47 = polarPlot46.clone();
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(dateFormat39);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        columnArrangement0.clear();
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 0);
        double double3 = range2.getUpperBound();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) 100L);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        dateAxis0.setUpperBound((double) 0.0f);
        java.awt.Paint paint6 = dateAxis0.getAxisLinePaint();
        java.awt.Shape shape7 = dateAxis0.getLeftArrow();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        double double12 = dateAxis11.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis11.setTickUnit(dateTickUnit13);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, 8, 2, (java.lang.Comparable) dateTickUnit13, "HorizontalAlignment.RIGHT", "hi!");
        java.lang.Comparable comparable18 = pieSectionEntity17.getSectionKey();
        java.awt.Shape shape19 = pieSectionEntity17.getArea();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(comparable18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.LEFT", "ThreadContext", "", "java.awt.Color[r=255,g=255,b=255]");
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        java.lang.String str2 = rotation0.toString();
        double double3 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Rotation.CLOCKWISE" + "'", str2.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        double double4 = numberAxis0.getLowerMargin();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets7.getTop();
        double double9 = rectangleInsets7.getRight();
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame14 = textTitle13.getFrame();
        blockContainer11.setFrame(blockFrame14);
        java.awt.geom.Rectangle2D rectangle2D16 = blockContainer11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets7.createOutsetRectangle(rectangle2D16, false, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double21 = rectangleInsets20.getTop();
        double double22 = rectangleInsets20.getRight();
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement23);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame27 = textTitle26.getFrame();
        blockContainer24.setFrame(blockFrame27);
        java.awt.geom.Rectangle2D rectangle2D29 = blockContainer24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets20.createOutsetRectangle(rectangle2D29, false, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            org.jfree.chart.axis.AxisState axisState35 = numberAxis0.draw(graphics2D5, 2.0d, rectangle2D16, rectangle2D32, rectangleEdge33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(blockFrame14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(blockFrame27);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Paint paint2 = dateAxis0.getAxisLinePaint();
        boolean boolean3 = dateAxis0.isVisible();
        java.awt.Font font4 = dateAxis0.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat6 = dateAxis5.getDateFormatOverride();
        dateAxis5.setLabelURL("");
        dateAxis5.setUpperBound((double) 0.0f);
        java.awt.Paint paint11 = dateAxis5.getAxisLinePaint();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color15 = java.awt.Color.YELLOW;
        java.awt.Color color16 = color15.darker();
        java.awt.Stroke stroke17 = null;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color13, stroke14, (java.awt.Paint) color15, stroke17, (float) 1);
        dateAxis5.setLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.centerRange(0.025d);
        java.awt.Stroke stroke24 = dateAxis21.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot25);
        java.awt.Color color29 = java.awt.Color.YELLOW;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        ringPlot25.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color30);
        dateAxis21.setPlot((org.jfree.chart.plot.Plot) ringPlot25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer33);
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        xYPlot34.setRangeAxisLocation((int) (short) 1, axisLocation36, false);
        java.awt.Paint paint39 = xYPlot34.getDomainTickBandPaint();
        org.jfree.chart.plot.RingPlot ringPlot40 = new org.jfree.chart.plot.RingPlot();
        int int41 = ringPlot40.getBackgroundImageAlignment();
        boolean boolean42 = ringPlot40.getIgnoreNullValues();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        ringPlot40.setLabelLinkPaint((java.awt.Paint) color43);
        java.awt.Color color45 = color43.darker();
        int int46 = color43.getBlue();
        xYPlot34.setDomainGridlinePaint((java.awt.Paint) color43);
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder((double) (byte) 10, (double) (byte) -1, 102.0d, (double) (byte) 10, (java.awt.Paint) color43);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 255 + "'", int46 == 255);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setLabelURL("");
        boolean boolean4 = dateAxis0.isAutoTickUnitSelection();
        double double5 = dateAxis0.getLowerMargin();
        dateAxis0.setVerticalTickLabels(false);
        java.awt.Paint paint8 = dateAxis0.getLabelPaint();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot10);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = ringPlot10.getLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        ringPlot10.setInsets(rectangleInsets13);
        double double15 = rectangleInsets13.getTop();
        double double17 = rectangleInsets13.extendWidth((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        double double19 = categoryAxis18.getCategoryMargin();
        boolean boolean20 = categoryAxis18.isAxisLineVisible();
        categoryAxis18.setCategoryMargin((double) 100);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        boolean boolean24 = dateAxis23.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis23.setStandardTickUnits(tickUnitSource25);
        dateAxis23.setRange((-4.0d), (double) (short) -1);
        java.util.Date date30 = dateAxis23.getMinimumDate();
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 1.0E-5d, (short) 10, 0L, (byte) 10, 100.0f, 0.4d };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.RELATIVE", "RectangleEdge.LEFT", numberArray41);
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement44);
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame48 = textTitle47.getFrame();
        blockContainer45.setFrame(blockFrame48);
        java.awt.geom.Rectangle2D rectangle2D50 = blockContainer45.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.TOP;
        double double52 = categoryAxis18.getCategorySeriesMiddle((java.lang.Comparable) date30, (java.lang.Comparable) 0.14d, categoryDataset42, (-4.0d), rectangle2D50, rectangleEdge51);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets13.createOutsetRectangle(rectangle2D50);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat56 = dateAxis55.getDateFormatOverride();
        dateAxis55.setLabelURL("");
        dateAxis55.setUpperBound((double) 0.0f);
        java.awt.Paint paint61 = dateAxis55.getAxisLinePaint();
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke64 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color65 = java.awt.Color.YELLOW;
        java.awt.Color color66 = color65.darker();
        java.awt.Stroke stroke67 = null;
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color63, stroke64, (java.awt.Paint) color65, stroke67, (float) 1);
        dateAxis55.setLabelPaint((java.awt.Paint) color65);
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        dateAxis71.centerRange(0.025d);
        java.awt.Stroke stroke74 = dateAxis71.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot75 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent76 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot75);
        java.awt.Color color79 = java.awt.Color.YELLOW;
        java.awt.Color color80 = java.awt.Color.getColor("", color79);
        ringPlot75.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color80);
        dateAxis71.setPlot((org.jfree.chart.plot.Plot) ringPlot75);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer83 = null;
        org.jfree.chart.plot.XYPlot xYPlot84 = new org.jfree.chart.plot.XYPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis71, xYItemRenderer83);
        org.jfree.chart.util.Layer layer85 = null;
        java.util.Collection collection86 = xYPlot84.getRangeMarkers(layer85);
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = xYPlot84.getRangeAxisEdge((int) (byte) 1);
        double double89 = dateAxis0.java2DToValue((double) 4, rectangle2D53, rectangleEdge88);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 102.0d + "'", double17 == 102.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(blockFrame48);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNull(dateFormat56);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNull(collection86);
        org.junit.Assert.assertNotNull(rectangleEdge88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + (-1.0d) + "'", double89 == (-1.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "TextBlockAnchor.TOP_LEFT", "WMAP_Plot", image3, "ThreadContext", "RectangleEdge.LEFT", "");
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = ringPlot8.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot8.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot8);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart12.getLegend((int) ' ');
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart12.createBufferedImage(500, (int) (short) 1);
        projectInfo7.setLogo((java.awt.Image) bufferedImage17);
        java.lang.String str19 = projectInfo7.toString();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + " version TextBlockAnchor.TOP_LEFT.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:WMAP_Plot\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n" + "'", str19.equals(" version TextBlockAnchor.TOP_LEFT.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:WMAP_Plot\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = ringPlot0.getLabelPadding();
        double double4 = ringPlot0.getExplodePercent((java.lang.Comparable) "WMAP_Plot");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean2 = dateAxis0.isInverted();
        dateAxis0.setNegativeArrowVisible(false);
        dateAxis0.setFixedDimension(0.025d);
        boolean boolean7 = dateAxis0.isPositiveArrowVisible();
        java.awt.Stroke stroke8 = dateAxis0.getTickMarkStroke();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        int int3 = ringPlot2.getBackgroundImageAlignment();
        ringPlot0.setParent((org.jfree.chart.plot.Plot) ringPlot2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot2.getURLGenerator();
        ringPlot2.setInnerSeparatorExtension(0.0d);
        double double8 = ringPlot2.getMaximumLabelWidth();
        ringPlot2.setLabelLinkMargin((double) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14d + "'", double8 == 0.14d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis0.getTickLabelInsets();
        dateAxis0.setTickMarkOutsideLength(0.0f);
        double double5 = dateAxis0.getUpperMargin();
        java.util.Date date6 = dateAxis0.getMaximumDate();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis0.getTickMarkPosition();
        java.text.DateFormat dateFormat8 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNull(dateFormat8);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.util.SortOrder sortOrder3 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Color color2 = java.awt.Color.getColor("Pie Plot", 8);
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        float[] floatArray7 = null;
        float[] floatArray8 = color2.getColorComponents(colorSpace6, floatArray7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color10 = java.awt.Color.YELLOW;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11);
        int int13 = color10.getBlue();
        java.awt.Color color16 = java.awt.Color.getColor("Pie Plot", 8);
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Color color19 = java.awt.Color.getColor("", color18);
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        float[] floatArray21 = null;
        float[] floatArray22 = color16.getColorComponents(colorSpace20, floatArray21);
        java.awt.Color color23 = java.awt.Color.pink;
        java.awt.Color color24 = color23.brighter();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Color color27 = java.awt.Color.getColor("", color26);
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        float[] floatArray32 = null;
        float[] floatArray33 = java.awt.Color.RGBtoHSB(15, (int) ' ', (int) ' ', floatArray32);
        float[] floatArray34 = color24.getComponents(colorSpace28, floatArray32);
        float[] floatArray35 = color10.getComponents(colorSpace20, floatArray34);
        float[] floatArray36 = color9.getComponents(floatArray34);
        float[] floatArray37 = color2.getRGBComponents(floatArray34);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        textTitle0.setFrame(blockFrame4);
        java.lang.Object obj6 = textTitle0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotChangeEvent1, jFreeChart2, chartChangeEventType3);
        org.jfree.chart.plot.Plot plot5 = plotChangeEvent1.getPlot();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isInverted();
        java.awt.Shape shape2 = dateAxis0.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleEdge.TOP", "java.awt.Color[r=255,g=255,b=255]");
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat9 = dateAxis8.getDateFormatOverride();
        dateAxis8.setLabelURL("");
        dateAxis8.setUpperBound((double) 0.0f);
        java.awt.Paint paint14 = dateAxis8.getAxisLinePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color18 = java.awt.Color.YELLOW;
        java.awt.Color color19 = color18.darker();
        java.awt.Stroke stroke20 = null;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color16, stroke17, (java.awt.Paint) color18, stroke20, (float) 1);
        dateAxis8.setLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot24);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = ringPlot24.getLabelGenerator();
        java.awt.Font font27 = ringPlot24.getNoDataMessageFont();
        dateAxis8.setTickLabelFont(font27);
        dateAxis8.setTickLabelsVisible(false);
        boolean boolean31 = dateAxis8.isVerticalTickLabels();
        int int32 = objectList7.indexOf((java.lang.Object) dateAxis8);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat34 = dateAxis33.getDateFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = dateAxis33.getTickLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat37 = dateAxis36.getDateFormatOverride();
        boolean boolean38 = dateAxis36.isInverted();
        dateAxis36.setNegativeArrowVisible(false);
        boolean boolean41 = dateAxis36.isAutoTickUnitSelection();
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setDownArrow(shape42);
        dateAxis33.setRightArrow(shape42);
        dateAxis8.setLeftArrow(shape42);
        chartEntity5.setArea(shape42);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0,0,2,-2,2,2,2,2" + "'", str6.equals("0,0,2,-2,2,2,2,2"));
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNull(dateFormat34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNull(dateFormat37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = color4.darker();
        java.awt.Stroke stroke6 = null;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color2, stroke3, (java.awt.Paint) color4, stroke6, (float) 1);
        java.awt.Paint paint9 = valueMarker8.getPaint();
        boolean boolean10 = blockBorder0.equals((java.lang.Object) valueMarker8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            blockBorder0.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame3 = textTitle2.getFrame();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        ringPlot4.setPieIndex((int) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = ringPlot7.getLabelPadding();
        double double10 = rectangleInsets8.calculateRightInset((double) '#');
        ringPlot4.setSimpleLabelOffset(rectangleInsets8);
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) ringPlot4);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = dateAxis13.isInverted();
        java.awt.Paint paint15 = dateAxis13.getAxisLinePaint();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(paint15);
        ringPlot4.setLabelPaint(paint15);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        boolean boolean45 = dateAxis44.isInverted();
        org.jfree.chart.axis.TickUnitSource tickUnitSource46 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis44.setStandardTickUnits(tickUnitSource46);
        int int48 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        org.jfree.chart.axis.AxisSpace axisSpace49 = xYPlot30.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(tickUnitSource46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNull(axisSpace49);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement3);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame7 = textTitle6.getFrame();
        blockContainer4.setFrame(blockFrame7);
        java.awt.geom.Rectangle2D rectangle2D9 = blockContainer4.getBounds();
        try {
            blockBorder1.draw(graphics2D2, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(blockFrame7);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle0.equals(obj3);
        java.lang.String str5 = textTitle0.getToolTipText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        textTitle0.setID("Pie Plot");
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot9.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = ringPlot9.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        int int14 = jFreeChart13.getSubtitleCount();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart13);
        java.awt.Image image16 = jFreeChart13.getBackgroundImage();
        jFreeChart13.setBorderVisible(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(image16);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle3.getFrame();
        blockContainer1.setFrame(blockFrame4);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.lang.String str7 = textTitle6.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle6.getHorizontalAlignment();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot9.getLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        ringPlot9.setInsets(rectangleInsets12);
        blockContainer1.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) ringPlot9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment15, verticalAlignment16, (double) 0, (double) '4');
        blockContainer1.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement19);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.awt.Font font23 = textTitle22.getFont();
        textTitle22.setHeight(1.0d);
        blockContainer1.add((org.jfree.chart.block.Block) textTitle22, (java.lang.Object) (-1.0d));
        java.lang.Object obj28 = null;
        boolean boolean29 = blockContainer1.equals(obj28);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        java.awt.Paint paint2 = ringPlot0.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot5.getLabelGenerator();
        java.lang.String str8 = ringPlot5.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlotState piePlotState11 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) ringPlot5, (java.lang.Integer) 10, plotRenderingInfo10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        ringPlot5.setSimpleLabelOffset(rectangleInsets12);
        ringPlot5.setNoDataMessage("HorizontalAlignment.RIGHT");
        org.jfree.chart.util.Rotation rotation16 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str17 = rotation16.toString();
        java.lang.String str18 = rotation16.toString();
        ringPlot5.setDirection(rotation16);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie Plot" + "'", str8.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(piePlotState11);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Rotation.CLOCKWISE" + "'", str17.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Rotation.CLOCKWISE" + "'", str18.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.String str1 = textTitle0.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle0.getHorizontalAlignment();
        java.lang.Object obj3 = null;
        boolean boolean4 = textTitle0.equals(obj3);
        java.lang.String str5 = textTitle0.getToolTipText();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        textTitle0.setID("Pie Plot");
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = ringPlot9.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = ringPlot9.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot9);
        int int14 = jFreeChart13.getSubtitleCount();
        textTitle0.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart13);
        jFreeChart13.setTextAntiAlias(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame2 = textTitle1.getFrame();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.lang.String str4 = textTitle3.getID();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle3.getHorizontalAlignment();
        textTitle1.setTextAlignment(horizontalAlignment5);
        java.lang.String str7 = horizontalAlignment5.toString();
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot0.getLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) ringPlot0);
        jFreeChart4.clearSubtitles();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("UnitType.RELATIVE");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getDomainMarkers(layer2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(collection3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.centerRange(0.025d);
        java.awt.Stroke stroke5 = dateAxis2.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot6);
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = java.awt.Color.getColor("", color10);
        ringPlot6.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color11);
        dateAxis2.setPlot((org.jfree.chart.plot.Plot) ringPlot6);
        java.util.Date date14 = dateAxis2.getMaximumDate();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) date14);
        boolean boolean16 = categoryAxis0.isVisible();
        java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelURL("");
        dateAxis1.setUpperBound((double) 0.0f);
        java.awt.Paint paint7 = dateAxis1.getAxisLinePaint();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        java.awt.Color color12 = color11.darker();
        java.awt.Stroke stroke13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color11, stroke13, (float) 1);
        dateAxis1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.centerRange(0.025d);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot21);
        java.awt.Color color25 = java.awt.Color.YELLOW;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        ringPlot21.setSectionPaint((java.lang.Comparable) 1.0d, (java.awt.Paint) color26);
        dateAxis17.setPlot((org.jfree.chart.plot.Plot) ringPlot21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot30.getAxisOffset();
        java.awt.Paint paint32 = xYPlot30.getDomainTickBandPaint();
        java.awt.Paint paint33 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = xYPlot30.getDomainMarkers(layer34);
        java.awt.Paint paint36 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat38 = dateAxis37.getDateFormatOverride();
        dateAxis37.setLabelURL("");
        dateAxis37.setUpperBound((double) 0.0f);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis37);
        xYPlot30.setWeight(0);
        boolean boolean46 = xYPlot30.isDomainZeroBaselineVisible();
        java.awt.Color color47 = java.awt.Color.YELLOW;
        org.jfree.chart.JFreeChart jFreeChart48 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color47, jFreeChart48);
        int int50 = color47.getBlue();
        java.awt.Color color51 = java.awt.Color.YELLOW;
        org.jfree.chart.JFreeChart jFreeChart52 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color51, jFreeChart52);
        int int54 = color51.getBlue();
        java.awt.Color color57 = java.awt.Color.getColor("Pie Plot", 8);
        java.awt.Color color59 = java.awt.Color.YELLOW;
        java.awt.Color color60 = java.awt.Color.getColor("", color59);
        java.awt.color.ColorSpace colorSpace61 = color60.getColorSpace();
        float[] floatArray62 = null;
        float[] floatArray63 = color57.getColorComponents(colorSpace61, floatArray62);
        java.awt.Color color64 = java.awt.Color.pink;
        java.awt.Color color65 = color64.brighter();
        java.awt.Color color67 = java.awt.Color.YELLOW;
        java.awt.Color color68 = java.awt.Color.getColor("", color67);
        java.awt.color.ColorSpace colorSpace69 = color68.getColorSpace();
        float[] floatArray73 = null;
        float[] floatArray74 = java.awt.Color.RGBtoHSB(15, (int) ' ', (int) ' ', floatArray73);
        float[] floatArray75 = color65.getComponents(colorSpace69, floatArray73);
        float[] floatArray76 = color51.getComponents(colorSpace61, floatArray75);
        float[] floatArray77 = color47.getComponents(floatArray76);
        xYPlot30.setBackgroundPaint((java.awt.Paint) color47);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(dateFormat38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(colorSpace61);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(colorSpace69);
        org.junit.Assert.assertNotNull(floatArray74);
        org.junit.Assert.assertNotNull(floatArray75);
        org.junit.Assert.assertNotNull(floatArray76);
        org.junit.Assert.assertNotNull(floatArray77);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setPieIndex((int) (short) 0);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = ringPlot3.getLabelPadding();
        double double6 = rectangleInsets4.calculateRightInset((double) '#');
        ringPlot0.setSimpleLabelOffset(rectangleInsets4);
        double double8 = ringPlot0.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.mapDatasetToRangeAxis(8, (int) (short) 1);
        categoryPlot0.clearAnnotations();
        java.util.List list5 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint7 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }
}

