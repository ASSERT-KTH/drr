import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=64,g=255,b=255]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', (double) 1L, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) -1, (float) (byte) 1, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-655360) + "'", int3 == (-655360));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) rectangleInsets1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets1.createOutsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, (int) (short) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int3 = java.awt.Color.HSBtoRGB(100.0f, (float) (byte) 1, (float) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3407872) + "'", int3 == (-3407872));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = null;
        try {
            xYPlot0.setNoDataMessageFont(font6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 500, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '#', (-9.0d), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot4.setAxisOffset(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot4.setDomainCrosshairStroke(stroke9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getRangeAxisEdge((int) ' ');
        try {
            double double13 = dateAxis1.java2DToValue((-9.0d), rectangle2D3, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.Plot plot7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot9.setAxisOffset(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot9.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot9.getRangeAxisEdge((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace19 = categoryAxis0.reserveSpace(graphics2D6, plot7, rectangle2D8, rectangleEdge17, axisSpace18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.setLowerBound(10.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.geom.Point2D point2D10 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        try {
            dateAxis1.setRangeAboutValue((double) (short) 1, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.5) <= upper (0.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker10.setLabelAnchor(rectangleAnchor13);
        categoryMarker10.setKey((java.lang.Comparable) 0L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        try {
            categoryMarker10.setLabelOffsetType(lengthAdjustmentType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) "", dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot12.setDomainCrosshairStroke(stroke17);
        xYPlot0.setRangeGridlineStroke(stroke17);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.util.List list22 = null;
        try {
            xYPlot0.drawDomainTickBands(graphics2D20, rectangle2D21, list22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot9.setAxisOffset(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot9.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot9.getRangeAxisEdge((int) ' ');
        try {
            java.util.List list18 = categoryAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (short) -1);
        double double4 = rectangleInsets0.extendHeight((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) 3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot7.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot7.setDataset((int) (byte) 10, xYDataset11);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot7.setNoDataMessageFont(font13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot7.setOutlineStroke(stroke15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot7.getRangeAxisEdge();
        try {
            double double18 = categoryAxis0.getCategoryStart((int) 'a', 4, rectangle2D6, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis9.setLowerBound((double) 0);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range12, false, true);
        dateAxis1.setRangeWithMargins(range12, false, false);
        dateAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=64,g=64,b=64]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=64,g=64,b=64]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot4.setDataset((int) (byte) 10, xYDataset8);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot4.setNoDataMessageFont(font10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot4.setOutlineStroke(stroke12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot4.getRangeAxisEdge();
        try {
            double double15 = numberAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (short) -1);
        double double4 = rectangleInsets0.extendWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.0d) + "'", double2 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis(10);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection8);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            boolean boolean16 = xYPlot0.removeAnnotation(xYAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            xYPlot0.drawOutline(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        xYPlot0.setRangeCrosshairValue(0.0d, false);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot0.drawBackgroundImage(graphics2D23, rectangle2D24);
        xYPlot0.setBackgroundImageAlpha((float) (byte) 0);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((-655360));
        categoryAxis0.setLabelToolTip("");
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            xYPlot0.handleClick(0, (int) (short) 0, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getBottom();
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 100, paint3, stroke4);
        boolean boolean6 = rectangleInsets0.equals((java.lang.Object) paint3);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis19.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color21);
        java.lang.String str23 = categoryAxis19.getLabelURL();
        int int24 = categoryAxis19.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset27 = xYPlot25.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot25.setDataset((int) (byte) 10, xYDataset29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.util.List list33 = null;
        xYPlot25.drawRangeTickBands(graphics2D31, rectangle2D32, list33);
        categoryAxis19.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot25);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset38 = xYPlot36.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis40.setLowerBound((double) 0);
        xYPlot36.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.data.Range range44 = xYPlot25.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis46.setLowerBound((double) 0);
        org.jfree.data.Range range49 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis46.setRange(range49, false, true);
        dateAxis40.setRange(range49, false, false);
        try {
            xYPlot0.setDomainAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) dateAxis40, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNull(xYDataset38);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { (-3407872) };
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.lang.String str26 = xYPlot6.getPlotType();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (-3407872), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        xYPlot0.setRangeCrosshairValue(0.0d, false);
        xYPlot0.zoom((double) 0.0f);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis1.draw(graphics2D2, 0.0d, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = xYPlot6.render(graphics2D9, rectangle2D10, (int) 'a', plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker16.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryMarker16.getLabelTextAnchor();
        boolean boolean22 = rectangleAnchor5.equals((java.lang.Object) textAnchor21);
        boolean boolean23 = day0.equals((java.lang.Object) rectangleAnchor5);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day0.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        try {
            java.awt.Paint paint16 = xYPlot0.getQuadrantPaint((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(255);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Color color1 = java.awt.Color.getColor("Layer.BACKGROUND");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke3 = categoryAxis0.getTickMarkStroke();
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot8.setAxisOffset(rectangleInsets11);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot8.setDomainCrosshairStroke(stroke13);
        java.lang.Object obj15 = xYPlot8.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot8.getDomainAxisEdge(8);
        try {
            double double18 = categoryAxis0.getCategoryMiddle(255, (int) ' ', rectangle2D7, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 100, "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        float[] floatArray5 = new float[] { (short) 1, 9 };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB((int) (byte) -1, (-12517377), 15, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.data.Range range8 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis13.setLowerBound((double) 0);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16, false, true);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis10.setRangeWithMargins(range20, true, true);
        dateAxis1.setRange(range20, true, true);
        java.text.DateFormat dateFormat27 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(dateFormat27);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        int int3 = color1.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker10.setLabelAnchor(rectangleAnchor13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int16 = color15.getRGB();
        categoryMarker10.setLabelPaint((java.awt.Paint) color15);
        java.awt.Paint paint18 = categoryMarker10.getOutlinePaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-12517377) + "'", int16 == (-12517377));
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            xYPlot0.handleClick((int) (byte) 10, 4, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        xYPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot0.getDataset(192);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(xYDataset7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot11.setAxisOffset(rectangleInsets14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setDomainCrosshairStroke(stroke16);
        java.lang.Object obj18 = xYPlot11.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot11.getDomainAxisEdge(8);
        try {
            double double21 = dateAxis1.valueToJava2D((double) (short) 1, rectangle2D10, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        java.util.Date date5 = day0.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 1.0d, (double) 255, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets9.createInsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.awt.Paint paint13 = categoryMarker8.getOutlinePaint();
        java.lang.String str14 = categoryMarker8.getLabel();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        java.awt.Stroke stroke15 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot16 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Object obj3 = null;
        boolean boolean4 = chartChangeEventType2.equals(obj3);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str4 = rectangleAnchor3.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-655360), (double) 10L, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.RIGHT" + "'", str4.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.text.TextAnchor textAnchor13 = categoryMarker8.getLabelTextAnchor();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str5 = categoryAxis4.getLabelToolTip();
        int int6 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = categoryAxis4.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis8.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color10);
        boolean boolean12 = categoryAxis8.isVisible();
        java.awt.Paint paint13 = categoryAxis8.getTickMarkPaint();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 100, paint15, stroke16);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color3, stroke7, paint13, stroke16, (float) (byte) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.CrosshairState crosshairState28 = null;
        boolean boolean29 = xYPlot21.render(graphics2D24, rectangle2D25, (int) 'a', plotRenderingInfo27, crosshairState28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot21.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker31, layer32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker31.setLabelAnchor(rectangleAnchor34);
        org.jfree.chart.text.TextAnchor textAnchor36 = categoryMarker31.getLabelTextAnchor();
        boolean boolean37 = rectangleAnchor20.equals((java.lang.Object) textAnchor36);
        boolean boolean38 = intervalMarker19.equals((java.lang.Object) boolean37);
        double double39 = intervalMarker19.getEndValue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = java.awt.Color.getColor("java.awt.Color[r=128,g=128,b=255]", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        xYPlot0.removeChangeListener(plotChangeListener8);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6);
        java.awt.Stroke stroke8 = xYPlot0.getRangeCrosshairStroke();
        java.lang.String str9 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "XY Plot" + "'", str9.equals("XY Plot"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis16.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color18);
        boolean boolean20 = categoryAxis16.isVisible();
        java.awt.Paint paint21 = categoryAxis16.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint21);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        java.awt.Paint paint10 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot0.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot20.setAxisOffset(rectangleInsets23);
        boolean boolean25 = rectangleAnchor19.equals((java.lang.Object) rectangleInsets23);
        xYPlot6.setAxisOffset(rectangleInsets23);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot27.getDataset((-655360));
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        xYPlot27.drawBackgroundImage(graphics2D30, rectangle2D31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot27.setRangeGridlineStroke(stroke33);
        xYPlot6.setRangeGridlineStroke(stroke33);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot12.setDomainCrosshairStroke(stroke17);
        xYPlot0.setRangeGridlineStroke(stroke17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot0.setRenderer(xYItemRenderer20);
        boolean boolean22 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleInsets5);
        double double8 = rectangleInsets4.calculateBottomInset((double) (byte) 10);
        categoryAxis0.setTickLabelInsets(rectangleInsets4);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot11.setDataset((int) (byte) 10, xYDataset15);
        xYPlot11.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = xYPlot11.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.CrosshairState crosshairState28 = null;
        boolean boolean29 = xYPlot21.render(graphics2D24, rectangle2D25, (int) 'a', plotRenderingInfo27, crosshairState28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot21.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker31, layer32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker31.setLabelAnchor(rectangleAnchor34);
        org.jfree.chart.text.TextAnchor textAnchor36 = categoryMarker31.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset39 = xYPlot37.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot37.setAxisOffset(rectangleInsets40);
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker43, layer44);
        boolean boolean47 = xYPlot11.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker31, layer44, false);
        xYPlot11.setWeight((int) (short) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray51 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer50 };
        xYPlot11.setRenderers(xYItemRendererArray51);
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset56 = xYPlot54.getDataset((-655360));
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        org.jfree.chart.plot.CrosshairState crosshairState61 = null;
        boolean boolean62 = xYPlot54.render(graphics2D57, rectangle2D58, (int) 'a', plotRenderingInfo60, crosshairState61);
        org.jfree.chart.plot.CategoryMarker categoryMarker64 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer65 = null;
        xYPlot54.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker64, layer65);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = xYPlot54.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace68 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace69 = categoryAxis0.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) xYPlot11, rectangle2D53, rectangleEdge67, axisSpace68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNull(xYDataset39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray51);
        org.junit.Assert.assertNull(xYDataset56);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        xYPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.lang.String str10 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.awt.Color color4 = color2.darker();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        dateAxis1.setRightArrow(shape14);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        java.lang.String str4 = categoryAxis0.getLabel();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        try {
            xYPlot0.setDataset((-1), xYDataset2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        boolean boolean3 = day0.equals((java.lang.Object) color2);
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset32 = xYPlot30.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot30.setAxisOffset(rectangleInsets33);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot30.setDomainCrosshairStroke(stroke35);
        java.lang.Object obj37 = xYPlot30.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot30.getDomainAxisEdge(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            org.jfree.chart.axis.AxisState axisState41 = dateAxis21.draw(graphics2D26, (double) 1, rectangle2D28, rectangle2D29, rectangleEdge39, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.awt.Paint paint6 = categoryMarker1.getOutlinePaint();
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.awt.Color color10 = color9.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str12 = categoryAxis11.getLabelToolTip();
        int int13 = categoryAxis11.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke14 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis15.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color17);
        boolean boolean19 = categoryAxis15.isVisible();
        java.awt.Paint paint20 = categoryAxis15.getTickMarkPaint();
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 100, paint22, stroke23);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color10, stroke14, paint20, stroke23, (float) (byte) 1);
        categoryMarker1.setStroke(stroke23);
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass29 = paint28.getClass();
        try {
            java.util.EventListener[] eventListenerArray30 = categoryMarker1.getListeners((java.lang.Class) wildcardClass29);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        boolean boolean4 = categoryAxis0.isVisible();
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setCategoryLabelPositionOffset((int) (short) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-3407872));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Stroke stroke8 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot10.setAxisOffset(rectangleInsets13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = xYPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
        java.lang.String str19 = layer17.toString();
        try {
            xYPlot0.addRangeMarker(marker9, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Layer.BACKGROUND" + "'", str19.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            xYPlot2.drawOutline(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        boolean boolean21 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        float float4 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot9.setDataset((int) (byte) 10, xYDataset13);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot9.setNoDataMessageFont(font15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot9.setOutlineStroke(stroke17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot9.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = numberAxis1.draw(graphics2D5, 100.0d, rectangle2D7, rectangle2D8, rectangleEdge19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        xYPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        xYPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot20.render(graphics2D23, rectangle2D24, (int) 'a', plotRenderingInfo26, crosshairState27);
        java.awt.Paint paint30 = xYPlot20.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset32 = xYPlot20.getDataset((-655360));
        valueMarker16.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot20);
        double double34 = valueMarker16.getValue();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot5.setDomainCrosshairStroke(stroke10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) ' ');
        try {
            java.util.List list14 = numberAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = xYPlot1.getDataset((-655360));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot1.render(graphics2D4, rectangle2D5, (int) 'a', plotRenderingInfo7, crosshairState8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot1.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker11.setLabelAnchor(rectangleAnchor14);
        try {
            java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        categoryAxis0.setLabelAngle((double) ' ');
        categoryAxis0.setUpperMargin(0.0d);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge();
        java.lang.String str11 = xYPlot0.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot0.getRangeAxisEdge();
        boolean boolean13 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        int int4 = xYPlot0.indexOf(xYDataset3);
        java.awt.Paint paint6 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        boolean boolean7 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker10.setLabelAnchor(rectangleAnchor13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int16 = color15.getRGB();
        categoryMarker10.setLabelPaint((java.awt.Paint) color15);
        java.awt.Stroke stroke18 = categoryMarker10.getOutlineStroke();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-12517377) + "'", int16 == (-12517377));
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot0.getDomainAxisEdge(8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot11.setDataset((int) (byte) 10, xYDataset15);
        xYPlot11.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = xYPlot11.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot22.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot22.setAxisOffset(rectangleInsets25);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot22.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker28, layer29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = xYPlot20.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker28, layer31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot20.setDomainAxisLocation(1, axisLocation34);
        boolean boolean36 = plotOrientation19.equals((java.lang.Object) axisLocation34);
        try {
            xYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(1.0d);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.calculateRightInset((double) 10L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets0.createInsetRectangle(rectangle2D6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = null;
        try {
            java.util.Date date19 = dateAxis10.calculateLowestVisibleTickValue(dateTickUnit18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.RIGHT");
        java.util.Date date2 = null;
        try {
            dateAxis1.setMinimumDate(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) 3);
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        dateAxis1.setRange((double) (-12517377), 0.05d);
        java.awt.Paint paint12 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        try {
            categoryMarker6.setAlpha((float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        try {
            xYPlot6.setRangeAxisLocation(axisLocation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        double double5 = rectangleInsets3.getTop();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        java.awt.Paint paint10 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot16.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot16.setDataset((int) (byte) 10, xYDataset20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.util.List list24 = null;
        xYPlot16.drawRangeTickBands(graphics2D22, rectangle2D23, list24);
        java.awt.Color color26 = java.awt.Color.BLACK;
        xYPlot16.setDomainTickBandPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 100, paint30, stroke31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot16.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker32, layer33, true);
        java.util.Collection collection36 = xYPlot0.getDomainMarkers(layer33);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace37, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation40 = null;
        try {
            boolean boolean42 = xYPlot0.removeAnnotation(xYAnnotation40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker10.setLabelAnchor(rectangleAnchor13);
        org.jfree.chart.text.TextAnchor textAnchor15 = categoryMarker10.getLabelTextAnchor();
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        java.lang.String str18 = color17.toString();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 100, paint20, stroke21);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color17, stroke21);
        boolean boolean24 = textAnchor15.equals((java.lang.Object) stroke21);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stroke21);
        org.jfree.chart.JFreeChart jFreeChart26 = chartChangeEvent25.getChart();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str18.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jFreeChart26);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(10, xYItemRenderer9, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            xYPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        try {
            numberAxis1.zoomRange((double) 0, (-9.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-9.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleInsets5);
        double double8 = rectangleInsets4.calculateBottomInset((double) (byte) 10);
        categoryAxis0.setTickLabelInsets(rectangleInsets4);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets4.getUnitType();
        java.lang.String str11 = rectangleInsets4.toString();
        double double13 = rectangleInsets4.calculateRightInset((double) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str11.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getCategoryLabelPositionOffset();
        java.lang.Comparable comparable2 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        java.awt.Color color19 = java.awt.Color.BLUE;
        java.awt.Color color20 = color19.brighter();
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) rectangleInsets1);
        double double4 = rectangleInsets0.calculateBottomInset((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot20.setAxisOffset(rectangleInsets23);
        boolean boolean25 = rectangleAnchor19.equals((java.lang.Object) rectangleInsets23);
        xYPlot6.setAxisOffset(rectangleInsets23);
        xYPlot6.setDomainCrosshairValue((double) 6, true);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.util.List list32 = null;
        xYPlot6.drawDomainTickBands(graphics2D30, rectangle2D31, list32);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot20.setAxisOffset(rectangleInsets23);
        boolean boolean25 = rectangleAnchor19.equals((java.lang.Object) rectangleInsets23);
        xYPlot6.setAxisOffset(rectangleInsets23);
        xYPlot6.setDomainCrosshairValue((double) 6, true);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot6.setFixedDomainAxisSpace(axisSpace30);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        double double3 = categoryAxis0.getUpperMargin();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot4.setAxisOffset(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot4.setDomainCrosshairStroke(stroke9);
        java.awt.Stroke stroke11 = xYPlot4.getRangeGridlineStroke();
        categoryAxis0.setTickMarkStroke(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleInsets5);
        double double8 = rectangleInsets4.calculateBottomInset((double) (byte) 10);
        categoryAxis0.setTickLabelInsets(rectangleInsets4);
        categoryAxis0.setLabelURL("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.awt.Paint paint6 = categoryMarker1.getOutlinePaint();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker1.setLabelFont(font7);
        float float9 = categoryMarker1.getAlpha();
        boolean boolean10 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.data.Range range8 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis13.setLowerBound((double) 0);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16, false, true);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis10.setRangeWithMargins(range20, true, true);
        dateAxis1.setRange(range20, true, true);
        dateAxis1.zoomRange(0.0d, (double) 6);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.lang.Comparable comparable5 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.data.Range range8 = dateAxis1.getRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = null;
        try {
            java.util.Date date10 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        java.awt.Stroke stroke15 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot0, jFreeChart16, chartChangeEventType17);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent2.setChart(jFreeChart4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        chartChangeEvent2.setChart(jFreeChart6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.lang.String str2 = color1.toString();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100, paint4, stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.CrosshairState crosshairState16 = null;
        boolean boolean17 = xYPlot9.render(graphics2D12, rectangle2D13, (int) 'a', plotRenderingInfo15, crosshairState16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer20 = null;
        xYPlot9.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker19, layer20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker19.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.text.TextAnchor textAnchor24 = categoryMarker19.getLabelTextAnchor();
        boolean boolean25 = rectangleAnchor8.equals((java.lang.Object) textAnchor24);
        categoryMarker7.setLabelAnchor(rectangleAnchor8);
        java.awt.Stroke stroke27 = categoryMarker7.getStroke();
        categoryMarker7.setLabel("hi!");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset((int) (byte) 0, xYDataset9);
        java.awt.Paint paint11 = xYPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint11);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        boolean boolean3 = day0.equals((java.lang.Object) color2);
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
//        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
//        java.awt.Graphics2D graphics2D9 = null;
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
//        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
//        boolean boolean14 = xYPlot6.render(graphics2D9, rectangle2D10, (int) 'a', plotRenderingInfo12, crosshairState13);
//        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
//        org.jfree.chart.util.Layer layer17 = null;
//        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
//        categoryMarker16.setLabelAnchor(rectangleAnchor19);
//        org.jfree.chart.text.TextAnchor textAnchor21 = categoryMarker16.getLabelTextAnchor();
//        boolean boolean22 = rectangleAnchor5.equals((java.lang.Object) textAnchor21);
//        boolean boolean23 = day0.equals((java.lang.Object) rectangleAnchor5);
//        int int24 = day0.getMonth();
//        int int25 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(rectangleAnchor5);
//        org.junit.Assert.assertNull(xYDataset8);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(rectangleAnchor19);
//        org.junit.Assert.assertNotNull(textAnchor21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis9.setLowerBound((double) 0);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range12, false, true);
        org.jfree.data.Range range16 = dateAxis9.getRange();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRange(range24, false, true);
        org.jfree.data.Range range28 = dateAxis21.getRange();
        dateAxis18.setRangeWithMargins(range28, true, true);
        dateAxis9.setRange(range28, true, true);
        boolean boolean35 = xYPlot0.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = xYPlot0.getDomainMarkers(layer36);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation38 = null;
        try {
            boolean boolean40 = xYPlot0.removeAnnotation(xYAnnotation38, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        boolean boolean3 = day0.equals((java.lang.Object) color2);
//        java.util.Date date4 = day0.getEnd();
//        long long5 = day0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(1.0d);
        double double3 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D4, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setInverted(false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        categoryMarker6.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot9);
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass12 = paint11.getClass();
        categoryMarker6.setLabelPaint(paint11);
        java.awt.Color color14 = java.awt.Color.YELLOW;
        categoryMarker6.setLabelPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.setLowerBound(10.0d);
        float float10 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.setLowerBound(4.0d);
        java.util.Date date13 = null;
        try {
            dateAxis1.setMinimumDate(date13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        try {
            java.util.Date date6 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset((int) (byte) 0, xYDataset9);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double15 = rectangleInsets13.trimWidth((double) (short) -1);
        categoryMarker12.setLabelOffset(rectangleInsets13);
        java.awt.Paint paint17 = categoryMarker12.getOutlinePaint();
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker12.setLabelFont(font18);
        float float20 = categoryMarker12.getAlpha();
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker12, layer21);
        java.lang.String str23 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-9.0d) + "'", double15 == (-9.0d));
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "XY Plot" + "'", str23.equals("XY Plot"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((-655360));
        boolean boolean3 = categoryAxis0.isVisible();
        categoryAxis0.configure();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot5.setDataset((int) (byte) 10, xYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot5.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        xYPlot5.setDomainTickBandPaint((java.awt.Paint) color15);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 100, paint19, stroke20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot5.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker21, layer22, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis25.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean31 = rectangleInsets29.equals((java.lang.Object) rectangleInsets30);
        double double33 = rectangleInsets29.calculateBottomInset((double) (byte) 10);
        categoryAxis25.setTickLabelInsets(rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateLeftOutset(1.0d);
        categoryAxis25.setTickLabelInsets(rectangleInsets35);
        valueMarker21.setLabelOffset(rectangleInsets35);
        org.jfree.chart.util.UnitType unitType40 = rectangleInsets35.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets35);
        java.awt.Paint paint42 = null;
        try {
            categoryAxis0.setLabelPaint(paint42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(unitType40);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYPlot0.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        java.lang.String str9 = plotOrientation8.toString();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PlotOrientation.VERTICAL" + "'", str9.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            xYPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis27.setLowerBound((double) 0);
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRange(range30, false, true);
        dateAxis21.setRange(range30, false, false);
        boolean boolean37 = dateAxis21.isVisible();
        java.util.Date date38 = dateAxis21.getMinimumDate();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        xYPlot39.setRangeCrosshairValue((double) 'a');
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        xYPlot39.drawAnnotations(graphics2D42, rectangle2D43, plotRenderingInfo44);
        dateAxis21.setPlot((org.jfree.chart.plot.Plot) xYPlot39);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color49 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis47.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color49);
        boolean boolean51 = categoryAxis47.isVisible();
        java.awt.Paint paint52 = categoryAxis47.getTickMarkPaint();
        xYPlot39.setDomainCrosshairPaint(paint52);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 2.0f, (double) 2.0f, (double) (byte) 10, (double) (short) 0);
        double double6 = rectangleInsets4.calculateLeftOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        java.awt.Color color13 = java.awt.Color.darkGray;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Comparable comparable0 = null;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot2.setDomainCrosshairStroke(stroke7);
        java.awt.Paint paint9 = null;
        java.awt.Stroke stroke10 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker(comparable0, (java.awt.Paint) color1, stroke7, paint9, stroke10, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot0.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot21.setDataset((int) (byte) 10, xYDataset25);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot21.setNoDataMessageFont(font27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        xYPlot21.setRenderer(10, xYItemRenderer30, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = xYPlot21.getOrientation();
        xYPlot0.setOrientation(plotOrientation33);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(plotOrientation33);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.lang.String str2 = color1.toString();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100, paint4, stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color1, stroke5);
        int int8 = color1.getTransparency();
        java.awt.color.ColorSpace colorSpace9 = null;
        float[] floatArray14 = new float[] { (-655360), 3, (-3407872), 0 };
        try {
            float[] floatArray15 = color1.getColorComponents(colorSpace9, floatArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        java.awt.Paint paint10 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot0.getDataset((-655360));
        xYPlot0.setBackgroundImageAlignment((-3407872));
        java.awt.Color color18 = java.awt.Color.BLUE;
        java.awt.Color color19 = color18.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str21 = categoryAxis20.getLabelToolTip();
        int int22 = categoryAxis20.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke23 = categoryAxis20.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis24.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color26);
        boolean boolean28 = categoryAxis24.isVisible();
        java.awt.Paint paint29 = categoryAxis24.getTickMarkPaint();
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 100, paint31, stroke32);
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color19, stroke23, paint29, stroke32, (float) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset38 = xYPlot36.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot36.setAxisOffset(rectangleInsets39);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean44 = xYPlot36.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker42, layer43);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset48 = xYPlot46.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis50.setLowerBound((double) 0);
        xYPlot46.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis50);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis55.setLowerBound((double) 0);
        org.jfree.data.Range range58 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis55.setRange(range58, false, true);
        org.jfree.data.Range range62 = dateAxis55.getRange();
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource65 = dateAxis64.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis67.setLowerBound((double) 0);
        org.jfree.data.Range range70 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis67.setRange(range70, false, true);
        org.jfree.data.Range range74 = dateAxis67.getRange();
        dateAxis64.setRangeWithMargins(range74, true, true);
        dateAxis55.setRange(range74, true, true);
        boolean boolean81 = xYPlot46.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection83 = xYPlot46.getDomainMarkers(layer82);
        java.util.Collection collection84 = xYPlot36.getRangeMarkers((int) (short) 10, layer82);
        xYPlot0.addRangeMarker((-3407872), (org.jfree.chart.plot.Marker) intervalMarker35, layer82, false);
        boolean boolean88 = intervalMarker35.equals((java.lang.Object) 15);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(xYDataset38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(xYDataset48);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(tickUnitSource65);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNull(collection83);
        org.junit.Assert.assertNull(collection84);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) 12.0d);
        java.lang.String str3 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryAnchor.END" + "'", str3.equals("CategoryAnchor.END"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot8.setDataset((int) (byte) 10, xYDataset12);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot8.setNoDataMessageFont(font14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot8.setOutlineStroke(stroke16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot8.getRangeAxisEdge();
        java.lang.String str19 = xYPlot8.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot8.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = numberAxis1.draw(graphics2D4, (double) (-12517377), rectangle2D6, rectangle2D7, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "XY Plot" + "'", str19.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(1.0d);
        double double3 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets0.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot18.getDataset((-655360));
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.CrosshairState crosshairState25 = null;
        boolean boolean26 = xYPlot18.render(graphics2D21, rectangle2D22, (int) 'a', plotRenderingInfo24, crosshairState25);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis28.setLowerBound((double) 0);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRange(range31, false, true);
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            xYPlot0.drawOutline(graphics2D37, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot20.render(graphics2D23, rectangle2D24, (int) 'a', plotRenderingInfo26, crosshairState27);
        java.awt.Paint paint30 = xYPlot20.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset32 = xYPlot20.getDataset((-655360));
        valueMarker16.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot20);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot20.getDomainAxis((int) 'a');
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertNull(valueAxis35);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.setLowerBound(10.0d);
        float float10 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.setRangeAboutValue((double) 0L, (double) 10L);
        boolean boolean14 = dateAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setDomainAxisLocation(255, axisLocation11, false);
        int int14 = xYPlot0.getDatasetCount();
        java.awt.Paint paint15 = xYPlot0.getOutlinePaint();
        try {
            java.awt.Paint paint17 = xYPlot0.getQuadrantPaint((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (35) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        java.lang.String str4 = categoryAxis0.getLabel();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        numberAxis1.setAutoRangeStickyZero(true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass3 = categoryAxis2.getClass();
        try {
            java.util.EventListener[] eventListenerArray4 = categoryMarker1.getListeners((java.lang.Class) wildcardClass3);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.axis.CategoryAxis; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        int int16 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot20.setDataset((int) (byte) 10, xYDataset24);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot20.setNoDataMessageFont(font26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot20.setOutlineStroke(stroke28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot20.getRangeAxisEdge();
        try {
            java.util.List list31 = dateAxis11.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent2.setType(chartChangeEventType3);
        java.lang.String str5 = chartChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]" + "'", str5.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        int int9 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot0.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setRangeAxisLocation(8, axisLocation26);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.lang.String str2 = color1.toString();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100, paint4, stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.CrosshairState crosshairState16 = null;
        boolean boolean17 = xYPlot9.render(graphics2D12, rectangle2D13, (int) 'a', plotRenderingInfo15, crosshairState16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer20 = null;
        xYPlot9.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker19, layer20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker19.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.text.TextAnchor textAnchor24 = categoryMarker19.getLabelTextAnchor();
        boolean boolean25 = rectangleAnchor8.equals((java.lang.Object) textAnchor24);
        categoryMarker7.setLabelAnchor(rectangleAnchor8);
        java.lang.String str27 = categoryMarker7.getLabel();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis28.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color30);
        categoryAxis28.setLowerMargin((double) '#');
        categoryAxis28.setCategoryMargin(1.0d);
        java.awt.Color color36 = java.awt.Color.LIGHT_GRAY;
        categoryAxis28.setAxisLinePaint((java.awt.Paint) color36);
        org.jfree.data.general.Dataset dataset38 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color36, dataset38);
        boolean boolean40 = categoryMarker7.equals((java.lang.Object) dataset38);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot0.handleClick(5, (int) (byte) 0, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setInverted(false);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CrosshairState crosshairState19 = null;
        boolean boolean20 = xYPlot12.render(graphics2D15, rectangle2D16, (int) 'a', plotRenderingInfo18, crosshairState19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot12.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        boolean boolean29 = xYPlot12.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        int int31 = xYPlot12.getIndexOf(xYItemRenderer30);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot12.getDataset(255);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot12.getDomainAxisEdge(0);
        try {
            double double36 = dateAxis4.java2DToValue((double) 8, rectangle2D11, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.Plot plot26 = xYPlot0.getRootPlot();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plot26);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot21.setAxisOffset(rectangleInsets24);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean29 = xYPlot21.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker27, layer28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = xYPlot19.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker27, layer30);
        java.lang.Object obj32 = null;
        boolean boolean33 = xYPlot19.equals(obj32);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 100, paint36, stroke37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean41 = xYPlot19.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker38, layer39, false);
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot19.getRangeAxisLocation(3);
        xYPlot6.setDomainAxisLocation((int) (short) 100, axisLocation43, true);
        java.awt.Color color46 = java.awt.Color.darkGray;
        xYPlot6.setDomainZeroBaselinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        numberAxis1.setUpperMargin((double) 10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit7, false, true);
        org.junit.Assert.assertNotNull(numberTickUnit7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color3);
        java.lang.String str5 = categoryAxis1.getLabelURL();
        int int6 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot7.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot7.setDataset((int) (byte) 10, xYDataset11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot7.drawRangeTickBands(graphics2D13, rectangle2D14, list15);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot7);
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot7.getDatasetGroup();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str21 = categoryAxis20.getLabelToolTip();
        int int22 = categoryAxis20.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis20.setTickLabelPaint((java.awt.Paint) chartColor26);
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) chartColor26);
        float[] floatArray36 = new float[] { 4, 100L, 100, 1.0f };
        float[] floatArray37 = java.awt.Color.RGBtoHSB(255, 5, (int) (short) 10, floatArray36);
        float[] floatArray38 = chartColor26.getColorComponents(floatArray37);
        float[] floatArray39 = color0.getRGBComponents(floatArray37);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        int int16 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets17.createInsetRectangle(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color4);
        java.lang.String str6 = categoryAxis2.getLabelURL();
        int int7 = categoryAxis2.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot8.setDataset((int) (byte) 10, xYDataset12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        categoryAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot8);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot19.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis23.setLowerBound((double) 0);
        xYPlot19.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.data.Range range27 = xYPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis29.setLowerBound((double) 0);
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRange(range32, false, true);
        dateAxis23.setRange(range32, false, false);
        boolean boolean39 = dateAxis23.isVisible();
        java.util.Date date40 = dateAxis23.getMinimumDate();
        dateAxis1.setMaximumDate(date40);
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = null;
        try {
            java.util.Date date43 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge();
        java.lang.String str11 = xYPlot0.getPlotType();
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        boolean boolean4 = categoryAxis0.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.CrosshairState crosshairState15 = null;
        boolean boolean16 = xYPlot8.render(graphics2D11, rectangle2D12, (int) 'a', plotRenderingInfo14, crosshairState15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = null;
        xYPlot8.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        xYPlot8.drawAnnotations(graphics2D21, rectangle2D22, plotRenderingInfo23);
        boolean boolean25 = xYPlot8.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        int int27 = xYPlot8.getIndexOf(xYItemRenderer26);
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot8.getDataset(255);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot8.getDomainAxisEdge(0);
        try {
            double double32 = categoryAxis0.getCategoryEnd(0, 255, rectangle2D7, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        java.awt.Paint paint10 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        double double5 = categoryAxis0.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str10 = categoryAxis9.getLabelToolTip();
        categoryAxis9.setTickMarkInsideLength((float) 3);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot13.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot13.setAxisOffset(rectangleInsets16);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot13.getRangeAxisEdge(0);
        try {
            double double21 = categoryAxis0.getCategoryMiddle((int) '4', (int) (short) 1, rectangle2D8, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        xYPlot0.setWeight((int) (short) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray40 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer39 };
        xYPlot0.setRenderers(xYItemRendererArray40);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setRangeAxes(valueAxisArray42);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation44 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray40);
        org.junit.Assert.assertNotNull(valueAxisArray42);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            java.awt.Color color1 = java.awt.Color.decode("CategoryAnchor.END");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CategoryAnchor.END\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis20.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color22);
        java.lang.String str24 = categoryAxis20.getLabelURL();
        int int25 = categoryAxis20.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot26.setDataset((int) (byte) 10, xYDataset30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot26.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        categoryAxis20.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot26);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset39 = xYPlot37.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis41.setLowerBound((double) 0);
        xYPlot37.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.data.Range range45 = xYPlot26.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis47.setLowerBound((double) 0);
        org.jfree.data.Range range50 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis47.setRange(range50, false, true);
        dateAxis41.setRange(range50, false, false);
        boolean boolean57 = dateAxis41.isVisible();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(xYDataset39);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot20.setAxisOffset(rectangleInsets23);
        boolean boolean25 = rectangleAnchor19.equals((java.lang.Object) rectangleInsets23);
        xYPlot6.setAxisOffset(rectangleInsets23);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            rectangleInsets23.trim(rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str5 = categoryAxis4.getLabelToolTip();
        int int6 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = categoryAxis4.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis8.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color10);
        boolean boolean12 = categoryAxis8.isVisible();
        java.awt.Paint paint13 = categoryAxis8.getTickMarkPaint();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 100, paint15, stroke16);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color3, stroke7, paint13, stroke16, (float) (byte) 1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer22);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot3.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot3.setDataset((int) (byte) 10, xYDataset7);
        xYPlot3.setNoDataMessage("");
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot3.getDomainAxis(12);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot3);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot16.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot16.setAxisOffset(rectangleInsets19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean24 = xYPlot16.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean26 = xYPlot14.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker22, layer25);
        java.awt.Stroke stroke27 = categoryMarker22.getOutlineStroke();
        xYPlot3.setDomainCrosshairStroke(stroke27);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.trimWidth((double) (short) -1);
        categoryMarker7.setLabelOffset(rectangleInsets8);
        java.awt.Paint paint12 = categoryMarker7.getOutlinePaint();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker7.setLabelFont(font13);
        xYPlot0.setNoDataMessageFont(font13);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        double double21 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.0d) + "'", double10 == (-9.0d));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        xYPlot6.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str20 = categoryAxis19.getLabelToolTip();
        int int21 = categoryAxis19.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor25 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis19.setTickLabelPaint((java.awt.Paint) chartColor25);
        xYPlot6.setRangeZeroBaselinePaint((java.awt.Paint) chartColor25);
        float[] floatArray35 = new float[] { 4, 100L, 100, 1.0f };
        float[] floatArray36 = java.awt.Color.RGBtoHSB(255, 5, (int) (short) 10, floatArray35);
        float[] floatArray37 = chartColor25.getColorComponents(floatArray36);
        float[] floatArray38 = null;
        float[] floatArray39 = chartColor25.getRGBColorComponents(floatArray38);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge();
        boolean boolean11 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        boolean boolean26 = dateAxis1.isVerticalTickLabels();
        java.awt.Shape shape27 = dateAxis1.getDownArrow();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.lang.Object obj6 = categoryMarker1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryMarker1.notifyListeners(markerChangeEvent7);
        java.awt.Paint paint9 = categoryMarker1.getOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.lang.String str2 = color1.toString();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100, paint4, stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.CrosshairState crosshairState16 = null;
        boolean boolean17 = xYPlot9.render(graphics2D12, rectangle2D13, (int) 'a', plotRenderingInfo15, crosshairState16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer20 = null;
        xYPlot9.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker19, layer20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker19.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.text.TextAnchor textAnchor24 = categoryMarker19.getLabelTextAnchor();
        boolean boolean25 = rectangleAnchor8.equals((java.lang.Object) textAnchor24);
        categoryMarker7.setLabelAnchor(rectangleAnchor8);
        java.awt.Stroke stroke27 = categoryMarker7.getStroke();
        java.awt.Paint paint28 = categoryMarker7.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot5.setDataset((int) (byte) 10, xYDataset9);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot5.setNoDataMessageFont(font11);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        java.awt.Paint paint14 = categoryAxis0.getLabelPaint();
        categoryAxis0.setVisible(true);
        categoryAxis0.setUpperMargin(1.0d);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double19 = rectangleInsets17.calculateBottomOutset(1.0d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets17.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets17);
        java.lang.String str22 = rectangleInsets17.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str22.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot0.getRangeAxis(255);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.data.Range range8 = dateAxis1.getRange();
        dateAxis1.setUpperMargin((double) (-1L));
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        int int26 = xYPlot0.getIndexOf(xYItemRenderer25);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 6, (double) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets3.trimWidth((double) (short) -1);
        intervalMarker2.setLabelOffset(rectangleInsets3);
        double double8 = rectangleInsets3.calculateRightInset((double) 9);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge();
        java.lang.String str11 = xYPlot0.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot0.getRangeAxisEdge();
        xYPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        java.util.Date date5 = day0.getStart();
        java.util.Calendar calendar6 = null;
        try {
            day0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        java.awt.Paint paint4 = categoryAxis0.getAxisLinePaint();
        int int5 = categoryAxis0.getCategoryLabelPositionOffset();
        boolean boolean6 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        double double10 = dateAxis4.getFixedAutoRange();
        java.awt.Paint paint11 = dateAxis4.getLabelPaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        java.lang.String str18 = color17.toString();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 100, paint20, stroke21);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color17, stroke21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset27 = xYPlot25.getDataset((-655360));
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.CrosshairState crosshairState32 = null;
        boolean boolean33 = xYPlot25.render(graphics2D28, rectangle2D29, (int) 'a', plotRenderingInfo31, crosshairState32);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer36 = null;
        xYPlot25.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker35, layer36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker35.setLabelAnchor(rectangleAnchor38);
        org.jfree.chart.text.TextAnchor textAnchor40 = categoryMarker35.getLabelTextAnchor();
        boolean boolean41 = rectangleAnchor24.equals((java.lang.Object) textAnchor40);
        categoryMarker23.setLabelAnchor(rectangleAnchor24);
        java.lang.String str43 = categoryMarker23.getLabel();
        boolean boolean44 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str18.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(rangeType4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = xYPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(datasetGroup12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRange(range7, false, true);
        org.jfree.data.Range range11 = dateAxis4.getRange();
        dateAxis1.setRangeWithMargins(range11, true, true);
        dateAxis1.setLowerMargin((double) (short) 10);
        boolean boolean17 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) 3);
        java.lang.Object obj4 = categoryAxis0.clone();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot5.setDomainCrosshairStroke(stroke10);
        java.lang.Object obj12 = xYPlot5.clone();
        int int13 = xYPlot5.getBackgroundImageAlignment();
        int int14 = xYPlot5.getDomainAxisCount();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot5);
        boolean boolean16 = xYPlot5.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis0.setLabelInsets(rectangleInsets1);
        boolean boolean4 = categoryAxis0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        boolean boolean3 = objectList0.equals((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        java.awt.Paint paint4 = categoryAxis0.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot8.setAxisOffset(rectangleInsets11);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot8.setDomainCrosshairStroke(stroke13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot8.getRangeAxisEdge((int) ' ');
        try {
            double double17 = categoryAxis0.getCategoryMiddle((-12517377), (int) (short) 10, rectangle2D7, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis39.setLowerBound((double) 0);
        try {
            xYPlot0.setDomainAxis((-12517377), (org.jfree.chart.axis.ValueAxis) dateAxis39, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        java.awt.Paint paint5 = dateAxis1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double19 = rectangleInsets17.calculateBottomOutset(1.0d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets17.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets17);
        categoryAxis0.setUpperMargin((double) (short) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(unitType20);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis6.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color8);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color8);
        int int11 = color8.getRed();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot0.getDatasetRenderingOrder();
        java.lang.String str19 = datasetRenderingOrder18.toString();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str19.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = xYPlot0.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot10.setDataset((int) (byte) 10, xYDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot10.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        java.awt.Color color20 = java.awt.Color.BLACK;
        xYPlot10.setDomainTickBandPaint((java.awt.Paint) color20);
        boolean boolean22 = xYPlot10.isOutlineVisible();
        int int23 = xYPlot10.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot10.getRangeAxisLocation(3);
        xYPlot0.setDomainAxisLocation(axisLocation25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYPlot0.drawBackgroundImage(graphics2D27, rectangle2D28);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.Color color1 = color0.brighter();
        int int2 = color1.getTransparency();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str5 = categoryAxis4.getLabelToolTip();
        int int6 = categoryAxis4.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis4.setTickLabelPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis4.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions12);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.configure();
        dateAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        double double10 = dateAxis1.getUpperBound();
        org.jfree.data.Range range11 = null;
        try {
            dateAxis1.setDefaultAutoRange(range11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 6, (double) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets3.trimWidth((double) (short) -1);
        intervalMarker2.setLabelOffset(rectangleInsets3);
        intervalMarker2.setLabel("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis6.setLowerBound((double) 0);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis6.setRange(range9, false, true);
        boolean boolean13 = dateAxis6.isAxisLineVisible();
        dateAxis6.setRange((double) (-12517377), 0.05d);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.setAxisLineVisible(false);
        double double27 = dateAxis21.getFixedAutoRange();
        java.awt.Shape shape28 = dateAxis21.getUpArrow();
        dateAxis6.setLeftArrow(shape28);
        numberAxis1.setUpArrow(shape28);
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setTickMarkInsideLength((float) (byte) 1);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        xYPlot0.clearAnnotations();
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) 3);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot4.setAxisOffset(rectangleInsets7);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot4.getOrientation();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        org.jfree.chart.JFreeChart jFreeChart37 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) '4', jFreeChart37, chartChangeEventType38);
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        chartChangeEvent39.setChart(jFreeChart40);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer16, false);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(axisLocation19);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = xYPlot3.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer14);
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot3.equals(obj16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot3.setRenderer((int) ' ', xYItemRenderer19, false);
        boolean boolean22 = categoryAxis0.hasListener((java.util.EventListener) xYPlot3);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot23.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot23.setDataset((int) (byte) 10, xYDataset27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.util.List list31 = null;
        xYPlot23.drawRangeTickBands(graphics2D29, rectangle2D30, list31);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot23.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation34 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation35 = axisLocation34.getOpposite();
        xYPlot23.setRangeAxisLocation(axisLocation35, false);
        java.awt.Stroke stroke38 = xYPlot23.getDomainZeroBaselineStroke();
        xYPlot3.setDomainZeroBaselineStroke(stroke38);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((-655360));
        boolean boolean3 = categoryAxis0.isVisible();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit12, true, false);
        org.jfree.data.Range range16 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis11);
        numberAxis11.setLowerMargin(3.0d);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        double double10 = dateAxis4.getFixedAutoRange();
        java.awt.Shape shape11 = dateAxis4.getUpArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis4.getTickUnit();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.util.Date date15 = day13.getEnd();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.CrosshairState crosshairState24 = null;
        boolean boolean25 = xYPlot17.render(graphics2D20, rectangle2D21, (int) 'a', plotRenderingInfo23, crosshairState24);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer28 = null;
        xYPlot17.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker27, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot17.getRangeAxisEdge();
        try {
            double double31 = dateAxis4.dateToJava2D(date15, rectangle2D16, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        boolean boolean4 = categoryAxis0.isVisible();
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setLowerMargin((double) 0L);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot12.setDomainCrosshairStroke(stroke17);
        xYPlot0.setRangeGridlineStroke(stroke17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot0.setRenderer(xYItemRenderer20);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleInsets5);
        double double8 = rectangleInsets4.calculateBottomInset((double) (byte) 10);
        categoryAxis0.setTickLabelInsets(rectangleInsets4);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateLeftOutset(1.0d);
        categoryAxis0.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis0.getTickLabelInsets();
        java.lang.Object obj15 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(10, xYItemRenderer9, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.awt.Paint paint13 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100, paint1, stroke2);
        java.awt.Color color4 = java.awt.Color.blue;
        valueMarker3.setOutlinePaint((java.awt.Paint) color4);
        double double6 = valueMarker3.getValue();
        float float7 = valueMarker3.getAlpha();
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker3.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        java.lang.String str2 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) 'a');
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setAutoRangeStickyZero(true);
        numberAxis5.configure();
        xYPlot0.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot0.getDataset();
        org.junit.Assert.assertNull(xYDataset11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = null;
        try {
            xYPlot6.setDatasetRenderingOrder(datasetRenderingOrder19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        xYPlot0.clearRangeAxes();
        xYPlot0.setDomainCrosshairValue((double) (byte) 10);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis4.setTickUnit(dateTickUnit10, true, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis4.getTickUnit();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(dateTickUnit14);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(1.0d);
        double double3 = rectangleInsets0.getTop();
        double double4 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis0.setTickLabelPaint((java.awt.Paint) chartColor6);
        java.lang.String str9 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass11 = categoryAxis10.getClass();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CrosshairState crosshairState19 = null;
        boolean boolean20 = xYPlot12.render(graphics2D15, rectangle2D16, (int) 'a', plotRenderingInfo18, crosshairState19);
        java.awt.Paint paint22 = xYPlot12.getQuadrantPaint((int) (byte) 1);
        boolean boolean23 = categoryAxis10.hasListener((java.util.EventListener) xYPlot12);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot12.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        xYPlot12.zoomRangeAxes((double) (-3407872), plotRenderingInfo27, point2D28);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        double double7 = rectangleInsets2.calculateLeftOutset((double) 3);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot12.setDomainCrosshairStroke(stroke17);
        xYPlot0.setRangeGridlineStroke(stroke17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot0.setRenderer(xYItemRenderer20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = xYPlot0.getRenderer(192);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemRenderer23);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getRed();
        java.lang.Class<?> wildcardClass2 = color0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        double double7 = rectangleInsets2.extendHeight(8.0d);
        double double9 = rectangleInsets2.trimHeight((double) 0.0f);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.0d + "'", double7 == 12.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-4.0d) + "'", double9 == (-4.0d));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        float float4 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        java.awt.Paint paint6 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis4.setTickUnit(dateTickUnit10, true, true);
        dateAxis4.setFixedAutoRange(2.0d);
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot0.getAxisOffset();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range34, false, true);
        boolean boolean38 = dateAxis31.isAxisLineVisible();
        dateAxis31.setRange((double) (-12517377), 0.05d);
        dateAxis31.setNegativeArrowVisible(true);
        dateAxis31.setPositiveArrowVisible(true);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        boolean boolean26 = dateAxis1.isVerticalTickLabels();
        java.awt.Paint paint27 = dateAxis1.getAxisLinePaint();
        dateAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis16.setLowerBound((double) 0);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range19, false, true);
        boolean boolean23 = dateAxis16.isAxisLineVisible();
        java.text.DateFormat dateFormat24 = null;
        dateAxis16.setDateFormatOverride(dateFormat24);
        org.jfree.data.Range range26 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.util.Date date27 = dateAxis16.getMaximumDate();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        java.awt.Paint paint10 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot0.getDataset((-655360));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            xYPlot0.handleClick(13, 8, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(1.0d);
        double double4 = rectangleInsets0.calculateTopOutset((double) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis3.setLowerBound((double) 0);
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRange(range6, false, true);
        dateAxis3.setLowerBound(10.0d);
        float float12 = dateAxis3.getTickMarkInsideLength();
        dateAxis3.setLowerBound(4.0d);
        boolean boolean15 = categoryAxis1.equals((java.lang.Object) 4.0d);
        int int16 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(10, xYItemRenderer9, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = xYPlot0.getOrientation();
        java.lang.String str13 = plotOrientation12.toString();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.VERTICAL" + "'", str13.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str25 = color24.toString();
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        boolean boolean36 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke37 = dateAxis32.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = xYPlot38.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot38.setDataset((int) (byte) 10, xYDataset42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot38.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Color color48 = java.awt.Color.BLACK;
        xYPlot38.setDomainTickBandPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot50.setAxisOffset(rectangleInsets53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot50.setDomainCrosshairStroke(stroke55);
        xYPlot38.setRangeGridlineStroke(stroke55);
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke37, stroke55 };
        java.awt.Shape[] shapeArray59 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray26, strokeArray27, strokeArray58, shapeArray59);
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation62 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str25.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYDataset40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        int int13 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str16 = seriesRenderingOrder15.toString();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder15);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str16.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis(10);
        int int8 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        boolean boolean26 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setAutoRangeMinimumSize((double) 100);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis30.setUpArrow(shape33);
        java.util.TimeZone timeZone35 = dateAxis30.getTimeZone();
        java.util.Date date36 = dateAxis30.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis38.setLowerBound((double) 0);
        java.util.TimeZone timeZone41 = dateAxis38.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date36, timeZone41);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day44.next();
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean47 = day44.equals((java.lang.Object) color46);
        java.util.Date date48 = day44.getEnd();
        java.util.Date date49 = day44.getStart();
        dateAxis1.setRange(date36, date49);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = xYPlot6.render(graphics2D9, rectangle2D10, (int) 'a', plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker16.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryMarker16.getLabelTextAnchor();
        boolean boolean22 = rectangleAnchor5.equals((java.lang.Object) textAnchor21);
        boolean boolean23 = day0.equals((java.lang.Object) rectangleAnchor5);
        java.util.Calendar calendar24 = null;
        try {
            day0.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRange(range5, false, true);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        dateAxis2.setRangeWithMargins(range13, false, false);
        boolean boolean21 = dateAxis2.isHiddenValue(0L);
        boolean boolean22 = lengthAdjustmentType0.equals((java.lang.Object) dateAxis2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        int int4 = xYPlot0.indexOf(xYDataset3);
        java.awt.Paint paint6 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        java.lang.String str7 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        boolean boolean9 = xYPlot0.isDomainZeroBaselineVisible();
        xYPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        xYPlot12.setDataset((int) (byte) 10, xYDataset16);
        xYPlot12.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = xYPlot12.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot23.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot23.setAxisOffset(rectangleInsets26);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean31 = xYPlot23.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29, layer30);
        org.jfree.chart.util.Layer layer32 = null;
        boolean boolean33 = xYPlot21.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker29, layer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(1, axisLocation35);
        boolean boolean37 = plotOrientation20.equals((java.lang.Object) axisLocation35);
        java.lang.String str38 = plotOrientation20.toString();
        xYPlot0.setOrientation(plotOrientation20);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PlotOrientation.VERTICAL" + "'", str38.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color11);
        java.lang.String str13 = categoryAxis9.getLabelURL();
        int int14 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot15.setDataset((int) (byte) 10, xYDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot15.drawRangeTickBands(graphics2D21, rectangle2D22, list23);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.data.Range range34 = xYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis36.setLowerBound((double) 0);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range39, false, true);
        dateAxis30.setRange(range39, false, false);
        boolean boolean46 = dateAxis30.isVisible();
        java.util.Date date47 = dateAxis30.getMinimumDate();
        dateAxis8.setMaximumDate(date47);
        dateAxis6.setMaximumDate(date47);
        org.jfree.chart.plot.Plot plot50 = dateAxis6.getPlot();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(plot50);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot2.getDomainAxis((-12517377));
        xYPlot2.clearAnnotations();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        int int4 = xYPlot0.indexOf(xYDataset3);
        java.awt.Paint paint6 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.general.Dataset dataset7 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint6, dataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        xYPlot0.setRangeCrosshairValue(0.0d, false);
        int int23 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisSpace axisSpace24 = xYPlot0.getFixedRangeAxisSpace();
        java.awt.Paint paint25 = xYPlot0.getOutlinePaint();
        java.awt.Paint paint26 = xYPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str25 = color24.toString();
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        boolean boolean36 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke37 = dateAxis32.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = xYPlot38.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot38.setDataset((int) (byte) 10, xYDataset42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot38.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Color color48 = java.awt.Color.BLACK;
        xYPlot38.setDomainTickBandPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot50.setAxisOffset(rectangleInsets53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot50.setDomainCrosshairStroke(stroke55);
        xYPlot38.setRangeGridlineStroke(stroke55);
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke37, stroke55 };
        java.awt.Shape[] shapeArray59 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray26, strokeArray27, strokeArray58, shapeArray59);
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset64 = xYPlot62.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        xYPlot62.setDataset((int) (byte) 10, xYDataset66);
        java.awt.Font font68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot62.setNoDataMessageFont(font68);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot62.setOutlineStroke(stroke70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = xYPlot62.getRangeAxisEdge();
        java.lang.String str73 = xYPlot62.getPlotType();
        boolean boolean74 = xYPlot62.isDomainZoomable();
        java.awt.Paint paint75 = xYPlot62.getNoDataMessagePaint();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot62);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = xYPlot0.getDomainAxisEdge((int) 'a');
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str25.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYDataset40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNull(xYDataset64);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "XY Plot" + "'", str73.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Color color2 = java.awt.Color.cyan;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot3.getDataset((-655360));
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CrosshairState crosshairState10 = null;
        boolean boolean11 = xYPlot3.render(graphics2D6, rectangle2D7, (int) 'a', plotRenderingInfo9, crosshairState10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer14 = null;
        xYPlot3.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13, layer14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker13.setLabelAnchor(rectangleAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor18 = categoryMarker13.getLabelTextAnchor();
        java.awt.Color color20 = java.awt.Color.DARK_GRAY;
        java.lang.String str21 = color20.toString();
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 100, paint23, stroke24);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color20, stroke24);
        boolean boolean27 = textAnchor18.equals((java.lang.Object) stroke24);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stroke24);
        java.awt.Color color29 = java.awt.Color.YELLOW;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot32.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot32.setAxisOffset(rectangleInsets35);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean40 = xYPlot32.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker38, layer39);
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean42 = xYPlot30.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker38, layer41);
        java.awt.Stroke stroke43 = categoryMarker38.getOutlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) 1.0f, (double) (byte) 100, (java.awt.Paint) color2, stroke24, (java.awt.Paint) color29, stroke43, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str21.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis0.setTickLabelPaint((java.awt.Paint) chartColor6);
        java.lang.String str9 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass11 = categoryAxis10.getClass();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CrosshairState crosshairState19 = null;
        boolean boolean20 = xYPlot12.render(graphics2D15, rectangle2D16, (int) 'a', plotRenderingInfo18, crosshairState19);
        java.awt.Paint paint22 = xYPlot12.getQuadrantPaint((int) (byte) 1);
        boolean boolean23 = categoryAxis10.hasListener((java.util.EventListener) xYPlot12);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot12.getAxisOffset();
        java.awt.Paint paint26 = xYPlot12.getNoDataMessagePaint();
        java.awt.Stroke stroke27 = xYPlot12.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer16, false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.util.List list21 = null;
        xYPlot0.drawRangeTickBands(graphics2D19, rectangle2D20, list21);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        java.lang.String str4 = categoryAxis0.getLabel();
        java.awt.Font font5 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(1.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot11.setAxisOffset(rectangleInsets14);
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean19 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = xYPlot9.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker17, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot9.setDomainAxisLocation(1, axisLocation23);
        boolean boolean25 = plotOrientation8.equals((java.lang.Object) axisLocation23);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot26.render(graphics2D29, rectangle2D30, (int) 'a', plotRenderingInfo32, crosshairState33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis36.setLowerBound((double) 0);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range39, false, true);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        dateAxis36.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource48 = dateAxis47.getStandardTickUnits();
        dateAxis36.setStandardTickUnits(tickUnitSource48);
        boolean boolean50 = plotOrientation8.equals((java.lang.Object) dateAxis36);
        org.jfree.data.Range range51 = dateAxis36.getRange();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(tickUnitSource48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(range51);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        dateAxis1.setRange((double) (byte) 1, (double) 8);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.trimWidth((double) (short) -1);
        categoryMarker7.setLabelOffset(rectangleInsets8);
        java.awt.Paint paint12 = categoryMarker7.getOutlinePaint();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker7.setLabelFont(font13);
        xYPlot0.setNoDataMessageFont(font13);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        boolean boolean21 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.0d) + "'", double10 == (-9.0d));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(1.0d);
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.calculateBottomInset((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.lang.String str2 = color1.toString();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100, paint4, stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot8.setDataset((int) (byte) 10, xYDataset12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Color color18 = java.awt.Color.BLACK;
        xYPlot8.setDomainTickBandPaint((java.awt.Paint) color18);
        boolean boolean20 = xYPlot8.isOutlineVisible();
        double double21 = xYPlot8.getDomainCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot22.getDataset((-655360));
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = xYPlot22.render(graphics2D25, rectangle2D26, (int) 'a', plotRenderingInfo28, crosshairState29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis32.setRange(range35, false, true);
        xYPlot22.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        dateAxis32.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = dateAxis43.getStandardTickUnits();
        dateAxis32.setStandardTickUnits(tickUnitSource44);
        dateAxis32.zoomRange((double) (-3407872), (double) 192);
        int int49 = xYPlot8.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis32);
        categoryMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        int int16 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot17.setDataset((int) (byte) 10, xYDataset21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot17.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis28.setTickUnit(numberTickUnit29, true, false);
        org.jfree.data.Range range33 = xYPlot17.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis28);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot17.setOutlineStroke(stroke34);
        xYPlot0.setRangeZeroBaselineStroke(stroke34);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(numberTickUnit29);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot0.getAxisOffset();
        double double28 = rectangleInsets26.extendHeight((double) 1560495599999L);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.560495600007E12d + "'", double28 == 1.560495600007E12d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        dateAxis1.setRightArrow(shape14);
        java.lang.String str17 = dateAxis1.getLabel();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource18);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str17.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(tickUnitSource18);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis16.setLowerBound((double) 0);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range19, false, true);
        boolean boolean23 = dateAxis16.isAxisLineVisible();
        java.text.DateFormat dateFormat24 = null;
        dateAxis16.setDateFormatOverride(dateFormat24);
        org.jfree.data.Range range26 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis16);
        boolean boolean28 = dateAxis16.equals((java.lang.Object) 15);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        xYPlot0.clearRangeAxes();
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color26);
        boolean boolean28 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis6.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color8);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color8);
        int int11 = color8.getRGB();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-16728064) + "'", int11 == (-16728064));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setDomainAxisLocation(255, axisLocation11, false);
        int int14 = xYPlot0.getDatasetCount();
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = xYPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker19, layer20);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        int int13 = xYPlot0.getDatasetCount();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot0.getDomainAxisForDataset(192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 192 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        java.awt.Image image15 = xYPlot0.getBackgroundImage();
        xYPlot0.setWeight(15);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperMargin(100.0d);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot20.setAxisOffset(rectangleInsets23);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean28 = xYPlot20.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer27);
        boolean boolean29 = dateAxis10.equals((java.lang.Object) categoryMarker26);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis31.setAutoRangeIncludesZero(false);
        float float34 = numberAxis31.getTickMarkOutsideLength();
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis31.setStandardTickUnits(tickUnitSource35);
        dateAxis10.setStandardTickUnits(tickUnitSource35);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 2.0f + "'", float34 == 2.0f);
        org.junit.Assert.assertNotNull(tickUnitSource35);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        xYPlot0.drawBackgroundImage(graphics2D12, rectangle2D13);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.CrosshairState crosshairState15 = null;
        boolean boolean16 = xYPlot8.render(graphics2D11, rectangle2D12, (int) 'a', plotRenderingInfo14, crosshairState15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = null;
        xYPlot8.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker18.setLabelAnchor(rectangleAnchor21);
        categoryMarker18.setKey((java.lang.Comparable) 0L);
        java.awt.Paint paint25 = categoryMarker18.getOutlinePaint();
        dateAxis4.setTickMarkPaint(paint25);
        java.awt.Shape shape27 = dateAxis4.getRightArrow();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        categoryMarker6.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot9);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            xYPlot9.addAnnotation(xYAnnotation11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis9.setLowerBound((double) 0);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range12, false, true);
        dateAxis1.setRangeWithMargins(range12, false, false);
        boolean boolean20 = dateAxis1.isHiddenValue(0L);
        java.awt.Stroke stroke21 = null;
        try {
            dateAxis1.setAxisLineStroke(stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis25.setLowerBound((double) 0);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis25.setUpArrow(shape28);
        dateAxis10.setLeftArrow(shape28);
        dateAxis10.setInverted(false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str9 = categoryAxis8.getLabelToolTip();
        int int10 = categoryAxis8.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis8.setTickLabelPaint((java.awt.Paint) chartColor14);
        java.lang.String str17 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass19 = categoryAxis18.getClass();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot20.render(graphics2D23, rectangle2D24, (int) 'a', plotRenderingInfo26, crosshairState27);
        java.awt.Paint paint30 = xYPlot20.getQuadrantPaint((int) (byte) 1);
        boolean boolean31 = categoryAxis18.hasListener((java.util.EventListener) xYPlot20);
        categoryAxis8.setPlot((org.jfree.chart.plot.Plot) xYPlot20);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot20.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection33);
        org.jfree.data.xy.XYDataset xYDataset36 = xYPlot0.getDataset((int) (byte) 100);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertNull(xYDataset36);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double19 = rectangleInsets17.calculateBottomOutset(1.0d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets17.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets17);
        java.awt.Paint paint22 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotOrientation.VERTICAL");
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str7 = color6.toString();
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color5, color6 };
        java.awt.Stroke[] strokeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        boolean boolean18 = dateAxis14.isPositiveArrowVisible();
        java.awt.Stroke stroke19 = dateAxis14.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        xYPlot20.setDataset((int) (byte) 10, xYDataset24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.util.List list28 = null;
        xYPlot20.drawRangeTickBands(graphics2D26, rectangle2D27, list28);
        java.awt.Color color30 = java.awt.Color.BLACK;
        xYPlot20.setDomainTickBandPaint((java.awt.Paint) color30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot32.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot32.setAxisOffset(rectangleInsets35);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot32.setDomainCrosshairStroke(stroke37);
        xYPlot20.setRangeGridlineStroke(stroke37);
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke19, stroke37 };
        java.awt.Shape[] shapeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray4, paintArray8, strokeArray9, strokeArray40, shapeArray41);
        java.lang.Object obj43 = defaultDrawingSupplier42.clone();
        java.awt.Paint paint44 = defaultDrawingSupplier42.getNextPaint();
        categoryAxis1.setLabelPaint(paint44);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str7.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(shapeArray41);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setFixedDimension((double) 1);
        numberAxis1.setAutoRangeIncludesZero(false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis19.setLowerBound((double) 0);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range22, false, true);
        org.jfree.data.Range range26 = dateAxis19.getRange();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis28.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range34, false, true);
        org.jfree.data.Range range38 = dateAxis31.getRange();
        dateAxis28.setRangeWithMargins(range38, true, true);
        dateAxis19.setRange(range38, true, true);
        boolean boolean45 = xYPlot10.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = xYPlot10.getDomainMarkers(layer46);
        java.util.Collection collection48 = xYPlot0.getRangeMarkers((int) (short) 10, layer46);
        xYPlot0.setRangeGridlinesVisible(true);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        try {
            xYPlot0.drawBackground(graphics2D51, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNull(collection48);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str25 = color24.toString();
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        boolean boolean36 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke37 = dateAxis32.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = xYPlot38.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot38.setDataset((int) (byte) 10, xYDataset42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot38.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Color color48 = java.awt.Color.BLACK;
        xYPlot38.setDomainTickBandPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot50.setAxisOffset(rectangleInsets53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot50.setDomainCrosshairStroke(stroke55);
        xYPlot38.setRangeGridlineStroke(stroke55);
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke37, stroke55 };
        java.awt.Shape[] shapeArray59 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray26, strokeArray27, strokeArray58, shapeArray59);
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        java.awt.Stroke stroke62 = defaultDrawingSupplier60.getNextStroke();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str25.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYDataset40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        boolean boolean3 = xYPlot0.isDomainZeroBaselineVisible();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font4);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace20, true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        int int25 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeIncludesZero(false);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot3.getDataset((-655360));
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CrosshairState crosshairState10 = null;
        boolean boolean11 = xYPlot3.render(graphics2D6, rectangle2D7, (int) 'a', plotRenderingInfo9, crosshairState10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis13.setLowerBound((double) 0);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16, false, true);
        xYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        dateAxis13.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = dateAxis24.getStandardTickUnits();
        dateAxis13.setStandardTickUnits(tickUnitSource25);
        dateAxis13.zoomRange((double) (-3407872), (double) 192);
        java.awt.Shape shape30 = dateAxis13.getRightArrow();
        numberAxis0.setRightArrow(shape30);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getDomainAxis(12);
        xYPlot0.setRangeCrosshairVisible(true);
        java.awt.Color color13 = java.awt.Color.green;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot14.getDataset((-655360));
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot14.render(graphics2D17, rectangle2D18, (int) 'a', plotRenderingInfo20, crosshairState21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis24.setLowerBound((double) 0);
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRange(range27, false, true);
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 1560495599999L, (java.awt.Paint) color13, stroke32);
        xYPlot0.setRangeCrosshairStroke(stroke32);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        boolean boolean26 = dateAxis1.isVerticalTickLabels();
        java.awt.Paint paint27 = dateAxis1.getAxisLinePaint();
        dateAxis1.resizeRange(0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) 'a');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        xYPlot0.drawAnnotations(graphics2D3, rectangle2D4, plotRenderingInfo5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot0.getAxisOffset();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str5 = categoryAxis4.getLabelToolTip();
        int int6 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = categoryAxis4.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis8.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color10);
        boolean boolean12 = categoryAxis8.isVisible();
        java.awt.Paint paint13 = categoryAxis8.getTickMarkPaint();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 100, paint15, stroke16);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color3, stroke7, paint13, stroke16, (float) (byte) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.CrosshairState crosshairState28 = null;
        boolean boolean29 = xYPlot21.render(graphics2D24, rectangle2D25, (int) 'a', plotRenderingInfo27, crosshairState28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot21.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker31, layer32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker31.setLabelAnchor(rectangleAnchor34);
        org.jfree.chart.text.TextAnchor textAnchor36 = categoryMarker31.getLabelTextAnchor();
        boolean boolean37 = rectangleAnchor20.equals((java.lang.Object) textAnchor36);
        boolean boolean38 = intervalMarker19.equals((java.lang.Object) boolean37);
        intervalMarker19.setEndValue(0.0d);
        intervalMarker19.setStartValue(0.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(1.0d);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        double double5 = rectangleInsets0.calculateBottomInset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        xYPlot6.setDomainCrosshairLockedOnData(true);
        xYPlot6.clearRangeMarkers();
        java.awt.Stroke stroke29 = xYPlot6.getDomainCrosshairStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = xYPlot6.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis19.setLowerBound((double) 0);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range22, false, true);
        org.jfree.data.Range range26 = dateAxis19.getRange();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis28.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range34, false, true);
        org.jfree.data.Range range38 = dateAxis31.getRange();
        dateAxis28.setRangeWithMargins(range38, true, true);
        dateAxis19.setRange(range38, true, true);
        boolean boolean45 = xYPlot10.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = xYPlot10.getDomainMarkers(layer46);
        java.util.Collection collection48 = xYPlot0.getRangeMarkers((int) (short) 10, layer46);
        int int49 = xYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 15 + "'", int49 == 15);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.setLowerBound(10.0d);
        float float10 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.setLowerBound(4.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis14.setRange(range17, false, true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis22.setLowerBound((double) 0);
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis22.setRange(range25, false, true);
        dateAxis14.setRangeWithMargins(range25, false, false);
        dateAxis1.setRange(range25);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis34.setLowerBound((double) 0);
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis34.setRange(range37, false, true);
        dateAxis34.setLowerBound(10.0d);
        float float43 = dateAxis34.getTickMarkInsideLength();
        dateAxis34.setRangeAboutValue((double) 0L, (double) 10L);
        org.jfree.data.Range range47 = dateAxis34.getRange();
        dateAxis1.setDefaultAutoRange(range47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset55 = xYPlot53.getDataset((-655360));
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.plot.CrosshairState crosshairState60 = null;
        boolean boolean61 = xYPlot53.render(graphics2D56, rectangle2D57, (int) 'a', plotRenderingInfo59, crosshairState60);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer64 = null;
        xYPlot53.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer64);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot53.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        try {
            org.jfree.chart.axis.AxisState axisState68 = dateAxis1.draw(graphics2D49, 12.0d, rectangle2D51, rectangle2D52, rectangleEdge66, plotRenderingInfo67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(xYDataset55);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        boolean boolean16 = xYPlot0.isRangeCrosshairVisible();
        java.awt.geom.Point2D point2D17 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        boolean boolean16 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint17 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation18 = null;
        try {
            boolean boolean20 = xYPlot0.removeAnnotation(xYAnnotation18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRange(range5, false, true);
        dateAxis2.setLowerBound(10.0d);
        float float11 = dateAxis2.getTickMarkInsideLength();
        dateAxis2.setLowerBound(4.0d);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis15.setLowerBound((double) 0);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRange(range18, false, true);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis23.setLowerBound((double) 0);
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis23.setRange(range26, false, true);
        dateAxis15.setRangeWithMargins(range26, false, false);
        dateAxis2.setRange(range26);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis35.setLowerBound((double) 0);
        dateAxis35.setLowerBound((double) 500);
        boolean boolean40 = dateAxis35.isPositiveArrowVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer41);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = xYPlot3.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer14);
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot3.equals(obj16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot3.setRenderer((int) ' ', xYItemRenderer19, false);
        boolean boolean22 = categoryAxis0.hasListener((java.util.EventListener) xYPlot3);
        double double23 = xYPlot3.getDomainCrosshairValue();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        xYPlot3.drawAnnotations(graphics2D24, rectangle2D25, plotRenderingInfo26);
        java.awt.Stroke stroke28 = xYPlot3.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color11);
        java.lang.String str13 = categoryAxis9.getLabelURL();
        int int14 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot15.setDataset((int) (byte) 10, xYDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot15.drawRangeTickBands(graphics2D21, rectangle2D22, list23);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.data.Range range34 = xYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis36.setLowerBound((double) 0);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range39, false, true);
        dateAxis30.setRange(range39, false, false);
        boolean boolean46 = dateAxis30.isVisible();
        java.util.Date date47 = dateAxis30.getMinimumDate();
        dateAxis8.setMaximumDate(date47);
        dateAxis6.setMaximumDate(date47);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.CrosshairState crosshairState57 = null;
        boolean boolean58 = xYPlot50.render(graphics2D53, rectangle2D54, (int) 'a', plotRenderingInfo56, crosshairState57);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot50.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker60, layer61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        xYPlot50.drawAnnotations(graphics2D63, rectangle2D64, plotRenderingInfo65);
        boolean boolean67 = xYPlot50.isDomainCrosshairVisible();
        dateAxis6.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot50);
        xYPlot50.clearAnnotations();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 100, jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart1, jFreeChart3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        xYPlot6.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str20 = categoryAxis19.getLabelToolTip();
        int int21 = categoryAxis19.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor25 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis19.setTickLabelPaint((java.awt.Paint) chartColor25);
        xYPlot6.setRangeZeroBaselinePaint((java.awt.Paint) chartColor25);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = xYPlot6.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        dateAxis1.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((-655360));
        boolean boolean3 = categoryAxis0.isVisible();
        categoryAxis0.configure();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color9);
        java.lang.String str11 = categoryAxis7.getLabelURL();
        int int12 = categoryAxis7.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot13.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot13.setDataset((int) (byte) 10, xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.util.List list21 = null;
        xYPlot13.drawRangeTickBands(graphics2D19, rectangle2D20, list21);
        categoryAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot13);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset26 = xYPlot24.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis28.setLowerBound((double) 0);
        xYPlot24.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.data.Range range32 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis34.setLowerBound((double) 0);
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis34.setRange(range37, false, true);
        dateAxis28.setRange(range37, false, false);
        boolean boolean44 = dateAxis28.isVisible();
        java.util.Date date45 = dateAxis28.getMinimumDate();
        dateAxis6.setMaximumDate(date45);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) date45, "");
        categoryAxis0.configure();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot0.getRendererForDataset(xYDataset27);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(xYItemRenderer28);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            xYPlot0.drawOutline(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        double double7 = rectangleInsets2.extendHeight(8.0d);
        double double9 = rectangleInsets2.calculateLeftInset((double) 1);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.0d + "'", double7 == 12.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0E-8d, (double) 10L, 2.0d, (double) (-1.0f));
        double double7 = rectangleInsets5.calculateBottomInset((double) (-1));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=64,g=255,b=255]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str25 = color24.toString();
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        boolean boolean36 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke37 = dateAxis32.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = xYPlot38.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot38.setDataset((int) (byte) 10, xYDataset42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot38.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Color color48 = java.awt.Color.BLACK;
        xYPlot38.setDomainTickBandPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot50.setAxisOffset(rectangleInsets53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot50.setDomainCrosshairStroke(stroke55);
        xYPlot38.setRangeGridlineStroke(stroke55);
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke37, stroke55 };
        java.awt.Shape[] shapeArray59 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray26, strokeArray27, strokeArray58, shapeArray59);
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot63 = categoryAxis62.getPlot();
        java.awt.Stroke stroke64 = categoryAxis62.getAxisLineStroke();
        boolean boolean65 = defaultDrawingSupplier60.equals((java.lang.Object) stroke64);
        java.awt.Stroke stroke66 = defaultDrawingSupplier60.getNextStroke();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str25.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYDataset40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNull(plot63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str25 = color24.toString();
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        boolean boolean36 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke37 = dateAxis32.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = xYPlot38.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot38.setDataset((int) (byte) 10, xYDataset42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot38.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Color color48 = java.awt.Color.BLACK;
        xYPlot38.setDomainTickBandPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot50.setAxisOffset(rectangleInsets53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot50.setDomainCrosshairStroke(stroke55);
        xYPlot38.setRangeGridlineStroke(stroke55);
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke37, stroke55 };
        java.awt.Shape[] shapeArray59 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray26, strokeArray27, strokeArray58, shapeArray59);
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace64);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str25.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYDataset40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge((int) ' ');
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        java.awt.Paint paint20 = xYPlot10.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot10.getDataset((-655360));
        xYPlot10.setBackgroundImageAlignment((-3407872));
        java.awt.Color color28 = java.awt.Color.BLUE;
        java.awt.Color color29 = color28.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str31 = categoryAxis30.getLabelToolTip();
        int int32 = categoryAxis30.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke33 = categoryAxis30.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis34.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color36);
        boolean boolean38 = categoryAxis34.isVisible();
        java.awt.Paint paint39 = categoryAxis34.getTickMarkPaint();
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 100, paint41, stroke42);
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color29, stroke33, paint39, stroke42, (float) (byte) 1);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset48 = xYPlot46.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot46.setAxisOffset(rectangleInsets49);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean54 = xYPlot46.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer53);
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset58 = xYPlot56.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis60.setLowerBound((double) 0);
        xYPlot56.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis60);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis65.setLowerBound((double) 0);
        org.jfree.data.Range range68 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis65.setRange(range68, false, true);
        org.jfree.data.Range range72 = dateAxis65.getRange();
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource75 = dateAxis74.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis77.setLowerBound((double) 0);
        org.jfree.data.Range range80 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis77.setRange(range80, false, true);
        org.jfree.data.Range range84 = dateAxis77.getRange();
        dateAxis74.setRangeWithMargins(range84, true, true);
        dateAxis65.setRange(range84, true, true);
        boolean boolean91 = xYPlot56.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection93 = xYPlot56.getDomainMarkers(layer92);
        java.util.Collection collection94 = xYPlot46.getRangeMarkers((int) (short) 10, layer92);
        xYPlot10.addRangeMarker((-3407872), (org.jfree.chart.plot.Marker) intervalMarker45, layer92, false);
        org.jfree.chart.util.Layer layer97 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot0.addDomainMarker((int) (byte) 100, (org.jfree.chart.plot.Marker) intervalMarker45, layer97);
        java.awt.Paint paint99 = intervalMarker45.getLabelPaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(xYDataset48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(xYDataset58);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(tickUnitSource75);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertNotNull(range84);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertNull(collection93);
        org.junit.Assert.assertNull(collection94);
        org.junit.Assert.assertNotNull(layer97);
        org.junit.Assert.assertNotNull(paint99);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        categoryAxis0.setCategoryMargin((double) 0.5f);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset((int) (byte) 0, xYDataset9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) '4', 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        java.awt.Shape shape10 = dateAxis4.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = dateAxis12.getStandardTickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis12.getTickUnit();
        dateAxis4.setTickUnit(dateTickUnit14, true, true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(dateTickUnit14);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis19.setLowerBound((double) 0);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range22, false, true);
        org.jfree.data.Range range26 = dateAxis19.getRange();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis28.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range34, false, true);
        org.jfree.data.Range range38 = dateAxis31.getRange();
        dateAxis28.setRangeWithMargins(range38, true, true);
        dateAxis19.setRange(range38, true, true);
        boolean boolean45 = xYPlot10.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = xYPlot10.getDomainMarkers(layer46);
        java.util.Collection collection48 = xYPlot0.getRangeMarkers((int) (short) 10, layer46);
        java.lang.String str49 = layer46.toString();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Layer.FOREGROUND" + "'", str49.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis6.setLowerBound((double) 0);
        xYPlot2.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        boolean boolean10 = dateAxis6.isPositiveArrowVisible();
        double double11 = dateAxis6.getLowerMargin();
        boolean boolean12 = seriesRenderingOrder0.equals((java.lang.Object) dateAxis6);
        java.lang.Object obj13 = null;
        boolean boolean14 = seriesRenderingOrder0.equals(obj13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        boolean boolean4 = categoryAxis0.isVisible();
        java.awt.Paint paint6 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (-655360));
        categoryAxis0.setFixedDimension((double) 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = xYPlot1.getDataset((-655360));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot1.render(graphics2D4, rectangle2D5, (int) 'a', plotRenderingInfo7, crosshairState8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot1.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker11.setLabelAnchor(rectangleAnchor14);
        boolean boolean16 = lengthAdjustmentType0.equals((java.lang.Object) rectangleAnchor14);
        java.lang.String str17 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(xYDataset3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CONTRACT" + "'", str17.equals("CONTRACT"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.START" + "'", str1.equals("CategoryAnchor.START"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 0, (double) (-1L), (double) 100L, (-4.0d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot2.getRangeAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        int int9 = xYPlot0.getDomainAxisCount();
        xYPlot0.clearDomainMarkers((-3407872));
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str6 = categoryAxis5.getLabelToolTip();
        categoryAxis5.setTickMarkInsideLength((float) 3);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot9.setAxisOffset(rectangleInsets12);
        categoryAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot9);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot9.getRangeAxisEdge(0);
        try {
            double double17 = categoryAxis0.getCategoryMiddle(15, (int) '4', rectangle2D4, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot17.setAxisOffset(rectangleInsets20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot17.setDomainCrosshairStroke(stroke22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot17.setRenderer(xYItemRenderer24);
        java.awt.geom.Point2D point2D26 = xYPlot17.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (-3407872), plotRenderingInfo16, point2D26, false);
        boolean boolean29 = xYPlot0.isOutlineVisible();
        boolean boolean30 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue((double) (-12517377), rectangle2D5, rectangleEdge6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit9, true, true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberTickUnit9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = xYPlot0.getDomainCrosshairStroke();
        boolean boolean20 = xYPlot0.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot0.getRendererForDataset(xYDataset21);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(xYItemRenderer22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 1.0E-8d, (double) 10L, 2.0d, (double) (-1.0f));
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot19.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis23.setLowerBound((double) 0);
        xYPlot19.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis28.setLowerBound((double) 0);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRange(range31, false, true);
        org.jfree.data.Range range35 = dateAxis28.getRange();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = dateAxis37.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis40.setLowerBound((double) 0);
        org.jfree.data.Range range43 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis40.setRange(range43, false, true);
        org.jfree.data.Range range47 = dateAxis40.getRange();
        dateAxis37.setRangeWithMargins(range47, true, true);
        dateAxis28.setRange(range47, true, true);
        boolean boolean54 = xYPlot19.equals((java.lang.Object) true);
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot19.getRangeAxisLocation();
        xYPlot0.setRangeAxisLocation(64, axisLocation55, false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        java.lang.Class<?> wildcardClass2 = dateAxis1.getClass();
        dateAxis1.centerRange((double) 1.0f);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        java.awt.Paint paint17 = xYPlot0.getDomainTickBandPaint();
        java.awt.Paint paint18 = null;
        try {
            xYPlot0.setRangeCrosshairPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue((double) (-12517377), rectangle2D5, rectangleEdge6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1);
        numberAxis1.setAutoRange(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        xYPlot12.setDataset((int) (byte) 10, xYDataset16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.util.List list20 = null;
        xYPlot12.drawRangeTickBands(graphics2D18, rectangle2D19, list20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot12.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot12.setFixedRangeAxisSpace(axisSpace23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot26.setDataset((int) (byte) 10, xYDataset30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot26.setFixedDomainAxisSpace(axisSpace32);
        xYPlot26.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot26.getRangeAxisEdge((-16728064));
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace38 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) xYPlot12, rectangle2D25, rectangleEdge36, axisSpace37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        dateAxis4.setUpperMargin((double) 0.5f);
        org.junit.Assert.assertNull(xYDataset2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color3);
        categoryAxis1.setLowerMargin((double) '#');
        categoryAxis1.setCategoryMargin(1.0d);
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint12 = null;
        java.awt.Color color15 = java.awt.Color.BLUE;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str18 = categoryAxis17.getLabelToolTip();
        int int19 = categoryAxis17.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke20 = categoryAxis17.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color23);
        boolean boolean25 = categoryAxis21.isVisible();
        java.awt.Paint paint26 = categoryAxis21.getTickMarkPaint();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100, paint28, stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color16, stroke20, paint26, stroke29, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(Double.NEGATIVE_INFINITY, (java.awt.Paint) color9, stroke11, paint12, stroke29, 0.0f);
        java.awt.Paint paint35 = valueMarker34.getPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier8);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis12.getMarkerBand();
        java.text.NumberFormat numberFormat16 = null;
        numberAxis12.setNumberFormatOverride(numberFormat16);
        xYPlot0.setDomainAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis12, true);
        numberAxis12.setInverted(false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(markerAxisBand15);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis20.setLowerBound((double) 0);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis20.setRange(range23, false, true);
        boolean boolean27 = dateAxis20.isAxisLineVisible();
        double double28 = dateAxis20.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot31.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot31.setAxisOffset(rectangleInsets34);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = xYPlot31.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker37, layer38);
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean41 = xYPlot29.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker37, layer40);
        java.awt.Font font42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker37.setLabelFont(font42);
        dateAxis20.setTickLabelFont(font42);
        boolean boolean45 = dateAxis20.isVerticalTickLabels();
        java.awt.Paint paint46 = dateAxis20.getAxisLinePaint();
        xYPlot0.setDomainTickBandPaint(paint46);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.RIGHT");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot4.setAxisOffset(rectangleInsets7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot4.setDomainCrosshairStroke(stroke9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getRangeAxisEdge((int) ' ');
        try {
            double double13 = dateAxis1.valueToJava2D(12.0d, rectangle2D3, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot5.setDataset((int) (byte) 10, xYDataset9);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot5.setNoDataMessageFont(font11);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        boolean boolean14 = xYPlot5.isDomainZoomable();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.setLowerMargin((double) 10.0f);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        int int13 = xYPlot0.getDatasetCount();
        xYPlot0.setWeight(500);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setMaximumCategoryLabelLines(15);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis27.setLowerBound((double) 0);
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRange(range30, false, true);
        dateAxis21.setRange(range30, false, false);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis38.setLowerBound((double) 0);
        org.jfree.data.Range range41 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis38.setRange(range41, false, true);
        org.jfree.data.Range range45 = dateAxis38.getRange();
        dateAxis21.setRangeWithMargins(range45, true, false);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis50.getStandardTickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = dateAxis50.getTickUnit();
        java.util.Date date53 = dateAxis21.calculateHighestVisibleTickValue(dateTickUnit52);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertNotNull(date53);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleInsets5);
        double double8 = rectangleInsets4.calculateBottomInset((double) (byte) 10);
        categoryAxis0.setTickLabelInsets(rectangleInsets4);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets4.getUnitType();
        java.lang.String str11 = unitType10.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) 11, (double) 9, (double) 10, (double) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType10, 12.0d, (double) 8, (double) (-1), (double) 12);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont();
        double double3 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis2.setLabelInsets(rectangleInsets3);
        int int5 = objectList0.indexOf((java.lang.Object) rectangleInsets3);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        int int4 = categoryAxis2.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis2.setTickLabelPaint((java.awt.Paint) chartColor8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color12);
        java.lang.String str14 = categoryAxis10.getLabelURL();
        int int15 = categoryAxis10.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot16.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot16.setDataset((int) (byte) 10, xYDataset20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.util.List list24 = null;
        xYPlot16.drawRangeTickBands(graphics2D22, rectangle2D23, list24);
        categoryAxis10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot16);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot27.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        xYPlot27.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.jfree.data.Range range35 = xYPlot16.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis31);
        xYPlot16.setDomainCrosshairLockedOnData(true);
        xYPlot16.clearRangeMarkers();
        java.awt.Stroke stroke39 = xYPlot16.getDomainCrosshairStroke();
        java.awt.Color color40 = java.awt.Color.lightGray;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str42 = categoryAxis41.getLabelToolTip();
        int int43 = categoryAxis41.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke44 = categoryAxis41.getTickMarkStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) (short) 0, (java.awt.Paint) chartColor8, stroke39, (java.awt.Paint) color40, stroke44, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.awt.Paint paint6 = categoryMarker1.getOutlinePaint();
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.awt.Color color10 = color9.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str12 = categoryAxis11.getLabelToolTip();
        int int13 = categoryAxis11.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke14 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis15.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color17);
        boolean boolean19 = categoryAxis15.isVisible();
        java.awt.Paint paint20 = categoryAxis15.getTickMarkPaint();
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 100, paint22, stroke23);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color10, stroke14, paint20, stroke23, (float) (byte) 1);
        categoryMarker1.setStroke(stroke23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot29.getDataset((-655360));
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.plot.CrosshairState crosshairState36 = null;
        boolean boolean37 = xYPlot29.render(graphics2D32, rectangle2D33, (int) 'a', plotRenderingInfo35, crosshairState36);
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer40 = null;
        xYPlot29.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker39, layer40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker39.setLabelAnchor(rectangleAnchor42);
        boolean boolean44 = lengthAdjustmentType28.equals((java.lang.Object) rectangleAnchor42);
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType28);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot47 = categoryAxis46.getPlot();
        double double48 = categoryAxis46.getFixedDimension();
        categoryAxis46.configure();
        java.awt.Paint paint50 = categoryAxis46.getAxisLinePaint();
        boolean boolean51 = categoryMarker1.equals((java.lang.Object) paint50);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType28);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            xYPlot0.handleClick(3, 4, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        boolean boolean9 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean10 = xYPlot0.isOutlineVisible();
        java.awt.Color color12 = java.awt.Color.DARK_GRAY;
        java.lang.String str13 = color12.toString();
        try {
            xYPlot0.setQuadrantPaint((int) (short) 100, (java.awt.Paint) color12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str13.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.trimWidth((double) (short) -1);
        categoryMarker7.setLabelOffset(rectangleInsets8);
        java.awt.Paint paint12 = categoryMarker7.getOutlinePaint();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker7.setLabelFont(font13);
        xYPlot0.setNoDataMessageFont(font13);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = xYPlot0.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot20.render(graphics2D23, rectangle2D24, (int) 'a', plotRenderingInfo26, crosshairState27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        org.jfree.data.Range range33 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis30.setRange(range33, false, true);
        xYPlot20.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        dateAxis30.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = dateAxis41.getStandardTickUnits();
        dateAxis30.setStandardTickUnits(tickUnitSource42);
        dateAxis30.zoomRange((double) (-3407872), (double) 192);
        java.awt.Shape shape47 = dateAxis30.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis49.setLowerBound((double) 0);
        dateAxis49.setLowerBound((double) 500);
        boolean boolean54 = dateAxis49.isPositiveArrowVisible();
        org.jfree.chart.axis.Timeline timeline55 = dateAxis49.getTimeline();
        dateAxis30.setTimeline(timeline55);
        xYPlot0.setDomainAxis(1, (org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.0d) + "'", double10 == (-9.0d));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(timeline55);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        boolean boolean3 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot4.setDataset((int) (byte) 10, xYDataset8);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot4.setNoDataMessageFont(font10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot4.setOutlineStroke(stroke12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot4.getRangeAxisEdge();
        java.lang.String str15 = xYPlot4.getPlotType();
        boolean boolean16 = xYPlot4.isDomainZoomable();
        categoryMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "XY Plot" + "'", str15.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis3.setLowerBound((double) 0);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=255,b=255]", timeZone6);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis18.setLowerBound((double) 0);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRange(range21, false, true);
        dateAxis10.setRangeWithMargins(range21, false, false);
        dateAxis8.setDefaultAutoRange(range21);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        int int13 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getRangeAxisLocation(3);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot16.getDataset((-655360));
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.CrosshairState crosshairState23 = null;
        boolean boolean24 = xYPlot16.render(graphics2D19, rectangle2D20, (int) 'a', plotRenderingInfo22, crosshairState23);
        java.awt.Paint paint26 = xYPlot16.getQuadrantPaint((int) (byte) 1);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot31.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        xYPlot31.setDataset((int) (byte) 10, xYDataset35);
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot31.setNoDataMessageFont(font37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        xYPlot31.setRenderer(10, xYItemRenderer40, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = xYPlot31.getOrientation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset49 = xYPlot47.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        xYPlot47.setDataset((int) (byte) 10, xYDataset51);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        java.util.List list55 = null;
        xYPlot47.drawRangeTickBands(graphics2D53, rectangle2D54, list55);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot47.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation59 = axisLocation58.getOpposite();
        xYPlot47.setRangeAxisLocation(axisLocation59, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset66 = xYPlot64.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot64.setAxisOffset(rectangleInsets67);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot64.setDomainCrosshairStroke(stroke69);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        xYPlot64.setRenderer(xYItemRenderer71);
        java.awt.geom.Point2D point2D73 = xYPlot64.getQuadrantOrigin();
        xYPlot47.zoomRangeAxes((double) (-3407872), plotRenderingInfo63, point2D73, false);
        xYPlot31.zoomRangeAxes((double) (-1.0f), (double) (-1L), plotRenderingInfo46, point2D73);
        xYPlot16.zoomDomainAxes((double) (-655360), (double) (byte) 0, plotRenderingInfo30, point2D73);
        xYPlot0.setQuadrantOrigin(point2D73);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertNull(xYDataset49);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNull(xYDataset66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(point2D73);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue((double) (-12517377), rectangle2D5, rectangleEdge6);
        numberAxis1.configure();
        numberAxis1.resizeRange(1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        double double8 = xYPlot0.getDomainCrosshairValue();
        boolean boolean9 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        categoryAxis0.setLowerMargin((double) '#');
        categoryAxis0.setCategoryMargin(1.0d);
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color8);
        categoryAxis0.setMaximumCategoryLabelLines(10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRange(range7, false, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis12.setLowerBound((double) 0);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRange(range15, false, true);
        dateAxis4.setRangeWithMargins(range15, false, false);
        dateAxis1.setRangeWithMargins(range15);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean26 = day23.equals((java.lang.Object) color25);
        java.util.Date date27 = day23.getEnd();
        java.util.Date date28 = day23.getStart();
        dateAxis1.setMaximumDate(date28);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setDomainAxisLocation(255, axisLocation11, false);
        java.awt.Stroke stroke14 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double19 = rectangleInsets17.calculateBottomOutset(1.0d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets17.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets17);
        java.lang.Comparable comparable22 = null;
        try {
            java.awt.Paint paint23 = categoryAxis0.getTickLabelPaint(comparable22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
        org.junit.Assert.assertNotNull(unitType20);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
        java.lang.Object obj6 = null;
        int int7 = day0.compareTo(obj6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str5 = categoryAxis4.getLabelToolTip();
        int int6 = categoryAxis4.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke7 = categoryAxis4.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis8.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color10);
        boolean boolean12 = categoryAxis8.isVisible();
        java.awt.Paint paint13 = categoryAxis8.getTickMarkPaint();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 100, paint15, stroke16);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color3, stroke7, paint13, stroke16, (float) (byte) 1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer20);
        java.lang.Object obj22 = intervalMarker19.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer23);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = null;
        intervalMarker19.setGradientPaintTransformer(gradientPaintTransformer25);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis20.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleInsets25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (byte) 10);
        categoryAxis20.setTickLabelInsets(rectangleInsets24);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double32 = rectangleInsets30.calculateLeftOutset(1.0d);
        categoryAxis20.setTickLabelInsets(rectangleInsets30);
        valueMarker16.setLabelOffset(rectangleInsets30);
        org.jfree.chart.util.UnitType unitType35 = rectangleInsets30.getUnitType();
        org.jfree.chart.util.UnitType unitType36 = rectangleInsets30.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets(unitType36, (double) (short) 100, (double) 10, (double) 1560409200000L, (double) 64);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertNotNull(unitType35);
        org.junit.Assert.assertNotNull(unitType36);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = xYPlot3.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer14);
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot3.equals(obj16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot3.setRenderer((int) ' ', xYItemRenderer19, false);
        boolean boolean22 = categoryAxis0.hasListener((java.util.EventListener) xYPlot3);
        boolean boolean23 = xYPlot3.isDomainZeroBaselineVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation24 = null;
        try {
            xYPlot3.addAnnotation(xYAnnotation24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        xYPlot0.setRangeCrosshairValue(0.0d, false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot0.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        numberAxis1.setAxisLineVisible(true);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot9.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot9.setAxisOffset(rectangleInsets12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot9.setDomainCrosshairStroke(stroke14);
        java.lang.Object obj16 = xYPlot9.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot9.getDomainAxisEdge(8);
        try {
            double double19 = numberAxis1.valueToJava2D((double) (-1L), rectangle2D8, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand4);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = xYPlot1.getDataset((-655360));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot1.render(graphics2D4, rectangle2D5, (int) 'a', plotRenderingInfo7, crosshairState8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot1.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker11.setLabelAnchor(rectangleAnchor14);
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryMarker11.getLabelTextAnchor();
        boolean boolean17 = rectangleAnchor0.equals((java.lang.Object) textAnchor16);
        java.lang.String str18 = textAnchor16.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(xYDataset3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextAnchor.CENTER" + "'", str18.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot4.setAxisOffset(rectangleInsets7);
        boolean boolean9 = rectangleAnchor3.equals((java.lang.Object) rectangleInsets7);
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 1, (double) 1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = xYPlot6.render(graphics2D9, rectangle2D10, (int) 'a', plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker16.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryMarker16.getLabelTextAnchor();
        boolean boolean22 = rectangleAnchor5.equals((java.lang.Object) textAnchor21);
        boolean boolean23 = day0.equals((java.lang.Object) rectangleAnchor5);
        int int24 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day0.previous();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot26.setDataset((int) (byte) 10, xYDataset30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot26.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Color color36 = java.awt.Color.BLACK;
        xYPlot26.setDomainTickBandPaint((java.awt.Paint) color36);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 100, paint40, stroke41);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot26.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker42, layer43, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis46.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean52 = rectangleInsets50.equals((java.lang.Object) rectangleInsets51);
        double double54 = rectangleInsets50.calculateBottomInset((double) (byte) 10);
        categoryAxis46.setTickLabelInsets(rectangleInsets50);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double58 = rectangleInsets56.calculateLeftOutset(1.0d);
        categoryAxis46.setTickLabelInsets(rectangleInsets56);
        valueMarker42.setLabelOffset(rectangleInsets56);
        boolean boolean61 = day0.equals((java.lang.Object) rectangleInsets56);
        int int62 = day0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 4.0d + "'", double58 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        xYPlot2.setDomainCrosshairVisible(true);
        int int16 = xYPlot2.getSeriesCount();
        xYPlot2.setDomainCrosshairValue((double) 9);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        java.util.Date date5 = day0.getStart();
        java.util.Date date6 = day0.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis3.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean9 = rectangleInsets7.equals((java.lang.Object) rectangleInsets8);
        double double11 = rectangleInsets7.calculateBottomInset((double) (byte) 10);
        categoryAxis3.setTickLabelInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double15 = rectangleInsets13.calculateLeftOutset(1.0d);
        categoryAxis3.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis3.getTickLabelInsets();
        numberAxis1.setTickLabelInsets(rectangleInsets17);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

