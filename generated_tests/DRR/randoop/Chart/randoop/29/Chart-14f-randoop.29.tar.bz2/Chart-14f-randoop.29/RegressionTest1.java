import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        xYPlot0.setWeight((int) (short) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray40 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer39 };
        xYPlot0.setRenderers(xYItemRendererArray40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot0.getRenderer();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection45 = xYPlot0.getRangeMarkers((int) '4', layer44);
        java.lang.Object obj46 = null;
        boolean boolean47 = layer44.equals(obj46);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray40);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        xYPlot0.setRenderer(xYItemRenderer7);
        xYPlot0.setDomainCrosshairValue(0.0d, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setUpArrow(shape4);
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        java.util.Date date7 = dateAxis1.getMaximumDate();
        dateAxis1.configure();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis9.setLowerBound((double) 0);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range12, false, true);
        org.jfree.data.Range range16 = dateAxis9.getRange();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRange(range24, false, true);
        org.jfree.data.Range range28 = dateAxis21.getRange();
        dateAxis18.setRangeWithMargins(range28, true, true);
        dateAxis9.setRange(range28, true, true);
        boolean boolean35 = xYPlot0.equals((java.lang.Object) true);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis36.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean42 = rectangleInsets40.equals((java.lang.Object) rectangleInsets41);
        double double44 = rectangleInsets40.calculateBottomInset((double) (byte) 10);
        categoryAxis36.setTickLabelInsets(rectangleInsets40);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double48 = rectangleInsets46.calculateLeftOutset(1.0d);
        categoryAxis36.setTickLabelInsets(rectangleInsets46);
        xYPlot0.setInsets(rectangleInsets46);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 4.0d + "'", double48 == 4.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        xYPlot0.setRangeCrosshairValue(0.0d, false);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot0.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CrosshairState crosshairState33 = null;
        boolean boolean34 = xYPlot26.render(graphics2D29, rectangle2D30, (int) 'a', plotRenderingInfo32, crosshairState33);
        java.awt.Paint paint36 = xYPlot26.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset38 = xYPlot26.getDataset((-655360));
        java.awt.Stroke stroke39 = xYPlot26.getDomainZeroBaselineStroke();
        xYPlot0.setOutlineStroke(stroke39);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNull(xYDataset38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setCategoryLabelPositionOffset((-3407872));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer16, false);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot0.indexOf(xYDataset19);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot0.setDataset(9, xYDataset22);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot6.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace17);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot22.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot22.setAxisOffset(rectangleInsets25);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot22.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker28, layer29);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = xYPlot20.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker28, layer31);
        boolean boolean33 = categoryMarker28.getDrawAsLine();
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker28);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.lang.Object obj6 = categoryMarker1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryMarker1.notifyListeners(markerChangeEvent7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color12);
        categoryAxis10.setLowerMargin((double) '#');
        categoryAxis10.setCategoryMargin(1.0d);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        categoryAxis10.setAxisLinePaint((java.awt.Paint) color18);
        boolean boolean20 = categoryMarker1.equals((java.lang.Object) categoryAxis10);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot21.setAxisOffset(rectangleInsets24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke26);
        java.awt.Stroke stroke28 = xYPlot21.getRangeGridlineStroke();
        categoryMarker1.setOutlineStroke(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource22);
        dateAxis10.zoomRange((double) (-3407872), (double) 192);
        java.awt.Shape shape27 = dateAxis10.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis29.setLowerBound((double) 0);
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRange(range32, false, true);
        dateAxis29.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition37 = dateAxis29.getTickMarkPosition();
        dateAxis10.setTickMarkPosition(dateTickMarkPosition37);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(dateTickMarkPosition37);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean3 = chartChangeEventType0.equals((java.lang.Object) color2);
        int int4 = color2.getTransparency();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color1 = color0.darker();
        float[] floatArray12 = new float[] { 1560409200000L, 100.0f, 5, (short) 0 };
        float[] floatArray13 = java.awt.Color.RGBtoHSB(0, 5, 8, floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (short) 10, 12, floatArray13);
        float[] floatArray15 = color1.getRGBColorComponents(floatArray14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.setLowerBound(10.0d);
        boolean boolean10 = dateAxis1.isNegativeArrowVisible();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        dateAxis1.setTickMarkStroke(stroke11);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis27.setLowerBound((double) 0);
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRange(range30, false, true);
        dateAxis21.setRange(range30, false, false);
        boolean boolean37 = dateAxis21.isVisible();
        java.util.Date date38 = dateAxis21.getMinimumDate();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.Calendar calendar40 = null;
        try {
            day39.peg(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot0.getDomainAxisEdge(8);
        java.awt.Font font10 = xYPlot0.getNoDataMessageFont();
        java.awt.Paint paint11 = xYPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        int int11 = color10.getRed();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        dateAxis1.setLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis20.setLowerBound((double) 0);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis20.setRange(range23, false, true);
        dateAxis20.setLowerBound(10.0d);
        float float29 = dateAxis20.getTickMarkInsideLength();
        dateAxis20.setRangeAboutValue((double) 0L, (double) 10L);
        java.awt.Paint paint33 = dateAxis20.getTickMarkPaint();
        dateAxis1.setTickMarkPaint(paint33);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = xYPlot6.render(graphics2D9, rectangle2D10, (int) 'a', plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker16.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryMarker16.getLabelTextAnchor();
        boolean boolean22 = rectangleAnchor5.equals((java.lang.Object) textAnchor21);
        boolean boolean23 = day0.equals((java.lang.Object) rectangleAnchor5);
        java.lang.String str24 = rectangleAnchor5.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str24.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = xYPlot0.getDrawingSupplier();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            boolean boolean14 = xYPlot0.removeAnnotation(xYAnnotation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color11);
        java.lang.String str13 = categoryAxis9.getLabelURL();
        int int14 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot15.setDataset((int) (byte) 10, xYDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot15.drawRangeTickBands(graphics2D21, rectangle2D22, list23);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.data.Range range34 = xYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis36.setLowerBound((double) 0);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range39, false, true);
        dateAxis30.setRange(range39, false, false);
        boolean boolean46 = dateAxis30.isVisible();
        java.util.Date date47 = dateAxis30.getMinimumDate();
        dateAxis8.setMaximumDate(date47);
        dateAxis6.setMaximumDate(date47);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.CrosshairState crosshairState57 = null;
        boolean boolean58 = xYPlot50.render(graphics2D53, rectangle2D54, (int) 'a', plotRenderingInfo56, crosshairState57);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot50.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker60, layer61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        xYPlot50.drawAnnotations(graphics2D63, rectangle2D64, plotRenderingInfo65);
        boolean boolean67 = xYPlot50.isDomainCrosshairVisible();
        dateAxis6.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot50);
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        xYPlot50.setFixedDomainAxisSpace(axisSpace69);
        java.awt.Image image71 = null;
        xYPlot50.setBackgroundImage(image71);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue((double) (-12517377), rectangle2D5, rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleInsets9);
        numberAxis1.setLabelInsets(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset((int) (byte) 0, xYDataset9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot13.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot13.setAxisOffset(rectangleInsets16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean21 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker19, layer20);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = xYPlot11.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker19, layer22);
        java.lang.Object obj24 = null;
        boolean boolean25 = xYPlot11.equals(obj24);
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100, paint28, stroke29);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean33 = xYPlot11.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker30, layer31, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = null;
        xYPlot11.notifyListeners(plotChangeEvent34);
        xYPlot11.clearRangeAxes();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot11.setDomainTickBandPaint((java.awt.Paint) color37);
        int int39 = color37.getGreen();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color41 = color40.darker();
        float[] floatArray42 = null;
        float[] floatArray43 = color40.getColorComponents(floatArray42);
        float[] floatArray44 = color37.getRGBColorComponents(floatArray43);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color37);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 64 + "'", int39 == 64);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        java.lang.Object obj3 = objectList0.get((-655360));
        int int5 = objectList0.indexOf((java.lang.Object) "DatasetRenderingOrder.REVERSE");
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        xYPlot6.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot6.getOrientation();
        boolean boolean15 = objectList0.equals((java.lang.Object) plotOrientation14);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer10, false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis0.setTickLabelPaint((java.awt.Paint) chartColor6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = xYPlot0.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot10.setDataset((int) (byte) 10, xYDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot10.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        java.awt.Color color20 = java.awt.Color.BLACK;
        xYPlot10.setDomainTickBandPaint((java.awt.Paint) color20);
        boolean boolean22 = xYPlot10.isOutlineVisible();
        int int23 = xYPlot10.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot10.getRangeAxisLocation(3);
        xYPlot0.setDomainAxisLocation(axisLocation25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = axisLocation25.getOpposite();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        double double2 = categoryAxis0.getCategoryMargin();
        categoryAxis0.configure();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.data.general.Dataset dataset2 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) axisLocation0, dataset2);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        boolean boolean26 = dateAxis1.isVerticalTickLabels();
        java.awt.Paint paint27 = dateAxis1.getAxisLinePaint();
        try {
            dateAxis1.setAutoRangeMinimumSize((double) (-655360), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotOrientation.VERTICAL");
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Stroke stroke3 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin((double) 4);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        boolean boolean26 = dateAxis1.isVerticalTickLabels();
        dateAxis1.setAutoRangeMinimumSize((double) 100);
        dateAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot0.setDataset((int) (byte) 0, xYDataset9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        int int15 = xYPlot0.getIndexOf(xYItemRenderer14);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        boolean boolean7 = rectangleAnchor1.equals((java.lang.Object) rectangleInsets5);
        numberAxis0.setTickLabelInsets(rectangleInsets5);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str12 = categoryAxis11.getLabelToolTip();
        categoryAxis11.setTickMarkInsideLength((float) 3);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot15.setAxisOffset(rectangleInsets18);
        categoryAxis11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot15.getRangeAxisEdge(0);
        try {
            double double23 = numberAxis0.valueToJava2D(8.0d, rectangle2D10, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis20.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleInsets25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (byte) 10);
        categoryAxis20.setTickLabelInsets(rectangleInsets24);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double32 = rectangleInsets30.calculateLeftOutset(1.0d);
        categoryAxis20.setTickLabelInsets(rectangleInsets30);
        valueMarker16.setLabelOffset(rectangleInsets30);
        double double36 = rectangleInsets30.calculateBottomOutset((double) (short) 0);
        java.lang.String str37 = rectangleInsets30.toString();
        double double39 = rectangleInsets30.trimHeight((double) 3);
        double double41 = rectangleInsets30.calculateRightOutset((double) 100L);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str37.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 12, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = xYPlot1.getDataset((-655360));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot1.render(graphics2D4, rectangle2D5, (int) 'a', plotRenderingInfo7, crosshairState8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot1.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker11.setLabelAnchor(rectangleAnchor14);
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryMarker11.getLabelTextAnchor();
        boolean boolean17 = rectangleAnchor0.equals((java.lang.Object) textAnchor16);
        java.lang.String str18 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(xYDataset3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str18.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        int int16 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.TimeZone timeZone17 = dateAxis11.getTimeZone();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timeZone17);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, (double) 100, (double) 3, (double) (-1L));
        java.lang.String str5 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=0.0,l=100.0,b=3.0,r=-1.0]" + "'", str5.equals("RectangleInsets[t=0.0,l=100.0,b=3.0,r=-1.0]"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis19.setLowerBound((double) 0);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range22, false, true);
        org.jfree.data.Range range26 = dateAxis19.getRange();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis28.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range34, false, true);
        org.jfree.data.Range range38 = dateAxis31.getRange();
        dateAxis28.setRangeWithMargins(range38, true, true);
        dateAxis19.setRange(range38, true, true);
        boolean boolean45 = xYPlot10.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = xYPlot10.getDomainMarkers(layer46);
        java.util.Collection collection48 = xYPlot0.getRangeMarkers((int) (short) 10, layer46);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        int int50 = xYPlot0.indexOf(xYDataset49);
        org.jfree.data.general.DatasetGroup datasetGroup51 = xYPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNull(datasetGroup51);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setUpArrow(shape4);
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        java.util.Date date7 = dateAxis1.getMaximumDate();
        java.util.TimeZone timeZone8 = dateAxis1.getTimeZone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        int int4 = color2.getBlue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder20);
        java.awt.Stroke stroke22 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue((double) (-12517377), rectangle2D5, rectangleEdge6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1);
        java.lang.Object obj9 = chartChangeEvent8.getSource();
        java.lang.Object obj10 = chartChangeEvent8.getSource();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        numberAxis1.setUpperMargin((double) 10);
        double double7 = numberAxis1.getFixedAutoRange();
        boolean boolean8 = numberAxis1.getAutoRangeIncludesZero();
        double double9 = numberAxis1.getLowerBound();
        try {
            numberAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color11);
        java.lang.String str13 = categoryAxis9.getLabelURL();
        int int14 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot15.setDataset((int) (byte) 10, xYDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot15.drawRangeTickBands(graphics2D21, rectangle2D22, list23);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.data.Range range34 = xYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis36.setLowerBound((double) 0);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range39, false, true);
        dateAxis30.setRange(range39, false, false);
        boolean boolean46 = dateAxis30.isVisible();
        java.util.Date date47 = dateAxis30.getMinimumDate();
        dateAxis8.setMaximumDate(date47);
        dateAxis6.setMaximumDate(date47);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.CrosshairState crosshairState57 = null;
        boolean boolean58 = xYPlot50.render(graphics2D53, rectangle2D54, (int) 'a', plotRenderingInfo56, crosshairState57);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot50.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker60, layer61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        xYPlot50.drawAnnotations(graphics2D63, rectangle2D64, plotRenderingInfo65);
        boolean boolean67 = xYPlot50.isDomainCrosshairVisible();
        dateAxis6.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot50);
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        xYPlot50.setFixedDomainAxisSpace(axisSpace69);
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset73 = xYPlot71.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        xYPlot71.setDataset((int) (byte) 10, xYDataset75);
        java.awt.Graphics2D graphics2D77 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        java.util.List list79 = null;
        xYPlot71.drawRangeTickBands(graphics2D77, rectangle2D78, list79);
        java.awt.Color color81 = java.awt.Color.BLACK;
        xYPlot71.setDomainTickBandPaint((java.awt.Paint) color81);
        boolean boolean83 = xYPlot71.isOutlineVisible();
        int int84 = xYPlot71.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation85 = xYPlot71.getRangeAxisLocation();
        java.lang.String str86 = axisLocation85.toString();
        xYPlot50.setDomainAxisLocation(axisLocation85, false);
        java.awt.Paint paint89 = xYPlot50.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(xYDataset73);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 11 + "'", int84 == 11);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str86.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(paint89);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, true, false);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((-655360));
        boolean boolean3 = categoryAxis0.isVisible();
        categoryAxis0.configure();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot5.setDataset((int) (byte) 10, xYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot5.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        xYPlot5.setDomainTickBandPaint((java.awt.Paint) color15);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 100, paint19, stroke20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot5.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker21, layer22, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis25.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean31 = rectangleInsets29.equals((java.lang.Object) rectangleInsets30);
        double double33 = rectangleInsets29.calculateBottomInset((double) (byte) 10);
        categoryAxis25.setTickLabelInsets(rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateLeftOutset(1.0d);
        categoryAxis25.setTickLabelInsets(rectangleInsets35);
        valueMarker21.setLabelOffset(rectangleInsets35);
        org.jfree.chart.util.UnitType unitType40 = rectangleInsets35.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets35);
        int int42 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(unitType40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot6.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace17);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        java.awt.Image image20 = null;
        xYPlot6.setBackgroundImage(image20);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(valueAxis16);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis20.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = numberAxis20.getMarkerBand();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis20.setNumberFormatOverride(numberFormat24);
        double double26 = numberAxis20.getAutoRangeMinimumSize();
        xYPlot6.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis20, true);
        boolean boolean29 = numberAxis20.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(markerAxisBand23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot6.indexOf(xYDataset17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot21.setDataset((int) (byte) 10, xYDataset25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot21.drawRangeTickBands(graphics2D27, rectangle2D28, list29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation33 = axisLocation32.getOpposite();
        xYPlot21.setRangeAxisLocation(axisLocation33, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = xYPlot38.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot38.setAxisOffset(rectangleInsets41);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot38.setDomainCrosshairStroke(stroke43);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        xYPlot38.setRenderer(xYItemRenderer45);
        java.awt.geom.Point2D point2D47 = xYPlot38.getQuadrantOrigin();
        xYPlot21.zoomRangeAxes((double) (-3407872), plotRenderingInfo37, point2D47, false);
        xYPlot6.zoomDomainAxes(8.0d, plotRenderingInfo20, point2D47);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNull(xYDataset40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        boolean boolean13 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) (short) -1, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            rectangleInsets9.trim(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            java.awt.Color color1 = java.awt.Color.decode("13-June-2019");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"13-June-2019\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        int int9 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        float float15 = numberAxis12.getTickMarkOutsideLength();
        numberAxis12.setLowerMargin((double) (-3407872));
        try {
            xYPlot0.setDomainAxis(6, (org.jfree.chart.axis.ValueAxis) numberAxis12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3407872.0) <= upper (1.05).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("CONTRACT");
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis3.setLowerBound((double) 0);
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRange(range6, false, true);
        dateAxis3.setLowerBound(10.0d);
        float float12 = dateAxis3.getTickMarkInsideLength();
        dateAxis3.setLowerBound(4.0d);
        boolean boolean15 = categoryAxis1.equals((java.lang.Object) 4.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str17 = categoryAxis16.getLabelToolTip();
        categoryAxis16.setTickMarkInsideLength((float) 3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis16.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(10, xYItemRenderer9, false);
        xYPlot0.mapDatasetToRangeAxis(500, (int) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = xYPlot0.getDrawingSupplier();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(drawingSupplier15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 255);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot8.setDataset((int) (byte) 10, xYDataset12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot8.drawRangeTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Color color18 = java.awt.Color.BLACK;
        xYPlot8.setDomainTickBandPaint((java.awt.Paint) color18);
        boolean boolean20 = xYPlot8.isOutlineVisible();
        org.jfree.data.general.DatasetGroup datasetGroup21 = xYPlot8.getDatasetGroup();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot8.getDomainAxisEdge(11);
        try {
            double double24 = categoryAxis0.getCategoryStart((-3407872), (int) (short) 1, rectangle2D7, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        boolean boolean4 = categoryAxis0.isVisible();
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        java.awt.Stroke stroke6 = categoryAxis0.getAxisLineStroke();
        float float7 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        xYPlot2.setDomainCrosshairVisible(true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot2.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.configure();
        java.awt.Font font9 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis1.getTickUnit();
        dateAxis1.setLabelToolTip("EXPAND");
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100, paint1, stroke2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker3.getLabelOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.trimWidth((double) (short) -1);
        categoryMarker7.setLabelOffset(rectangleInsets8);
        java.awt.Paint paint12 = categoryMarker7.getOutlinePaint();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker7.setLabelFont(font13);
        xYPlot0.setNoDataMessageFont(font13);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = xYPlot0.removeRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color22 = color21.brighter();
        xYPlot0.setOutlinePaint((java.awt.Paint) color21);
        int int24 = xYPlot0.getWeight();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        try {
            xYPlot0.setDataset((-12517377), xYDataset26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.0d) + "'", double10 == (-9.0d));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = xYPlot3.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot3.setDataset((int) (byte) 10, xYDataset7);
        xYPlot3.setNoDataMessage("");
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot3.getDomainAxis(12);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot3);
        xYPlot3.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot3.getRangeAxis();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((-655360));
        boolean boolean3 = categoryAxis0.isVisible();
        categoryAxis0.configure();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot5.setDataset((int) (byte) 10, xYDataset9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot5.drawRangeTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Color color15 = java.awt.Color.BLACK;
        xYPlot5.setDomainTickBandPaint((java.awt.Paint) color15);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 100, paint19, stroke20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot5.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker21, layer22, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis25.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean31 = rectangleInsets29.equals((java.lang.Object) rectangleInsets30);
        double double33 = rectangleInsets29.calculateBottomInset((double) (byte) 10);
        categoryAxis25.setTickLabelInsets(rectangleInsets29);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateLeftOutset(1.0d);
        categoryAxis25.setTickLabelInsets(rectangleInsets35);
        valueMarker21.setLabelOffset(rectangleInsets35);
        org.jfree.chart.util.UnitType unitType40 = rectangleInsets35.getUnitType();
        categoryAxis0.setTickLabelInsets(rectangleInsets35);
        categoryAxis0.setLabel("org.jfree.chart.event.ChartChangeEvent[source=100]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(unitType40);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        xYPlot0.setWeight((int) (short) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray40 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer39 };
        xYPlot0.setRenderers(xYItemRendererArray40);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder42 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str43 = seriesRenderingOrder42.toString();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset46 = xYPlot44.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis48.setLowerBound((double) 0);
        xYPlot44.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis48);
        boolean boolean52 = dateAxis48.isPositiveArrowVisible();
        double double53 = dateAxis48.getLowerMargin();
        boolean boolean54 = seriesRenderingOrder42.equals((java.lang.Object) dateAxis48);
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder42);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray40);
        org.junit.Assert.assertNotNull(seriesRenderingOrder42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str43.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertNull(xYDataset46);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        double double7 = rectangleInsets2.extendHeight(8.0d);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset10 = xYPlot8.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot8.setAxisOffset(rectangleInsets11);
        boolean boolean13 = rectangleInsets2.equals((java.lang.Object) xYPlot8);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.0d + "'", double7 == 12.0d);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getRangeAxisEdge();
        java.lang.String str11 = xYPlot0.getPlotType();
        boolean boolean12 = xYPlot0.isDomainZoomable();
        java.awt.Paint paint13 = xYPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot14.getDataset((-655360));
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot14.render(graphics2D17, rectangle2D18, (int) 'a', plotRenderingInfo20, crosshairState21);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer25 = null;
        xYPlot14.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker24, layer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        xYPlot14.drawAnnotations(graphics2D27, rectangle2D28, plotRenderingInfo29);
        boolean boolean31 = xYPlot14.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        int int33 = xYPlot14.getIndexOf(xYItemRenderer32);
        float float34 = xYPlot14.getForegroundAlpha();
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str39 = color38.toString();
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, color38 };
        java.awt.Stroke[] strokeArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset44 = xYPlot42.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis46.setLowerBound((double) 0);
        xYPlot42.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis46);
        boolean boolean50 = dateAxis46.isPositiveArrowVisible();
        java.awt.Stroke stroke51 = dateAxis46.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset54 = xYPlot52.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        xYPlot52.setDataset((int) (byte) 10, xYDataset56);
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        java.util.List list60 = null;
        xYPlot52.drawRangeTickBands(graphics2D58, rectangle2D59, list60);
        java.awt.Color color62 = java.awt.Color.BLACK;
        xYPlot52.setDomainTickBandPaint((java.awt.Paint) color62);
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset66 = xYPlot64.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot64.setAxisOffset(rectangleInsets67);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot64.setDomainCrosshairStroke(stroke69);
        xYPlot52.setRangeGridlineStroke(stroke69);
        java.awt.Stroke[] strokeArray72 = new java.awt.Stroke[] { stroke51, stroke69 };
        java.awt.Shape[] shapeArray73 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier74 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray35, paintArray36, paintArray40, strokeArray41, strokeArray72, shapeArray73);
        xYPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier74);
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot77 = categoryAxis76.getPlot();
        java.awt.Stroke stroke78 = categoryAxis76.getAxisLineStroke();
        boolean boolean79 = defaultDrawingSupplier74.equals((java.lang.Object) stroke78);
        java.awt.Shape shape80 = defaultDrawingSupplier74.getNextShape();
        java.awt.Paint paint81 = defaultDrawingSupplier74.getNextPaint();
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier74);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str39.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(xYDataset54);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNull(xYDataset66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(strokeArray72);
        org.junit.Assert.assertNotNull(shapeArray73);
        org.junit.Assert.assertNull(plot77);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(paint81);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getDomainAxis(12);
        java.awt.Image image10 = null;
        xYPlot0.setBackgroundImage(image10);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        int int15 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker10.setLabelAnchor(rectangleAnchor13);
        org.jfree.chart.text.TextAnchor textAnchor15 = categoryMarker10.getLabelTextAnchor();
        boolean boolean17 = textAnchor15.equals((java.lang.Object) (byte) 10);
        java.lang.String str18 = textAnchor15.toString();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextAnchor.CENTER" + "'", str18.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        boolean boolean10 = dateAxis1.isAutoRange();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot14.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        xYPlot14.setDataset((int) (byte) 10, xYDataset18);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot14.setNoDataMessageFont(font20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot14.setOutlineStroke(stroke22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot14.getRangeAxisEdge();
        try {
            java.util.List list25 = dateAxis1.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder20);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getDomainAxisForDataset((-10419871));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -10419871 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 6, (double) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets3.trimWidth((double) (short) -1);
        intervalMarker2.setLabelOffset(rectangleInsets3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        java.lang.String str3 = day1.toString();
//        boolean boolean4 = seriesRenderingOrder0.equals((java.lang.Object) day1);
//        java.lang.String str5 = seriesRenderingOrder0.toString();
//        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str5.equals("SeriesRenderingOrder.FORWARD"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.setLabelAngle(10.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        int int11 = color10.getRed();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        dateAxis1.setLabelPaint((java.awt.Paint) color10);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.RIGHT");
        java.text.DateFormat dateFormat24 = null;
        dateAxis23.setDateFormatOverride(dateFormat24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis27.setLowerBound((double) 0);
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRange(range30, false, true);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis35.setLowerBound((double) 0);
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis35.setRange(range38, false, true);
        dateAxis27.setRangeWithMargins(range38, false, false);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset47 = xYPlot45.getDataset((-655360));
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.chart.plot.CrosshairState crosshairState52 = null;
        boolean boolean53 = xYPlot45.render(graphics2D48, rectangle2D49, (int) 'a', plotRenderingInfo51, crosshairState52);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis55.setLowerBound((double) 0);
        org.jfree.data.Range range58 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis55.setRange(range58, false, true);
        xYPlot45.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis55);
        java.awt.Shape shape63 = dateAxis55.getDownArrow();
        dateAxis27.setLeftArrow(shape63);
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset67 = xYPlot65.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis69.setLowerBound((double) 0);
        xYPlot65.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis69);
        dateAxis69.setAxisLineVisible(false);
        double double75 = dateAxis69.getFixedAutoRange();
        java.awt.Shape shape76 = dateAxis69.getUpArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit77 = dateAxis69.getTickUnit();
        java.util.Date date78 = dateAxis27.calculateLowestVisibleTickValue(dateTickUnit77);
        java.util.Date date79 = dateAxis23.calculateHighestVisibleTickValue(dateTickUnit77);
        try {
            dateAxis1.setRange(date21, date79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(xYDataset47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNull(xYDataset67);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(dateTickUnit77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(date79);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Shape shape18 = dateAxis10.getDownArrow();
        dateAxis10.resizeRange((double) 7);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        categoryAxis0.setUpperMargin(4.0d);
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.text.DateFormat dateFormat18 = dateAxis10.getDateFormatOverride();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(dateFormat18);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        java.awt.Shape shape10 = dateAxis4.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis12.setLowerBound((double) 0);
        java.util.TimeZone timeZone15 = dateAxis12.getTimeZone();
        dateAxis4.setTimeZone(timeZone15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis4.setTickLabelFont(font17);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color11);
        java.lang.String str13 = categoryAxis9.getLabelURL();
        int int14 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot15.setDataset((int) (byte) 10, xYDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot15.drawRangeTickBands(graphics2D21, rectangle2D22, list23);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.data.Range range34 = xYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis36.setLowerBound((double) 0);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range39, false, true);
        dateAxis30.setRange(range39, false, false);
        boolean boolean46 = dateAxis30.isVisible();
        java.util.Date date47 = dateAxis30.getMinimumDate();
        dateAxis8.setMaximumDate(date47);
        dateAxis6.setMaximumDate(date47);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.CrosshairState crosshairState57 = null;
        boolean boolean58 = xYPlot50.render(graphics2D53, rectangle2D54, (int) 'a', plotRenderingInfo56, crosshairState57);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot50.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker60, layer61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        xYPlot50.drawAnnotations(graphics2D63, rectangle2D64, plotRenderingInfo65);
        boolean boolean67 = xYPlot50.isDomainCrosshairVisible();
        dateAxis6.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot50);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis70 = xYPlot50.getRangeAxisForDataset((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis0.setTickLabelPaint((java.awt.Paint) chartColor6);
        java.awt.Font font9 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 9);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.trimWidth((double) (short) -1);
        categoryMarker13.setLabelOffset(rectangleInsets14);
        java.awt.Paint paint18 = categoryMarker13.getOutlinePaint();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker13.setLabelFont(font19);
        float float21 = categoryMarker13.getAlpha();
        boolean boolean22 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13);
        categoryMarker13.setDrawAsLine(true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-9.0d) + "'", double16 == (-9.0d));
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=0,b=192]" + "'", str1.equals("java.awt.Color[r=192,g=0,b=192]"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setUpArrow(shape4);
        dateAxis1.resizeRange((double) (-16728064));
        dateAxis1.setUpperMargin((double) 5);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        org.jfree.data.general.DatasetGroup datasetGroup13 = xYPlot0.getDatasetGroup();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot0.getDomainAxisEdge(11);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot16.getDataset((-655360));
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.CrosshairState crosshairState23 = null;
        boolean boolean24 = xYPlot16.render(graphics2D19, rectangle2D20, (int) 'a', plotRenderingInfo22, crosshairState23);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer27 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        xYPlot16.drawAnnotations(graphics2D29, rectangle2D30, plotRenderingInfo31);
        boolean boolean33 = xYPlot16.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        int int35 = xYPlot16.getIndexOf(xYItemRenderer34);
        float float36 = xYPlot16.getForegroundAlpha();
        java.awt.Paint[] paintArray37 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str41 = color40.toString();
        java.awt.Paint[] paintArray42 = new java.awt.Paint[] { color39, color40 };
        java.awt.Stroke[] strokeArray43 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset46 = xYPlot44.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis48.setLowerBound((double) 0);
        xYPlot44.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis48);
        boolean boolean52 = dateAxis48.isPositiveArrowVisible();
        java.awt.Stroke stroke53 = dateAxis48.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset56 = xYPlot54.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        xYPlot54.setDataset((int) (byte) 10, xYDataset58);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        java.util.List list62 = null;
        xYPlot54.drawRangeTickBands(graphics2D60, rectangle2D61, list62);
        java.awt.Color color64 = java.awt.Color.BLACK;
        xYPlot54.setDomainTickBandPaint((java.awt.Paint) color64);
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset68 = xYPlot66.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot66.setAxisOffset(rectangleInsets69);
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot66.setDomainCrosshairStroke(stroke71);
        xYPlot54.setRangeGridlineStroke(stroke71);
        java.awt.Stroke[] strokeArray74 = new java.awt.Stroke[] { stroke53, stroke71 };
        java.awt.Shape[] shapeArray75 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier76 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray37, paintArray38, paintArray42, strokeArray43, strokeArray74, shapeArray75);
        xYPlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier76);
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot79 = categoryAxis78.getPlot();
        java.awt.Stroke stroke80 = categoryAxis78.getAxisLineStroke();
        boolean boolean81 = defaultDrawingSupplier76.equals((java.lang.Object) stroke80);
        java.awt.Shape shape82 = defaultDrawingSupplier76.getNextShape();
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier76);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(datasetGroup13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(paintArray38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str41.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray42);
        org.junit.Assert.assertNotNull(strokeArray43);
        org.junit.Assert.assertNull(xYDataset46);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(xYDataset56);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNull(xYDataset68);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(strokeArray74);
        org.junit.Assert.assertNotNull(shapeArray75);
        org.junit.Assert.assertNull(plot79);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(shape82);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) 3);
        java.lang.Object obj4 = categoryAxis0.clone();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot5.setDomainCrosshairStroke(stroke10);
        java.lang.Object obj12 = xYPlot5.clone();
        int int13 = xYPlot5.getBackgroundImageAlignment();
        int int14 = xYPlot5.getDomainAxisCount();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot5);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot5.setDomainCrosshairStroke(stroke16);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.setLowerBound(10.0d);
        boolean boolean10 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setTickMarkOutsideLength((float) 1560495599999L);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint12 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis27.setLowerBound((double) 0);
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRange(range30, false, true);
        dateAxis21.setRange(range30, false, false);
        boolean boolean37 = dateAxis21.isVisible();
        java.util.Date date38 = dateAxis21.getMinimumDate();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        long long40 = day39.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-14400001L) + "'", long40 == (-14400001L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis0.setTickLabelPaint((java.awt.Paint) chartColor6);
        java.awt.Paint paint8 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = xYPlot1.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot1.setAxisOffset(rectangleInsets4);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean9 = xYPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker7, layer8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        categoryMarker7.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot10);
        boolean boolean12 = rectangleAnchor0.equals((java.lang.Object) categoryMarker7);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(xYDataset3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        boolean boolean16 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint17 = xYPlot0.getDomainTickBandPaint();
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot0.setRenderer((int) ' ', xYItemRenderer16, false);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot0.indexOf(xYDataset19);
        java.awt.Paint paint21 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke3 = categoryAxis0.getTickMarkStroke();
        float float4 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        double double5 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str4 = color3.toString();
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color2, color3 };
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot7.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean15 = dateAxis11.isPositiveArrowVisible();
        java.awt.Stroke stroke16 = dateAxis11.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot17.setDataset((int) (byte) 10, xYDataset21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot17.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color27 = java.awt.Color.BLACK;
        xYPlot17.setDomainTickBandPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot29.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot29.setAxisOffset(rectangleInsets32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot29.setDomainCrosshairStroke(stroke34);
        xYPlot17.setRangeGridlineStroke(stroke34);
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] { stroke16, stroke34 };
        java.awt.Shape[] shapeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray5, strokeArray6, strokeArray37, shapeArray38);
        java.lang.Object obj40 = defaultDrawingSupplier39.clone();
        java.awt.Paint paint41 = defaultDrawingSupplier39.getNextPaint();
        java.awt.Paint paint42 = defaultDrawingSupplier39.getNextFillPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str4.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot0.getDomainAxis(192);
        int int22 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot24 = categoryAxis23.getPlot();
        double double25 = categoryAxis23.getFixedDimension();
        categoryAxis23.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = categoryAxis23.getCategoryLabelPositions();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot28.setDataset((int) (byte) 10, xYDataset32);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot28.setNoDataMessageFont(font34);
        categoryAxis23.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot28);
        java.awt.Paint paint37 = categoryAxis23.getLabelPaint();
        xYPlot0.setRangeZeroBaselinePaint(paint37);
        java.awt.Stroke stroke39 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.RIGHT");
        java.text.DateFormat dateFormat42 = null;
        dateAxis41.setDateFormatOverride(dateFormat42);
        org.jfree.data.Range range44 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace45, false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier8);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis12.getMarkerBand();
        java.text.NumberFormat numberFormat16 = null;
        numberAxis12.setNumberFormatOverride(numberFormat16);
        xYPlot0.setDomainAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis12, true);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace20);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(markerAxisBand15);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        boolean boolean13 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot0.setNoDataMessagePaint(paint14);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
        categoryMarker6.setKey((java.lang.Comparable) regularTimePeriod10);
        boolean boolean12 = categoryMarker6.getDrawAsLine();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100, paint1, stroke2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        boolean boolean6 = valueMarker3.equals((java.lang.Object) regularTimePeriod5);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        numberAxis1.setUpperMargin((double) 10);
        double double7 = numberAxis1.getFixedAutoRange();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelLines((-655360));
        boolean boolean3 = categoryAxis0.isVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot7.getDataset((-655360));
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = null;
        boolean boolean15 = xYPlot7.render(graphics2D10, rectangle2D11, (int) 'a', plotRenderingInfo13, crosshairState14);
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer18 = null;
        xYPlot7.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot7.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        boolean boolean24 = xYPlot7.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        int int26 = xYPlot7.getIndexOf(xYItemRenderer25);
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot7.getDataset(255);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot7.getDomainAxisEdge(0);
        try {
            java.util.List list31 = categoryAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleInsets5);
        double double8 = rectangleInsets4.calculateBottomInset((double) (byte) 10);
        categoryAxis0.setTickLabelInsets(rectangleInsets4);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets4.getUnitType();
        java.lang.String str11 = unitType10.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) 11, (double) 9, (double) 10, (double) 10L);
        double double18 = rectangleInsets16.calculateBottomInset((double) 9);
        double double19 = rectangleInsets16.getTop();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 11.0d + "'", double19 == 11.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleInsets0.equals(obj1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        boolean boolean9 = xYPlot0.isDomainZeroBaselineVisible();
        xYPlot0.clearRangeMarkers((int) ' ');
        double double12 = xYPlot0.getDomainCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot0.getDataset((int) (short) 10);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(xYDataset14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Date date5 = day3.getEnd();
        java.awt.Paint paint6 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) date5);
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot0.getDomainAxisEdge(8);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder12);
        java.awt.Image image14 = null;
        xYPlot0.setBackgroundImage(image14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis17.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color19);
        java.lang.String str21 = categoryAxis17.getLabelURL();
        int int22 = categoryAxis17.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot23.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot23.setDataset((int) (byte) 10, xYDataset27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.util.List list31 = null;
        xYPlot23.drawRangeTickBands(graphics2D29, rectangle2D30, list31);
        categoryAxis17.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot23);
        org.jfree.data.general.DatasetGroup datasetGroup34 = xYPlot23.getDatasetGroup();
        xYPlot23.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str37 = categoryAxis36.getLabelToolTip();
        int int38 = categoryAxis36.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor42 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis36.setTickLabelPaint((java.awt.Paint) chartColor42);
        xYPlot23.setRangeZeroBaselinePaint((java.awt.Paint) chartColor42);
        float[] floatArray52 = new float[] { 4, 100L, 100, 1.0f };
        float[] floatArray53 = java.awt.Color.RGBtoHSB(255, 5, (int) (short) 10, floatArray52);
        float[] floatArray54 = chartColor42.getColorComponents(floatArray53);
        int int55 = chartColor42.getRGB();
        try {
            xYPlot0.setQuadrantPaint((-3407872), (java.awt.Paint) chartColor42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-3407872) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNull(datasetGroup34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-10419871) + "'", int55 == (-10419871));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot0.getRangeAxisLocation(3);
        java.awt.Image image25 = xYPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(image25);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        double double10 = dateAxis4.getFixedAutoRange();
        java.awt.Shape shape11 = dateAxis4.getUpArrow();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot14.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot14.setAxisOffset(rectangleInsets17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot14.setDomainCrosshairStroke(stroke19);
        java.lang.Object obj21 = xYPlot14.clone();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setOutlineStroke(stroke22);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis25.setLowerBound((double) 0);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis25.setUpArrow(shape28);
        int int30 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot14.setAxisOffset(rectangleInsets31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot14.getRangeAxisLocation(10);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset37 = xYPlot35.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        xYPlot35.setDataset((int) (byte) 10, xYDataset39);
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot35.setNoDataMessageFont(font41);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        xYPlot35.setRenderer(10, xYItemRenderer44, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = xYPlot35.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation34, plotOrientation47);
        try {
            double double49 = dateAxis4.valueToJava2D(12.0d, rectangle2D13, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=0]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=0]"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        float float4 = numberAxis1.getTickMarkOutsideLength();
        numberAxis1.setLowerMargin((double) (-3407872));
        numberAxis1.setLabelAngle((-9.0d));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.Plot plot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = categoryAxis0.reserveSpace(graphics2D2, plot3, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource22);
        dateAxis10.zoomRange((double) (-3407872), (double) 192);
        java.awt.Shape shape27 = dateAxis10.getRightArrow();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis28.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color30);
        java.lang.String str32 = categoryAxis28.getLabelURL();
        int int33 = categoryAxis28.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset36 = xYPlot34.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot34.setDataset((int) (byte) 10, xYDataset38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.util.List list42 = null;
        xYPlot34.drawRangeTickBands(graphics2D40, rectangle2D41, list42);
        categoryAxis28.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot34);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double47 = rectangleInsets45.calculateBottomOutset(1.0d);
        org.jfree.chart.util.UnitType unitType48 = rectangleInsets45.getUnitType();
        categoryAxis28.setTickLabelInsets(rectangleInsets45);
        dateAxis10.setLabelInsets(rectangleInsets45);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(xYDataset36);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 3.0d + "'", double47 == 3.0d);
        org.junit.Assert.assertNotNull(unitType48);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(1.0d);
        double double4 = rectangleInsets0.trimWidth((double) 500);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 492.0d + "'", double4 == 492.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setDomainAxisLocation(255, axisLocation11, false);
        int int14 = xYPlot0.getDatasetCount();
        java.awt.Paint paint15 = xYPlot0.getOutlinePaint();
        java.lang.String str16 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        java.awt.Stroke stroke2 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis4.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color6);
        java.lang.String str8 = categoryAxis4.getLabelURL();
        int int9 = categoryAxis4.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot10.setDataset((int) (byte) 10, xYDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot10.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        categoryAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis25.setLowerBound((double) 0);
        xYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.data.Range range29 = xYPlot10.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range34, false, true);
        dateAxis25.setRange(range34, false, false);
        boolean boolean41 = dateAxis25.isVisible();
        java.util.Date date42 = dateAxis25.getMinimumDate();
        boolean boolean43 = categoryAnchor3.equals((java.lang.Object) date42);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset49 = xYPlot47.getDataset((-655360));
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.chart.plot.CrosshairState crosshairState54 = null;
        boolean boolean55 = xYPlot47.render(graphics2D50, rectangle2D51, (int) 'a', plotRenderingInfo53, crosshairState54);
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer58 = null;
        xYPlot47.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker57, layer58);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        xYPlot47.drawAnnotations(graphics2D60, rectangle2D61, plotRenderingInfo62);
        boolean boolean64 = xYPlot47.isDomainCrosshairVisible();
        int int65 = xYPlot47.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = xYPlot47.getRangeAxisEdge(3);
        try {
            double double68 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor3, (int) (short) -1, (int) (byte) 0, rectangle2D46, rectangleEdge67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(xYDataset49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 15 + "'", int65 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRange(range5, false, true);
        boolean boolean9 = dateAxis2.isAxisLineVisible();
        double double10 = dateAxis2.getLowerMargin();
        java.util.Date date11 = dateAxis2.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis13.setLowerBound((double) 0);
        java.util.TimeZone timeZone16 = dateAxis13.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11, timeZone16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("", timeZone16);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(tickUnitSource17);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        int int13 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis20.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleInsets25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (byte) 10);
        categoryAxis20.setTickLabelInsets(rectangleInsets24);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double32 = rectangleInsets30.calculateLeftOutset(1.0d);
        categoryAxis20.setTickLabelInsets(rectangleInsets30);
        valueMarker16.setLabelOffset(rectangleInsets30);
        org.jfree.chart.util.UnitType unitType35 = rectangleInsets30.getUnitType();
        org.jfree.chart.util.UnitType unitType36 = rectangleInsets30.getUnitType();
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset39 = xYPlot37.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis41.setLowerBound((double) 0);
        xYPlot37.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset47 = xYPlot45.getDataset((-655360));
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.chart.plot.CrosshairState crosshairState52 = null;
        boolean boolean53 = xYPlot45.render(graphics2D48, rectangle2D49, (int) 'a', plotRenderingInfo51, crosshairState52);
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer56 = null;
        xYPlot45.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker55, layer56);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker55.setLabelAnchor(rectangleAnchor58);
        categoryMarker55.setKey((java.lang.Comparable) 0L);
        java.awt.Paint paint62 = categoryMarker55.getOutlinePaint();
        dateAxis41.setTickMarkPaint(paint62);
        boolean boolean64 = unitType36.equals((java.lang.Object) dateAxis41);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertNotNull(unitType35);
        org.junit.Assert.assertNotNull(unitType36);
        org.junit.Assert.assertNull(xYDataset39);
        org.junit.Assert.assertNull(xYDataset47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis0.setTickLabelPaint((java.awt.Paint) chartColor6);
        java.lang.String str9 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass11 = categoryAxis10.getClass();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CrosshairState crosshairState19 = null;
        boolean boolean20 = xYPlot12.render(graphics2D15, rectangle2D16, (int) 'a', plotRenderingInfo18, crosshairState19);
        java.awt.Paint paint22 = xYPlot12.getQuadrantPaint((int) (byte) 1);
        boolean boolean23 = categoryAxis10.hasListener((java.util.EventListener) xYPlot12);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot12.getAxisOffset();
        java.awt.Paint paint26 = xYPlot12.getNoDataMessagePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation27 = null;
        try {
            xYPlot12.addAnnotation(xYAnnotation27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        float float4 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.valueToJava2D(0.0d, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit11, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        java.awt.Stroke stroke15 = xYPlot0.getDomainZeroBaselineStroke();
        xYPlot0.mapDatasetToDomainAxis(1, 4);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot19.getDataset((-655360));
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CrosshairState crosshairState26 = null;
        boolean boolean27 = xYPlot19.render(graphics2D22, rectangle2D23, (int) 'a', plotRenderingInfo25, crosshairState26);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer30 = null;
        xYPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker29, layer30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        xYPlot19.drawAnnotations(graphics2D32, rectangle2D33, plotRenderingInfo34);
        boolean boolean36 = xYPlot19.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        int int38 = xYPlot19.getIndexOf(xYItemRenderer37);
        float float39 = xYPlot19.getForegroundAlpha();
        java.awt.Paint[] paintArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str44 = color43.toString();
        java.awt.Paint[] paintArray45 = new java.awt.Paint[] { color42, color43 };
        java.awt.Stroke[] strokeArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset49 = xYPlot47.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis51.setLowerBound((double) 0);
        xYPlot47.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis51);
        boolean boolean55 = dateAxis51.isPositiveArrowVisible();
        java.awt.Stroke stroke56 = dateAxis51.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset59 = xYPlot57.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        xYPlot57.setDataset((int) (byte) 10, xYDataset61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        java.util.List list65 = null;
        xYPlot57.drawRangeTickBands(graphics2D63, rectangle2D64, list65);
        java.awt.Color color67 = java.awt.Color.BLACK;
        xYPlot57.setDomainTickBandPaint((java.awt.Paint) color67);
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset71 = xYPlot69.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot69.setAxisOffset(rectangleInsets72);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot69.setDomainCrosshairStroke(stroke74);
        xYPlot57.setRangeGridlineStroke(stroke74);
        java.awt.Stroke[] strokeArray77 = new java.awt.Stroke[] { stroke56, stroke74 };
        java.awt.Shape[] shapeArray78 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier79 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray40, paintArray41, paintArray45, strokeArray46, strokeArray77, shapeArray78);
        xYPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier79);
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot82 = categoryAxis81.getPlot();
        java.awt.Stroke stroke83 = categoryAxis81.getAxisLineStroke();
        boolean boolean84 = defaultDrawingSupplier79.equals((java.lang.Object) stroke83);
        xYPlot0.setDomainGridlineStroke(stroke83);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str44.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNull(xYDataset49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNull(xYDataset59);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNull(xYDataset71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(strokeArray77);
        org.junit.Assert.assertNotNull(shapeArray78);
        org.junit.Assert.assertNull(plot82);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot0.setDomainAxisLocation(255, axisLocation11, false);
        int int14 = xYPlot0.getDatasetCount();
        java.awt.Paint paint15 = xYPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double17 = rectangleInsets16.getRight();
        double double19 = rectangleInsets16.calculateTopOutset((double) '#');
        xYPlot0.setInsets(rectangleInsets16);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = xYPlot0.getDomainMarkers(layer21);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean8 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6, layer7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis19.setLowerBound((double) 0);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range22, false, true);
        org.jfree.data.Range range26 = dateAxis19.getRange();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis28.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis31.setLowerBound((double) 0);
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range34, false, true);
        org.jfree.data.Range range38 = dateAxis31.getRange();
        dateAxis28.setRangeWithMargins(range38, true, true);
        dateAxis19.setRange(range38, true, true);
        boolean boolean45 = xYPlot10.equals((java.lang.Object) true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection47 = xYPlot10.getDomainMarkers(layer46);
        java.util.Collection collection48 = xYPlot0.getRangeMarkers((int) (short) 10, layer46);
        xYPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener51 = null;
        xYPlot0.removeChangeListener(plotChangeListener51);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNull(collection47);
        org.junit.Assert.assertNull(collection48);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        numberAxis1.setUpperMargin((double) 10);
        double double7 = numberAxis1.getFixedAutoRange();
        boolean boolean8 = numberAxis1.getAutoRangeIncludesZero();
        java.lang.String str9 = numberAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue((double) (-12517377), rectangle2D5, rectangleEdge6);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1);
        numberAxis1.setAutoRange(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            numberAxis1.setLabelInsets(rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean13 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = xYPlot3.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker11, layer14);
        java.lang.Object obj16 = null;
        boolean boolean17 = xYPlot3.equals(obj16);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        xYPlot3.setRenderer((int) ' ', xYItemRenderer19, false);
        boolean boolean22 = categoryAxis0.hasListener((java.util.EventListener) xYPlot3);
        double double23 = xYPlot3.getDomainCrosshairValue();
        java.awt.Color color25 = java.awt.Color.white;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        boolean boolean34 = dateAxis30.isPositiveArrowVisible();
        java.awt.Stroke stroke35 = dateAxis30.getAxisLineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 5, (java.awt.Paint) color25, stroke35);
        xYPlot3.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker36);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis16.setLowerBound((double) 0);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range19, false, true);
        boolean boolean23 = dateAxis16.isAxisLineVisible();
        java.text.DateFormat dateFormat24 = null;
        dateAxis16.setDateFormatOverride(dateFormat24);
        org.jfree.data.Range range26 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font27 = xYPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        numberAxis1.setAxisLineVisible(true);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNull(markerAxisBand4);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        boolean boolean3 = day0.equals((java.lang.Object) color2);
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis3.setLowerBound((double) 0);
        java.util.TimeZone timeZone6 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone6);
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date0, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        dateAxis1.resizeRange((double) ' ');
        dateAxis1.zoomRange(1.0E-8d, (double) 13);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.trimWidth((double) (short) -1);
        categoryMarker7.setLabelOffset(rectangleInsets8);
        java.awt.Paint paint12 = categoryMarker7.getOutlinePaint();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker7.setLabelFont(font13);
        xYPlot0.setNoDataMessageFont(font13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot16.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis20.setLowerBound((double) 0);
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        boolean boolean24 = dateAxis20.isPositiveArrowVisible();
        java.awt.Stroke stroke25 = dateAxis20.getAxisLineStroke();
        xYPlot0.setRangeCrosshairStroke(stroke25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = null;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor30);
        xYPlot0.zoomDomainAxes((double) (byte) 1, plotRenderingInfo28, point2D31);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-9.0d) + "'", double10 == (-9.0d));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(point2D31);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot0.getRangeAxisLocation(3);
        org.jfree.chart.plot.Plot plot25 = xYPlot0.getParent();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.data.Range range8 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis13.setLowerBound((double) 0);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16, false, true);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis10.setRangeWithMargins(range20, true, true);
        dateAxis1.setRange(range20, true, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        java.lang.Object obj28 = chartChangeEvent27.getSource();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + obj28 + "' != '" + true + "'", obj28.equals(true));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryAxis0.setLabelInsets(rectangleInsets2);
        categoryAxis0.setLabelAngle((double) ' ');
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot11.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot11.setDataset((int) (byte) 10, xYDataset15);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot11.setOutlineStroke(stroke19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot11.getRangeAxisEdge();
        try {
            double double22 = categoryAxis0.getCategoryMiddle(15, 11, rectangle2D10, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNull(xYDataset13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str4 = color3.toString();
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color2, color3 };
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot7.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean15 = dateAxis11.isPositiveArrowVisible();
        java.awt.Stroke stroke16 = dateAxis11.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot17.setDataset((int) (byte) 10, xYDataset21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot17.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color27 = java.awt.Color.BLACK;
        xYPlot17.setDomainTickBandPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot29.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot29.setAxisOffset(rectangleInsets32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot29.setDomainCrosshairStroke(stroke34);
        xYPlot17.setRangeGridlineStroke(stroke34);
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] { stroke16, stroke34 };
        java.awt.Shape[] shapeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray5, strokeArray6, strokeArray37, shapeArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass41 = categoryAxis40.getClass();
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset44 = xYPlot42.getDataset((-655360));
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.plot.CrosshairState crosshairState49 = null;
        boolean boolean50 = xYPlot42.render(graphics2D45, rectangle2D46, (int) 'a', plotRenderingInfo48, crosshairState49);
        java.awt.Paint paint52 = xYPlot42.getQuadrantPaint((int) (byte) 1);
        boolean boolean53 = categoryAxis40.hasListener((java.util.EventListener) xYPlot42);
        xYPlot42.setDomainCrosshairVisible(true);
        int int56 = xYPlot42.getSeriesCount();
        boolean boolean57 = defaultDrawingSupplier39.equals((java.lang.Object) xYPlot42);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str4.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.data.Range range8 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis10.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis13.setLowerBound((double) 0);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16, false, true);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        dateAxis10.setRangeWithMargins(range20, true, true);
        dateAxis1.setRange(range20, true, true);
        org.jfree.chart.axis.Timeline timeline27 = dateAxis1.getTimeline();
        dateAxis1.resizeRange((double) 64, (double) 0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(timeline27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            xYPlot0.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot0.getDataset(255);
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot0.getDataset((int) (short) 0);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertNull(xYDataset23);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str1.equals("TextAnchor.TOP_LEFT"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        valueMarker1.setValue((double) 1560495599999L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str3 = categoryAxis2.getLabelToolTip();
        objectList0.set((int) (byte) 1, (java.lang.Object) str3);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis1.getTickMarkPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        int int11 = color10.getRed();
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color10.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        dateAxis1.setLabelPaint((java.awt.Paint) color10);
        java.awt.Color color19 = color10.darker();
        float[] floatArray30 = new float[] { 1560409200000L, 100.0f, 5, (short) 0 };
        float[] floatArray31 = java.awt.Color.RGBtoHSB(0, 5, 8, floatArray30);
        float[] floatArray32 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (short) 10, 12, floatArray31);
        float[] floatArray33 = color10.getColorComponents(floatArray31);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 192 + "'", int11 == 192);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getRed();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis8.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color10);
        categoryAxis8.setLowerMargin((double) '#');
        categoryAxis8.setCategoryMargin(1.0d);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        categoryAxis8.setAxisLinePaint((java.awt.Paint) color16);
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color16, dataset18);
        float[] floatArray27 = new float[] { 1560409200000L, 100.0f, 5, (short) 0 };
        float[] floatArray28 = java.awt.Color.RGBtoHSB(0, 5, 8, floatArray27);
        float[] floatArray29 = color16.getColorComponents(floatArray28);
        float[] floatArray30 = color0.getRGBComponents(floatArray29);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        int int8 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = xYPlot0.getAxisOffset();
        xYPlot0.setRangeCrosshairValue(0.0d);
        xYPlot0.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot13.getDataset((-655360));
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.CrosshairState crosshairState20 = null;
        boolean boolean21 = xYPlot13.render(graphics2D16, rectangle2D17, (int) 'a', plotRenderingInfo19, crosshairState20);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot13.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker23, layer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        xYPlot13.drawAnnotations(graphics2D26, rectangle2D27, plotRenderingInfo28);
        boolean boolean30 = xYPlot13.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        int int32 = xYPlot13.getIndexOf(xYItemRenderer31);
        xYPlot13.setRangeCrosshairValue(0.0d, false);
        int int36 = xYPlot13.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisSpace axisSpace37 = xYPlot13.getFixedRangeAxisSpace();
        java.awt.Paint paint38 = xYPlot13.getOutlinePaint();
        xYPlot0.setRangeZeroBaselinePaint(paint38);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 15 + "'", int36 == 15);
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.lang.String str2 = color1.toString();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100, paint4, stroke5);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1.0d, (java.awt.Paint) color1, stroke5);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryMarker7.setStroke(stroke8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str2.equals("java.awt.Color[r=64,g=64,b=64]"));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot12.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean20 = xYPlot12.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer19);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = xYPlot10.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker18, layer21);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker18.setLabelFont(font23);
        dateAxis1.setTickLabelFont(font23);
        boolean boolean26 = dateAxis1.isVerticalTickLabels();
        java.util.TimeZone timeZone27 = dateAxis1.getTimeZone();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color3);
        categoryAxis1.setLowerMargin((double) '#');
        categoryAxis1.setCategoryMargin(1.0d);
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint12 = null;
        java.awt.Color color15 = java.awt.Color.BLUE;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str18 = categoryAxis17.getLabelToolTip();
        int int19 = categoryAxis17.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke20 = categoryAxis17.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color23);
        boolean boolean25 = categoryAxis21.isVisible();
        java.awt.Paint paint26 = categoryAxis21.getTickMarkPaint();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100, paint28, stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color16, stroke20, paint26, stroke29, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(Double.NEGATIVE_INFINITY, (java.awt.Paint) color9, stroke11, paint12, stroke29, 0.0f);
        double double35 = valueMarker34.getValue();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        boolean boolean7 = rectangleAnchor1.equals((java.lang.Object) rectangleInsets5);
        numberAxis0.setTickLabelInsets(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str9.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYPlot0.equals(obj13);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 100, paint17, stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = xYPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker19, layer20, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot0.notifyListeners(plotChangeEvent23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot0.setRenderer(xYItemRenderer29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        dateAxis32.setLowerBound((double) 500);
        boolean boolean37 = dateAxis32.isPositiveArrowVisible();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        java.awt.Stroke stroke39 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.CrosshairState crosshairState22 = null;
        boolean boolean23 = xYPlot15.render(graphics2D18, rectangle2D19, (int) 'a', plotRenderingInfo21, crosshairState22);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer26 = null;
        xYPlot15.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        xYPlot15.drawAnnotations(graphics2D28, rectangle2D29, plotRenderingInfo30);
        boolean boolean32 = xYPlot15.isDomainCrosshairVisible();
        boolean boolean33 = xYPlot15.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset36 = xYPlot34.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot34.setDataset((int) (byte) 10, xYDataset38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.util.List list42 = null;
        xYPlot34.drawRangeTickBands(graphics2D40, rectangle2D41, list42);
        java.awt.Color color44 = java.awt.Color.BLACK;
        xYPlot34.setDomainTickBandPaint((java.awt.Paint) color44);
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 100, paint48, stroke49);
        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot34.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker50, layer51, true);
        java.util.Collection collection54 = xYPlot15.getDomainMarkers(layer51);
        try {
            xYPlot0.addDomainMarker((int) 'a', marker14, layer51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(xYDataset36);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(layer51);
        org.junit.Assert.assertNull(collection54);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        float float4 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        float float6 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        boolean boolean16 = xYPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint17 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot0.getRendererForDataset(xYDataset18);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(xYItemRenderer19);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        double double10 = dateAxis4.getFixedAutoRange();
        java.awt.Shape shape11 = dateAxis4.getUpArrow();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str13 = textAnchor12.toString();
        boolean boolean14 = dateAxis4.equals((java.lang.Object) str13);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str13.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setRange((double) (-3407872), (double) (-655360));
        numberAxis1.setVerticalTickLabels(false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.plot.Plot plot18 = xYPlot6.getRootPlot();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(plot18);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str4 = color3.toString();
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color2, color3 };
        java.awt.Stroke[] strokeArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot7.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean15 = dateAxis11.isPositiveArrowVisible();
        java.awt.Stroke stroke16 = dateAxis11.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot17.setDataset((int) (byte) 10, xYDataset21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.util.List list25 = null;
        xYPlot17.drawRangeTickBands(graphics2D23, rectangle2D24, list25);
        java.awt.Color color27 = java.awt.Color.BLACK;
        xYPlot17.setDomainTickBandPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot29.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot29.setAxisOffset(rectangleInsets32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot29.setDomainCrosshairStroke(stroke34);
        xYPlot17.setRangeGridlineStroke(stroke34);
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] { stroke16, stroke34 };
        java.awt.Shape[] shapeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray5, strokeArray6, strokeArray37, shapeArray38);
        java.awt.Shape shape40 = defaultDrawingSupplier39.getNextShape();
        java.awt.Stroke stroke41 = defaultDrawingSupplier39.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str4.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = xYPlot6.getOrientation();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(plotOrientation19);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        java.util.Date date5 = day0.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color3);
        categoryAxis1.setLowerMargin((double) '#');
        categoryAxis1.setCategoryMargin(1.0d);
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint12 = null;
        java.awt.Color color15 = java.awt.Color.BLUE;
        java.awt.Color color16 = color15.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str18 = categoryAxis17.getLabelToolTip();
        int int19 = categoryAxis17.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke20 = categoryAxis17.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color23);
        boolean boolean25 = categoryAxis21.isVisible();
        java.awt.Paint paint26 = categoryAxis21.getTickMarkPaint();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100, paint28, stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color16, stroke20, paint26, stroke29, (float) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(Double.NEGATIVE_INFINITY, (java.awt.Paint) color9, stroke11, paint12, stroke29, 0.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = valueMarker34.getLabelOffsetType();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType35);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation12 = axisLocation11.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation12, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis16.setLowerBound((double) 0);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range19, false, true);
        boolean boolean23 = dateAxis16.isAxisLineVisible();
        java.text.DateFormat dateFormat24 = null;
        dateAxis16.setDateFormatOverride(dateFormat24);
        org.jfree.data.Range range26 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis16);
        boolean boolean27 = dateAxis16.isInverted();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = numberAxis1.java2DToValue((double) (-12517377), rectangle2D5, rectangleEdge6);
        numberAxis1.configure();
        java.lang.Class<?> wildcardClass9 = numberAxis1.getClass();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        dateAxis1.setLowerBound((double) 500);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis1.getTimeline();
        org.jfree.chart.plot.Plot plot8 = dateAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        xYPlot0.setRangeCrosshairValue((double) (-1.0f), false);
        xYPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6);
        java.awt.Stroke stroke8 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier8);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis12.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis12.getMarkerBand();
        java.text.NumberFormat numberFormat16 = null;
        numberAxis12.setNumberFormatOverride(numberFormat16);
        xYPlot0.setDomainAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis12, true);
        boolean boolean20 = numberAxis12.isNegativeArrowVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis12.setMarkerBand(markerAxisBand21);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(markerAxisBand15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRange(range7, false, true);
        org.jfree.data.Range range11 = dateAxis4.getRange();
        dateAxis1.setRangeWithMargins(range11, true, true);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot15.setDataset((int) (byte) 10, xYDataset19);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot15.setNoDataMessageFont(font21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot15.setOutlineStroke(stroke23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot15.getRangeAxisEdge();
        java.lang.String str26 = xYPlot15.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot15.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis29.setAutoRangeStickyZero(true);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = numberAxis29.java2DToValue((double) (-12517377), rectangle2D33, rectangleEdge34);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis29);
        numberAxis29.setAutoRange(false);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis40.setLowerBound((double) 0);
        java.util.TimeZone timeZone43 = dateAxis40.getTimeZone();
        java.awt.Paint paint44 = dateAxis40.getAxisLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis45.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color47);
        java.lang.String str49 = categoryAxis45.getLabelURL();
        int int50 = categoryAxis45.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset53 = xYPlot51.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        xYPlot51.setDataset((int) (byte) 10, xYDataset55);
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        java.util.List list59 = null;
        xYPlot51.drawRangeTickBands(graphics2D57, rectangle2D58, list59);
        categoryAxis45.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot51);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset64 = xYPlot62.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis66.setLowerBound((double) 0);
        xYPlot62.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis66);
        org.jfree.data.Range range70 = xYPlot51.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis66);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis72.setLowerBound((double) 0);
        org.jfree.data.Range range75 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis72.setRange(range75, false, true);
        dateAxis66.setRange(range75, false, false);
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis83.setLowerBound((double) 0);
        org.jfree.data.Range range86 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis83.setRange(range86, false, true);
        org.jfree.data.Range range90 = dateAxis83.getRange();
        dateAxis66.setRangeWithMargins(range90, true, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray94 = new org.jfree.chart.axis.ValueAxis[] { numberAxis29, dateAxis40, dateAxis66 };
        xYPlot15.setDomainAxes(valueAxisArray94);
        float float96 = xYPlot15.getBackgroundAlpha();
        boolean boolean97 = dateAxis1.equals((java.lang.Object) xYPlot15);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "XY Plot" + "'", str26.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNull(xYDataset53);
        org.junit.Assert.assertNull(xYDataset64);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(range86);
        org.junit.Assert.assertNotNull(range90);
        org.junit.Assert.assertNotNull(valueAxisArray94);
        org.junit.Assert.assertTrue("'" + float96 + "' != '" + 1.0f + "'", float96 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.RIGHT");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        double double4 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawRangeTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        xYPlot6.clearDomainMarkers(8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation28 = null;
        try {
            xYPlot6.addAnnotation(xYAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setUpArrow(shape4);
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis8.setLowerBound((double) 0);
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range11, false, true);
        dateAxis1.setRange(range11);
        java.awt.Paint paint16 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperMargin(100.0d);
        java.util.Date date20 = dateAxis10.getMaximumDate();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) 3);
        java.lang.Object obj4 = categoryAxis0.clone();
        java.awt.Paint paint5 = categoryAxis0.getTickLabelPaint();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        boolean boolean3 = day0.equals((java.lang.Object) color2);
//        java.util.Date date4 = day0.getEnd();
//        java.util.Date date5 = day0.getStart();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker8.setLabelFont(font13);
        java.lang.Object obj15 = categoryMarker8.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryMarker8.getLabelOffset();
        float float17 = categoryMarker8.getAlpha();
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        boolean boolean3 = day0.equals((java.lang.Object) color2);
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke19 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        xYPlot0.clearRangeMarkers(3);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        int int16 = xYPlot0.indexOf(xYDataset15);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.trimWidth((double) (short) -1);
        categoryMarker6.setLabelOffset(rectangleInsets7);
        java.awt.Paint paint11 = categoryMarker6.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        xYPlot12.setDataset((int) (byte) 10, xYDataset16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.util.List list20 = null;
        xYPlot12.drawRangeTickBands(graphics2D18, rectangle2D19, list20);
        java.awt.Color color22 = java.awt.Color.BLACK;
        xYPlot12.setDomainTickBandPaint((java.awt.Paint) color22);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 100, paint26, stroke27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot12.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker28, layer29, true);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot12.getDomainAxis(192);
        int int34 = xYPlot12.getDatasetCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot36 = categoryAxis35.getPlot();
        double double37 = categoryAxis35.getFixedDimension();
        categoryAxis35.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions39 = categoryAxis35.getCategoryLabelPositions();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset42 = xYPlot40.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        xYPlot40.setDataset((int) (byte) 10, xYDataset44);
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot40.setNoDataMessageFont(font46);
        categoryAxis35.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot40);
        java.awt.Paint paint49 = categoryAxis35.getLabelPaint();
        xYPlot12.setRangeZeroBaselinePaint(paint49);
        java.awt.Stroke stroke51 = xYPlot12.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis53.setLowerBound((double) 0);
        org.jfree.data.Range range56 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis53.setRange(range56, false, true);
        dateAxis53.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition61 = dateAxis53.getTickMarkPosition();
        java.awt.Color color62 = org.jfree.chart.ChartColor.DARK_RED;
        int int63 = color62.getRed();
        java.awt.image.ColorModel colorModel64 = null;
        java.awt.Rectangle rectangle65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color62.createContext(colorModel64, rectangle65, rectangle2D66, affineTransform67, renderingHints68);
        dateAxis53.setLabelPaint((java.awt.Paint) color62);
        java.awt.Color color71 = color62.darker();
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset74 = xYPlot72.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset76 = null;
        xYPlot72.setDataset((int) (byte) 10, xYDataset76);
        org.jfree.chart.axis.AxisSpace axisSpace78 = null;
        xYPlot72.setFixedDomainAxisSpace(axisSpace78);
        java.awt.Stroke stroke80 = xYPlot72.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker82 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, paint11, stroke51, (java.awt.Paint) color62, stroke80, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor83 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str84 = textAnchor83.toString();
        categoryMarker82.setLabelTextAnchor(textAnchor83);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-9.0d) + "'", double9 == (-9.0d));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 11 + "'", int34 == 11);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions39);
        org.junit.Assert.assertNull(xYDataset42);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(dateTickMarkPosition61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 192 + "'", int63 == 192);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNull(xYDataset74);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(textAnchor83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str84.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource22);
        dateAxis10.zoomRange((double) (-3407872), (double) 192);
        java.awt.Color color29 = java.awt.Color.BLUE;
        java.awt.Color color30 = color29.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str32 = categoryAxis31.getLabelToolTip();
        int int33 = categoryAxis31.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke34 = categoryAxis31.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis35.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color37);
        boolean boolean39 = categoryAxis35.isVisible();
        java.awt.Paint paint40 = categoryAxis35.getTickMarkPaint();
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 100, paint42, stroke43);
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color30, stroke34, paint40, stroke43, (float) (byte) 1);
        dateAxis10.setTickMarkStroke(stroke34);
        double double48 = dateAxis10.getLowerMargin();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset3 = xYPlot1.getDataset((-655360));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.CrosshairState crosshairState8 = null;
        boolean boolean9 = xYPlot1.render(graphics2D4, rectangle2D5, (int) 'a', plotRenderingInfo7, crosshairState8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer12 = null;
        xYPlot1.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker11, layer12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker11.setLabelAnchor(rectangleAnchor14);
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryMarker11.getLabelTextAnchor();
        boolean boolean17 = rectangleAnchor0.equals((java.lang.Object) textAnchor16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color19 = color18.brighter();
        boolean boolean20 = rectangleAnchor0.equals((java.lang.Object) color19);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(xYDataset3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        int int16 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis18.setLowerBound((double) 0);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRange(range21, false, true);
        dateAxis18.configure();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis18.getTickMarkPosition();
        dateAxis11.setTickMarkPosition(dateTickMarkPosition26);
        dateAxis11.setUpperMargin((double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot32.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot32.setAxisOffset(rectangleInsets35);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot32.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot32.getRangeAxisEdge((int) ' ');
        try {
            double double41 = dateAxis11.valueToJava2D((double) (byte) 0, rectangle2D31, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.next();
//        java.lang.String str3 = day1.toString();
//        boolean boolean4 = seriesRenderingOrder0.equals((java.lang.Object) day1);
//        java.lang.String str5 = day1.toString();
//        java.util.Date date6 = day1.getEnd();
//        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100, paint1, stroke2);
        java.lang.String str4 = valueMarker3.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis9.setLowerBound((double) 0);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range12, false, true);
        org.jfree.data.Range range16 = dateAxis9.getRange();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis18.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRange(range24, false, true);
        org.jfree.data.Range range28 = dateAxis21.getRange();
        dateAxis18.setRangeWithMargins(range28, true, true);
        dateAxis9.setRange(range28, true, true);
        boolean boolean35 = xYPlot0.equals((java.lang.Object) true);
        java.awt.Color color38 = java.awt.Color.BLUE;
        java.awt.Color color39 = color38.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str41 = categoryAxis40.getLabelToolTip();
        int int42 = categoryAxis40.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke43 = categoryAxis40.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis44.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color46);
        boolean boolean48 = categoryAxis44.isVisible();
        java.awt.Paint paint49 = categoryAxis44.getTickMarkPaint();
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) 100, paint51, stroke52);
        org.jfree.chart.plot.IntervalMarker intervalMarker55 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color39, stroke43, paint49, stroke52, (float) (byte) 1);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color39);
        int int57 = color39.getGreen();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        xYPlot0.setWeight((int) (short) 0);
        org.jfree.chart.plot.Plot plot39 = xYPlot0.getParent();
        org.jfree.chart.plot.Marker marker40 = null;
        try {
            xYPlot0.addRangeMarker(marker40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(plot39);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int3 = java.awt.Color.HSBtoRGB((float) 8, (float) 1560495599999L, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        float float12 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        int int13 = xYPlot0.getDatasetCount();
        boolean boolean14 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.data.general.DatasetGroup datasetGroup17 = xYPlot6.getDatasetGroup();
        int int18 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot20.setAxisOffset(rectangleInsets23);
        boolean boolean25 = rectangleAnchor19.equals((java.lang.Object) rectangleInsets23);
        xYPlot6.setAxisOffset(rectangleInsets23);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset29 = xYPlot27.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        xYPlot27.setDataset((int) (byte) 10, xYDataset31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot27.drawRangeTickBands(graphics2D33, rectangle2D34, list35);
        java.awt.Color color37 = java.awt.Color.BLACK;
        xYPlot27.setDomainTickBandPaint((java.awt.Paint) color37);
        java.awt.Color color39 = color37.darker();
        xYPlot6.setRangeGridlinePaint((java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '#', (float) (short) 1, (float) 'a');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis2.setLowerBound((double) 0);
        java.util.TimeZone timeZone5 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color11);
        java.lang.String str13 = categoryAxis9.getLabelURL();
        int int14 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = xYPlot15.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        xYPlot15.setDataset((int) (byte) 10, xYDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.util.List list23 = null;
        xYPlot15.drawRangeTickBands(graphics2D21, rectangle2D22, list23);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis30.setLowerBound((double) 0);
        xYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.data.Range range34 = xYPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis30);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis36.setLowerBound((double) 0);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range39, false, true);
        dateAxis30.setRange(range39, false, false);
        boolean boolean46 = dateAxis30.isVisible();
        java.util.Date date47 = dateAxis30.getMinimumDate();
        dateAxis8.setMaximumDate(date47);
        dateAxis6.setMaximumDate(date47);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.CrosshairState crosshairState57 = null;
        boolean boolean58 = xYPlot50.render(graphics2D53, rectangle2D54, (int) 'a', plotRenderingInfo56, crosshairState57);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot50.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker60, layer61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        xYPlot50.drawAnnotations(graphics2D63, rectangle2D64, plotRenderingInfo65);
        boolean boolean67 = xYPlot50.isDomainCrosshairVisible();
        dateAxis6.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot50);
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        xYPlot50.setFixedDomainAxisSpace(axisSpace69);
        int int71 = xYPlot50.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 15 + "'", int71 == 15);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        xYPlot0.zoom((double) (-1.0f));
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace23);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairValue((double) 'a');
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.trimWidth((double) (short) -1);
        categoryMarker4.setLabelOffset(rectangleInsets5);
        java.awt.Paint paint9 = categoryMarker4.getOutlinePaint();
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryMarker4.setLabelFont(font10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker4);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot13.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot13.setAxisOffset(rectangleInsets16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setDomainCrosshairStroke(stroke18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot13.getRangeAxisEdge((int) ' ');
        boolean boolean22 = categoryMarker4.equals((java.lang.Object) xYPlot13);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        markerChangeEvent23.setType(chartChangeEventType24);
        xYPlot0.markerChanged(markerChangeEvent23);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-9.0d) + "'", double7 == (-9.0d));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) rectangleInsets5);
        double double8 = rectangleInsets4.calculateBottomInset((double) (byte) 10);
        categoryAxis0.setTickLabelInsets(rectangleInsets4);
        double double11 = rectangleInsets4.calculateTopInset((double) '4');
        double double13 = rectangleInsets4.trimHeight(1.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-3.0d) + "'", double13 == (-3.0d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        categoryAxis0.setLowerMargin((double) '#');
        categoryAxis0.setCategoryMargin(1.0d);
        double double8 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        int int4 = xYPlot0.indexOf(xYDataset3);
        java.awt.Paint paint6 = xYPlot0.getQuadrantPaint((int) (byte) 1);
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.awt.Color color10 = color9.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str12 = categoryAxis11.getLabelToolTip();
        int int13 = categoryAxis11.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke14 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis15.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color17);
        boolean boolean19 = categoryAxis15.isVisible();
        java.awt.Paint paint20 = categoryAxis15.getTickMarkPaint();
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 100, paint22, stroke23);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color10, stroke14, paint20, stroke23, (float) (byte) 1);
        xYPlot0.setRangeZeroBaselineStroke(stroke14);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        objectList0.clear();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot4.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis8.setLowerBound((double) 0);
        xYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis13.setLowerBound((double) 0);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range16, false, true);
        org.jfree.data.Range range20 = dateAxis13.getRange();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis22.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis25.setLowerBound((double) 0);
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis25.setRange(range28, false, true);
        org.jfree.data.Range range32 = dateAxis25.getRange();
        dateAxis22.setRangeWithMargins(range32, true, true);
        dateAxis13.setRange(range32, true, true);
        boolean boolean39 = xYPlot4.equals((java.lang.Object) true);
        objectList0.set((int) '#', (java.lang.Object) boolean39);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        categoryAxis0.setCategoryMargin((double) 100L);
        categoryAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        float float10 = dateAxis4.getTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = xYPlot13.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot13.setDataset((int) (byte) 10, xYDataset17);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot13.setNoDataMessageFont(font19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot13.setOutlineStroke(stroke21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot13.getRangeAxisEdge();
        java.lang.String str24 = xYPlot13.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot13.getRangeAxisEdge();
        try {
            double double26 = dateAxis4.valueToJava2D((double) 1, rectangle2D12, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "XY Plot" + "'", str24.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace8 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot18.getDataset((-655360));
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.CrosshairState crosshairState25 = null;
        boolean boolean26 = xYPlot18.render(graphics2D21, rectangle2D22, (int) 'a', plotRenderingInfo24, crosshairState25);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis28.setLowerBound((double) 0);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRange(range31, false, true);
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        dateAxis28.setNegativeArrowVisible(true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        double double8 = xYPlot0.getDomainCrosshairValue();
        boolean boolean9 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace10, true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot0.getDataset(255);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(xYDataset21);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = xYPlot0.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot10.setDataset((int) (byte) 10, xYDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot10.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        java.awt.Color color20 = java.awt.Color.BLACK;
        xYPlot10.setDomainTickBandPaint((java.awt.Paint) color20);
        boolean boolean22 = xYPlot10.isOutlineVisible();
        int int23 = xYPlot10.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot10.getRangeAxisLocation(3);
        xYPlot0.setDomainAxisLocation(axisLocation25);
        xYPlot0.setBackgroundAlpha(10.0f);
        xYPlot0.setRangeGridlinesVisible(true);
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        numberAxis1.configure();
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setFixedDimension((double) 1);
        try {
            numberAxis1.setRangeWithMargins((double) 2.0f, (double) (-14400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (-1.4400001E7).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        dateAxis1.setLowerBound(10.0d);
        float float10 = dateAxis1.getTickMarkInsideLength();
        dateAxis1.setLowerBound(4.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis14.setLowerBound((double) 0);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis14.setRange(range17, false, true);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis22.setLowerBound((double) 0);
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis22.setRange(range25, false, true);
        dateAxis14.setRangeWithMargins(range25, false, false);
        dateAxis1.setRange(range25);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis34.setLowerBound((double) 0);
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis34.setRange(range37, false, true);
        dateAxis34.setLowerBound(10.0d);
        float float43 = dateAxis34.getTickMarkInsideLength();
        dateAxis34.setRangeAboutValue((double) 0L, (double) 10L);
        org.jfree.data.Range range47 = dateAxis34.getRange();
        dateAxis1.setDefaultAutoRange(range47);
        java.awt.Paint paint49 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot1 = categoryAxis0.getPlot();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.configure();
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(plot1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis6.setLowerBound((double) 0);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis6.setRange(range9, false, true);
        boolean boolean13 = dateAxis6.isAxisLineVisible();
        double double14 = dateAxis6.getLowerMargin();
        java.util.Date date15 = dateAxis6.getMaximumDate();
        java.text.DateFormat dateFormat16 = null;
        dateAxis6.setDateFormatOverride(dateFormat16);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis6.getTickUnit();
        java.util.Date date19 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit18);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        xYPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        xYPlot2.setDataset((int) (byte) 10, xYDataset6);
        xYPlot2.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot2.getOrientation();
        boolean boolean11 = xYPlot2.isDomainZeroBaselineVisible();
        xYPlot2.clearRangeMarkers((int) ' ');
        double double14 = xYPlot2.getDomainCrosshairValue();
        int int15 = objectList0.indexOf((java.lang.Object) xYPlot2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        xYPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke6);
        java.lang.String str8 = xYPlot0.getPlotType();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "XY Plot" + "'", str8.equals("XY Plot"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Date date5 = regularTimePeriod4.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass1 = categoryAxis0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot2.render(graphics2D5, rectangle2D6, (int) 'a', plotRenderingInfo8, crosshairState9);
        java.awt.Paint paint12 = xYPlot2.getQuadrantPaint((int) (byte) 1);
        boolean boolean13 = categoryAxis0.hasListener((java.util.EventListener) xYPlot2);
        xYPlot2.setDomainCrosshairVisible(true);
        xYPlot2.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setTickMarkInsideLength((float) 3);
        java.lang.Object obj4 = categoryAxis0.clone();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot5.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot5.setAxisOffset(rectangleInsets8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot5.setDomainCrosshairStroke(stroke10);
        java.lang.Object obj12 = xYPlot5.clone();
        int int13 = xYPlot5.getBackgroundImageAlignment();
        int int14 = xYPlot5.getDomainAxisCount();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot5);
        boolean boolean16 = xYPlot5.isDomainZoomable();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        xYPlot6.setDomainCrosshairLockedOnData(true);
        xYPlot6.clearRangeMarkers();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot29.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        xYPlot29.setDataset((int) (byte) 10, xYDataset33);
        xYPlot29.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = xYPlot29.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot39.getDataset((-655360));
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.chart.plot.CrosshairState crosshairState46 = null;
        boolean boolean47 = xYPlot39.render(graphics2D42, rectangle2D43, (int) 'a', plotRenderingInfo45, crosshairState46);
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer50 = null;
        xYPlot39.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker49, layer50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker49.setLabelAnchor(rectangleAnchor52);
        org.jfree.chart.text.TextAnchor textAnchor54 = categoryMarker49.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset57 = xYPlot55.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot55.setAxisOffset(rectangleInsets58);
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean63 = xYPlot55.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker61, layer62);
        boolean boolean65 = xYPlot29.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker49, layer62, false);
        xYPlot29.setWeight((int) (short) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray69 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer68 };
        xYPlot29.setRenderers(xYItemRendererArray69);
        xYPlot6.setRenderers(xYItemRendererArray69);
        xYPlot6.setNoDataMessage("");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(textAnchor54);
        org.junit.Assert.assertNull(xYDataset57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray69);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis9.setLowerBound((double) 0);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range12, false, true);
        dateAxis1.setRangeWithMargins(range12, false, false);
        boolean boolean20 = dateAxis1.isHiddenValue(0L);
        dateAxis1.setLowerBound((double) (-16728064));
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis24.setLowerBound((double) 0);
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRange(range27, false, true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis32.setRange(range35, false, true);
        dateAxis24.setRangeWithMargins(range35, false, false);
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset44 = xYPlot42.getDataset((-655360));
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.plot.CrosshairState crosshairState49 = null;
        boolean boolean50 = xYPlot42.render(graphics2D45, rectangle2D46, (int) 'a', plotRenderingInfo48, crosshairState49);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis52.setLowerBound((double) 0);
        org.jfree.data.Range range55 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis52.setRange(range55, false, true);
        xYPlot42.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis52);
        java.awt.Shape shape60 = dateAxis52.getDownArrow();
        dateAxis24.setLeftArrow(shape60);
        boolean boolean62 = dateAxis1.equals((java.lang.Object) dateAxis24);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(xYDataset44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        xYPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot0.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CrosshairState crosshairState17 = null;
        boolean boolean18 = xYPlot10.render(graphics2D13, rectangle2D14, (int) 'a', plotRenderingInfo16, crosshairState17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker20.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = categoryMarker20.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot26.setAxisOffset(rectangleInsets29);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot26.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer33);
        boolean boolean36 = xYPlot0.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker20, layer33, false);
        xYPlot0.setWeight((int) (short) 0);
        org.jfree.chart.plot.Plot plot39 = xYPlot0.getParent();
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(plot39);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset24 = xYPlot22.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot22.setDataset((int) (byte) 10, xYDataset26);
        xYPlot22.setNoDataMessage("");
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = xYPlot22.getOrientation();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot32.getDataset((-655360));
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.CrosshairState crosshairState39 = null;
        boolean boolean40 = xYPlot32.render(graphics2D35, rectangle2D36, (int) 'a', plotRenderingInfo38, crosshairState39);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer43 = null;
        xYPlot32.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker42, layer43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker42.setLabelAnchor(rectangleAnchor45);
        org.jfree.chart.text.TextAnchor textAnchor47 = categoryMarker42.getLabelTextAnchor();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset50 = xYPlot48.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot48.setAxisOffset(rectangleInsets51);
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean56 = xYPlot48.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker54, layer55);
        boolean boolean58 = xYPlot22.removeDomainMarker((int) '4', (org.jfree.chart.plot.Marker) categoryMarker42, layer55, false);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21, layer55);
        java.lang.Class<?> wildcardClass60 = layer55.getClass();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(xYDataset24);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNull(xYDataset50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(wildcardClass60);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        boolean boolean12 = xYPlot0.isOutlineVisible();
        double double13 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot14.getDataset((-655360));
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot14.render(graphics2D17, rectangle2D18, (int) 'a', plotRenderingInfo20, crosshairState21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis24.setLowerBound((double) 0);
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRange(range27, false, true);
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis24);
        dateAxis24.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis35.getStandardTickUnits();
        dateAxis24.setStandardTickUnits(tickUnitSource36);
        dateAxis24.zoomRange((double) (-3407872), (double) 192);
        int int41 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis24);
        dateAxis24.zoomRange((double) (-10419871), (double) 64);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis20.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean26 = rectangleInsets24.equals((java.lang.Object) rectangleInsets25);
        double double28 = rectangleInsets24.calculateBottomInset((double) (byte) 10);
        categoryAxis20.setTickLabelInsets(rectangleInsets24);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double32 = rectangleInsets30.calculateLeftOutset(1.0d);
        categoryAxis20.setTickLabelInsets(rectangleInsets30);
        valueMarker16.setLabelOffset(rectangleInsets30);
        double double35 = valueMarker16.getValue();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        java.lang.Object obj7 = xYPlot0.clone();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setOutlineStroke(stroke8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis11.setLowerBound((double) 0);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis11.setUpArrow(shape14);
        int int16 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot0.getLegendItems();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = day0.getEnd();
        int int3 = day0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Date date5 = day0.getEnd();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) day0, dataset6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        java.awt.Paint paint17 = null;
        xYPlot6.setDomainTickBandPaint(paint17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot6.indexOf(xYDataset19);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis9.setLowerBound((double) 0);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range12, false, true);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis17.setLowerBound((double) 0);
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range20, false, true);
        dateAxis9.setRangeWithMargins(range20, false, false);
        dateAxis1.setRangeWithMargins(range20);
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setFixedAutoRange((double) (short) 0);
        java.awt.Font font32 = dateAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis4.setLowerBound((double) 0);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        dateAxis4.setAxisLineVisible(false);
        double double10 = dateAxis4.getFixedAutoRange();
        java.awt.Shape shape11 = dateAxis4.getUpArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis4.getTickUnit();
        boolean boolean13 = dateAxis4.isVerticalTickLabels();
        dateAxis4.setAxisLineVisible(false);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean3 = day0.equals((java.lang.Object) color2);
        java.util.Date date4 = day0.getEnd();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CrosshairState crosshairState13 = null;
        boolean boolean14 = xYPlot6.render(graphics2D9, rectangle2D10, (int) 'a', plotRenderingInfo12, crosshairState13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker16.setLabelAnchor(rectangleAnchor19);
        org.jfree.chart.text.TextAnchor textAnchor21 = categoryMarker16.getLabelTextAnchor();
        boolean boolean22 = rectangleAnchor5.equals((java.lang.Object) textAnchor21);
        boolean boolean23 = day0.equals((java.lang.Object) rectangleAnchor5);
        int int24 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day0.previous();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset28 = xYPlot26.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot26.setDataset((int) (byte) 10, xYDataset30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot26.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        java.awt.Color color36 = java.awt.Color.BLACK;
        xYPlot26.setDomainTickBandPaint((java.awt.Paint) color36);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 100, paint40, stroke41);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot26.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker42, layer43, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis46.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean52 = rectangleInsets50.equals((java.lang.Object) rectangleInsets51);
        double double54 = rectangleInsets50.calculateBottomInset((double) (byte) 10);
        categoryAxis46.setTickLabelInsets(rectangleInsets50);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double58 = rectangleInsets56.calculateLeftOutset(1.0d);
        categoryAxis46.setTickLabelInsets(rectangleInsets56);
        valueMarker42.setLabelOffset(rectangleInsets56);
        boolean boolean61 = day0.equals((java.lang.Object) rectangleInsets56);
        double double62 = rectangleInsets56.getRight();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(xYDataset28);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 4.0d + "'", double58 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 4.0d + "'", double62 == 4.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color3);
        java.lang.String str5 = categoryAxis1.getLabelURL();
        int int6 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot7.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        xYPlot7.setDataset((int) (byte) 10, xYDataset11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot7.drawRangeTickBands(graphics2D13, rectangle2D14, list15);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot7);
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot7.getDatasetGroup();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str21 = categoryAxis20.getLabelToolTip();
        int int22 = categoryAxis20.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis20.setTickLabelPaint((java.awt.Paint) chartColor26);
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) chartColor26);
        float[] floatArray36 = new float[] { 4, 100L, 100, 1.0f };
        float[] floatArray37 = java.awt.Color.RGBtoHSB(255, 5, (int) (short) 10, floatArray36);
        float[] floatArray38 = chartColor26.getColorComponents(floatArray37);
        float[] floatArray39 = color0.getRGBColorComponents(floatArray37);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis10.setLowerBound((double) 0);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range13, false, true);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setUpperMargin(100.0d);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis21.getStandardTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource22);
        dateAxis10.zoomRange((double) (-3407872), (double) 192);
        java.awt.Color color29 = java.awt.Color.BLUE;
        java.awt.Color color30 = color29.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str32 = categoryAxis31.getLabelToolTip();
        int int33 = categoryAxis31.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke34 = categoryAxis31.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis35.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color37);
        boolean boolean39 = categoryAxis35.isVisible();
        java.awt.Paint paint40 = categoryAxis35.getTickMarkPaint();
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 100, paint42, stroke43);
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color30, stroke34, paint40, stroke43, (float) (byte) 1);
        dateAxis10.setTickMarkStroke(stroke34);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        org.jfree.chart.plot.CrosshairState crosshairState57 = null;
        boolean boolean58 = xYPlot50.render(graphics2D53, rectangle2D54, (int) 'a', plotRenderingInfo56, crosshairState57);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot50.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker60, layer61);
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        xYPlot50.drawAnnotations(graphics2D63, rectangle2D64, plotRenderingInfo65);
        boolean boolean67 = xYPlot50.isDomainCrosshairVisible();
        int int68 = xYPlot50.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = xYPlot50.getRangeAxisEdge(3);
        try {
            double double71 = dateAxis10.java2DToValue((double) 1.0f, rectangle2D49, rectangleEdge70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 15 + "'", int68 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeStickyZero(true);
        try {
            numberAxis1.setRange((double) 64, (-3.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (64.0) <= upper (-3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4, false, true);
        boolean boolean8 = dateAxis1.isAxisLineVisible();
        double double9 = dateAxis1.getLowerMargin();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CrosshairState crosshairState19 = null;
        boolean boolean20 = xYPlot12.render(graphics2D15, rectangle2D16, (int) 'a', plotRenderingInfo18, crosshairState19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        xYPlot12.drawAnnotations(graphics2D25, rectangle2D26, plotRenderingInfo27);
        boolean boolean29 = xYPlot12.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        int int31 = xYPlot12.getIndexOf(xYItemRenderer30);
        org.jfree.data.xy.XYDataset xYDataset33 = xYPlot12.getDataset(255);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot12.getDomainAxisEdge(0);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot12);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(xYDataset33);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = xYPlot0.getDomainAxisIndex(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot10.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot10.setDataset((int) (byte) 10, xYDataset14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        xYPlot10.drawRangeTickBands(graphics2D16, rectangle2D17, list18);
        java.awt.Color color20 = java.awt.Color.BLACK;
        xYPlot10.setDomainTickBandPaint((java.awt.Paint) color20);
        boolean boolean22 = xYPlot10.isOutlineVisible();
        int int23 = xYPlot10.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot10.getRangeAxisLocation(3);
        xYPlot0.setDomainAxisLocation(axisLocation25);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer27);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        xYPlot6.setDomainCrosshairLockedOnData(true);
        xYPlot6.clearRangeMarkers();
        xYPlot6.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.trimWidth((double) (short) -1);
        categoryMarker1.setLabelOffset(rectangleInsets2);
        java.awt.Paint paint6 = categoryMarker1.getOutlinePaint();
        java.awt.Color color9 = java.awt.Color.BLUE;
        java.awt.Color color10 = color9.brighter();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str12 = categoryAxis11.getLabelToolTip();
        int int13 = categoryAxis11.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke14 = categoryAxis11.getTickMarkStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis15.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color17);
        boolean boolean19 = categoryAxis15.isVisible();
        java.awt.Paint paint20 = categoryAxis15.getTickMarkPaint();
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) 100, paint22, stroke23);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 100.0d, (java.awt.Paint) color10, stroke14, paint20, stroke23, (float) (byte) 1);
        categoryMarker1.setStroke(stroke23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot29.getDataset((-655360));
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.plot.CrosshairState crosshairState36 = null;
        boolean boolean37 = xYPlot29.render(graphics2D32, rectangle2D33, (int) 'a', plotRenderingInfo35, crosshairState36);
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer40 = null;
        xYPlot29.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker39, layer40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker39.setLabelAnchor(rectangleAnchor42);
        boolean boolean44 = lengthAdjustmentType28.equals((java.lang.Object) rectangleAnchor42);
        categoryMarker1.setLabelOffsetType(lengthAdjustmentType28);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.Plot plot47 = categoryAxis46.getPlot();
        double double48 = categoryAxis46.getFixedDimension();
        categoryAxis46.configure();
        categoryAxis46.addCategoryLabelToolTip((java.lang.Comparable) (-1.0f), "Layer.BACKGROUND");
        boolean boolean53 = lengthAdjustmentType28.equals((java.lang.Object) "Layer.BACKGROUND");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType28);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1L), (double) 8, (double) ' ', (double) 0L);
        double double6 = rectangleInsets4.calculateBottomInset((double) 5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = xYPlot21.getDataset((-655360));
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.CrosshairState crosshairState28 = null;
        boolean boolean29 = xYPlot21.render(graphics2D24, rectangle2D25, (int) 'a', plotRenderingInfo27, crosshairState28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot21.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker31, layer32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot21.drawAnnotations(graphics2D34, rectangle2D35, plotRenderingInfo36);
        boolean boolean38 = xYPlot21.isDomainCrosshairVisible();
        int int39 = xYPlot21.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot21.getRangeAxisEdge(3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        try {
            org.jfree.chart.axis.AxisState axisState43 = categoryAxis0.draw(graphics2D17, 35.0d, rectangle2D19, rectangle2D20, rectangleEdge41, plotRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 15 + "'", int39 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "java.awt.Color[r=64,g=64,b=64]", (java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis0.getLabelURL();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot6.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot6.drawRangeTickBands(graphics2D12, rectangle2D13, list14);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot17.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis21.setLowerBound((double) 0);
        xYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.Range range25 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        xYPlot6.setDomainCrosshairLockedOnData(true);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot28.setDataset((int) (byte) 10, xYDataset32);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot28.setNoDataMessageFont(font34);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot28.setDataset((int) (byte) 0, xYDataset37);
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot39.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot39.setAxisOffset(rectangleInsets42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot39.setDomainCrosshairStroke(stroke44);
        java.lang.Object obj46 = xYPlot39.clone();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot39.setOutlineStroke(stroke47);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = xYPlot39.getDatasetRenderingOrder();
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot50.setDataset((int) (byte) 10, xYDataset54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot50.getDomainAxis(10);
        org.jfree.chart.axis.ValueAxis valueAxis59 = xYPlot50.getDomainAxis((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str61 = categoryAxis60.getLabelToolTip();
        int int62 = categoryAxis60.getCategoryLabelPositionOffset();
        org.jfree.chart.ChartColor chartColor66 = new org.jfree.chart.ChartColor((int) 'a', (int) (byte) 1, (int) 'a');
        categoryAxis60.setTickLabelPaint((java.awt.Paint) chartColor66);
        java.lang.String str69 = categoryAxis60.getCategoryLabelToolTip((java.lang.Comparable) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Class<?> wildcardClass71 = categoryAxis70.getClass();
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset74 = xYPlot72.getDataset((-655360));
        java.awt.Graphics2D graphics2D75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        org.jfree.chart.plot.CrosshairState crosshairState79 = null;
        boolean boolean80 = xYPlot72.render(graphics2D75, rectangle2D76, (int) 'a', plotRenderingInfo78, crosshairState79);
        java.awt.Paint paint82 = xYPlot72.getQuadrantPaint((int) (byte) 1);
        boolean boolean83 = categoryAxis70.hasListener((java.util.EventListener) xYPlot72);
        categoryAxis60.setPlot((org.jfree.chart.plot.Plot) xYPlot72);
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = xYPlot72.getAxisOffset();
        java.awt.Paint paint86 = xYPlot72.getNoDataMessagePaint();
        xYPlot50.setRangeTickBandPaint(paint86);
        boolean boolean88 = datasetRenderingOrder49.equals((java.lang.Object) paint86);
        xYPlot28.setDatasetRenderingOrder(datasetRenderingOrder49);
        xYPlot6.setDatasetRenderingOrder(datasetRenderingOrder49);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation91 = null;
        try {
            boolean boolean92 = xYPlot6.removeAnnotation(xYAnnotation91);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset8);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNull(valueAxis59);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNull(xYDataset74);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(paint82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(rectangleInsets85);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge((int) ' ');
        java.awt.Paint paint9 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.configureRangeAxes();
        boolean boolean11 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset14 = xYPlot12.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis16.setLowerBound((double) 0);
        xYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot20.render(graphics2D23, rectangle2D24, (int) 'a', plotRenderingInfo26, crosshairState27);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer31 = null;
        xYPlot20.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker30, layer31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        categoryMarker30.setLabelAnchor(rectangleAnchor33);
        categoryMarker30.setKey((java.lang.Comparable) 0L);
        java.awt.Paint paint37 = categoryMarker30.getOutlinePaint();
        dateAxis16.setTickMarkPaint(paint37);
        xYPlot0.setRangeTickBandPaint(paint37);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        xYPlot0.notifyListeners(plotChangeEvent40);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset4 = xYPlot2.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot2.setAxisOffset(rectangleInsets5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer9);
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = xYPlot0.removeDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker8, layer11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setDomainAxisLocation(1, axisLocation14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot16.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot16.setDataset((int) (byte) 10, xYDataset20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.util.List list24 = null;
        xYPlot16.drawRangeTickBands(graphics2D22, rectangle2D23, list24);
        java.awt.Color color26 = java.awt.Color.BLACK;
        xYPlot16.setDomainTickBandPaint((java.awt.Paint) color26);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 100, paint30, stroke31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot16.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker32, layer33, true);
        java.util.Collection collection36 = xYPlot0.getDomainMarkers(layer33);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = xYPlot0.getRangeMarkers((int) (byte) 1, layer38);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNull(collection39);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = null;
        boolean boolean8 = xYPlot0.render(graphics2D3, rectangle2D4, (int) 'a', plotRenderingInfo6, crosshairState7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-3407872));
        org.jfree.chart.util.Layer layer11 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker10, layer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        xYPlot0.drawAnnotations(graphics2D13, rectangle2D14, plotRenderingInfo15);
        boolean boolean17 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot0.getIndexOf(xYItemRenderer18);
        float float20 = xYPlot0.getForegroundAlpha();
        java.awt.Paint[] paintArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str25 = color24.toString();
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color23, color24 };
        java.awt.Stroke[] strokeArray27 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset30 = xYPlot28.getDataset((-655360));
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis32.setLowerBound((double) 0);
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        boolean boolean36 = dateAxis32.isPositiveArrowVisible();
        java.awt.Stroke stroke37 = dateAxis32.getAxisLineStroke();
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = xYPlot38.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        xYPlot38.setDataset((int) (byte) 10, xYDataset42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.util.List list46 = null;
        xYPlot38.drawRangeTickBands(graphics2D44, rectangle2D45, list46);
        java.awt.Color color48 = java.awt.Color.BLACK;
        xYPlot38.setDomainTickBandPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset52 = xYPlot50.getDataset((-655360));
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        xYPlot50.setAxisOffset(rectangleInsets53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot50.setDomainCrosshairStroke(stroke55);
        xYPlot38.setRangeGridlineStroke(stroke55);
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke37, stroke55 };
        java.awt.Shape[] shapeArray59 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray22, paintArray26, strokeArray27, strokeArray58, shapeArray59);
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier60);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset64 = xYPlot62.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        xYPlot62.setDataset((int) (byte) 10, xYDataset66);
        java.awt.Font font68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot62.setNoDataMessageFont(font68);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot62.setOutlineStroke(stroke70);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = xYPlot62.getRangeAxisEdge();
        java.lang.String str73 = xYPlot62.getPlotType();
        boolean boolean74 = xYPlot62.isDomainZoomable();
        java.awt.Paint paint75 = xYPlot62.getNoDataMessagePaint();
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot62);
        java.awt.Paint paint77 = xYPlot0.getBackgroundPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent78 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str25.equals("java.awt.Color[r=128,g=128,b=255]"));
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(xYDataset40);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(xYDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNull(xYDataset64);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "XY Plot" + "'", str73.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=64,g=64,b=64]");
        dateAxis1.setLowerBound((double) 0);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis1.setUpArrow(shape4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets6.getRight();
        dateAxis1.setTickLabelInsets(rectangleInsets6);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = xYPlot0.getDataset((-655360));
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        xYPlot0.drawRangeTickBands(graphics2D6, rectangle2D7, list8);
        java.awt.Color color10 = java.awt.Color.BLACK;
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color10);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 100, paint14, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addRangeMarker(15, (org.jfree.chart.plot.Marker) valueMarker16, layer17, true);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot20.getDataset((-655360));
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot20.render(graphics2D23, rectangle2D24, (int) 'a', plotRenderingInfo26, crosshairState27);
        java.awt.Paint paint30 = xYPlot20.getQuadrantPaint((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset32 = xYPlot20.getDataset((-655360));
        valueMarker16.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot20);
        valueMarker16.setValue(4.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker16.setLabelOffsetType(lengthAdjustmentType36);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNull(xYDataset32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
//        boolean boolean3 = day0.equals((java.lang.Object) color2);
//        java.util.Date date4 = day0.getEnd();
//        java.util.Date date5 = day0.getStart();
//        java.util.Date date6 = day0.getStart();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }
//}

