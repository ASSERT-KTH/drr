import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        boolean boolean17 = xYPlot16.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot16.getFixedRangeAxisSpace();
        xYPlot16.setRangeCrosshairValue((double) 2, true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(axisSpace18);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 1);
        boolean boolean7 = numberAxis1.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis1.getMarkerBand();
        java.lang.Object obj9 = numberAxis1.clone();
        numberAxis1.configure();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        numberAxis1.setTickMarkPaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(markerAxisBand8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot16);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot16.getAxisOffset();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabel();
        numberAxis39.setLabelURL("");
        boolean boolean44 = numberAxis39.equals((java.lang.Object) 1);
        boolean boolean45 = numberAxis39.isAutoRange();
        double double46 = numberAxis39.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis39, xYItemRenderer47);
        java.awt.Stroke stroke49 = xYPlot48.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        xYPlot48.drawBackgroundImage(graphics2D50, rectangle2D51);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = xYPlot48.getRenderer(100);
        java.awt.Stroke stroke55 = xYPlot48.getDomainGridlineStroke();
        java.awt.Paint paint56 = null;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker((double) 11, 3.0d, (java.awt.Paint) color31, stroke55, paint56, stroke57, 0.0f);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        intervalMarker59.setGradientPaintTransformer(gradientPaintTransformer60);
        double double62 = intervalMarker59.getEndValue();
        java.awt.Stroke stroke63 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        intervalMarker59.setOutlineStroke(stroke63);
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker59);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = intervalMarker59.getLabelOffset();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(xYItemRenderer54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 3.0d + "'", double62 == 3.0d);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(rectangleInsets66);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setLabelURL("");
        boolean boolean13 = numberAxis8.equals((java.lang.Object) 1);
        boolean boolean14 = numberAxis8.isAutoRange();
        double double15 = numberAxis8.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer16);
        java.awt.Stroke stroke18 = xYPlot17.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot17.setDomainAxisLocation(axisLocation19, false);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str27 = numberAxis26.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis26.setMarkerBand(markerAxisBand28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabel();
        numberAxis31.setLabelURL("");
        boolean boolean36 = numberAxis31.equals((java.lang.Object) 1);
        boolean boolean37 = numberAxis31.isAutoRange();
        double double38 = numberAxis31.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer39);
        java.awt.Stroke stroke41 = xYPlot40.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot40.setDomainGridlineStroke(stroke42);
        java.awt.Paint paint44 = xYPlot40.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot40.getRangeMarkers(layer45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = xYPlot40.getDomainAxisEdge((int) (short) 100);
        boolean boolean49 = dateAxis23.equals((java.lang.Object) xYPlot40);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str51 = plotOrientation50.toString();
        xYPlot40.setOrientation(plotOrientation50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation50);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str51.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = numberAxis12.getMarkerBand();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (-1.0f), (double) 1, (double) (short) 1, (double) (short) 1);
        numberAxis12.setTickLabelInsets(rectangleInsets24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis27.configure();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range31 = numberAxis30.getDefaultAutoRange();
        dateAxis27.setRangeWithMargins(range31, false, true);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis37.setMarkerBand(markerAxisBand39);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str43 = numberAxis42.getLabel();
        numberAxis42.setLabelURL("");
        boolean boolean47 = numberAxis42.equals((java.lang.Object) 1);
        boolean boolean48 = numberAxis42.isAutoRange();
        double double49 = numberAxis42.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) numberAxis37, (org.jfree.chart.axis.ValueAxis) numberAxis42, xYItemRenderer50);
        org.jfree.data.Range range52 = numberAxis37.getDefaultAutoRange();
        dateAxis27.setRange(range52, true, false);
        numberAxis12.setRangeWithMargins(range52, true, false);
        dateAxis7.setRange(range52);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(markerAxisBand19);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertNotNull(range52);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot10.getRenderer(4);
        categoryPlot10.setForegroundAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        int int28 = xYPlot16.getIndexOf(xYItemRenderer27);
        boolean boolean29 = xYPlot16.isOutlineVisible();
        xYPlot16.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation((int) 'a', axisLocation32);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot16.getDataset();
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot36.getDomainAxisLocation();
        boolean boolean38 = textAnchor35.equals((java.lang.Object) axisLocation37);
        xYPlot16.setDomainAxisLocation(axisLocation37, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot16.getRenderer((int) (byte) 0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation43 = null;
        try {
            boolean boolean44 = xYPlot16.removeAnnotation(xYAnnotation43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(xYItemRenderer42);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 10);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setLowerMargin(0.0d);
        categoryAxis14.setLabelAngle((-5.0d));
        org.jfree.chart.plot.Plot plot19 = categoryAxis14.getPlot();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.setLowerMargin(0.0d);
        double double24 = categoryAxis21.getUpperMargin();
        int int25 = categoryAxis21.getCategoryLabelPositionOffset();
        categoryAxis21.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        double double28 = dateAxis27.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        double double32 = categoryAxis31.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        double double34 = categoryAxis33.getUpperMargin();
        double double35 = categoryAxis33.getLowerMargin();
        double double36 = categoryAxis33.getLowerMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        double double38 = categoryAxis37.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setLowerMargin(0.0d);
        double double42 = categoryAxis39.getUpperMargin();
        int int43 = categoryAxis39.getCategoryLabelPositionOffset();
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_RED;
        int int48 = color47.getRGB();
        categoryAxis39.setTickLabelPaint((java.lang.Comparable) "TextAnchor.BASELINE_LEFT", (java.awt.Paint) color47);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray50 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis14, categoryAxis21, categoryAxis31, categoryAxis33, categoryAxis37, categoryAxis39 };
        categoryPlot10.setDomainAxes(categoryAxisArray50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis53.setMarkerBand(markerAxisBand55);
        java.lang.String str57 = numberAxis53.getLabel();
        org.jfree.data.RangeType rangeType58 = numberAxis53.getRangeType();
        double double59 = numberAxis53.getLowerBound();
        java.awt.Stroke stroke60 = numberAxis53.getAxisLineStroke();
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis53);
        categoryPlot10.configureRangeAxes();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.data.xy.XYDataset xYDataset66 = null;
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str69 = numberAxis68.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand70 = null;
        numberAxis68.setMarkerBand(markerAxisBand70);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str74 = numberAxis73.getLabel();
        numberAxis73.setLabelURL("");
        boolean boolean78 = numberAxis73.equals((java.lang.Object) 1);
        boolean boolean79 = numberAxis73.isAutoRange();
        double double80 = numberAxis73.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer81 = null;
        org.jfree.chart.plot.XYPlot xYPlot82 = new org.jfree.chart.plot.XYPlot(xYDataset66, (org.jfree.chart.axis.ValueAxis) numberAxis68, (org.jfree.chart.axis.ValueAxis) numberAxis73, xYItemRenderer81);
        java.awt.Stroke stroke83 = xYPlot82.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D84 = null;
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        xYPlot82.drawBackgroundImage(graphics2D84, rectangle2D85);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer88 = xYPlot82.getRenderer(100);
        java.awt.Stroke stroke89 = xYPlot82.getDomainGridlineStroke();
        java.awt.Paint paint90 = null;
        java.awt.Stroke stroke91 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker93 = new org.jfree.chart.plot.IntervalMarker((double) 11, 3.0d, (java.awt.Paint) color65, stroke89, paint90, stroke91, 0.0f);
        double double94 = intervalMarker93.getEndValue();
        boolean boolean95 = categoryPlot10.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker93);
        double double96 = intervalMarker93.getEndValue();
        intervalMarker93.setStartValue(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-4194304) + "'", int48 == (-4194304));
        org.junit.Assert.assertNotNull(categoryAxisArray50);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.05d + "'", double80 == 0.05d);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNull(xYItemRenderer88);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 3.0d + "'", double94 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 3.0d + "'", double96 == 3.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        categoryPlot10.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot10.getRangeAxisLocation(1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray17 = new float[] { (byte) 100, ' ', (short) 100, '4', 100L };
        float[] floatArray18 = color11.getRGBComponents(floatArray17);
        float[] floatArray19 = java.awt.Color.RGBtoHSB(2, (int) 'a', (int) ' ', floatArray18);
        float[] floatArray20 = color5.getColorComponents(colorSpace7, floatArray19);
        java.awt.Color color21 = java.awt.Color.black;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray31 = new float[] { (byte) 100, ' ', (short) 100, '4', 100L };
        float[] floatArray32 = color25.getRGBComponents(floatArray31);
        float[] floatArray33 = java.awt.Color.RGBtoHSB(2, (int) 'a', (int) ' ', floatArray32);
        float[] floatArray34 = color21.getRGBComponents(floatArray33);
        float[] floatArray35 = color4.getComponents(colorSpace7, floatArray33);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis36.setLowerMargin(0.0d);
        java.awt.Stroke stroke39 = categoryAxis36.getAxisLineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker(3.0d, 1.0d, paint2, stroke3, (java.awt.Paint) color4, stroke39, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        int int28 = xYPlot16.getIndexOf(xYItemRenderer27);
        boolean boolean29 = xYPlot16.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot16.getDataset(6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(xYDataset31);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot10.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot10.setFixedRangeAxisSpace(axisSpace19, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot10.getRenderer();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNull(categoryItemRenderer22);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range5 = numberAxis4.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range5, false, true);
        dateAxis1.setRange((-5.0d), (double) (short) 10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis1, jFreeChart12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str16 = numberAxis15.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis15.setMarkerBand(markerAxisBand17);
        double double19 = numberAxis15.getUpperMargin();
        java.awt.Font font20 = numberAxis15.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis15.lengthToJava2D((double) 10, rectangle2D22, rectangleEdge23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str33 = numberAxis32.getLabel();
        numberAxis32.setLabelURL("");
        boolean boolean37 = numberAxis32.equals((java.lang.Object) 1);
        boolean boolean38 = numberAxis32.isAutoRange();
        double double39 = numberAxis32.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer40);
        double double42 = xYPlot41.getRangeCrosshairValue();
        xYPlot41.setDomainCrosshairValue((double) (-1L));
        boolean boolean45 = xYPlot41.isDomainZeroBaselineVisible();
        numberAxis15.setPlot((org.jfree.chart.plot.Plot) xYPlot41);
        double double47 = numberAxis15.getFixedDimension();
        java.awt.Shape shape48 = numberAxis15.getRightArrow();
        dateAxis1.setDownArrow(shape48);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        numberAxis1.setNegativeArrowVisible(false);
        double double7 = numberAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        java.lang.Object obj29 = null;
        boolean boolean30 = xYPlot21.equals(obj29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot21.setRenderer(xYItemRenderer31);
        java.awt.Paint paint33 = xYPlot21.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str42 = numberAxis41.getLabel();
        numberAxis41.setLabelURL("");
        boolean boolean46 = numberAxis41.equals((java.lang.Object) 1);
        boolean boolean47 = numberAxis41.isAutoRange();
        double double48 = numberAxis41.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis41, xYItemRenderer49);
        double double51 = xYPlot50.getRangeCrosshairValue();
        xYPlot50.setDomainCrosshairValue((double) (-1L));
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot50.setDatasetRenderingOrder(datasetRenderingOrder54);
        xYPlot50.setDomainCrosshairValue(7.0d, true);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str62 = numberAxis61.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand63 = null;
        numberAxis61.setMarkerBand(markerAxisBand63);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str67 = numberAxis66.getLabel();
        numberAxis66.setLabelURL("");
        boolean boolean71 = numberAxis66.equals((java.lang.Object) 1);
        boolean boolean72 = numberAxis66.isAutoRange();
        double double73 = numberAxis66.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis61, (org.jfree.chart.axis.ValueAxis) numberAxis66, xYItemRenderer74);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = xYPlot75.getRangeAxisEdge(0);
        xYPlot75.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.Plot plot81 = xYPlot75.getRootPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray82 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot75.setRenderers(xYItemRendererArray82);
        org.jfree.chart.axis.AxisLocation axisLocation84 = xYPlot75.getRangeAxisLocation();
        xYPlot50.setRangeAxisLocation(axisLocation84);
        xYPlot21.setRangeAxisLocation(axisLocation84);
        java.awt.Graphics2D graphics2D87 = null;
        java.awt.geom.Rectangle2D rectangle2D88 = null;
        try {
            xYPlot21.drawBackground(graphics2D87, rectangle2D88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertNotNull(plot81);
        org.junit.Assert.assertNotNull(xYItemRendererArray82);
        org.junit.Assert.assertNotNull(axisLocation84);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        java.awt.Stroke stroke23 = xYPlot16.getRangeZeroBaselineStroke();
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        boolean boolean28 = dateAxis26.isHiddenValue((long) 10);
        int int29 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) 0, (double) 8, (double) 2.0f, 0.0d);
        xYPlot16.setInsets(rectangleInsets34, true);
        double double38 = rectangleInsets34.calculateBottomInset((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        java.text.DateFormat dateFormat11 = null;
        dateAxis7.setDateFormatOverride(dateFormat11);
        double double13 = dateAxis7.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis15.configure();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = dateAxis15.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge20);
        java.util.Date date22 = dateAxis15.getMinimumDate();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str34 = numberAxis33.getLabel();
        numberAxis33.setLabelURL("");
        boolean boolean38 = numberAxis33.equals((java.lang.Object) 1);
        boolean boolean39 = numberAxis33.isAutoRange();
        double double40 = numberAxis33.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis33, xYItemRenderer41);
        java.awt.Stroke stroke43 = xYPlot42.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot42.setDomainAxisLocation(axisLocation44, false);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str52 = numberAxis51.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = null;
        numberAxis51.setMarkerBand(markerAxisBand53);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str57 = numberAxis56.getLabel();
        numberAxis56.setLabelURL("");
        boolean boolean61 = numberAxis56.equals((java.lang.Object) 1);
        boolean boolean62 = numberAxis56.isAutoRange();
        double double63 = numberAxis56.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.axis.ValueAxis) numberAxis56, xYItemRenderer64);
        java.awt.Stroke stroke66 = xYPlot65.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot65.setDomainGridlineStroke(stroke67);
        java.awt.Paint paint69 = xYPlot65.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer70 = null;
        java.util.Collection collection71 = xYPlot65.getRangeMarkers(layer70);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = xYPlot65.getDomainAxisEdge((int) (short) 100);
        boolean boolean74 = dateAxis48.equals((java.lang.Object) xYPlot65);
        org.jfree.chart.plot.PlotOrientation plotOrientation75 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str76 = plotOrientation75.toString();
        xYPlot65.setOrientation(plotOrientation75);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation44, plotOrientation75);
        try {
            double double79 = dateAxis7.dateToJava2D(date22, rectangle2D25, rectangleEdge78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNull(list21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.05d + "'", double63 == 0.05d);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(plotOrientation75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str76.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setLowerMargin(0.0d);
        categoryAxis2.setLabelAngle((-5.0d));
        boolean boolean7 = objectList1.equals((java.lang.Object) categoryAxis2);
        int int8 = objectList1.size();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis20.setMarkerBand(markerAxisBand22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabel();
        numberAxis25.setLabelURL("");
        boolean boolean30 = numberAxis25.equals((java.lang.Object) 1);
        boolean boolean31 = numberAxis25.isAutoRange();
        double double32 = numberAxis25.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer33);
        java.awt.Stroke stroke35 = xYPlot34.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot34.setDomainGridlineStroke(stroke36);
        java.awt.Paint paint38 = xYPlot34.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot34.setRangeAxis(valueAxis39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot34.getInsets();
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str47 = numberAxis46.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis46.setMarkerBand(markerAxisBand48);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str52 = numberAxis51.getLabel();
        numberAxis51.setLabelURL("");
        boolean boolean56 = numberAxis51.equals((java.lang.Object) 1);
        boolean boolean57 = numberAxis51.isAutoRange();
        double double58 = numberAxis51.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis51, xYItemRenderer59);
        java.awt.Stroke stroke61 = xYPlot60.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot60.setDomainGridlineStroke(stroke62);
        java.awt.Paint paint64 = xYPlot60.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        xYPlot60.setRangeAxis(valueAxis65);
        categoryMarker43.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot60);
        xYPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker43);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str70 = layer69.toString();
        boolean boolean72 = categoryPlot10.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker43, layer69, true);
        java.lang.Comparable comparable73 = categoryMarker43.getKey();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Layer.BACKGROUND" + "'", str70.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + comparable73 + "' != '" + 100L + "'", comparable73.equals(100L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        xYPlot16.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.Plot plot22 = xYPlot16.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot16.zoomDomainAxes((double) 9, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str33 = numberAxis32.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabel();
        numberAxis37.setLabelURL("");
        boolean boolean42 = numberAxis37.equals((java.lang.Object) 1);
        boolean boolean43 = numberAxis37.isAutoRange();
        double double44 = numberAxis37.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer45);
        java.awt.Stroke stroke47 = xYPlot46.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot46.setDomainGridlineStroke(stroke48);
        java.awt.Paint paint50 = xYPlot46.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        xYPlot46.setRangeAxis(valueAxis51);
        categoryMarker29.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot46);
        xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        xYPlot16.clearRangeMarkers((int) '4');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent57 = null;
        xYPlot16.rendererChanged(rendererChangeEvent57);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        xYPlot16.setRangeCrosshairValue(0.0d, false);
        xYPlot16.setRangeCrosshairLockedOnData(false);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        xYPlot16.zoomRangeAxes((double) (short) 1, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot16.getRangeAxisLocation();
        xYPlot16.clearAnnotations();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        xYPlot16.setFixedLegendItems(legendItemCollection21);
        xYPlot16.mapDatasetToRangeAxis(1, 0);
        xYPlot16.setRangeCrosshairValue((double) 3, false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis20.setMarkerBand(markerAxisBand22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabel();
        numberAxis25.setLabelURL("");
        boolean boolean30 = numberAxis25.equals((java.lang.Object) 1);
        boolean boolean31 = numberAxis25.isAutoRange();
        double double32 = numberAxis25.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer33);
        java.awt.Stroke stroke35 = xYPlot34.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot34.setDomainGridlineStroke(stroke36);
        java.awt.Paint paint38 = xYPlot34.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot34.setRangeAxis(valueAxis39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot34.getInsets();
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str47 = numberAxis46.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis46.setMarkerBand(markerAxisBand48);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str52 = numberAxis51.getLabel();
        numberAxis51.setLabelURL("");
        boolean boolean56 = numberAxis51.equals((java.lang.Object) 1);
        boolean boolean57 = numberAxis51.isAutoRange();
        double double58 = numberAxis51.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis51, xYItemRenderer59);
        java.awt.Stroke stroke61 = xYPlot60.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot60.setDomainGridlineStroke(stroke62);
        java.awt.Paint paint64 = xYPlot60.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        xYPlot60.setRangeAxis(valueAxis65);
        categoryMarker43.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot60);
        xYPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker43);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str70 = layer69.toString();
        boolean boolean72 = categoryPlot10.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker43, layer69, true);
        boolean boolean73 = categoryPlot10.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Layer.BACKGROUND" + "'", str70.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        xYPlot16.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.Plot plot22 = xYPlot16.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot16.zoomDomainAxes((double) 9, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str33 = numberAxis32.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabel();
        numberAxis37.setLabelURL("");
        boolean boolean42 = numberAxis37.equals((java.lang.Object) 1);
        boolean boolean43 = numberAxis37.isAutoRange();
        double double44 = numberAxis37.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer45);
        java.awt.Stroke stroke47 = xYPlot46.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot46.setDomainGridlineStroke(stroke48);
        java.awt.Paint paint50 = xYPlot46.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        xYPlot46.setRangeAxis(valueAxis51);
        categoryMarker29.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot46);
        xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        xYPlot16.clearRangeMarkers((int) '4');
        java.awt.Paint paint57 = xYPlot16.getRangeTickBandPaint();
        java.awt.Stroke stroke58 = xYPlot16.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(paint57);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        xYPlot16.setDomainCrosshairValue((double) (short) 1);
        double double23 = xYPlot16.getDomainCrosshairValue();
        boolean boolean24 = xYPlot16.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str33 = numberAxis32.getLabel();
        numberAxis32.setLabelURL("");
        boolean boolean37 = numberAxis32.equals((java.lang.Object) 1);
        boolean boolean38 = numberAxis32.isAutoRange();
        double double39 = numberAxis32.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer40);
        java.awt.Stroke stroke42 = xYPlot41.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot41.setDomainGridlineStroke(stroke43);
        java.awt.Paint paint45 = xYPlot41.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        xYPlot41.setRangeAxis(valueAxis46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = xYPlot41.getInsets();
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis53.setMarkerBand(markerAxisBand55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str59 = numberAxis58.getLabel();
        numberAxis58.setLabelURL("");
        boolean boolean63 = numberAxis58.equals((java.lang.Object) 1);
        boolean boolean64 = numberAxis58.isAutoRange();
        double double65 = numberAxis58.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis53, (org.jfree.chart.axis.ValueAxis) numberAxis58, xYItemRenderer66);
        java.awt.Stroke stroke68 = xYPlot67.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot67.setDomainGridlineStroke(stroke69);
        java.awt.Paint paint71 = xYPlot67.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        xYPlot67.setRangeAxis(valueAxis72);
        categoryMarker50.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot67);
        xYPlot41.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker50);
        xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker50);
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str79 = numberAxis78.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand80 = null;
        numberAxis78.setMarkerBand(markerAxisBand80);
        double double82 = numberAxis78.getUpperMargin();
        java.awt.Font font83 = numberAxis78.getLabelFont();
        categoryMarker50.setLabelFont(font83);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.05d + "'", double65 == 0.05d);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.05d + "'", double82 == 0.05d);
        org.junit.Assert.assertNotNull(font83);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        try {
            categoryPlot10.setDomainAxisLocation((-16776961), axisLocation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        xYPlot16.setFixedLegendItems(legendItemCollection21);
        xYPlot16.mapDatasetToRangeAxis(1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str31 = numberAxis30.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabel();
        numberAxis35.setLabelURL("");
        boolean boolean40 = numberAxis35.equals((java.lang.Object) 1);
        boolean boolean41 = numberAxis35.isAutoRange();
        double double42 = numberAxis35.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot44.getRangeAxisEdge(0);
        xYPlot44.setRangeCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D50 = xYPlot44.getQuadrantOrigin();
        xYPlot16.zoomDomainAxes(0.0d, plotRenderingInfo27, point2D50, false);
        org.jfree.chart.axis.AxisLocation axisLocation54 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean56 = axisLocation54.equals((java.lang.Object) "PlotOrientation.HORIZONTAL");
        xYPlot16.setRangeAxisLocation(0, axisLocation54, false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        int int28 = xYPlot16.getIndexOf(xYItemRenderer27);
        boolean boolean29 = xYPlot16.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str33 = numberAxis32.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabel();
        numberAxis37.setLabelURL("");
        boolean boolean42 = numberAxis37.equals((java.lang.Object) 1);
        boolean boolean43 = numberAxis37.isAutoRange();
        double double44 = numberAxis37.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer45);
        java.awt.Stroke stroke47 = xYPlot46.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        xYPlot46.drawBackgroundImage(graphics2D48, rectangle2D49);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer53 = null;
        xYPlot46.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer53);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = categoryMarker52.getLabelAnchor();
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52);
        boolean boolean57 = xYPlot16.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int3 = java.awt.Color.HSBtoRGB((float) 43629L, (float) (byte) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setTickLabelsVisible(true);
        numberAxis1.setAutoTickUnitSelection(true);
        numberAxis1.setLabel("SeriesRenderingOrder.FORWARD");
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        xYPlot16.clearDomainMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = null;
        boolean boolean32 = xYPlot16.render(graphics2D27, rectangle2D28, 10, plotRenderingInfo30, crosshairState31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot16.setRenderer(xYItemRenderer33);
        org.jfree.chart.JFreeChart jFreeChart35 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYItemRenderer33, jFreeChart35, chartChangeEventType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot10.getOrientation();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str17 = layer16.toString();
        java.lang.String str18 = layer16.toString();
        try {
            categoryPlot10.addRangeMarker((-1), marker15, layer16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.BACKGROUND" + "'", str17.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Layer.BACKGROUND" + "'", str18.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        valueMarker1.setValue((double) (-16777216));
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = xYPlot21.isDomainCrosshairLockedOnData();
        java.awt.Paint paint30 = xYPlot21.getDomainZeroBaselinePaint();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot21.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        double double17 = xYPlot16.getRangeCrosshairValue();
        xYPlot16.setDomainCrosshairValue((double) (-1L));
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot16.setDatasetRenderingOrder(datasetRenderingOrder20);
        xYPlot16.setRangeCrosshairLockedOnData(false);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setLowerMargin(0.0d);
        double double30 = categoryAxis27.getUpperMargin();
        int int31 = categoryAxis27.getCategoryLabelPositionOffset();
        categoryAxis27.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        double double34 = dateAxis33.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        categoryPlot36.setRangeCrosshairLockedOnData(true);
        java.util.List list39 = categoryPlot36.getAnnotations();
        xYPlot16.drawDomainTickBands(graphics2D24, rectangle2D25, list39);
        java.awt.Image image41 = xYPlot16.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNull(image41);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 10);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.awt.Paint paint5 = dateAxis1.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setLowerMargin(0.0d);
        categoryAxis14.setLabelAngle((-5.0d));
        org.jfree.chart.plot.Plot plot19 = categoryAxis14.getPlot();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.setLowerMargin(0.0d);
        double double24 = categoryAxis21.getUpperMargin();
        int int25 = categoryAxis21.getCategoryLabelPositionOffset();
        categoryAxis21.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        double double28 = dateAxis27.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis27, categoryItemRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        double double32 = categoryAxis31.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        double double34 = categoryAxis33.getUpperMargin();
        double double35 = categoryAxis33.getLowerMargin();
        double double36 = categoryAxis33.getLowerMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        double double38 = categoryAxis37.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setLowerMargin(0.0d);
        double double42 = categoryAxis39.getUpperMargin();
        int int43 = categoryAxis39.getCategoryLabelPositionOffset();
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_RED;
        int int48 = color47.getRGB();
        categoryAxis39.setTickLabelPaint((java.lang.Comparable) "TextAnchor.BASELINE_LEFT", (java.awt.Paint) color47);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray50 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis14, categoryAxis21, categoryAxis31, categoryAxis33, categoryAxis37, categoryAxis39 };
        categoryPlot10.setDomainAxes(categoryAxisArray50);
        org.jfree.chart.axis.AxisSpace axisSpace52 = categoryPlot10.getFixedDomainAxisSpace();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-4194304) + "'", int48 == (-4194304));
        org.junit.Assert.assertNotNull(categoryAxisArray50);
        org.junit.Assert.assertNull(axisSpace52);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        boolean boolean5 = categoryMarker4.getDrawAsLine();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str7 = layer6.toString();
        java.lang.String str8 = layer6.toString();
        xYPlot0.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker4, layer6);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setLowerMargin(0.0d);
        double double14 = categoryAxis11.getUpperMargin();
        int int15 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        double double18 = dateAxis17.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis17, categoryItemRenderer19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot20.rendererChanged(rendererChangeEvent21);
        java.util.List list23 = categoryPlot20.getCategories();
        java.awt.Stroke stroke24 = categoryPlot20.getDomainGridlineStroke();
        categoryMarker4.setOutlineStroke(stroke24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Layer.BACKGROUND" + "'", str7.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Layer.BACKGROUND" + "'", str8.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNull(list23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range5 = numberAxis4.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range5, false, true);
        dateAxis1.setRange((-5.0d), (double) (short) 10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis1, jFreeChart12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis15.configure();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range19 = numberAxis18.getDefaultAutoRange();
        dateAxis15.setRangeWithMargins(range19, false, true);
        dateAxis15.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        numberAxis34.setLabelURL("");
        boolean boolean39 = numberAxis34.equals((java.lang.Object) 1);
        boolean boolean40 = numberAxis34.isAutoRange();
        double double41 = numberAxis34.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer42);
        java.awt.Stroke stroke44 = xYPlot43.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot43.setDomainGridlineStroke(stroke45);
        java.awt.Paint paint47 = xYPlot43.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        xYPlot43.setRangeAxis(valueAxis48);
        categoryMarker26.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot43);
        java.awt.Paint paint51 = categoryMarker26.getOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str55 = numberAxis54.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = null;
        numberAxis54.setMarkerBand(markerAxisBand56);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str60 = numberAxis59.getLabel();
        numberAxis59.setLabelURL("");
        boolean boolean64 = numberAxis59.equals((java.lang.Object) 1);
        boolean boolean65 = numberAxis59.isAutoRange();
        double double66 = numberAxis59.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.axis.ValueAxis) numberAxis59, xYItemRenderer67);
        java.awt.Stroke stroke69 = xYPlot68.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot68.setDomainAxisLocation(axisLocation70, false);
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str75 = numberAxis74.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand76 = null;
        numberAxis74.setMarkerBand(markerAxisBand76);
        int int78 = xYPlot68.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis74);
        java.awt.Font font79 = numberAxis74.getTickLabelFont();
        categoryMarker26.setLabelFont(font79);
        dateAxis15.setTickLabelFont(font79);
        org.jfree.chart.axis.DateTickUnit dateTickUnit82 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date83 = dateAxis15.calculateHighestVisibleTickValue(dateTickUnit82);
        java.util.Date date84 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit82);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "hi!" + "'", str55.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.05d + "'", double66 == 0.05d);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertNotNull(dateTickUnit82);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date84);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        java.awt.Paint paint5 = numberAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        java.lang.String str27 = xYPlot16.getNoDataMessage();
        java.awt.Font font28 = xYPlot16.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace29 = xYPlot16.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(axisSpace29);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setLowerMargin(0.0d);
        double double22 = categoryAxis19.getUpperMargin();
        int int23 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        double double26 = dateAxis25.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis25, categoryItemRenderer27);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot28.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot28.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray32 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot28.setRenderers(categoryItemRendererArray32);
        categoryPlot10.setRenderers(categoryItemRendererArray32);
        categoryPlot10.clearRangeMarkers(9);
        java.awt.Stroke stroke37 = categoryPlot10.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNotNull(categoryItemRendererArray32);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot10.setFixedDomainAxisSpace(axisSpace16, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeCrosshairVisible();
        double double2 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        double double17 = xYPlot16.getRangeCrosshairValue();
        xYPlot16.setDomainCrosshairValue((double) (-1L));
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot16.setDatasetRenderingOrder(datasetRenderingOrder20);
        xYPlot16.setRangeCrosshairLockedOnData(false);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setLowerMargin(0.0d);
        double double30 = categoryAxis27.getUpperMargin();
        int int31 = categoryAxis27.getCategoryLabelPositionOffset();
        categoryAxis27.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        double double34 = dateAxis33.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        categoryPlot36.setRangeCrosshairLockedOnData(true);
        java.util.List list39 = categoryPlot36.getAnnotations();
        xYPlot16.drawDomainTickBands(graphics2D24, rectangle2D25, list39);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str43 = numberAxis42.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = null;
        numberAxis42.setMarkerBand(markerAxisBand44);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str49 = numberAxis48.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        numberAxis53.setLabelURL("");
        boolean boolean58 = numberAxis53.equals((java.lang.Object) 1);
        boolean boolean59 = numberAxis53.isAutoRange();
        double double60 = numberAxis53.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis53, xYItemRenderer61);
        java.awt.Stroke stroke63 = xYPlot62.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        xYPlot62.drawBackgroundImage(graphics2D64, rectangle2D65);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = xYPlot62.getRenderer(100);
        numberAxis42.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot62);
        java.awt.Stroke stroke70 = numberAxis42.getTickMarkStroke();
        xYPlot16.setRangeZeroBaselineStroke(stroke70);
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = xYPlot16.getOrientation();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.05d + "'", double60 == 0.05d);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(plotOrientation72);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean2 = axisLocation0.equals((java.lang.Object) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        xYPlot16.clearDomainMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = null;
        boolean boolean32 = xYPlot16.render(graphics2D27, rectangle2D28, 10, plotRenderingInfo30, crosshairState31);
        boolean boolean33 = xYPlot16.isSubplot();
        java.awt.Paint paint34 = null;
        try {
            xYPlot16.setDomainCrosshairPaint(paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getUpperMargin();
        java.awt.Font font6 = numberAxis1.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis10.configure();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range14 = numberAxis13.getDefaultAutoRange();
        dateAxis10.setRangeWithMargins(range14, false, true);
        dateAxis10.setRange((-5.0d), (double) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str24 = numberAxis23.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis23.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabel();
        numberAxis28.setLabelURL("");
        boolean boolean33 = numberAxis28.equals((java.lang.Object) 1);
        boolean boolean34 = numberAxis28.isAutoRange();
        double double35 = numberAxis28.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) numberAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer36);
        java.awt.Stroke stroke38 = xYPlot37.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot37.setDomainGridlineStroke(stroke39);
        java.awt.Paint paint41 = xYPlot37.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = xYPlot37.getRangeMarkers(layer42);
        java.awt.Stroke stroke44 = xYPlot37.getRangeZeroBaselineStroke();
        xYPlot37.configureRangeAxes();
        java.awt.Stroke stroke46 = xYPlot37.getDomainZeroBaselineStroke();
        dateAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot37);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot37.getRangeAxisEdge((int) (byte) 0);
        try {
            double double50 = numberAxis1.java2DToValue((double) 9, rectangle2D8, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis20.setMarkerBand(markerAxisBand22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabel();
        numberAxis25.setLabelURL("");
        boolean boolean30 = numberAxis25.equals((java.lang.Object) 1);
        boolean boolean31 = numberAxis25.isAutoRange();
        double double32 = numberAxis25.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer33);
        java.awt.Stroke stroke35 = xYPlot34.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot34.setDomainGridlineStroke(stroke36);
        java.awt.Paint paint38 = xYPlot34.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        xYPlot34.setRangeAxis(valueAxis39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot34.getInsets();
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str47 = numberAxis46.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis46.setMarkerBand(markerAxisBand48);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str52 = numberAxis51.getLabel();
        numberAxis51.setLabelURL("");
        boolean boolean56 = numberAxis51.equals((java.lang.Object) 1);
        boolean boolean57 = numberAxis51.isAutoRange();
        double double58 = numberAxis51.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis51, xYItemRenderer59);
        java.awt.Stroke stroke61 = xYPlot60.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot60.setDomainGridlineStroke(stroke62);
        java.awt.Paint paint64 = xYPlot60.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        xYPlot60.setRangeAxis(valueAxis65);
        categoryMarker43.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot60);
        xYPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker43);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str70 = layer69.toString();
        boolean boolean72 = categoryPlot10.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker43, layer69, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        double double74 = categoryAxis73.getUpperMargin();
        double double75 = categoryAxis73.getLowerMargin();
        double double76 = categoryAxis73.getLowerMargin();
        java.util.List list77 = categoryPlot10.getCategoriesForAxis(categoryAxis73);
        categoryAxis73.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Layer.BACKGROUND" + "'", str70.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.05d + "'", double74 == 0.05d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.05d + "'", double75 == 0.05d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
        org.junit.Assert.assertNotNull(list77);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range6 = numberAxis5.getDefaultAutoRange();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color3, color7, color9 };
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str16 = numberAxis15.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis15.setMarkerBand(markerAxisBand17);
        java.awt.Shape shape19 = numberAxis15.getUpArrow();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] { shape19, shape20, shape21 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray22);
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 15, (java.awt.Paint) color1, stroke24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setLowerMargin(0.0d);
        double double30 = categoryAxis27.getUpperMargin();
        int int31 = categoryAxis27.getCategoryLabelPositionOffset();
        categoryAxis27.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        double double34 = dateAxis33.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis33, categoryItemRenderer35);
        categoryPlot36.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot36.getFixedLegendItems();
        categoryPlot36.zoom((-5.0d));
        org.jfree.chart.axis.AxisSpace axisSpace42 = categoryPlot36.getFixedRangeAxisSpace();
        boolean boolean43 = categoryPlot36.isRangeCrosshairLockedOnData();
        categoryMarker25.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot36);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str50 = numberAxis49.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = null;
        numberAxis49.setMarkerBand(markerAxisBand51);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str55 = numberAxis54.getLabel();
        numberAxis54.setLabelURL("");
        boolean boolean59 = numberAxis54.equals((java.lang.Object) 1);
        boolean boolean60 = numberAxis54.isAutoRange();
        double double61 = numberAxis54.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) numberAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis54, xYItemRenderer62);
        java.awt.Stroke stroke64 = xYPlot63.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot63.setDomainGridlineStroke(stroke65);
        java.awt.Paint paint67 = xYPlot63.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer68 = null;
        java.util.Collection collection69 = xYPlot63.getRangeMarkers(layer68);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = xYPlot63.getDomainAxisEdge((int) (short) 100);
        boolean boolean72 = dateAxis46.equals((java.lang.Object) xYPlot63);
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str74 = plotOrientation73.toString();
        xYPlot63.setOrientation(plotOrientation73);
        categoryPlot36.setOrientation(plotOrientation73);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection39);
        org.junit.Assert.assertNull(axisSpace42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "hi!" + "'", str55.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNull(collection69);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str74.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        xYPlot16.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.Plot plot22 = xYPlot16.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot16.zoomDomainAxes((double) 9, plotRenderingInfo24, point2D25, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str33 = numberAxis32.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabel();
        numberAxis37.setLabelURL("");
        boolean boolean42 = numberAxis37.equals((java.lang.Object) 1);
        boolean boolean43 = numberAxis37.isAutoRange();
        double double44 = numberAxis37.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer45);
        java.awt.Stroke stroke47 = xYPlot46.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot46.setDomainGridlineStroke(stroke48);
        java.awt.Paint paint50 = xYPlot46.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        xYPlot46.setRangeAxis(valueAxis51);
        categoryMarker29.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot46);
        xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        xYPlot16.clearRangeMarkers((int) '4');
        java.awt.Paint paint57 = xYPlot16.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str61 = numberAxis60.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis60.setMarkerBand(markerAxisBand62);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str66 = numberAxis65.getLabel();
        numberAxis65.setLabelURL("");
        boolean boolean70 = numberAxis65.equals((java.lang.Object) 1);
        boolean boolean71 = numberAxis65.isAutoRange();
        double double72 = numberAxis65.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset58, (org.jfree.chart.axis.ValueAxis) numberAxis60, (org.jfree.chart.axis.ValueAxis) numberAxis65, xYItemRenderer73);
        java.awt.Stroke stroke75 = xYPlot74.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke76 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot74.setDomainGridlineStroke(stroke76);
        java.awt.Paint paint78 = xYPlot74.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer79 = null;
        java.util.Collection collection80 = xYPlot74.getRangeMarkers(layer79);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = xYPlot74.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot74.setInsets(rectangleInsets83);
        double double85 = rectangleInsets83.getTop();
        double double87 = rectangleInsets83.extendWidth((-1.0d));
        double double89 = rectangleInsets83.trimWidth((double) 1560409200000L);
        xYPlot16.setInsets(rectangleInsets83);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(paint57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.05d + "'", double72 == 0.05d);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNull(collection80);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertNotNull(rectangleInsets83);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 2.0d + "'", double85 == 2.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 7.0d + "'", double87 == 7.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.560409199992E12d + "'", double89 == 1.560409199992E12d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot10.getFixedLegendItems();
        categoryPlot10.zoom((-5.0d));
        java.lang.Object obj16 = categoryPlot10.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot10.getFixedLegendItems();
        double double14 = categoryPlot10.getRangeCrosshairValue();
        categoryPlot10.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot10.getDomainAxisEdge(6);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            categoryPlot10.addAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.CrosshairState crosshairState24 = null;
        boolean boolean25 = xYPlot16.render(graphics2D20, rectangle2D21, 0, plotRenderingInfo23, crosshairState24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        xYPlot16.setDomainTickBandPaint((java.awt.Paint) color26);
        xYPlot16.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range5 = numberAxis4.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range5, false, true);
        boolean boolean9 = dateAxis1.isAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis11.configure();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis14.configure();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range18 = numberAxis17.getDefaultAutoRange();
        dateAxis14.setRangeWithMargins(range18, false, true);
        dateAxis11.setRange(range18, true, false);
        org.jfree.chart.axis.Timeline timeline25 = dateAxis11.getTimeline();
        dateAxis1.setTimeline(timeline25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range29 = numberAxis28.getDefaultAutoRange();
        dateAxis1.setDefaultAutoRange(range29);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(timeline25);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        double double3 = categoryAxis0.getUpperMargin();
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.clearCategoryLabelToolTips();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str12 = numberAxis11.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis11.setMarkerBand(markerAxisBand13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str17 = numberAxis16.getLabel();
        numberAxis16.setLabelURL("");
        boolean boolean21 = numberAxis16.equals((java.lang.Object) 1);
        boolean boolean22 = numberAxis16.isAutoRange();
        double double23 = numberAxis16.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer24);
        java.awt.Stroke stroke26 = xYPlot25.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYPlot25.drawBackgroundImage(graphics2D27, rectangle2D28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot25.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker31, layer32);
        xYPlot25.clearDomainMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.plot.CrosshairState crosshairState40 = null;
        boolean boolean41 = xYPlot25.render(graphics2D36, rectangle2D37, 10, plotRenderingInfo39, crosshairState40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = xYPlot25.getDomainAxisEdge((-16776961));
        try {
            double double44 = categoryAxis0.getCategoryMiddle((-16777216), (int) (byte) 100, rectangle2D8, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        categoryPlot10.clearDomainMarkers();
        java.awt.Stroke stroke18 = categoryPlot10.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        xYPlot16.setRangeCrosshairValue(0.0d, false);
        xYPlot16.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setRangeGridlineStroke(stroke24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        xYPlot16.removeChangeListener(plotChangeListener26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot10.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setLowerMargin(0.0d);
        double double21 = categoryAxis18.getUpperMargin();
        int int22 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        double double25 = dateAxis24.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot27.setDataset(categoryDataset29);
        categoryPlot27.setRangeGridlinesVisible(true);
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot27);
        categoryPlot27.setAnchorValue((double) 12);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str38 = numberAxis37.getLabel();
        numberAxis37.setLabelURL("");
        boolean boolean42 = numberAxis37.equals((java.lang.Object) 1);
        boolean boolean43 = numberAxis37.isAutoRange();
        double double44 = numberAxis37.getLowerMargin();
        boolean boolean45 = numberAxis37.isVisible();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str49 = numberAxis48.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        numberAxis53.setLabelURL("");
        boolean boolean58 = numberAxis53.equals((java.lang.Object) 1);
        boolean boolean59 = numberAxis53.isAutoRange();
        double double60 = numberAxis53.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis53, xYItemRenderer61);
        java.awt.Stroke stroke63 = xYPlot62.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation64 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot62.setDomainAxisLocation(axisLocation64, false);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str69 = numberAxis68.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand70 = null;
        numberAxis68.setMarkerBand(markerAxisBand70);
        int int72 = xYPlot62.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis68);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit73 = numberAxis68.getTickUnit();
        numberAxis37.setTickUnit(numberTickUnit73);
        numberAxis37.setAutoRangeStickyZero(false);
        org.jfree.data.Range range77 = categoryPlot27.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.05d + "'", double60 == 0.05d);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit73);
        org.junit.Assert.assertNull(range77);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot10.getRenderer(4);
        java.awt.Paint paint17 = categoryPlot10.getDomainGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        numberAxis20.setLabelURL("");
        numberAxis20.setVisible(true);
        numberAxis20.setFixedAutoRange((double) (short) 100);
        boolean boolean28 = numberAxis20.isAutoTickUnitSelection();
        java.text.NumberFormat numberFormat29 = numberAxis20.getNumberFormatOverride();
        categoryPlot10.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.setLowerMargin(0.0d);
        double double35 = categoryAxis32.getUpperMargin();
        int int36 = categoryAxis32.getCategoryLabelPositionOffset();
        categoryAxis32.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        double double39 = dateAxis38.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer40);
        boolean boolean42 = categoryPlot41.isRangeGridlinesVisible();
        double double43 = categoryPlot41.getAnchorValue();
        categoryPlot41.setRangeCrosshairLockedOnData(false);
        java.lang.String str46 = categoryPlot41.getPlotType();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot41.setDomainGridlinePaint((java.awt.Paint) color47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = categoryPlot41.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str51 = plotOrientation50.toString();
        categoryPlot41.setOrientation(plotOrientation50);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot41.getDomainAxisForDataset((int) (byte) -1);
        numberAxis20.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot41);
        java.awt.Stroke stroke56 = categoryPlot41.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(numberFormat29);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Category Plot" + "'", str46.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str51.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(categoryAxis54);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        java.util.List list13 = categoryPlot10.getCategories();
        categoryPlot10.clearRangeMarkers(12);
        double double16 = categoryPlot10.getAnchorValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getBlue();
        float[] floatArray2 = null;
        float[] floatArray3 = color0.getComponents(floatArray2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setLowerMargin(0.0d);
        double double6 = categoryAxis3.getUpperMargin();
        int int7 = categoryAxis3.getCategoryLabelPositionOffset();
        categoryAxis3.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        double double10 = dateAxis9.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer11);
        boolean boolean13 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot12.setDataset(categoryDataset14);
        categoryPlot12.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke18 = categoryPlot12.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "java.awt.Color[r=0,g=0,b=128]", (java.awt.Paint) color1, stroke18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setTickLabelsVisible(true);
        numberAxis1.setLowerBound((double) (-4194304));
        boolean boolean9 = numberAxis1.isVerticalTickLabels();
        boolean boolean10 = numberAxis1.isVisible();
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabel();
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        java.lang.Object obj7 = numberAxis1.clone();
        java.lang.String str8 = numberAxis1.getLabelToolTip();
        double double9 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        boolean boolean17 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot10.setFixedRangeAxisSpace(axisSpace18, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot10.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = null;
        try {
            categoryPlot10.setRenderers(categoryItemRendererArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        xYPlot16.clearDomainMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = null;
        boolean boolean32 = xYPlot16.render(graphics2D27, rectangle2D28, 10, plotRenderingInfo30, crosshairState31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot16.getDomainAxisEdge((-16776961));
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot36.getDomainAxisLocation();
        xYPlot16.setDomainAxisLocation(0, axisLocation37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setLowerMargin(0.0d);
        double double17 = categoryAxis14.getUpperMargin();
        int int18 = categoryAxis14.getCategoryLabelPositionOffset();
        categoryAxis14.clearCategoryLabelToolTips();
        categoryPlot10.setDomainAxis(3, categoryAxis14, false);
        categoryAxis14.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        xYPlot16.clearDomainMarkers((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        java.lang.String str32 = numberAxis28.getLabel();
        org.jfree.data.RangeType rangeType33 = numberAxis28.getRangeType();
        java.lang.Object obj34 = numberAxis28.clone();
        java.awt.Paint paint35 = numberAxis28.getTickLabelPaint();
        xYPlot16.setDomainTickBandPaint(paint35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range39 = numberAxis38.getDefaultAutoRange();
        numberAxis38.setFixedAutoRange((double) (short) 0);
        org.jfree.chart.plot.Plot plot42 = numberAxis38.getPlot();
        int int43 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        xYPlot16.clearDomainMarkers();
        java.awt.Paint paint46 = null;
        xYPlot16.setQuadrantPaint(0, paint46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setFixedAutoRange((double) (short) 0);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.axis.AxisState axisState11 = numberAxis1.draw(graphics2D5, (double) (-1L), rectangle2D7, rectangle2D8, rectangleEdge9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setTickMarksVisible(true);
        boolean boolean4 = numberAxis1.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str7 = numberAxis6.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis6.setMarkerBand(markerAxisBand8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str18 = numberAxis17.getLabel();
        numberAxis17.setLabelURL("");
        boolean boolean22 = numberAxis17.equals((java.lang.Object) 1);
        boolean boolean23 = numberAxis17.isAutoRange();
        double double24 = numberAxis17.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer25);
        java.awt.Stroke stroke27 = xYPlot26.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        xYPlot26.drawBackgroundImage(graphics2D28, rectangle2D29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot26.getRenderer(100);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot26);
        boolean boolean34 = xYPlot26.isDomainCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray35 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot26.setRenderers(xYItemRendererArray35);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot26.setRangeZeroBaselinePaint(paint37);
        numberAxis1.setTickLabelPaint(paint37);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(xYItemRendererArray35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str5 = numberAxis4.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str10 = numberAxis9.getLabel();
        numberAxis9.setLabelURL("");
        boolean boolean14 = numberAxis9.equals((java.lang.Object) 1);
        boolean boolean15 = numberAxis9.isAutoRange();
        double double16 = numberAxis9.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer17);
        java.awt.Stroke stroke19 = xYPlot18.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot18.setDomainGridlineStroke(stroke20);
        java.awt.Paint paint22 = xYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot18.getRangeMarkers(layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot18.getDomainAxisEdge((int) (short) 100);
        boolean boolean27 = dateAxis1.equals((java.lang.Object) xYPlot18);
        dateAxis1.setRange((double) 5, 100.0d);
        org.jfree.chart.plot.Plot plot31 = dateAxis1.getPlot();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str42 = numberAxis41.getLabel();
        numberAxis41.setLabelURL("");
        boolean boolean46 = numberAxis41.equals((java.lang.Object) 1);
        boolean boolean47 = numberAxis41.isAutoRange();
        double double48 = numberAxis41.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis41, xYItemRenderer49);
        java.awt.Stroke stroke51 = xYPlot50.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        xYPlot50.drawBackgroundImage(graphics2D52, rectangle2D53);
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer57 = null;
        xYPlot50.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker56, layer57);
        xYPlot50.clearDomainMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.plot.CrosshairState crosshairState65 = null;
        boolean boolean66 = xYPlot50.render(graphics2D61, rectangle2D62, 10, plotRenderingInfo64, crosshairState65);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = xYPlot50.getDomainAxisEdge((-16776961));
        try {
            double double69 = dateAxis1.java2DToValue((double) 1, rectangle2D33, rectangleEdge68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(plot31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        boolean boolean17 = categoryPlot10.isDomainZoomable();
        categoryPlot10.setAnchorValue((double) (short) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot10.setDomainGridlinePosition(categoryAnchor20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range24 = numberAxis23.getDefaultAutoRange();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis23.setTickLabelPaint((java.awt.Paint) color25);
        categoryPlot10.setRangeGridlinePaint((java.awt.Paint) color25);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot10.setFixedRangeAxisSpace(axisSpace28, false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot10.getRendererForDataset(categoryDataset31);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(categoryItemRenderer32);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        int int28 = xYPlot16.getIndexOf(xYItemRenderer27);
        boolean boolean29 = xYPlot16.isOutlineVisible();
        xYPlot16.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation((int) 'a', axisLocation32);
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot16.getDataset();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str14 = numberAxis13.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str19 = numberAxis18.getLabel();
        numberAxis18.setLabelURL("");
        boolean boolean23 = numberAxis18.equals((java.lang.Object) 1);
        boolean boolean24 = numberAxis18.isAutoRange();
        double double25 = numberAxis18.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot27.getRangeAxisEdge(0);
        xYPlot27.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabel();
        numberAxis39.setLabelURL("");
        boolean boolean44 = numberAxis39.equals((java.lang.Object) 1);
        boolean boolean45 = numberAxis39.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str48 = numberAxis47.getLabel();
        numberAxis47.setLabelURL("");
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis53.setMarkerBand(markerAxisBand55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str59 = numberAxis58.getLabel();
        numberAxis58.setLabelURL("");
        boolean boolean63 = numberAxis58.equals((java.lang.Object) 1);
        boolean boolean64 = numberAxis58.isAutoRange();
        double double65 = numberAxis58.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis53, (org.jfree.chart.axis.ValueAxis) numberAxis58, xYItemRenderer66);
        java.awt.Stroke stroke68 = xYPlot67.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot67.setDomainAxisLocation(axisLocation69, false);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str74 = numberAxis73.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand75 = null;
        numberAxis73.setMarkerBand(markerAxisBand75);
        int int77 = xYPlot67.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis73);
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis79.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis numberAxis83 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray84 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis39, numberAxis47, numberAxis73, numberAxis79, numberAxis83 };
        xYPlot27.setDomainAxes(valueAxisArray84);
        int int86 = xYPlot27.getWeight();
        double double87 = xYPlot27.getRangeCrosshairValue();
        java.awt.Paint paint88 = xYPlot27.getDomainGridlinePaint();
        categoryPlot10.setRangeCrosshairPaint(paint88);
        org.jfree.chart.axis.AxisSpace axisSpace90 = categoryPlot10.getFixedDomainAxisSpace();
        categoryPlot10.mapDatasetToRangeAxis(10, (int) (byte) 100);
        java.awt.Graphics2D graphics2D94 = null;
        java.awt.geom.Rectangle2D rectangle2D95 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo97 = null;
        boolean boolean98 = categoryPlot10.render(graphics2D94, rectangle2D95, (int) ' ', plotRenderingInfo97);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.05d + "'", double65 == 0.05d);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(valueAxisArray84);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNull(axisSpace90);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(10, 200, 13);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        java.util.List list13 = categoryPlot10.getAnnotations();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot10.setRangeGridlineStroke(stroke14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis20.setMarkerBand(markerAxisBand22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabel();
        numberAxis25.setLabelURL("");
        boolean boolean30 = numberAxis25.equals((java.lang.Object) 1);
        boolean boolean31 = numberAxis25.isAutoRange();
        double double32 = numberAxis25.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer33);
        java.awt.Stroke stroke35 = xYPlot34.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot34.setDomainAxisLocation(axisLocation36, false);
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        xYPlot34.setFixedLegendItems(legendItemCollection39);
        xYPlot34.mapDatasetToRangeAxis(1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str49 = numberAxis48.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        numberAxis53.setLabelURL("");
        boolean boolean58 = numberAxis53.equals((java.lang.Object) 1);
        boolean boolean59 = numberAxis53.isAutoRange();
        double double60 = numberAxis53.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis53, xYItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot62.getRangeAxisEdge(0);
        xYPlot62.setRangeCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D68 = xYPlot62.getQuadrantOrigin();
        xYPlot34.zoomDomainAxes(0.0d, plotRenderingInfo45, point2D68, false);
        categoryPlot10.zoomDomainAxes(0.0d, plotRenderingInfo17, point2D68, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.05d + "'", double60 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(point2D68);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 10);
        boolean boolean5 = dateAxis1.isHiddenValue((long) 6);
        java.text.DateFormat dateFormat6 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(dateFormat6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot10.getRendererForDataset(categoryDataset11);
        int int13 = categoryPlot10.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(categoryItemRenderer12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = xYPlot21.isDomainCrosshairLockedOnData();
        xYPlot21.clearRangeMarkers();
        xYPlot21.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        double double38 = numberAxis34.getUpperMargin();
        numberAxis34.setLowerBound((-5.0d));
        int int41 = xYPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        numberAxis1.zoomRange((double) (-4194304), (double) (byte) 10);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 1);
        boolean boolean7 = numberAxis1.isAutoRange();
        double double8 = numberAxis1.getLowerMargin();
        numberAxis1.setLowerMargin((double) 0.0f);
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean13 = numberAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str14 = numberAxis13.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str19 = numberAxis18.getLabel();
        numberAxis18.setLabelURL("");
        boolean boolean23 = numberAxis18.equals((java.lang.Object) 1);
        boolean boolean24 = numberAxis18.isAutoRange();
        double double25 = numberAxis18.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot27.getRangeAxisEdge(0);
        xYPlot27.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabel();
        numberAxis39.setLabelURL("");
        boolean boolean44 = numberAxis39.equals((java.lang.Object) 1);
        boolean boolean45 = numberAxis39.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str48 = numberAxis47.getLabel();
        numberAxis47.setLabelURL("");
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis53.setMarkerBand(markerAxisBand55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str59 = numberAxis58.getLabel();
        numberAxis58.setLabelURL("");
        boolean boolean63 = numberAxis58.equals((java.lang.Object) 1);
        boolean boolean64 = numberAxis58.isAutoRange();
        double double65 = numberAxis58.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis53, (org.jfree.chart.axis.ValueAxis) numberAxis58, xYItemRenderer66);
        java.awt.Stroke stroke68 = xYPlot67.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot67.setDomainAxisLocation(axisLocation69, false);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str74 = numberAxis73.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand75 = null;
        numberAxis73.setMarkerBand(markerAxisBand75);
        int int77 = xYPlot67.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis73);
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis79.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis numberAxis83 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray84 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis39, numberAxis47, numberAxis73, numberAxis79, numberAxis83 };
        xYPlot27.setDomainAxes(valueAxisArray84);
        int int86 = xYPlot27.getWeight();
        double double87 = xYPlot27.getRangeCrosshairValue();
        java.awt.Paint paint88 = xYPlot27.getDomainGridlinePaint();
        categoryPlot10.setRangeCrosshairPaint(paint88);
        org.jfree.chart.axis.AxisSpace axisSpace90 = categoryPlot10.getFixedDomainAxisSpace();
        org.jfree.chart.util.SortOrder sortOrder91 = categoryPlot10.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.05d + "'", double65 == 0.05d);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(valueAxisArray84);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNull(axisSpace90);
        org.junit.Assert.assertNotNull(sortOrder91);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        boolean boolean3 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double2 = rectangleInsets0.getLeft();
        double double4 = rectangleInsets0.trimWidth((double) (-1.0f));
        double double6 = rectangleInsets0.calculateBottomInset((double) (byte) 0);
        double double8 = rectangleInsets0.extendHeight(0.0d);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets0.createOutsetRectangle(rectangle2D9, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-9.0d) + "'", double4 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str5 = numberAxis4.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str10 = numberAxis9.getLabel();
        numberAxis9.setLabelURL("");
        boolean boolean14 = numberAxis9.equals((java.lang.Object) 1);
        boolean boolean15 = numberAxis9.isAutoRange();
        double double16 = numberAxis9.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer17);
        java.awt.Stroke stroke19 = xYPlot18.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot18.setDomainGridlineStroke(stroke20);
        java.awt.Paint paint22 = xYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot18.getRangeMarkers(layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot18.getDomainAxisEdge((int) (short) 100);
        boolean boolean27 = dateAxis1.equals((java.lang.Object) xYPlot18);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str29 = plotOrientation28.toString();
        xYPlot18.setOrientation(plotOrientation28);
        java.awt.Image image31 = xYPlot18.getBackgroundImage();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabel();
        numberAxis39.setLabelURL("");
        boolean boolean44 = numberAxis39.equals((java.lang.Object) 1);
        boolean boolean45 = numberAxis39.isAutoRange();
        double double46 = numberAxis39.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis39, xYItemRenderer47);
        java.awt.Stroke stroke49 = xYPlot48.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot48.setDomainAxisLocation(axisLocation50, false);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = null;
        xYPlot48.setFixedLegendItems(legendItemCollection53);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis55.setLowerMargin(0.0d);
        categoryAxis55.setLabelAngle((-5.0d));
        org.jfree.chart.plot.Plot plot60 = categoryAxis55.getPlot();
        java.awt.Font font61 = categoryAxis55.getLabelFont();
        xYPlot48.setNoDataMessageFont(font61);
        xYPlot18.setNoDataMessageFont(font61);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str29.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNull(plot60);
        org.junit.Assert.assertNotNull(font61);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        numberAxis1.setVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 100);
        boolean boolean9 = numberAxis1.isAutoTickUnitSelection();
        java.lang.String str10 = numberAxis1.getLabelURL();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str14 = numberAxis13.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str19 = numberAxis18.getLabel();
        numberAxis18.setLabelURL("");
        boolean boolean23 = numberAxis18.equals((java.lang.Object) 1);
        boolean boolean24 = numberAxis18.isAutoRange();
        double double25 = numberAxis18.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer26);
        java.awt.Stroke stroke28 = xYPlot27.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot27.setDomainGridlineStroke(stroke29);
        java.awt.Paint paint31 = xYPlot27.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot27.getRangeMarkers(layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot27.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot27.setInsets(rectangleInsets36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot27.zoomDomainAxes((double) (-1), plotRenderingInfo39, point2D40);
        boolean boolean42 = xYPlot27.isRangeCrosshairVisible();
        boolean boolean43 = xYPlot27.isDomainZeroBaselineVisible();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str20 = plotOrientation19.toString();
        categoryPlot10.setOrientation(plotOrientation19);
        categoryPlot10.setRangeCrosshairValue(11.0d);
        int int24 = categoryPlot10.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str20.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        boolean boolean15 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        categoryMarker17.setLabelPaint((java.awt.Paint) color18);
        int int20 = color18.getBlue();
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color18);
        boolean boolean22 = categoryPlot10.isSubplot();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 192 + "'", int20 == 192);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setLabelURL("");
        boolean boolean13 = numberAxis8.equals((java.lang.Object) 1);
        boolean boolean14 = numberAxis8.isAutoRange();
        double double15 = numberAxis8.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer16);
        java.awt.Stroke stroke18 = xYPlot17.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYPlot17.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer24 = null;
        xYPlot17.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker23, layer24);
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot10.removeChangeListener(plotChangeListener15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot10.getRangeAxisEdge();
        categoryPlot10.setDrawSharedDomainAxis(false);
        java.lang.Object obj20 = categoryPlot10.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        java.util.List list13 = categoryPlot10.getAnnotations();
        boolean boolean14 = categoryPlot10.isDomainGridlinesVisible();
        categoryPlot10.clearDomainMarkers(128);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        boolean boolean19 = sortOrder17.equals((java.lang.Object) 1560495599999L);
        categoryPlot10.setColumnRenderingOrder(sortOrder17);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot16.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29);
        boolean boolean31 = xYPlot16.isRangeCrosshairVisible();
        boolean boolean32 = xYPlot16.isDomainZeroBaselineVisible();
        xYPlot16.setDomainCrosshairValue((double) 192);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot16.getRenderer();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(xYItemRenderer35);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis1.getMarkerBand();
        java.lang.Object obj7 = numberAxis1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        boolean boolean17 = xYPlot16.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot16.getFixedRangeAxisSpace();
        float float19 = xYPlot16.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setLowerMargin(0.0d);
        double double17 = categoryAxis14.getUpperMargin();
        int int18 = categoryAxis14.getCategoryLabelPositionOffset();
        categoryAxis14.clearCategoryLabelToolTips();
        categoryPlot10.setDomainAxis(3, categoryAxis14, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabel();
        numberAxis25.setLabelURL("");
        numberAxis25.setVisible(true);
        numberAxis25.setFixedAutoRange((double) (short) 100);
        numberAxis25.setAxisLineVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range37 = numberAxis36.getDefaultAutoRange();
        numberAxis36.setFixedAutoRange((double) (short) 0);
        org.jfree.chart.plot.Plot plot40 = numberAxis36.getPlot();
        numberAxis36.setUpperBound((double) 1560409200000L);
        java.text.NumberFormat numberFormat43 = null;
        numberAxis36.setNumberFormatOverride(numberFormat43);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis46.configure();
        java.awt.Shape shape48 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis46.setUpArrow(shape48);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { numberAxis23, numberAxis25, numberAxis36, dateAxis46 };
        categoryPlot10.setRangeAxes(valueAxisArray50);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(valueAxisArray50);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray14);
        categoryPlot10.mapDatasetToRangeAxis(0, (int) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str25 = numberAxis24.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis24.setMarkerBand(markerAxisBand26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabel();
        numberAxis29.setLabelURL("");
        boolean boolean34 = numberAxis29.equals((java.lang.Object) 1);
        boolean boolean35 = numberAxis29.isAutoRange();
        double double36 = numberAxis29.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer37);
        java.awt.Stroke stroke39 = xYPlot38.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        xYPlot38.drawBackgroundImage(graphics2D40, rectangle2D41);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot38.getRenderer(100);
        java.awt.Stroke stroke45 = xYPlot38.getDomainGridlineStroke();
        java.awt.Paint paint46 = null;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 11, 3.0d, (java.awt.Paint) color21, stroke45, paint46, stroke47, 0.0f);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer50 = null;
        intervalMarker49.setGradientPaintTransformer(gradientPaintTransformer50);
        double double52 = intervalMarker49.getEndValue();
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        intervalMarker49.setOutlineStroke(stroke53);
        boolean boolean55 = categoryPlot10.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker49);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str58 = numberAxis57.getLabel();
        numberAxis57.setLabelURL("");
        boolean boolean62 = numberAxis57.equals((java.lang.Object) 1);
        boolean boolean63 = numberAxis57.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = numberAxis57.getMarkerBand();
        java.awt.Stroke stroke65 = numberAxis57.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke65);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52 == 3.0d);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(markerAxisBand64);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        double double17 = xYPlot16.getRangeCrosshairValue();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot16.getDomainAxisForDataset(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 4 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        java.awt.Stroke stroke23 = xYPlot16.getRangeZeroBaselineStroke();
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        boolean boolean28 = dateAxis26.isHiddenValue((long) 10);
        int int29 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) 0, (double) 8, (double) 2.0f, 0.0d);
        xYPlot16.setInsets(rectangleInsets34, true);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range39 = numberAxis38.getDefaultAutoRange();
        numberAxis38.setAutoTickUnitSelection(true, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = numberAxis38.getStandardTickUnits();
        int int44 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str47 = numberAxis46.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis46.setMarkerBand(markerAxisBand48);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit50 = numberAxis46.getTickUnit();
        int int51 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(tickUnitSource43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertNotNull(numberTickUnit50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        dateAxis1.resizeRange(110.0d);
        float float5 = dateAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        numberAxis27.setLabelURL("");
        boolean boolean32 = numberAxis27.equals((java.lang.Object) 1);
        boolean boolean33 = numberAxis27.isAutoRange();
        double double34 = numberAxis27.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot36.getRangeAxisEdge(0);
        xYPlot36.setRangeCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D42 = xYPlot36.getQuadrantOrigin();
        categoryPlot10.zoomDomainAxes((double) '#', (double) (byte) 0, plotRenderingInfo19, point2D42);
        java.util.List list44 = categoryPlot10.getCategories();
        java.awt.Paint paint45 = categoryPlot10.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNull(list44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getUpperMargin();
        java.awt.Font font6 = numberAxis1.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.lengthToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        numberAxis1.setRange(2.0d, 11.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = xYPlot21.isDomainCrosshairLockedOnData();
        xYPlot21.clearRangeMarkers();
        java.lang.String str31 = xYPlot21.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = null;
        try {
            xYPlot21.setDatasetRenderingOrder(datasetRenderingOrder32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "XY Plot" + "'", str31.equals("XY Plot"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range31 = numberAxis30.getDefaultAutoRange();
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis30.setTickLabelPaint((java.awt.Paint) color32);
        xYPlot21.setRangeZeroBaselinePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot21.getRangeAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = xYPlot21.getAxisOffset();
        double double38 = rectangleInsets36.extendHeight((double) 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 19.0d + "'", double38 == 19.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass3 = stroke2.getClass();
        boolean boolean4 = day0.equals((java.lang.Object) wildcardClass3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot21.setDomainAxisLocation(axisLocation23, false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        int int31 = xYPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot21);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = xYPlot21.getAxisOffset();
        boolean boolean34 = day0.equals((java.lang.Object) xYPlot21);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        java.lang.String str40 = numberAxis36.getLabel();
        org.jfree.data.RangeType rangeType41 = numberAxis36.getRangeType();
        java.lang.Object obj42 = numberAxis36.clone();
        java.awt.Paint paint43 = numberAxis36.getTickLabelPaint();
        numberAxis36.setAutoRangeStickyZero(true);
        float float46 = numberAxis36.getTickMarkOutsideLength();
        java.lang.Object obj47 = numberAxis36.clone();
        boolean boolean48 = day0.equals((java.lang.Object) numberAxis36);
        numberAxis36.setFixedAutoRange((double) 1560409200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType41);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 2.0f + "'", float46 == 2.0f);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setMaximumCategoryLabelLines((int) '#');
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 1);
        boolean boolean7 = numberAxis1.isAutoRange();
        double double8 = numberAxis1.getLowerMargin();
        boolean boolean9 = numberAxis1.isTickLabelsVisible();
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        numberAxis1.setTickMarkPaint(paint10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str15 = numberAxis14.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str20 = numberAxis19.getLabel();
        numberAxis19.setLabelURL("");
        boolean boolean24 = numberAxis19.equals((java.lang.Object) 1);
        boolean boolean25 = numberAxis19.isAutoRange();
        double double26 = numberAxis19.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis19, xYItemRenderer27);
        org.jfree.data.Range range29 = numberAxis14.getDefaultAutoRange();
        org.jfree.data.Range range30 = numberAxis14.getDefaultAutoRange();
        numberAxis1.setDefaultAutoRange(range30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot16.getRenderer(100);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str34 = numberAxis33.getLabel();
        numberAxis33.setLabelURL("");
        boolean boolean38 = numberAxis33.equals((java.lang.Object) 1);
        boolean boolean39 = numberAxis33.isAutoRange();
        double double40 = numberAxis33.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis33, xYItemRenderer41);
        java.awt.Stroke stroke43 = xYPlot42.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot42.setDomainGridlineStroke(stroke44);
        java.awt.Paint paint46 = xYPlot42.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        xYPlot42.setRangeAxis(valueAxis47);
        categoryMarker25.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot42);
        java.awt.Paint paint50 = categoryMarker25.getOutlinePaint();
        categoryMarker25.setDrawAsLine(true);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean55 = xYPlot16.removeDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) categoryMarker25, layer53, false);
        java.awt.Paint paint56 = xYPlot16.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(paint56);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range5 = numberAxis4.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range5, false, true);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str12 = numberAxis11.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis11.setMarkerBand(markerAxisBand13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str17 = numberAxis16.getLabel();
        numberAxis16.setLabelURL("");
        boolean boolean21 = numberAxis16.equals((java.lang.Object) 1);
        boolean boolean22 = numberAxis16.isAutoRange();
        double double23 = numberAxis16.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) numberAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer24);
        org.jfree.data.Range range26 = numberAxis11.getDefaultAutoRange();
        dateAxis1.setRange(range26, true, false);
        org.jfree.chart.axis.Timeline timeline30 = dateAxis1.getTimeline();
        boolean boolean32 = dateAxis1.isHiddenValue((long) 0);
        org.jfree.chart.plot.Plot plot33 = dateAxis1.getPlot();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(timeline30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(plot33);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        categoryPlot10.clearDomainMarkers();
        boolean boolean18 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot10.setRenderer(200, categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot16.getRenderer(100);
        xYPlot16.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemRenderer22);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot10.getRowRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setAutoTickUnitSelection(false);
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset21);
        categoryPlot10.datasetChanged(datasetChangeEvent22);
        int int24 = categoryPlot10.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        double double3 = numberAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.trimHeight((double) 6);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        int int28 = xYPlot16.getIndexOf(xYItemRenderer27);
        java.awt.Stroke stroke29 = xYPlot16.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateTopOutset(11.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.awt.Shape shape5 = numberAxis1.getUpArrow();
        double double6 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        numberAxis27.setLabelURL("");
        boolean boolean32 = numberAxis27.equals((java.lang.Object) 1);
        boolean boolean33 = numberAxis27.isAutoRange();
        double double34 = numberAxis27.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot36.getRangeAxisEdge(0);
        xYPlot36.setRangeCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D42 = xYPlot36.getQuadrantOrigin();
        categoryPlot10.zoomDomainAxes((double) '#', (double) (byte) 0, plotRenderingInfo19, point2D42);
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot10.getDataset(500);
        int int46 = categoryPlot10.getDatasetCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation47 = null;
        try {
            boolean boolean48 = categoryPlot10.removeAnnotation(categoryAnnotation47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str5 = numberAxis4.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str10 = numberAxis9.getLabel();
        numberAxis9.setLabelURL("");
        boolean boolean14 = numberAxis9.equals((java.lang.Object) 1);
        boolean boolean15 = numberAxis9.isAutoRange();
        double double16 = numberAxis9.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer17);
        java.awt.Stroke stroke19 = xYPlot18.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot18.setDomainGridlineStroke(stroke20);
        java.awt.Paint paint22 = xYPlot18.getDomainZeroBaselinePaint();
        xYPlot18.setDomainZeroBaselineVisible(true);
        boolean boolean25 = plotOrientation0.equals((java.lang.Object) xYPlot18);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str31 = numberAxis30.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabel();
        numberAxis35.setLabelURL("");
        boolean boolean40 = numberAxis35.equals((java.lang.Object) 1);
        boolean boolean41 = numberAxis35.isAutoRange();
        double double42 = numberAxis35.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot44.getRangeAxisEdge(0);
        xYPlot44.setRangeCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D50 = xYPlot44.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        try {
            xYPlot18.draw(graphics2D26, rectangle2D27, point2D50, plotState51, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range6 = numberAxis5.getDefaultAutoRange();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color3, color7, color9 };
        java.awt.Paint[] paintArray11 = null;
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str16 = numberAxis15.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis15.setMarkerBand(markerAxisBand17);
        java.awt.Shape shape19 = numberAxis15.getUpArrow();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] { shape19, shape20, shape21 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray10, paintArray11, strokeArray12, strokeArray13, shapeArray22);
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 15, (java.awt.Paint) color1, stroke24);
        int int26 = color1.getBlue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        xYPlot16.clearRangeMarkers(0);
        xYPlot16.setDomainCrosshairVisible(false);
        java.awt.Paint paint31 = xYPlot16.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        java.util.List list13 = categoryPlot10.getAnnotations();
        boolean boolean14 = categoryPlot10.isDomainGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot10.getDataset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryDataset15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        boolean boolean17 = categoryPlot10.isDomainZoomable();
        categoryPlot10.setAnchorValue((double) (short) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot10.setDomainGridlinePosition(categoryAnchor20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range24 = numberAxis23.getDefaultAutoRange();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis23.setTickLabelPaint((java.awt.Paint) color25);
        categoryPlot10.setRangeGridlinePaint((java.awt.Paint) color25);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot10.setFixedRangeAxisSpace(axisSpace28, false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.setLowerMargin(0.0d);
        double double35 = categoryAxis32.getUpperMargin();
        int int36 = categoryAxis32.getCategoryLabelPositionOffset();
        categoryAxis32.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        double double39 = dateAxis38.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer40);
        categoryPlot41.setRangeCrosshairLockedOnData(true);
        java.util.List list44 = categoryPlot41.getAnnotations();
        java.awt.Paint paint45 = categoryPlot41.getDomainGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str49 = numberAxis48.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        numberAxis53.setLabelURL("");
        boolean boolean58 = numberAxis53.equals((java.lang.Object) 1);
        boolean boolean59 = numberAxis53.isAutoRange();
        double double60 = numberAxis53.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis53, xYItemRenderer61);
        java.awt.Stroke stroke63 = xYPlot62.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke64 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot62.setDomainGridlineStroke(stroke64);
        java.awt.Paint paint66 = xYPlot62.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        xYPlot62.setRangeAxis(valueAxis67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = xYPlot62.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        xYPlot62.setRangeAxis(valueAxis70);
        org.jfree.data.xy.XYDataset xYDataset72 = null;
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str75 = numberAxis74.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand76 = null;
        numberAxis74.setMarkerBand(markerAxisBand76);
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str80 = numberAxis79.getLabel();
        numberAxis79.setLabelURL("");
        boolean boolean84 = numberAxis79.equals((java.lang.Object) 1);
        boolean boolean85 = numberAxis79.isAutoRange();
        double double86 = numberAxis79.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer87 = null;
        org.jfree.chart.plot.XYPlot xYPlot88 = new org.jfree.chart.plot.XYPlot(xYDataset72, (org.jfree.chart.axis.ValueAxis) numberAxis74, (org.jfree.chart.axis.ValueAxis) numberAxis79, xYItemRenderer87);
        java.awt.Stroke stroke89 = xYPlot88.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D90 = null;
        java.awt.geom.Rectangle2D rectangle2D91 = null;
        xYPlot88.drawBackgroundImage(graphics2D90, rectangle2D91);
        org.jfree.chart.plot.PlotOrientation plotOrientation93 = xYPlot88.getOrientation();
        xYPlot62.setOrientation(plotOrientation93);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder95 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot62.setDatasetRenderingOrder(datasetRenderingOrder95);
        java.lang.String str97 = datasetRenderingOrder95.toString();
        categoryPlot41.setDatasetRenderingOrder(datasetRenderingOrder95);
        categoryPlot10.setDatasetRenderingOrder(datasetRenderingOrder95);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.05d + "'", double60 == 0.05d);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "hi!" + "'", str80.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.05d + "'", double86 == 0.05d);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(plotOrientation93);
        org.junit.Assert.assertNotNull(datasetRenderingOrder95);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str97.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str20 = plotOrientation19.toString();
        categoryPlot10.setOrientation(plotOrientation19);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot10.getDomainAxisForDataset((int) (byte) -1);
        java.awt.Paint paint24 = categoryAxis23.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str20.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Color color17 = java.awt.Color.orange;
        int int18 = color17.getGreen();
        xYPlot16.setDomainCrosshairPaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 200 + "'", int18 == 200);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int3 = java.awt.Color.HSBtoRGB((float) 13, (float) 6, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        categoryPlot10.clearDomainMarkers();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis20.setMarkerBand(markerAxisBand22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabel();
        numberAxis25.setLabelURL("");
        boolean boolean30 = numberAxis25.equals((java.lang.Object) 1);
        boolean boolean31 = numberAxis25.isAutoRange();
        double double32 = numberAxis25.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer33);
        java.awt.Stroke stroke35 = xYPlot34.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot34.setDomainAxisLocation(axisLocation36, false);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str41 = numberAxis40.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis40.setMarkerBand(markerAxisBand42);
        int int44 = xYPlot34.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis40);
        java.lang.String str45 = xYPlot34.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot34.setRangeAxisLocation(0, axisLocation47, false);
        categoryPlot10.setDomainAxisLocation(axisLocation47);
        java.awt.Color color51 = java.awt.Color.white;
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color51);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str18 = numberAxis17.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        numberAxis22.setLabelURL("");
        boolean boolean27 = numberAxis22.equals((java.lang.Object) 1);
        boolean boolean28 = numberAxis22.isAutoRange();
        double double29 = numberAxis22.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis22.setLabelPaint((java.awt.Paint) color32);
        categoryPlot10.setOutlinePaint((java.awt.Paint) color32);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot16.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29);
        xYPlot16.setRangeZeroBaselineVisible(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation33 = null;
        try {
            boolean boolean34 = xYPlot16.removeAnnotation(xYAnnotation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot10.getFixedLegendItems();
        double double14 = categoryPlot10.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str18 = numberAxis17.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        numberAxis22.setLabelURL("");
        boolean boolean27 = numberAxis22.equals((java.lang.Object) 1);
        boolean boolean28 = numberAxis22.isAutoRange();
        double double29 = numberAxis22.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer30);
        java.awt.Stroke stroke32 = xYPlot31.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot31.setDomainGridlineStroke(stroke33);
        java.awt.Paint paint35 = xYPlot31.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = xYPlot31.getRangeMarkers(layer36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot31.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot31.setInsets(rectangleInsets40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        int int43 = xYPlot31.getIndexOf(xYItemRenderer42);
        boolean boolean44 = xYPlot31.isOutlineVisible();
        xYPlot31.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot31.setDomainAxisLocation((int) 'a', axisLocation47);
        categoryPlot10.setRangeAxisLocation(axisLocation47);
        java.lang.String str50 = axisLocation47.toString();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str50.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        xYPlot16.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str24 = numberAxis23.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis23.setMarkerBand(markerAxisBand25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabel();
        numberAxis28.setLabelURL("");
        boolean boolean33 = numberAxis28.equals((java.lang.Object) 1);
        boolean boolean34 = numberAxis28.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabel();
        numberAxis36.setLabelURL("");
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str43 = numberAxis42.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = null;
        numberAxis42.setMarkerBand(markerAxisBand44);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str48 = numberAxis47.getLabel();
        numberAxis47.setLabelURL("");
        boolean boolean52 = numberAxis47.equals((java.lang.Object) 1);
        boolean boolean53 = numberAxis47.isAutoRange();
        double double54 = numberAxis47.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) numberAxis42, (org.jfree.chart.axis.ValueAxis) numberAxis47, xYItemRenderer55);
        java.awt.Stroke stroke57 = xYPlot56.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot56.setDomainAxisLocation(axisLocation58, false);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str63 = numberAxis62.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = null;
        numberAxis62.setMarkerBand(markerAxisBand64);
        int int66 = xYPlot56.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis62);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis68.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray73 = new org.jfree.chart.axis.ValueAxis[] { numberAxis23, numberAxis28, numberAxis36, numberAxis62, numberAxis68, numberAxis72 };
        xYPlot16.setDomainAxes(valueAxisArray73);
        xYPlot16.clearRangeMarkers(1);
        xYPlot16.setDomainCrosshairValue(14.0d, false);
        org.jfree.data.xy.XYDataset xYDataset80 = null;
        xYPlot16.setDataset(xYDataset80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(valueAxisArray73);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot10.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        try {
            categoryPlot10.setDomainAxisLocation((int) (byte) -1, axisLocation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor15);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = xYPlot21.isDomainCrosshairLockedOnData();
        java.awt.Paint paint30 = xYPlot21.getDomainZeroBaselinePaint();
        java.awt.Image image31 = null;
        xYPlot21.setBackgroundImage(image31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        java.lang.String str27 = xYPlot16.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot16.setRangeAxisLocation(0, axisLocation29, false);
        java.awt.Color color32 = java.awt.Color.RED;
        xYPlot16.setRangeZeroBaselinePaint((java.awt.Paint) color32);
        java.awt.Paint paint34 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot16.setRangeZeroBaselinePaint(paint34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabel();
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        double double7 = numberAxis1.getLowerBound();
        boolean boolean8 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.zoomRange((double) (byte) -1, (double) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        java.awt.Stroke stroke23 = xYPlot16.getRangeZeroBaselineStroke();
        xYPlot16.configureRangeAxes();
        java.lang.Class<?> wildcardClass25 = xYPlot16.getClass();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot16.setFixedDomainAxisSpace(axisSpace26, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder29 = xYPlot16.getSeriesRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabel();
        numberAxis39.setLabelURL("");
        boolean boolean44 = numberAxis39.equals((java.lang.Object) 1);
        boolean boolean45 = numberAxis39.isAutoRange();
        double double46 = numberAxis39.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis39, xYItemRenderer47);
        java.awt.Stroke stroke49 = xYPlot48.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot48.setDomainGridlineStroke(stroke50);
        java.awt.Paint paint52 = xYPlot48.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        xYPlot48.setRangeAxis(valueAxis53);
        categoryMarker31.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot48);
        java.awt.Paint paint56 = categoryMarker31.getOutlinePaint();
        xYPlot16.setOutlinePaint(paint56);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        categoryMarker22.setLabelAnchor(rectangleAnchor25);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = categoryMarker22.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = categoryMarker22.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.String str30 = textAnchor29.toString();
        categoryMarker22.setLabelTextAnchor(textAnchor29);
        boolean boolean32 = categoryMarker22.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str30.equals("TextAnchor.BASELINE_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = dateAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.util.Date date8 = dateAxis1.getMinimumDate();
        dateAxis1.setRange((-9.0d), (double) 6);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        xYPlot16.setRangeCrosshairValue(0.0d, false);
        xYPlot16.setRangeCrosshairLockedOnData(false);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot16.getAxisOffset();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range5 = numberAxis4.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range5, false, true);
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str16 = numberAxis15.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis15.setMarkerBand(markerAxisBand17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        numberAxis20.setLabelURL("");
        boolean boolean25 = numberAxis20.equals((java.lang.Object) 1);
        boolean boolean26 = numberAxis20.isAutoRange();
        double double27 = numberAxis20.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer28);
        java.awt.Stroke stroke30 = xYPlot29.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot29.setDomainGridlineStroke(stroke31);
        java.awt.Paint paint33 = xYPlot29.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        xYPlot29.setRangeAxis(valueAxis34);
        categoryMarker12.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot29);
        java.awt.Paint paint37 = categoryMarker12.getOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str41 = numberAxis40.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis40.setMarkerBand(markerAxisBand42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str46 = numberAxis45.getLabel();
        numberAxis45.setLabelURL("");
        boolean boolean50 = numberAxis45.equals((java.lang.Object) 1);
        boolean boolean51 = numberAxis45.isAutoRange();
        double double52 = numberAxis45.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) numberAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis45, xYItemRenderer53);
        java.awt.Stroke stroke55 = xYPlot54.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot54.setDomainAxisLocation(axisLocation56, false);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str61 = numberAxis60.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis60.setMarkerBand(markerAxisBand62);
        int int64 = xYPlot54.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis60);
        java.awt.Font font65 = numberAxis60.getTickLabelFont();
        categoryMarker12.setLabelFont(font65);
        dateAxis1.setTickLabelFont(font65);
        org.jfree.chart.axis.DateTickUnit dateTickUnit68 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit68);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.05d + "'", double52 == 0.05d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(dateTickUnit68);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot10.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setLowerMargin(0.0d);
        double double21 = categoryAxis18.getUpperMargin();
        int int22 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        double double25 = dateAxis24.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot27.setDataset(categoryDataset29);
        categoryPlot27.setRangeGridlinesVisible(true);
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot27);
        categoryPlot27.setAnchorValue((double) 12);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.TOP");
        categoryPlot27.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis38);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = categoryMarker22.getLabelAnchor();
        categoryMarker22.setLabel("13-June-2019");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.Stroke stroke3 = categoryAxis0.getAxisLineStroke();
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        double double5 = categoryAxis0.getUpperMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setLowerMargin(0.0d);
        double double17 = categoryAxis14.getUpperMargin();
        int int18 = categoryAxis14.getCategoryLabelPositionOffset();
        categoryAxis14.clearCategoryLabelToolTips();
        categoryPlot10.setDomainAxis(3, categoryAxis14, false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot10.getRendererForDataset(categoryDataset22);
        categoryPlot10.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        xYPlot16.setRangeAxis(valueAxis21);
        boolean boolean23 = xYPlot16.isRangeCrosshairVisible();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        java.lang.String str31 = numberAxis27.getLabel();
        org.jfree.data.RangeType rangeType32 = numberAxis27.getRangeType();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.AxisState axisState34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis27.refreshTicks(graphics2D33, axisState34, rectangle2D35, rectangleEdge36);
        xYPlot16.drawRangeTickBands(graphics2D24, rectangle2D25, list37);
        java.awt.Stroke stroke39 = xYPlot16.getOutlineStroke();
        boolean boolean40 = xYPlot16.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType32);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        xYPlot16.clearDomainMarkers((int) (short) -1);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.setLowerMargin(0.0d);
        double double31 = categoryAxis28.getUpperMargin();
        int int32 = categoryAxis28.getCategoryLabelPositionOffset();
        categoryAxis28.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        double double35 = dateAxis34.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis34, categoryItemRenderer36);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        categoryPlot37.rendererChanged(rendererChangeEvent38);
        java.util.List list40 = categoryPlot37.getCategories();
        java.awt.Stroke stroke41 = categoryPlot37.getDomainGridlineStroke();
        xYPlot16.setDomainGridlineStroke(stroke41);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNull(list40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str20 = plotOrientation19.toString();
        categoryPlot10.setOrientation(plotOrientation19);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot10.getDomainAxisForDataset((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        numberAxis34.setLabelURL("");
        boolean boolean39 = numberAxis34.equals((java.lang.Object) 1);
        boolean boolean40 = numberAxis34.isAutoRange();
        double double41 = numberAxis34.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer42);
        java.awt.Stroke stroke44 = xYPlot43.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot43.setDomainGridlineStroke(stroke45);
        java.awt.Paint paint47 = xYPlot43.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = xYPlot43.getRangeMarkers(layer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot43.getDomainAxisEdge((int) (short) 100);
        boolean boolean52 = dateAxis26.equals((java.lang.Object) xYPlot43);
        categoryPlot10.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis26, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str20.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(categoryAxis23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot10.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot10.setDataset(12, categoryDataset17);
        categoryPlot10.zoom(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor15);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        java.lang.Object obj29 = null;
        boolean boolean30 = xYPlot21.equals(obj29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot21.setRenderer(xYItemRenderer31);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot21.setDomainCrosshairPaint(paint33);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot21.getDomainAxis(255);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabel();
        numberAxis39.setLabelURL("");
        boolean boolean44 = numberAxis39.equals((java.lang.Object) 1);
        boolean boolean45 = numberAxis39.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = numberAxis39.getMarkerBand();
        java.lang.Object obj47 = numberAxis39.clone();
        xYPlot21.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(markerAxisBand46);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range5 = numberAxis4.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range5, false, true);
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis19.setAutoTickUnitSelection(false);
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) false, dataset22);
        xYPlot16.datasetChanged(datasetChangeEvent23);
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYPlot16.setNoDataMessageFont(font25);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        java.awt.Stroke stroke23 = xYPlot16.getRangeZeroBaselineStroke();
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot16.getDomainZeroBaselineStroke();
        xYPlot16.setWeight(4);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str31 = numberAxis30.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabel();
        numberAxis35.setLabelURL("");
        boolean boolean40 = numberAxis35.equals((java.lang.Object) 1);
        boolean boolean41 = numberAxis35.isAutoRange();
        double double42 = numberAxis35.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot44.getRangeAxisEdge(0);
        xYPlot44.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.Plot plot50 = xYPlot44.getRootPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray51 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot44.setRenderers(xYItemRendererArray51);
        xYPlot16.setRenderers(xYItemRendererArray51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(plot50);
        org.junit.Assert.assertNotNull(xYItemRendererArray51);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot10.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str20 = plotOrientation19.toString();
        categoryPlot10.setOrientation(plotOrientation19);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str25 = numberAxis24.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis24.setMarkerBand(markerAxisBand26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabel();
        numberAxis29.setLabelURL("");
        boolean boolean34 = numberAxis29.equals((java.lang.Object) 1);
        boolean boolean35 = numberAxis29.isAutoRange();
        double double36 = numberAxis29.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer37);
        java.awt.Stroke stroke39 = xYPlot38.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot38.setDomainAxisLocation(axisLocation40, false);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str48 = numberAxis47.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str53 = numberAxis52.getLabel();
        numberAxis52.setLabelURL("");
        boolean boolean57 = numberAxis52.equals((java.lang.Object) 1);
        boolean boolean58 = numberAxis52.isAutoRange();
        double double59 = numberAxis52.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) numberAxis47, (org.jfree.chart.axis.ValueAxis) numberAxis52, xYItemRenderer60);
        java.awt.Stroke stroke62 = xYPlot61.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke63 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot61.setDomainGridlineStroke(stroke63);
        java.awt.Paint paint65 = xYPlot61.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer66 = null;
        java.util.Collection collection67 = xYPlot61.getRangeMarkers(layer66);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = xYPlot61.getDomainAxisEdge((int) (short) 100);
        boolean boolean70 = dateAxis44.equals((java.lang.Object) xYPlot61);
        org.jfree.chart.plot.PlotOrientation plotOrientation71 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str72 = plotOrientation71.toString();
        xYPlot61.setOrientation(plotOrientation71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation40, plotOrientation71);
        categoryPlot10.setOrientation(plotOrientation71);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(valueAxis18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str20.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNull(collection67);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(plotOrientation71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str72.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        categoryMarker22.setLabelAnchor(rectangleAnchor25);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = categoryMarker22.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = categoryMarker22.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.String str30 = textAnchor29.toString();
        categoryMarker22.setLabelTextAnchor(textAnchor29);
        categoryMarker22.setKey((java.lang.Comparable) 46.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TextAnchor.BASELINE_LEFT" + "'", str30.equals("TextAnchor.BASELINE_LEFT"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setMaximumCategoryLabelLines((int) '#');
        categoryAxis0.setLowerMargin((double) 100L);
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 11);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        java.lang.String str15 = categoryPlot10.getPlotType();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot10.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setLowerMargin(0.0d);
        double double21 = categoryAxis18.getUpperMargin();
        int int22 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        double double25 = dateAxis24.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis24, categoryItemRenderer26);
        boolean boolean28 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot27.setDataset(categoryDataset29);
        categoryPlot27.setRangeGridlinesVisible(true);
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot27);
        boolean boolean34 = categoryPlot27.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        boolean boolean17 = categoryPlot10.isDomainZoomable();
        categoryPlot10.setAnchorValue((double) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot10.setFixedDomainAxisSpace(axisSpace20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str27 = numberAxis26.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis26.setMarkerBand(markerAxisBand28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabel();
        numberAxis31.setLabelURL("");
        boolean boolean36 = numberAxis31.equals((java.lang.Object) 1);
        boolean boolean37 = numberAxis31.isAutoRange();
        double double38 = numberAxis31.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer39);
        java.awt.Stroke stroke41 = xYPlot40.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot40.setDomainAxisLocation(axisLocation42, false);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = null;
        xYPlot40.setFixedLegendItems(legendItemCollection45);
        xYPlot40.mapDatasetToRangeAxis(1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str55 = numberAxis54.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = null;
        numberAxis54.setMarkerBand(markerAxisBand56);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str60 = numberAxis59.getLabel();
        numberAxis59.setLabelURL("");
        boolean boolean64 = numberAxis59.equals((java.lang.Object) 1);
        boolean boolean65 = numberAxis59.isAutoRange();
        double double66 = numberAxis59.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.axis.ValueAxis) numberAxis59, xYItemRenderer67);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = xYPlot68.getRangeAxisEdge(0);
        xYPlot68.setRangeCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D74 = xYPlot68.getQuadrantOrigin();
        xYPlot40.zoomDomainAxes(0.0d, plotRenderingInfo51, point2D74, false);
        categoryPlot10.zoomDomainAxes((double) 43629L, plotRenderingInfo23, point2D74, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "hi!" + "'", str55.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.05d + "'", double66 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(point2D74);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.data.RangeType rangeType7 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str10 = numberAxis9.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis9.setMarkerBand(markerAxisBand11);
        java.lang.String str13 = numberAxis9.getLabel();
        org.jfree.data.RangeType rangeType14 = numberAxis9.getRangeType();
        numberAxis1.setRangeType(rangeType14);
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType14);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        java.lang.String str27 = xYPlot16.getNoDataMessage();
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker30);
        java.awt.Paint paint32 = categoryMarker30.getOutlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent35 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker34);
        categoryMarker30.notifyListeners(markerChangeEvent35);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str38 = layer37.toString();
        boolean boolean39 = xYPlot16.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) categoryMarker30, layer37);
        java.awt.Color color40 = java.awt.Color.magenta;
        categoryMarker30.setPaint((java.awt.Paint) color40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace43 = color42.getColorSpace();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray53 = new float[] { (byte) 100, ' ', (short) 100, '4', 100L };
        float[] floatArray54 = color47.getRGBComponents(floatArray53);
        float[] floatArray55 = java.awt.Color.RGBtoHSB(2, (int) 'a', (int) ' ', floatArray54);
        float[] floatArray56 = color40.getComponents(colorSpace43, floatArray55);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Layer.BACKGROUND" + "'", str38.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(colorSpace43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot16);
        org.jfree.chart.plot.Plot plot28 = plotChangeEvent27.getPlot();
        org.jfree.chart.plot.Plot plot29 = plotChangeEvent27.getPlot();
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        plotChangeEvent27.setChart(jFreeChart30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(plot28);
        org.junit.Assert.assertNotNull(plot29);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        boolean boolean17 = xYPlot16.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace18 = xYPlot16.getFixedRangeAxisSpace();
        int int19 = xYPlot16.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        numberAxis27.setLabelURL("");
        boolean boolean32 = numberAxis27.equals((java.lang.Object) 1);
        boolean boolean33 = numberAxis27.isAutoRange();
        double double34 = numberAxis27.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot36.getRangeAxisEdge(0);
        xYPlot36.setRangeCrosshairValue(0.0d, false);
        java.awt.geom.Point2D point2D42 = xYPlot36.getQuadrantOrigin();
        categoryPlot10.zoomDomainAxes((double) '#', (double) (byte) 0, plotRenderingInfo19, point2D42);
        categoryPlot10.setWeight((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis47.setLowerMargin(0.0d);
        categoryAxis47.setLabelAngle((-5.0d));
        categoryAxis47.setMaximumCategoryLabelWidthRatio((float) 5);
        double double54 = categoryAxis47.getUpperMargin();
        categoryAxis47.removeCategoryLabelToolTip((java.lang.Comparable) 2.0f);
        categoryPlot10.setDomainAxis((int) ' ', categoryAxis47);
        categoryPlot10.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=0,b=0]");
        dateAxis2.configure();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = dateAxis2.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        java.util.Date date9 = dateAxis2.getMinimumDate();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date9, timeZone12);
        boolean boolean15 = rectangleAnchor0.equals((java.lang.Object) day14);
        java.lang.String str16 = day14.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-1969" + "'", str16.equals("31-December-1969"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        boolean boolean17 = categoryPlot10.isDomainZoomable();
        categoryPlot10.setAnchorValue((double) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot10.setFixedDomainAxisSpace(axisSpace20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot10.getRangeAxisForDataset(12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(valueAxis23);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot10.getFixedLegendItems();
        categoryPlot10.zoom((-5.0d));
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str19 = numberAxis18.getLabel();
        numberAxis18.setLabelURL("");
        boolean boolean23 = numberAxis18.equals((java.lang.Object) 1);
        boolean boolean24 = numberAxis18.isAutoRange();
        double double25 = numberAxis18.getLowerMargin();
        numberAxis18.setLowerMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = numberAxis18.getLabelInsets();
        categoryPlot10.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
        categoryPlot10.clearDomainMarkers(6);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        boolean boolean17 = categoryPlot10.isDomainZoomable();
        categoryPlot10.setAnchorValue((double) (short) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot10.setDomainGridlinePosition(categoryAnchor20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range24 = numberAxis23.getDefaultAutoRange();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis23.setTickLabelPaint((java.awt.Paint) color25);
        categoryPlot10.setRangeGridlinePaint((java.awt.Paint) color25);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.setLowerMargin(0.0d);
        double double32 = categoryAxis29.getUpperMargin();
        int int33 = categoryAxis29.getCategoryLabelPositionOffset();
        categoryAxis29.clearCategoryLabelToolTips();
        categoryPlot10.setDomainAxis(8, categoryAxis29, true);
        double double37 = categoryAxis29.getUpperMargin();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str46 = numberAxis45.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis45.setMarkerBand(markerAxisBand47);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str51 = numberAxis50.getLabel();
        numberAxis50.setLabelURL("");
        boolean boolean55 = numberAxis50.equals((java.lang.Object) 1);
        boolean boolean56 = numberAxis50.isAutoRange();
        double double57 = numberAxis50.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis45, (org.jfree.chart.axis.ValueAxis) numberAxis50, xYItemRenderer58);
        java.awt.Stroke stroke60 = xYPlot59.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        xYPlot59.drawBackgroundImage(graphics2D61, rectangle2D62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = xYPlot59.getRenderer(100);
        int int66 = xYPlot59.getWeight();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        xYPlot59.setRenderer(500, xYItemRenderer68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = xYPlot59.getRangeAxisEdge();
        try {
            double double71 = categoryAxis29.getCategorySeriesMiddle((java.lang.Comparable) "XY Plot", (java.lang.Comparable) "SortOrder.ASCENDING", categoryDataset40, (double) (-1L), rectangle2D42, rectangleEdge70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNull(xYItemRenderer65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = xYPlot21.isDomainCrosshairLockedOnData();
        xYPlot21.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis32.setAutoTickUnitSelection(false);
        java.awt.Font font35 = numberAxis32.getTickLabelFont();
        xYPlot21.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        java.awt.Paint paint37 = xYPlot21.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 1);
        boolean boolean7 = numberAxis1.isAutoRange();
        double double8 = numberAxis1.getLowerMargin();
        numberAxis1.setLowerMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis1.getLabelInsets();
        double double13 = rectangleInsets11.extendHeight(14.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray14);
        categoryPlot10.mapDatasetToRangeAxis(0, (int) (short) 1);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot10.getRangeAxisForDataset((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(valueAxis20);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        double double17 = xYPlot16.getRangeCrosshairValue();
        xYPlot16.setDomainCrosshairValue((double) (-1L));
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot16.setDatasetRenderingOrder(datasetRenderingOrder20);
        xYPlot16.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint24 = xYPlot16.getDomainGridlinePaint();
        java.awt.Paint paint25 = xYPlot16.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 1);
        boolean boolean7 = numberAxis1.isAutoRange();
        double double8 = numberAxis1.getLowerMargin();
        boolean boolean9 = numberAxis1.isTickLabelsVisible();
        numberAxis1.resizeRange(0.0d);
        java.lang.String str12 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = numberAxis22.getTickUnit();
        numberAxis22.setPositiveArrowVisible(true);
        boolean boolean30 = numberAxis22.isAutoRange();
        numberAxis22.setAutoRangeStickyZero(false);
        numberAxis22.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        double double17 = xYPlot16.getRangeCrosshairValue();
        xYPlot16.setDomainCrosshairValue((double) (-1L));
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str22 = numberAxis21.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis21.setMarkerBand(markerAxisBand23);
        java.lang.String str25 = numberAxis21.getLabel();
        org.jfree.data.RangeType rangeType26 = numberAxis21.getRangeType();
        java.lang.Object obj27 = numberAxis21.clone();
        java.awt.Paint paint28 = numberAxis21.getTickLabelPaint();
        numberAxis21.setAutoRangeStickyZero(true);
        float float31 = numberAxis21.getTickMarkOutsideLength();
        double double32 = numberAxis21.getAutoRangeMinimumSize();
        xYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        java.awt.Paint paint34 = xYPlot16.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0E-8d + "'", double32 == 1.0E-8d);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = null;
        xYPlot16.setFixedLegendItems(legendItemCollection21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setLowerMargin(0.0d);
        categoryAxis23.setLabelAngle((-5.0d));
        org.jfree.chart.plot.Plot plot28 = categoryAxis23.getPlot();
        java.awt.Font font29 = categoryAxis23.getLabelFont();
        xYPlot16.setNoDataMessageFont(font29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        xYPlot16.drawAnnotations(graphics2D31, rectangle2D32, plotRenderingInfo33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabel();
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        java.lang.Object obj7 = numberAxis1.clone();
        java.awt.Paint paint8 = numberAxis1.getTickLabelPaint();
        numberAxis1.setAutoRangeStickyZero(true);
        float float11 = numberAxis1.getTickMarkOutsideLength();
        java.lang.Object obj12 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str15 = numberAxis14.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        double double18 = numberAxis14.getUpperMargin();
        java.awt.Font font19 = numberAxis14.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis14.lengthToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str27 = numberAxis26.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis26.setMarkerBand(markerAxisBand28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabel();
        numberAxis31.setLabelURL("");
        boolean boolean36 = numberAxis31.equals((java.lang.Object) 1);
        boolean boolean37 = numberAxis31.isAutoRange();
        double double38 = numberAxis31.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis31, xYItemRenderer39);
        double double41 = xYPlot40.getRangeCrosshairValue();
        xYPlot40.setDomainCrosshairValue((double) (-1L));
        boolean boolean44 = xYPlot40.isDomainZeroBaselineVisible();
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot40);
        double double46 = numberAxis14.getFixedDimension();
        java.awt.Shape shape47 = numberAxis14.getRightArrow();
        numberAxis1.setLeftArrow(shape47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        boolean boolean29 = xYPlot21.isDomainCrosshairLockedOnData();
        xYPlot21.clearRangeMarkers();
        xYPlot21.setDomainCrosshairValue(0.0d);
        xYPlot21.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 15);
        valueMarker1.setValue((double) 1.0f);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range6 = numberAxis5.getDefaultAutoRange();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = valueMarker1.equals((java.lang.Object) color7);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        double double13 = categoryPlot10.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot10.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        categoryAxis0.setLabelAngle((-5.0d));
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 5);
        double double7 = categoryAxis0.getUpperMargin();
        java.lang.String str9 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(str9);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        java.lang.Class<?> wildcardClass3 = stroke2.getClass();
//        boolean boolean4 = day0.equals((java.lang.Object) wildcardClass3);
//        int int5 = day0.getDayOfMonth();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(stroke2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        int int28 = xYPlot16.getIndexOf(xYItemRenderer27);
        boolean boolean29 = xYPlot16.isOutlineVisible();
        xYPlot16.clearDomainAxes();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker32);
        xYPlot16.markerChanged(markerChangeEvent33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str6 = numberAxis5.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis5.setMarkerBand(markerAxisBand7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str11 = numberAxis10.getLabel();
        numberAxis10.setLabelURL("");
        boolean boolean15 = numberAxis10.equals((java.lang.Object) 1);
        boolean boolean16 = numberAxis10.isAutoRange();
        double double17 = numberAxis10.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer18);
        java.awt.Stroke stroke20 = xYPlot19.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        xYPlot19.drawBackgroundImage(graphics2D21, rectangle2D22);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot19.getRenderer(100);
        java.awt.Stroke stroke26 = xYPlot19.getDomainGridlineStroke();
        java.awt.Paint paint27 = null;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 11, 3.0d, (java.awt.Paint) color2, stroke26, paint27, stroke28, 0.0f);
        java.awt.Paint paint31 = intervalMarker30.getLabelPaint();
        intervalMarker30.setStartValue(1.560409199984E12d);
        intervalMarker30.setEndValue((double) (-1L));
        java.awt.Stroke stroke36 = intervalMarker30.getOutlineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot10.getFixedLegendItems();
        categoryPlot10.zoom((-5.0d));
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setLowerMargin(0.0d);
        double double19 = categoryAxis16.getUpperMargin();
        int int20 = categoryAxis16.getCategoryLabelPositionOffset();
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) 11);
        int int25 = categoryPlot10.getDomainAxisIndex(categoryAxis16);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str5 = numberAxis4.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str10 = numberAxis9.getLabel();
        numberAxis9.setLabelURL("");
        boolean boolean14 = numberAxis9.equals((java.lang.Object) 1);
        boolean boolean15 = numberAxis9.isAutoRange();
        double double16 = numberAxis9.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer17);
        java.awt.Stroke stroke19 = xYPlot18.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot18.setDomainGridlineStroke(stroke20);
        java.awt.Paint paint22 = xYPlot18.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        xYPlot18.setRangeAxis(valueAxis23);
        categoryMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot18);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str34 = numberAxis33.getLabel();
        numberAxis33.setLabelURL("");
        boolean boolean38 = numberAxis33.equals((java.lang.Object) 1);
        boolean boolean39 = numberAxis33.isAutoRange();
        double double40 = numberAxis33.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis33, xYItemRenderer41);
        java.awt.Stroke stroke43 = xYPlot42.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYPlot42.drawBackgroundImage(graphics2D44, rectangle2D45);
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer49 = null;
        xYPlot42.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker48, layer49);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        categoryMarker48.setLabelAnchor(rectangleAnchor51);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = categoryMarker48.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = categoryMarker48.getLabelAnchor();
        categoryMarker1.setLabelAnchor(rectangleAnchor54);
        java.lang.Object obj56 = null;
        boolean boolean57 = categoryMarker1.equals(obj56);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(lengthAdjustmentType53);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str14 = numberAxis13.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str19 = numberAxis18.getLabel();
        numberAxis18.setLabelURL("");
        boolean boolean23 = numberAxis18.equals((java.lang.Object) 1);
        boolean boolean24 = numberAxis18.isAutoRange();
        double double25 = numberAxis18.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot27.getRangeAxisEdge(0);
        xYPlot27.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str40 = numberAxis39.getLabel();
        numberAxis39.setLabelURL("");
        boolean boolean44 = numberAxis39.equals((java.lang.Object) 1);
        boolean boolean45 = numberAxis39.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str48 = numberAxis47.getLabel();
        numberAxis47.setLabelURL("");
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str54 = numberAxis53.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = null;
        numberAxis53.setMarkerBand(markerAxisBand55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str59 = numberAxis58.getLabel();
        numberAxis58.setLabelURL("");
        boolean boolean63 = numberAxis58.equals((java.lang.Object) 1);
        boolean boolean64 = numberAxis58.isAutoRange();
        double double65 = numberAxis58.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis53, (org.jfree.chart.axis.ValueAxis) numberAxis58, xYItemRenderer66);
        java.awt.Stroke stroke68 = xYPlot67.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot67.setDomainAxisLocation(axisLocation69, false);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str74 = numberAxis73.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand75 = null;
        numberAxis73.setMarkerBand(markerAxisBand75);
        int int77 = xYPlot67.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis73);
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis79.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis numberAxis83 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.ValueAxis[] valueAxisArray84 = new org.jfree.chart.axis.ValueAxis[] { numberAxis34, numberAxis39, numberAxis47, numberAxis73, numberAxis79, numberAxis83 };
        xYPlot27.setDomainAxes(valueAxisArray84);
        int int86 = xYPlot27.getWeight();
        double double87 = xYPlot27.getRangeCrosshairValue();
        java.awt.Paint paint88 = xYPlot27.getDomainGridlinePaint();
        categoryPlot10.setRangeCrosshairPaint(paint88);
        categoryPlot10.mapDatasetToDomainAxis(8, 11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo94 = null;
        java.awt.geom.Point2D point2D95 = null;
        categoryPlot10.zoomRangeAxes((-9.0d), plotRenderingInfo94, point2D95);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.05d + "'", double65 == 0.05d);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(valueAxisArray84);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(paint88);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        java.util.List list13 = categoryPlot10.getCategories();
        java.awt.Stroke stroke14 = categoryPlot10.getDomainGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot10.getRendererForDataset(categoryDataset15);
        categoryPlot10.zoom((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.extendWidth((double) 192);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 192.0d + "'", double3 == 192.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabel();
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        java.lang.Object obj7 = numberAxis1.clone();
        java.awt.Paint paint8 = numberAxis1.getTickLabelPaint();
        numberAxis1.setAutoRangeStickyZero(true);
        float float11 = numberAxis1.getTickMarkOutsideLength();
        java.awt.Paint paint12 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        java.lang.Object obj29 = null;
        boolean boolean30 = xYPlot21.equals(obj29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        xYPlot21.setRenderer(xYItemRenderer31);
        java.awt.Paint paint33 = xYPlot21.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str42 = numberAxis41.getLabel();
        numberAxis41.setLabelURL("");
        boolean boolean46 = numberAxis41.equals((java.lang.Object) 1);
        boolean boolean47 = numberAxis41.isAutoRange();
        double double48 = numberAxis41.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis41, xYItemRenderer49);
        double double51 = xYPlot50.getRangeCrosshairValue();
        xYPlot50.setDomainCrosshairValue((double) (-1L));
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot50.setDatasetRenderingOrder(datasetRenderingOrder54);
        xYPlot50.setDomainCrosshairValue(7.0d, true);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str62 = numberAxis61.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand63 = null;
        numberAxis61.setMarkerBand(markerAxisBand63);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str67 = numberAxis66.getLabel();
        numberAxis66.setLabelURL("");
        boolean boolean71 = numberAxis66.equals((java.lang.Object) 1);
        boolean boolean72 = numberAxis66.isAutoRange();
        double double73 = numberAxis66.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset59, (org.jfree.chart.axis.ValueAxis) numberAxis61, (org.jfree.chart.axis.ValueAxis) numberAxis66, xYItemRenderer74);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = xYPlot75.getRangeAxisEdge(0);
        xYPlot75.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.Plot plot81 = xYPlot75.getRootPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray82 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot75.setRenderers(xYItemRendererArray82);
        org.jfree.chart.axis.AxisLocation axisLocation84 = xYPlot75.getRangeAxisLocation();
        xYPlot50.setRangeAxisLocation(axisLocation84);
        xYPlot21.setRangeAxisLocation(axisLocation84);
        org.jfree.chart.axis.AxisLocation axisLocation87 = xYPlot21.getRangeAxisLocation();
        java.awt.Stroke stroke88 = xYPlot21.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertNotNull(plot81);
        org.junit.Assert.assertNotNull(xYItemRendererArray82);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(axisLocation87);
        org.junit.Assert.assertNotNull(stroke88);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        double double17 = xYPlot16.getRangeCrosshairValue();
        xYPlot16.setDomainCrosshairValue((double) (-1L));
        boolean boolean20 = xYPlot16.isDomainZeroBaselineVisible();
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot16, jFreeChart21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent22.setType(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 1);
        double double7 = numberAxis1.getLowerBound();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis1.setTickLabelFont(font8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        boolean boolean11 = categoryPlot10.isRangeGridlinesVisible();
        double double12 = categoryPlot10.getAnchorValue();
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot10.getRangeAxisEdge((int) (byte) 10);
        boolean boolean17 = categoryPlot10.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str21 = numberAxis20.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis20.setMarkerBand(markerAxisBand22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str26 = numberAxis25.getLabel();
        numberAxis25.setLabelURL("");
        boolean boolean30 = numberAxis25.equals((java.lang.Object) 1);
        boolean boolean31 = numberAxis25.isAutoRange();
        double double32 = numberAxis25.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        numberAxis25.setLabelPaint((java.awt.Paint) color35);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        try {
            categoryPlot10.zoomRangeAxes((double) 200, plotRenderingInfo39, point2D40, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot16.getRangeMarkers(layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot16.setInsets(rectangleInsets25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        xYPlot16.zoomDomainAxes((double) (-1), plotRenderingInfo28, point2D29);
        xYPlot16.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot16.setFixedRangeAxisSpace(axisSpace33);
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        xYPlot16.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        xYPlot16.setRangeAxis(valueAxis21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = xYPlot16.getInsets();
        java.lang.Object obj24 = xYPlot16.clone();
        java.awt.Paint paint25 = xYPlot16.getOutlinePaint();
        org.jfree.data.xy.XYDataset xYDataset27 = xYPlot16.getDataset(0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYDataset27);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getUpperMargin();
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        double double8 = dateAxis7.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis7, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray14);
        categoryPlot10.mapDatasetToRangeAxis(0, (int) (short) 1);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot10.getDomainAxisLocation(0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker23);
        boolean boolean25 = datasetRenderingOrder21.equals((java.lang.Object) markerChangeEvent24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str28 = numberAxis27.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        java.lang.String str31 = numberAxis27.getLabel();
        org.jfree.data.RangeType rangeType32 = numberAxis27.getRangeType();
        double double33 = numberAxis27.getLowerBound();
        java.lang.Object obj34 = numberAxis27.clone();
        boolean boolean35 = datasetRenderingOrder21.equals((java.lang.Object) numberAxis27);
        categoryPlot10.setDatasetRenderingOrder(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(rangeType32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer23);
        xYPlot16.clearDomainMarkers((int) (short) -1);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = null;
        boolean boolean32 = xYPlot16.render(graphics2D27, rectangle2D28, 10, plotRenderingInfo30, crosshairState31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot16.setRenderer(xYItemRenderer33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_RED;
        xYPlot16.setDomainGridlinePaint((java.awt.Paint) color35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        boolean boolean17 = xYPlot16.isRangeGridlinesVisible();
        xYPlot16.mapDatasetToDomainAxis(3, 255);
        java.awt.Paint paint21 = xYPlot16.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot16.getRenderer(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot16.getRangeAxisEdge((int) (short) 100);
        boolean boolean25 = xYPlot16.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.Stroke stroke3 = categoryAxis0.getAxisLineStroke();
        categoryAxis0.setMaximumCategoryLabelLines((-1));
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setLowerMargin(0.0d);
        double double13 = categoryAxis10.getUpperMargin();
        int int14 = categoryAxis10.getCategoryLabelPositionOffset();
        categoryAxis10.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        double double17 = dateAxis16.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis16, categoryItemRenderer18);
        categoryPlot19.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot19.getFixedLegendItems();
        double double23 = categoryPlot19.getRangeCrosshairValue();
        categoryPlot19.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getDomainAxisEdge(6);
        try {
            double double28 = categoryAxis0.getCategoryMiddle(0, (int) (byte) 1, rectangle2D8, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setLabelURL("");
        boolean boolean6 = numberAxis1.equals((java.lang.Object) 1);
        boolean boolean7 = numberAxis1.isAutoRange();
        double double8 = numberAxis1.getLowerMargin();
        boolean boolean9 = numberAxis1.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setLowerMargin(0.0d);
        double double16 = categoryAxis13.getUpperMargin();
        int int17 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        double double20 = dateAxis19.getUpperBound();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis19, categoryItemRenderer21);
        boolean boolean23 = categoryPlot22.isRangeGridlinesVisible();
        double double24 = categoryPlot22.getAnchorValue();
        categoryPlot22.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot22.getRangeAxisEdge((int) (byte) 10);
        try {
            double double29 = numberAxis1.java2DToValue((double) 192, rectangle2D11, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setAutoTickUnitSelection(true, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis1.getStandardTickUnits();
        double double7 = numberAxis1.getFixedDimension();
        org.jfree.data.RangeType rangeType8 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot16.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        xYPlot16.setRangeAxis(valueAxis21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = xYPlot16.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        xYPlot16.setRangeAxis(valueAxis24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str29 = numberAxis28.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str34 = numberAxis33.getLabel();
        numberAxis33.setLabelURL("");
        boolean boolean38 = numberAxis33.equals((java.lang.Object) 1);
        boolean boolean39 = numberAxis33.isAutoRange();
        double double40 = numberAxis33.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) numberAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis33, xYItemRenderer41);
        java.awt.Stroke stroke43 = xYPlot42.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYPlot42.drawBackgroundImage(graphics2D44, rectangle2D45);
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = xYPlot42.getOrientation();
        xYPlot16.setOrientation(plotOrientation47);
        java.awt.Paint[] paintArray49 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range53 = numberAxis52.getDefaultAutoRange();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_CYAN;
        numberAxis52.setTickLabelPaint((java.awt.Paint) color54);
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Paint[] paintArray57 = new java.awt.Paint[] { color50, color54, color56 };
        java.awt.Paint[] paintArray58 = null;
        java.awt.Stroke[] strokeArray59 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray60 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str63 = numberAxis62.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = null;
        numberAxis62.setMarkerBand(markerAxisBand64);
        java.awt.Shape shape66 = numberAxis62.getUpArrow();
        java.awt.Shape shape67 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape68 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray69 = new java.awt.Shape[] { shape66, shape67, shape68 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier70 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray49, paintArray57, paintArray58, strokeArray59, strokeArray60, shapeArray69);
        java.awt.Stroke stroke71 = defaultDrawingSupplier70.getNextOutlineStroke();
        xYPlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier70);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(paintArray49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(paintArray57);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(strokeArray60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(shapeArray69);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str4 = numberAxis3.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str9 = numberAxis8.getLabel();
        numberAxis8.setLabelURL("");
        boolean boolean13 = numberAxis8.equals((java.lang.Object) 1);
        boolean boolean14 = numberAxis8.isAutoRange();
        double double15 = numberAxis8.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer16);
        java.awt.Stroke stroke18 = xYPlot17.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYPlot17.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = xYPlot17.getRenderer(100);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str30 = numberAxis29.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str35 = numberAxis34.getLabel();
        numberAxis34.setLabelURL("");
        boolean boolean39 = numberAxis34.equals((java.lang.Object) 1);
        boolean boolean40 = numberAxis34.isAutoRange();
        double double41 = numberAxis34.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) numberAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer42);
        java.awt.Stroke stroke44 = xYPlot43.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot43.setDomainGridlineStroke(stroke45);
        java.awt.Paint paint47 = xYPlot43.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        xYPlot43.setRangeAxis(valueAxis48);
        categoryMarker26.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot43);
        java.awt.Paint paint51 = categoryMarker26.getOutlinePaint();
        categoryMarker26.setDrawAsLine(true);
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean56 = xYPlot17.removeDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) categoryMarker26, layer54, false);
        java.util.Collection collection57 = xYPlot0.getDomainMarkers(layer54);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(collection57);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot16.drawBackgroundImage(graphics2D18, rectangle2D19);
        boolean boolean21 = xYPlot16.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str25 = numberAxis24.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis24.setMarkerBand(markerAxisBand26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str31 = numberAxis30.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str36 = numberAxis35.getLabel();
        numberAxis35.setLabelURL("");
        boolean boolean40 = numberAxis35.equals((java.lang.Object) 1);
        boolean boolean41 = numberAxis35.isAutoRange();
        double double42 = numberAxis35.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) numberAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer43);
        java.awt.Stroke stroke45 = xYPlot44.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        xYPlot44.drawBackgroundImage(graphics2D46, rectangle2D47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = xYPlot44.getRenderer(100);
        numberAxis24.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot44);
        boolean boolean52 = xYPlot44.isDomainCrosshairLockedOnData();
        xYPlot44.clearRangeMarkers();
        xYPlot44.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot44.getDomainAxisLocation();
        xYPlot16.setDomainAxisLocation(0, axisLocation56, false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(axisLocation56);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        int int2 = objectList1.size();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str7 = numberAxis6.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis6.setMarkerBand(markerAxisBand8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str12 = numberAxis11.getLabel();
        numberAxis11.setLabelURL("");
        boolean boolean16 = numberAxis11.equals((java.lang.Object) 1);
        boolean boolean17 = numberAxis11.isAutoRange();
        double double18 = numberAxis11.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer19);
        java.awt.Stroke stroke21 = xYPlot20.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot20.setDomainAxisLocation(axisLocation22, false);
        xYPlot20.setDomainCrosshairValue((double) (short) 1);
        boolean boolean27 = xYPlot20.isDomainGridlinesVisible();
        objectList1.set(0, (java.lang.Object) xYPlot20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str13 = numberAxis12.getLabel();
        numberAxis12.setLabelURL("");
        boolean boolean17 = numberAxis12.equals((java.lang.Object) 1);
        boolean boolean18 = numberAxis12.isAutoRange();
        double double19 = numberAxis12.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot21.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRenderer(100);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot21);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        numberAxis1.setStandardTickUnits(tickUnitSource29);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis32.setAutoTickUnitSelection(false);
        java.awt.Font font35 = numberAxis32.getTickLabelFont();
        numberAxis1.setTickLabelFont(font35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str3 = numberAxis2.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str8 = numberAxis7.getLabel();
        numberAxis7.setLabelURL("");
        boolean boolean12 = numberAxis7.equals((java.lang.Object) 1);
        boolean boolean13 = numberAxis7.isAutoRange();
        double double14 = numberAxis7.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer15);
        java.awt.Stroke stroke17 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation18, false);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str23 = numberAxis22.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        int int26 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        java.lang.String str27 = xYPlot16.getNoDataMessage();
        java.awt.Font font28 = xYPlot16.getNoDataMessageFont();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str32 = numberAxis31.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis31.setMarkerBand(markerAxisBand33);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str37 = numberAxis36.getLabel();
        numberAxis36.setLabelURL("");
        boolean boolean41 = numberAxis36.equals((java.lang.Object) 1);
        boolean boolean42 = numberAxis36.isAutoRange();
        double double43 = numberAxis36.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer44);
        java.awt.Stroke stroke46 = xYPlot45.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        xYPlot45.drawBackgroundImage(graphics2D47, rectangle2D48);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100L);
        org.jfree.chart.util.Layer layer52 = null;
        xYPlot45.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker51, layer52);
        xYPlot45.clearDomainMarkers((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str58 = numberAxis57.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = null;
        numberAxis57.setMarkerBand(markerAxisBand59);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str64 = numberAxis63.getLabel();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand65 = null;
        numberAxis63.setMarkerBand(markerAxisBand65);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str69 = numberAxis68.getLabel();
        numberAxis68.setLabelURL("");
        boolean boolean73 = numberAxis68.equals((java.lang.Object) 1);
        boolean boolean74 = numberAxis68.isAutoRange();
        double double75 = numberAxis68.getLowerMargin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot(xYDataset61, (org.jfree.chart.axis.ValueAxis) numberAxis63, (org.jfree.chart.axis.ValueAxis) numberAxis68, xYItemRenderer76);
        java.awt.Stroke stroke78 = xYPlot77.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        xYPlot77.drawBackgroundImage(graphics2D79, rectangle2D80);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer83 = xYPlot77.getRenderer(100);
        numberAxis57.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot77);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray85 = new org.jfree.chart.axis.ValueAxis[] { numberAxis57 };
        xYPlot45.setRangeAxes(valueAxisArray85);
        xYPlot16.setRangeAxes(valueAxisArray85);
        org.jfree.chart.LegendItemCollection legendItemCollection88 = xYPlot16.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer89 = xYPlot16.getRenderer();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.05d + "'", double75 == 0.05d);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNull(xYItemRenderer83);
        org.junit.Assert.assertNotNull(valueAxisArray85);
        org.junit.Assert.assertNotNull(legendItemCollection88);
        org.junit.Assert.assertNull(xYItemRenderer89);
    }
}

