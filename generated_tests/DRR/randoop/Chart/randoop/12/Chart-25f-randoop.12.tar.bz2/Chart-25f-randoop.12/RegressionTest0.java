import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent(obj0, dataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Color color6 = java.awt.Color.WHITE;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", shape4, stroke5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (byte) -1, (double) '#', (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.Plot plot3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = numberAxis1.reserveSpace(graphics2D2, plot3, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        try {
            numberAxis1.setRange((double) (short) 100, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = null;
        try {
            numberAxis1.setLeftArrow(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (byte) 1, 0.0d, (int) (short) 1, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) '#', numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape7, (java.awt.Paint) color8);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape7, (double) 1.0f, (float) 0L, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        try {
            numberAxis1.setRangeWithMargins((double) 100.0f, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 1, (double) (byte) 1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            org.jfree.chart.axis.AxisState axisState8 = numberAxis1.draw(graphics2D2, (double) 0.0f, rectangle2D4, rectangle2D5, rectangleEdge6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, (double) (-1), (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, 0.0d, (double) (byte) 0, (double) 100L);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            blockBorder4.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", font1, paint2, (-1.0f), textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ClassContext");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ClassContext\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean11 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Paint paint15 = null;
        java.awt.Stroke stroke16 = null;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Stroke stroke21 = null;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem(attributedString0, "ThreadContext", "ClassContext", "ClassContext", true, shape7, true, (java.awt.Paint) color13, false, paint15, stroke16, true, shape20, stroke21, (java.awt.Paint) color22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        java.awt.Color color10 = java.awt.Color.gray;
        numberAxis1.setLabelPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            org.jfree.chart.axis.AxisState axisState18 = numberAxis1.draw(graphics2D12, (-1.0d), rectangle2D14, rectangle2D15, rectangleEdge16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) 0.0f, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        java.awt.Paint paint10 = numberAxis1.getTickMarkPaint();
        numberAxis1.configure();
        numberAxis1.setRangeAboutValue(0.0d, (double) (short) 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        java.lang.String str12 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        barRenderer0.setSeriesNegativeItemLabelPosition((int) 'a', itemLabelPosition2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape3, "hi!", "ThreadContext");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape3);
        java.lang.String str8 = chartEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape3, "hi!", "ThreadContext");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape3);
        java.lang.String str8 = chartEntity7.getShapeType();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "poly" + "'", str8.equals("poly"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = categoryItemRendererState1.getInfo();
        org.jfree.chart.entity.EntityCollection entityCollection4 = categoryItemRendererState1.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = categoryItemRendererState1.getInfo();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertNull(entityCollection4);
        org.junit.Assert.assertNull(plotRenderingInfo5);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("poly");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.text.TextBlock textBlock9 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.Size2D size2D11 = textBlock9.calculateDimensions(graphics2D10);
        try {
            org.jfree.chart.util.Size2D size2D12 = rectangleConstraint8.calculateConstrainedSize(size2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(size2D11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        java.awt.Paint paint9 = legendItem8.getFillPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("ClassContext", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getUpperBound();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, (double) 1L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1, lengthConstraintType2, (double) 10.0f, range4, lengthConstraintType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(100.0d);
        blockParams0.setGenerateEntities(true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        boolean boolean11 = range1.intersects((double) 3, (double) 1.0f);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = labelBlock1.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RangeType.NEGATIVE", "", "poly", "", "");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier0, jFreeChart1, (int) '#', 10);
        java.awt.Shape shape5 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.general.DatasetGroup datasetGroup6 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color9 = java.awt.Color.WHITE;
        numberAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = numberAxis8.isVisible();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis8.valueToJava2D((double) (byte) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint16 = numberAxis8.getTickMarkPaint();
        boolean boolean17 = datasetGroup6.equals((java.lang.Object) numberAxis8);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double19 = range18.getCentralValue();
        org.jfree.data.Range range22 = org.jfree.data.Range.expand(range18, (double) 1, (double) 0.0f);
        numberAxis8.setRange(range22);
        boolean boolean24 = defaultDrawingSupplier0.equals((java.lang.Object) numberAxis8);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.5d + "'", double19 == 0.5d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape8);
        barRenderer1.setBaseShape(shape5);
        java.awt.Stroke stroke12 = barRenderer1.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        boolean boolean26 = barRenderer13.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer13.setSeriesOutlinePaint((int) '4', paint28);
        barRenderer1.setBaseFillPaint(paint28);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint28);
        double double33 = rectangleInsets0.extendWidth((double) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        try {
            java.awt.Shape shape10 = textBlock0.calculateBounds(graphics2D3, (float) (short) 1, (float) (byte) 0, textBlockAnchor6, (float) ' ', (float) (-1L), (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(libraryArray12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f, numberFormat1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean2 = shapeList0.equals((java.lang.Object) itemLabelAnchor1);
        java.lang.Object obj3 = shapeList0.clone();
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RangeType.NEGATIVE", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createOutsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.lang.Comparable comparable8 = null;
        try {
            java.awt.Paint paint9 = categoryAxis1.getTickLabelPaint(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 3, (double) 1.0f, (int) (byte) 100, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image4, "hi!", "ClassContext", "hi!");
        java.lang.String str9 = projectInfo8.getLicenceName();
        projectInfo8.setLicenceText("hi!");
        java.awt.Image image12 = projectInfo8.getLogo();
        boolean boolean13 = unitType0.equals((java.lang.Object) image12);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertNull(image12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color0 = java.awt.Color.white;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        barRenderer0.setAutoPopulateSeriesPaint(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image15, "hi!", "ClassContext", "hi!");
        java.lang.String str20 = projectInfo19.getLicenceName();
        projectInfo19.setLicenceText("hi!");
        java.awt.Image image23 = projectInfo19.getLogo();
        projectInfo19.setInfo("ClassContext");
        projectInfo19.setVersion("RangeType.NEGATIVE");
        java.awt.Image image31 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image31, "hi!", "ClassContext", "hi!");
        java.lang.String str36 = projectInfo35.getLicenceName();
        projectInfo35.setLicenceText("hi!");
        java.awt.Image image39 = projectInfo35.getLogo();
        projectInfo35.setInfo("ClassContext");
        projectInfo35.setVersion("RangeType.NEGATIVE");
        projectInfo19.addLibrary((org.jfree.chart.ui.Library) projectInfo35);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo35);
        java.lang.String str46 = projectInfo7.getVersion();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ClassContext" + "'", str20.equals("ClassContext"));
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ClassContext" + "'", str36.equals("ClassContext"));
        org.junit.Assert.assertNull(image39);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        double double3 = categoryLabelPosition2.getAngle();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double15 = numberAxis1.java2DToValue(0.05d, rectangle2D13, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        float float3 = categoryLabelPosition2.getWidthRatio();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.95f + "'", float3 == 0.95f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color5 = java.awt.Color.darkGray;
        java.awt.Color color6 = java.awt.Color.getColor("hi!", color5);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, (double) (byte) 100, (double) (-1), (java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) -1, "CategoryAnchor.MIDDLE", textAnchor2, textAnchor3, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color1 = java.awt.Color.getColor("poly");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getTickMarkPaint();
        java.awt.Font font10 = numberAxis1.getLabelFont();
        numberAxis1.setAutoRange(false);
        numberAxis1.setFixedAutoRange((-1.0d));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getUpperBound();
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range12, (double) 1L);
        numberAxis2.setRange(range15, true, false);
        numberAxis2.setRange(1.0E-8d, (double) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("EXPAND", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        double double12 = numberAxis1.getFixedAutoRange();
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        numberAxis1.centerRange((double) (-1));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        boolean boolean8 = rectangleInsets2.equals((java.lang.Object) 1.0f);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets2.createInsetRectangle(rectangle2D9, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(100.0d);
        double double3 = blockParams0.getTranslateY();
        blockParams0.setTranslateY(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        boolean boolean10 = legendItem8.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        boolean boolean8 = rectangleInsets2.equals((java.lang.Object) 1.0f);
        try {
            java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Color color18 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color18);
        barRenderer0.setSeriesPaint(1, (java.awt.Paint) color18);
        int int21 = color18.getBlue();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 175 + "'", int21 == 175);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9, true);
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        java.lang.Comparable comparable2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity(comparable2, shape5, "hi!", "ThreadContext");
        boolean boolean9 = categoryLabelPositions1.equals((java.lang.Object) "hi!");
        boolean boolean10 = lineBorder0.equals((java.lang.Object) categoryLabelPositions1);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            lineBorder0.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("VerticalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            textTitle17.setBounds(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier0, jFreeChart1, (int) '#', 10);
        chartProgressEvent4.setPercent(10);
        org.jfree.chart.JFreeChart jFreeChart7 = chartProgressEvent4.getChart();
        int int8 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertNull(jFreeChart7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str10 = textAnchor9.toString();
        org.jfree.chart.axis.NumberTick numberTick12 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor8, textAnchor9, (-1.0d));
        try {
            java.awt.Shape shape13 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.CENTER", graphics2D1, (float) (byte) -1, (float) 0L, textAnchor4, (double) ' ', textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str10.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        boolean boolean16 = labelBlock1.equals((java.lang.Object) "ClassContext");
        org.jfree.chart.block.BlockFrame blockFrame17 = null;
        try {
            labelBlock1.setFrame(blockFrame17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        double double3 = categoryItemRendererState1.getSeriesRunningTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        barRenderer9.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color18, false);
        boolean boolean22 = barRenderer9.getAutoPopulateSeriesShape();
        java.awt.Paint paint25 = barRenderer9.getItemPaint((int) (short) 10, 0);
        boolean boolean26 = range1.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Layer.FOREGROUND", graphics2D1, (float) (byte) 0, (float) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtBottom();
        java.util.List list3 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle1.draw(graphics2D4, rectangle2D5);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.extendWidth((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.data.KeyToGroupMap keyToGroupMap19 = null;
        try {
            org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, keyToGroupMap19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(unitType2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        barRenderer9.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color18, false);
        java.awt.Paint paint24 = barRenderer9.getItemLabelPaint((int) (short) 0, (int) (byte) 1);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        barRenderer9.setSeriesStroke(2, stroke26, false);
        numberAxis1.setTickMarkStroke(stroke26);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.0d, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier0, jFreeChart1, (int) '#', 10);
        java.awt.Stroke stroke5 = defaultDrawingSupplier0.getNextStroke();
        java.lang.Object obj6 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        projectInfo7.setInfo("ClassContext");
        projectInfo7.setCopyright("ClassContext");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getSeriesIndex();
        java.lang.String str10 = legendItem8.getLabel();
        legendItem8.setSeriesKey((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 0);
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color21 = java.awt.Color.WHITE;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis20.isVisible();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis20.valueToJava2D((double) (byte) 10, rectangle2D25, rectangleEdge26);
        java.awt.Paint paint28 = numberAxis20.getLabelPaint();
        numberAxis20.setAutoRangeStickyZero(false);
        boolean boolean31 = numberAxis20.isInverted();
        double double32 = numberAxis20.getUpperBound();
        boolean boolean33 = categoryItemEntity18.equals((java.lang.Object) numberAxis20);
        java.awt.Paint paint34 = numberAxis20.getTickMarkPaint();
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double36 = range35.getCentralValue();
        boolean boolean39 = range35.intersects((double) (byte) 100, 100.0d);
        double double41 = range35.constrain((double) (short) 1);
        org.jfree.data.Range range42 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint(range35, range42);
        numberAxis20.setRangeWithMargins(range35, false, false);
        try {
            numberAxis20.setAutoRangeMinimumSize(0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.5d + "'", double36 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double15 = numberAxis14.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color18 = java.awt.Color.WHITE;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis17.isVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis17.valueToJava2D((double) (byte) 10, rectangle2D22, rectangleEdge23);
        java.awt.Paint paint25 = numberAxis17.getTickMarkPaint();
        java.awt.Font font26 = numberAxis17.getLabelFont();
        numberAxis14.setLabelFont(font26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color30 = java.awt.Color.WHITE;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis29.isVisible();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = numberAxis29.valueToJava2D((double) (byte) 10, rectangle2D34, rectangleEdge35);
        java.awt.Paint paint37 = numberAxis29.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("EXPAND", font26, paint37);
        try {
            barRenderer0.setSeriesItemLabelFont((int) (byte) -1, font26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "[size=1]");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key VerticalAlignment.CENTER");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Object obj2 = defaultStatisticalCategoryDataset0.clone();
        try {
            java.lang.Comparable comparable4 = defaultStatisticalCategoryDataset0.getColumnKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("TextAnchor.BASELINE_RIGHT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultStatisticalCategoryDataset0.getGroup();
        java.lang.Comparable comparable2 = null;
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex(comparable2);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, (double) 0.0f);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = barRenderer2.getBaseShape();
        barRenderer2.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj8 = defaultDrawingSupplier7.clone();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        barRenderer2.setSeriesStroke((int) 'a', stroke9);
        java.awt.Paint paint11 = barRenderer2.getBaseOutlinePaint();
        try {
            org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("Range[1.0,2.0]", font1, paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        double double12 = numberAxis1.getFixedAutoRange();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        numberAxis1.setAxisLinePaint(paint13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray8);
        java.lang.Comparable comparable10 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset9, comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Color color3 = java.awt.Color.darkGray;
        java.awt.Color color4 = java.awt.Color.getColor("hi!", color3);
        textTitle1.setPaint((java.awt.Paint) color3);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color3.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "poly", "hi!");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setBaseStroke(stroke15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset1.validateObject();
        java.lang.Object obj3 = defaultStatisticalCategoryDataset1.clone();
        try {
            java.lang.String str5 = standardCategorySeriesLabelGenerator0.generateLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities(3, (java.lang.Boolean) true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint(2);
        java.awt.Font font8 = barRenderer0.getSeriesItemLabelFont(15);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double double2 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = barRenderer0.getURLGenerator(0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(categoryURLGenerator5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem8.getFillPaintTransformer();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape12 = barRenderer11.getBaseShape();
        barRenderer11.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj17 = defaultDrawingSupplier16.clone();
        java.awt.Stroke stroke18 = defaultDrawingSupplier16.getNextStroke();
        barRenderer11.setSeriesStroke((int) 'a', stroke18);
        boolean boolean20 = barRenderer11.getIncludeBaseInRange();
        boolean boolean21 = legendItem8.equals((java.lang.Object) boolean20);
        boolean boolean23 = legendItem8.equals((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 2.0f, (double) 10, (double) (short) -1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color17 = java.awt.Color.WHITE;
        numberAxis16.setTickLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = numberAxis16.isVisible();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis16.valueToJava2D((double) (byte) 10, rectangle2D21, rectangleEdge22);
        java.awt.Paint paint24 = numberAxis16.getTickMarkPaint();
        java.awt.Font font25 = numberAxis16.getLabelFont();
        barRenderer0.setSeriesItemLabelFont((int) (byte) 1, font25);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(pieDataset20);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double9 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor4, (int) (byte) -1, (int) 'a', rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener2 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener2);
        try {
            java.lang.Comparable comparable5 = defaultStatisticalCategoryDataset0.getColumnKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier0, jFreeChart1, (int) '#', 10);
        chartProgressEvent4.setType(0);
        int int7 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        double double12 = numberAxis1.getFixedAutoRange();
        java.awt.Font font13 = numberAxis1.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape15 = barRenderer14.getBaseShape();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.equal(shape18, shape21);
        barRenderer14.setBaseShape(shape18);
        java.awt.Stroke stroke25 = barRenderer14.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape34, (java.awt.Paint) color35);
        barRenderer26.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color35, false);
        boolean boolean39 = barRenderer26.getAutoPopulateSeriesShape();
        java.awt.Paint paint41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer26.setSeriesOutlinePaint((int) '4', paint41);
        barRenderer14.setBaseFillPaint(paint41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_RED;
        barRenderer14.setBasePaint((java.awt.Paint) color44);
        numberAxis1.setTickMarkPaint((java.awt.Paint) color44);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double15 = numberAxis1.valueToJava2D(0.0d, rectangle2D13, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock1, textBlockAnchor2, textAnchor3, (double) (-1L));
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = categoryTick5.getLabelAnchor();
        double double7 = categoryTick5.getAngle();
        org.jfree.chart.text.TextBlock textBlock8 = categoryTick5.getLabel();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNull(textBlock8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        boolean boolean16 = labelBlock1.equals((java.lang.Object) "ClassContext");
        java.lang.String str17 = labelBlock1.getURLText();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.lang.Object obj20 = null;
        try {
            java.lang.Object obj21 = labelBlock1.draw(graphics2D18, rectangle2D19, obj20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.util.List list3 = textBlock0.getLines();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        boolean boolean16 = labelBlock1.equals((java.lang.Object) "ClassContext");
        java.lang.Object obj17 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape3, 0.0d, 0.0f, 1.0f);
        boolean boolean8 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE5" + "'", str1.equals("ItemLabelAnchor.OUTSIDE5"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.95f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color9 = java.awt.Color.WHITE;
        numberAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = numberAxis8.isVisible();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis8.valueToJava2D((double) (byte) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint16 = numberAxis8.getTickMarkPaint();
        boolean boolean17 = datasetGroup6.equals((java.lang.Object) numberAxis8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis8.getTickUnit();
        java.lang.String str19 = numberTickUnit18.toString();
        double double20 = numberTickUnit18.getSize();
        java.lang.Number number22 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) double20, (java.lang.Comparable) 8.0d);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[size=1]" + "'", str19.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNull(number22);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        try {
            java.util.Collection collection3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) strSet2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setBasePaint(paint5, false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D8, categoryPlot9, categoryAxis10, categoryMarker11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("EXPAND", font11, (java.awt.Paint) color12, rectangleEdge13, horizontalAlignment14, verticalAlignment17, rectangleInsets18);
        double double21 = rectangleInsets18.calculateLeftOutset(10.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray7 = new float[] { 2, 10.0f, 175, (byte) 0, 0 };
        try {
            float[] floatArray8 = color0.getColorComponents(colorSpace1, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemURLGenerator();
        boolean boolean15 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = barRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryURLGenerator17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) ' ', (double) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint6 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis4.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 1L);
        categoryAxis4.removeCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        boolean boolean13 = meanAndStandardDeviation2.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color4 = java.awt.Color.WHITE;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis3.isVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3.valueToJava2D((double) (byte) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis3.getTickMarkPaint();
        java.awt.Font font12 = numberAxis3.getLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = textTitle17.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("EXPAND", font12, (java.awt.Paint) color13, rectangleEdge14, horizontalAlignment15, verticalAlignment18, rectangleInsets19);
        boolean boolean21 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) verticalAlignment18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.lang.Object obj7 = null;
        boolean boolean8 = labelBlock1.equals(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem6 = legendItemCollection4.get((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        barRenderer0.setSeriesToolTipGenerator(2, categoryToolTipGenerator24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        int int27 = barRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 0.0d, 0.0f, 1.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "", "hi!");
        java.lang.String str10 = tickLabelEntity9.getShapeType();
        java.lang.String str11 = tickLabelEntity9.getShapeType();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "poly" + "'", str10.equals("poly"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberFormat9, jFreeChart10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(numberFormat9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, 10, 8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        try {
            double double5 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.axis.Axis axis2 = axisChangeEvent1.getAxis();
        org.junit.Assert.assertNotNull(axis2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleAnchor.CENTER");
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color5 = java.awt.Color.WHITE;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color5);
        boolean boolean7 = numberAxis4.isVisible();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis4.valueToJava2D((double) (byte) 10, rectangle2D9, rectangleEdge10);
        java.awt.Paint paint12 = numberAxis4.getTickMarkPaint();
        boolean boolean13 = datasetGroup2.equals((java.lang.Object) numberAxis4);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double15 = range14.getCentralValue();
        org.jfree.data.Range range18 = org.jfree.data.Range.expand(range14, (double) 1, (double) 0.0f);
        numberAxis4.setRange(range18);
        boolean boolean20 = textFragment1.equals((java.lang.Object) range18);
        java.lang.String str21 = textFragment1.getText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleAnchor.CENTER" + "'", str21.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock1, textBlockAnchor2, textAnchor3, (double) (-1L));
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier6, jFreeChart7, (int) '#', 10);
        chartProgressEvent10.setPercent(10);
        boolean boolean13 = categoryTick5.equals((java.lang.Object) chartProgressEvent10);
        java.lang.Comparable comparable14 = categoryTick5.getCategory();
        double double15 = categoryTick5.getAngle();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "ThreadContext" + "'", comparable14.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState(1.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list7 = numberAxis1.refreshTicks(graphics2D2, axisState4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(0.0d, rectangleEdge3);
        axisState1.cursorDown((double) 100L);
        axisState1.cursorUp(0.5d);
        org.jfree.chart.axis.AxisCollection axisCollection9 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list10 = axisCollection9.getAxesAtTop();
        java.util.List list11 = axisCollection9.getAxesAtBottom();
        java.util.List list12 = axisCollection9.getAxesAtLeft();
        axisState1.setTicks(list12);
        axisState1.setMax((double) 2.0f);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener5 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener5);
        try {
            java.lang.Comparable comparable8 = defaultStatisticalCategoryDataset0.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        java.awt.Paint paint18 = barRenderer0.getSeriesFillPaint(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator19);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("RangeType.FULL");
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration3 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(strEnumeration3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis20.setMaximumCategoryLabelLines((int) (byte) 0);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D17, categoryPlot18, categoryAxis20, categoryMarker23, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.POSITIVE" + "'", str1.equals("RangeType.POSITIVE"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        objectList1.clear();
        java.lang.Object obj4 = objectList1.get(0);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        barRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double double2 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 100, categoryToolTipGenerator4, true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getTickMarkPaint();
        java.awt.Font font14 = numberAxis5.getLabelFont();
        numberAxis2.setLabelFont(font14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color18 = java.awt.Color.WHITE;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis17.isVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis17.valueToJava2D((double) (byte) 10, rectangle2D22, rectangleEdge23);
        java.awt.Paint paint25 = numberAxis17.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("EXPAND", font14, paint25);
        java.awt.Graphics2D graphics2D27 = null;
        try {
            org.jfree.chart.util.Size2D size2D28 = textLine26.calculateDimensions(graphics2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        java.lang.Object obj19 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color5 = java.awt.Color.WHITE;
        numberAxis4.setTickLabelPaint((java.awt.Paint) color5);
        boolean boolean7 = numberAxis4.isVisible();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis4.valueToJava2D((double) (byte) 10, rectangle2D9, rectangleEdge10);
        java.awt.Paint paint12 = numberAxis4.getTickMarkPaint();
        java.awt.Font font13 = numberAxis4.getLabelFont();
        numberAxis1.setLabelFont(font13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis1.getLabelInsets();
        java.lang.String str16 = rectangleInsets15.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str16.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getTickMarkPaint();
        try {
            numberAxis1.zoomRange((double) (short) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition10.getTextAnchor();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape3, "hi!", "ThreadContext");
        java.lang.String str7 = categoryLabelEntity6.toString();
        java.lang.String str8 = categoryLabelEntity6.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext" + "'", str7.equals("CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext" + "'", str8.equals("CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape7, (java.awt.Paint) color8);
        boolean boolean10 = lengthConstraintType0.equals((java.lang.Object) legendItem9);
        boolean boolean11 = legendItem9.isLineVisible();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) ' ', shape7, "", "TextAnchor.BASELINE_RIGHT");
        java.awt.Paint paint11 = null;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "[size=1]", "RangeType.NEGATIVE", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", shape7, paint11, stroke13, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement1 = new org.jfree.chart.block.BorderArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double8 = range7.getCentralValue();
        boolean boolean11 = range7.intersects((double) (byte) 100, 100.0d);
        double double13 = range7.constrain((double) (short) 1);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range7, range14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        double double17 = rectangleConstraint15.getHeight();
        org.jfree.chart.util.Size2D size2D18 = borderArrangement1.arrange(blockContainer3, graphics2D6, rectangleConstraint15);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape29, (java.awt.Paint) color30);
        barRenderer21.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color30, false);
        java.awt.Paint paint36 = barRenderer21.getItemLabelPaint((int) (short) 0, (int) (byte) 1);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        barRenderer21.setSeriesStroke(2, stroke38, false);
        try {
            blockContainer3.add((org.jfree.chart.block.Block) textTitle20, (java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis1.getTickUnit();
        numberAxis1.setLabel("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getTickMarkPaint();
        java.awt.Font font14 = numberAxis5.getLabelFont();
        numberAxis2.setLabelFont(font14);
        java.awt.Color color16 = java.awt.Color.black;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryAnchor.START", font14, (java.awt.Paint) color16, (float) 10, 1, textMeasurer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        barRenderer0.setSeriesItemLabelPaint(8, (java.awt.Paint) color13, true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        double double12 = numberAxis1.getFixedAutoRange();
        java.awt.Font font13 = numberAxis1.getLabelFont();
        java.lang.String str14 = numberAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        numberAxis1.setDownArrow(shape17);
        numberAxis1.setRangeAboutValue(0.0d, 0.0d);
        org.jfree.chart.plot.Plot plot24 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(plot24);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape3, "hi!", "ThreadContext");
        categoryLabelEntity6.setURLText("Range[1.0,2.0]");
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape8);
        barRenderer1.setBaseShape(shape5);
        java.awt.Stroke stroke12 = barRenderer1.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        boolean boolean26 = barRenderer13.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer13.setSeriesOutlinePaint((int) '4', paint28);
        barRenderer1.setBaseFillPaint(paint28);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint28);
        double double33 = rectangleInsets0.calculateTopInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.lang.Object obj3 = labelBlock1.clone();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, 0.0d, (double) (byte) 0, (double) 100L);
        labelBlock1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        labelBlock1.setToolTipText("ThreadContext");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 1);
        boolean boolean17 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color2 = java.awt.Color.getColor("NOID", (int) '4');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Shape shape12 = numberAxis1.getRightArrow();
        boolean boolean13 = numberAxis1.isVerticalTickLabels();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = textTitle17.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle17.getPosition();
        try {
            double double20 = numberAxis1.java2DToValue((double) (byte) 10, rectangle2D15, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getCentralValue();
        boolean boolean4 = range0.intersects((double) (byte) 100, 100.0d);
        double double6 = range0.constrain((double) (short) 1);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range7);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double10 = range9.getCentralValue();
        boolean boolean13 = range9.intersects((double) (byte) 100, 100.0d);
        double double15 = range9.constrain((double) (short) 1);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range9, range16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range9, 1.0E-8d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint8.toRangeHeight(range9);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Range[1.0,2.0]");
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        try {
            java.awt.GradientPaint gradientPaint6 = standardGradientPaintTransformer0.transform(gradientPaint2, shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        boolean boolean4 = textTitle1.getNotify();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str2 = rectangleAnchor1.toString();
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.CENTER" + "'", str2.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        int int5 = barRenderer0.getRowCount();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        java.awt.Paint paint17 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        try {
            barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[][] doubleArray8 = new double[][] { doubleArray2, doubleArray3, doubleArray4, doubleArray5, doubleArray6, doubleArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset9, false);
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        categoryItemEntity18.setArea(shape21);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean14 = numberAxis1.equals((java.lang.Object) "hi!");
        numberAxis1.centerRange(0.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        java.awt.Paint paint18 = barRenderer0.getSeriesFillPaint(3);
        java.awt.Paint paint20 = null;
        barRenderer0.setSeriesPaint(1, paint20, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.Object obj3 = textTitle2.clone();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        textTitle2.draw(graphics2D4, rectangle2D5);
        boolean boolean7 = textBlock0.equals((java.lang.Object) graphics2D4);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean3 = rectangleInsets0.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets0.getUnitType();
        double double5 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        boolean boolean4 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext", "");
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = axisChangeEvent11.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = axisChangeEvent11.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) double8, jFreeChart9, chartChangeEventType13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = categoryItemRendererState1.getInfo();
        org.jfree.chart.entity.EntityCollection entityCollection4 = categoryItemRendererState1.getEntityCollection();
        categoryItemRendererState1.setBarWidth(0.05d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = categoryItemRendererState1.getInfo();
        categoryItemRendererState1.setBarWidth((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertNull(entityCollection4);
        org.junit.Assert.assertNull(plotRenderingInfo7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer0.getPositiveItemLabelPosition(2, (-1));
        org.jfree.chart.text.TextAnchor textAnchor25 = itemLabelPosition24.getRotationAnchor();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        boolean boolean16 = labelBlock1.equals((java.lang.Object) "ClassContext");
        java.lang.String str17 = labelBlock1.getURLText();
        labelBlock1.setURLText("poly");
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double22 = range21.getCentralValue();
        boolean boolean25 = range21.intersects((double) (byte) 100, 100.0d);
        double double27 = range21.constrain((double) (short) 1);
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range21, range28);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = rectangleConstraint29.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D31 = labelBlock1.arrange(graphics2D20, rectangleConstraint29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        java.lang.Comparable comparable10 = legendItemEntity7.getSeriesKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) paint0, jFreeChart1, (int) '#', (int) '#');
        int int5 = chartProgressEvent4.getType();
        chartProgressEvent4.setPercent((int) '#');
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        try {
            org.jfree.data.Range range11 = org.jfree.data.Range.expand(range0, (double) 255, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        boolean boolean4 = jFreeChartResources0.containsKey("[size=1]");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str15 = layer14.toString();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape22, (java.awt.Paint) color23);
        int int25 = legendItem24.getSeriesIndex();
        legendItem24.setSeriesKey((java.lang.Comparable) true);
        boolean boolean28 = layer14.equals((java.lang.Object) true);
        try {
            barRenderer0.addAnnotation(categoryAnnotation13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Layer.FOREGROUND" + "'", str15.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = barRenderer0.getURLGenerator((-1), (int) (short) 1);
        java.awt.Shape shape7 = barRenderer0.lookupSeriesShape(15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image11, "hi!", "ClassContext", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.lang.String str17 = projectInfo15.getLicenceName();
        projectInfo15.setVersion("CategoryAnchor.MIDDLE");
        projectInfo15.setInfo("CategoryLabelWidthType.CATEGORY");
        projectInfo15.setVersion("RangeType.POSITIVE");
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ClassContext" + "'", str17.equals("ClassContext"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType1 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "hi!", (java.lang.Object) lengthAdjustmentType1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean4 = categoryLabelWidthType0.equals((java.lang.Object) "");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Shape shape14 = numberAxis6.getLeftArrow();
        boolean boolean15 = numberAxis6.isNegativeArrowVisible();
        double double16 = numberAxis6.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double20 = range19.getCentralValue();
        boolean boolean23 = range19.intersects((double) (byte) 100, 100.0d);
        double double25 = range19.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range18, range19);
        double double28 = range19.constrain((double) 2);
        org.jfree.data.Range range30 = org.jfree.data.Range.shift(range19, (double) (byte) 100);
        numberAxis6.setDefaultAutoRange(range19);
        boolean boolean32 = numberAxis6.isAutoTickUnitSelection();
        boolean boolean33 = categoryLabelWidthType0.equals((java.lang.Object) numberAxis6);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str35 = layer34.toString();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape42, (java.awt.Paint) color43);
        int int45 = legendItem44.getSeriesIndex();
        legendItem44.setSeriesKey((java.lang.Comparable) true);
        boolean boolean48 = layer34.equals((java.lang.Object) true);
        boolean boolean49 = categoryLabelWidthType0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Layer.FOREGROUND" + "'", str35.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 3.0d, (double) 15, 1.0E-8d, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        java.awt.Color color18 = java.awt.Color.orange;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color18, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape30, (java.awt.Paint) color31);
        int int33 = legendItem32.getSeriesIndex();
        legendItem32.setSeriesKey((java.lang.Comparable) true);
        boolean boolean36 = layer22.equals((java.lang.Object) true);
        try {
            barRenderer0.addAnnotation(categoryAnnotation21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        java.lang.Object obj2 = objectList1.clone();
        objectList1.clear();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color21 = java.awt.Color.WHITE;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis20.isVisible();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis20.valueToJava2D((double) (byte) 10, rectangle2D25, rectangleEdge26);
        java.awt.Paint paint28 = numberAxis20.getLabelPaint();
        numberAxis20.setAutoRangeStickyZero(false);
        boolean boolean31 = numberAxis20.isInverted();
        double double32 = numberAxis20.getUpperBound();
        boolean boolean33 = categoryItemEntity18.equals((java.lang.Object) numberAxis20);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        numberAxis20.setRightArrow(shape36);
        numberAxis20.setFixedDimension((double) ' ');
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setUpperBound(0.5d);
        numberAxis1.setLabelAngle(0.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color14, false);
        org.jfree.chart.LegendItem legendItem19 = barRenderer0.getLegendItem(0, 175);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color24 = java.awt.Color.WHITE;
        numberAxis23.setTickLabelPaint((java.awt.Paint) color24);
        boolean boolean26 = numberAxis23.isVisible();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis23.valueToJava2D((double) (byte) 10, rectangle2D28, rectangleEdge29);
        java.awt.Paint paint31 = numberAxis23.getLabelPaint();
        numberAxis23.setAutoRangeStickyZero(false);
        boolean boolean34 = numberAxis23.isInverted();
        double double35 = numberAxis23.getUpperBound();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        barRenderer0.drawRangeGridline(graphics2D20, categoryPlot21, (org.jfree.chart.axis.ValueAxis) numberAxis23, rectangle2D36, Double.NaN);
        numberAxis23.setFixedDimension((double) (-1L));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0.0d, (java.lang.Number) (short) 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType1 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str2 = categoryLabelWidthType1.toString();
        boolean boolean3 = keyedObjects0.equals((java.lang.Object) str2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str2.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        try {
            java.lang.Number number4 = defaultStatisticalCategoryDataset0.getStdDevValue(15, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.configure();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.Size2D size2D14 = textBlock12.calculateDimensions(graphics2D13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str18 = rectangleAnchor17.toString();
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, Double.NaN, 0.0d, rectangleAnchor17);
        org.jfree.chart.text.TextBlock textBlock20 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = textBlock20.calculateDimensions(graphics2D21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str26 = rectangleAnchor25.toString();
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, Double.NaN, 0.0d, rectangleAnchor25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            org.jfree.chart.axis.AxisState axisState30 = categoryAxis1.draw(graphics2D10, (-1.0d), rectangle2D19, rectangle2D27, rectangleEdge28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleAnchor.CENTER" + "'", str18.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleAnchor.CENTER" + "'", str26.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection4.addAll(legendItemCollection5);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        legendItemCollection5.add(legendItem15);
        boolean boolean17 = legendItem15.isShapeFilled();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("NOID");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name NOID, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.setLabelToolTip("ClassContext");
        categoryAxis1.setCategoryLabelPositionOffset((-1));
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.lang.Object obj1 = textTitle0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100.0f);
        double double3 = range0.getLowerBound();
        boolean boolean5 = range0.contains(0.0d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getSeriesItemLabelGenerator((int) '4');
        java.awt.Stroke stroke12 = null;
        barRenderer0.setSeriesStroke(10, stroke12);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        numberAxis1.resizeRange(10.0d, (double) (short) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color4 = java.awt.Color.WHITE;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis3.isVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3.valueToJava2D((double) (byte) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis3.getTickMarkPaint();
        boolean boolean12 = datasetGroup1.equals((java.lang.Object) numberAxis3);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double14 = range13.getUpperBound();
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range13, (double) 1L);
        numberAxis3.setRange(range16, true, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = null;
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double23 = range22.getUpperBound();
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double26 = range25.getCentralValue();
        boolean boolean29 = range25.intersects((double) (byte) 100, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range25);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint30.getHeightConstraintType();
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range16, lengthConstraintType20, (double) (byte) 100, range22, lengthConstraintType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.5d + "'", double26 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("EXPAND", font11, (java.awt.Paint) color12, rectangleEdge13, horizontalAlignment14, verticalAlignment17, rectangleInsets18);
        double double20 = rectangleInsets18.getTop();
        double double22 = rectangleInsets18.calculateBottomInset(10.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        boolean boolean9 = legendItem8.isLineVisible();
        java.awt.Shape shape10 = legendItem8.getShape();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem8.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Color color0 = java.awt.Color.orange;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str1.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("CategoryAnchor.START");
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        java.lang.Object obj3 = keyedObjects0.clone();
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("Layer.FOREGROUND", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        boolean boolean1 = blockContainer0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getCentralValue();
        boolean boolean4 = range0.intersects((double) (byte) 100, 100.0d);
        double double6 = range0.constrain((double) (short) 1);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range7);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = rectangleConstraint8.getWidthConstraintType();
        double double10 = rectangleConstraint8.getWidth();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        numberAxis1.setDownArrow(shape17);
        numberAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Color color18 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color18);
        barRenderer0.setSeriesPaint(1, (java.awt.Paint) color18);
        int int21 = color18.getRed();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getCentralValue();
        boolean boolean4 = range0.intersects((double) (byte) 100, 100.0d);
        double double6 = range0.constrain((double) (short) 1);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range7);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = rectangleConstraint8.getWidthConstraintType();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((-1.0f), 0.0f);
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) rectangleConstraint8, (java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 10.0d);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 1);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlock textBlock23 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = textBlock23.calculateDimensions(graphics2D24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str29 = rectangleAnchor28.toString();
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, Double.NaN, 0.0d, rectangleAnchor28);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = barRenderer0.initialise(graphics2D22, rectangle2D30, categoryPlot31, 0, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleAnchor.CENTER" + "'", str29.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("poly", "NOID", "ClassContext", image3, "[size=1]", "RangeType.FULL", "CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext");
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.removeAnnotations();
        barRenderer0.removeAnnotations();
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape8);
        barRenderer1.setBaseShape(shape5);
        java.awt.Stroke stroke12 = barRenderer1.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        boolean boolean26 = barRenderer13.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer13.setSeriesOutlinePaint((int) '4', paint28);
        barRenderer1.setBaseFillPaint(paint28);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint28);
        double double33 = rectangleInsets0.trimHeight((double) 15);
        double double34 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 15.0d + "'", double33 == 15.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        java.awt.Paint paint3 = numberAxis1.getTickLabelPaint();
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getSeriesIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem8.getFillPaintTransformer();
        org.jfree.data.general.Dataset dataset11 = legendItem8.getDataset();
        int int12 = legendItem8.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNull(dataset11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer12.setSeriesOutlinePaint((int) '4', paint27);
        barRenderer0.setBaseFillPaint(paint27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        barRenderer0.setBasePaint((java.awt.Paint) color30);
        java.awt.Stroke stroke33 = barRenderer0.getSeriesOutlineStroke(0);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[][] doubleArray42 = new double[][] { doubleArray36, doubleArray37, doubleArray38, doubleArray39, doubleArray40, doubleArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray42);
        org.jfree.data.Range range44 = barRenderer0.findRangeBounds(categoryDataset43);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        numberAxis1.setLabelURL("poly");
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock1, textBlockAnchor2, textAnchor3, (double) (-1L));
        java.lang.Comparable comparable6 = categoryTick5.getCategory();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "ThreadContext" + "'", comparable6.equals("ThreadContext"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        barRenderer0.removeAnnotations();
        try {
            barRenderer0.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        java.awt.Paint paint10 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 100, paint10);
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        barRenderer0.setBaseItemLabelFont(font12, false);
        double double15 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape11 = barRenderer10.getBaseShape();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean18 = org.jfree.chart.util.ShapeUtilities.equal(shape14, shape17);
        barRenderer10.setBaseShape(shape14);
        java.awt.Color color20 = java.awt.Color.orange;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj22 = defaultDrawingSupplier21.clone();
        java.awt.Stroke stroke23 = defaultDrawingSupplier21.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint27 = categoryAxis25.getTickLabelPaint((java.lang.Comparable) "poly");
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "VerticalAlignment.CENTER", "RangeType.FULL", shape14, (java.awt.Paint) color20, stroke23, paint27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color30 = color29.brighter();
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "CategoryLabelWidthType.CATEGORY", "", "CategoryLabelWidthType.CATEGORY", shape5, stroke23, (java.awt.Paint) color30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Layer.FOREGROUND");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = barRenderer2.getBaseShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean10 = org.jfree.chart.util.ShapeUtilities.equal(shape6, shape9);
        barRenderer2.setBaseShape(shape6);
        java.awt.Stroke stroke13 = barRenderer2.lookupSeriesOutlineStroke(3);
        java.awt.Paint paint16 = barRenderer2.getItemPaint((int) '4', 2);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint16);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.lang.String str12 = legendTitle10.getID();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlock textBlock16 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = textBlock16.calculateDimensions(graphics2D17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str22 = rectangleAnchor21.toString();
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, Double.NaN, 0.0d, rectangleAnchor21);
        try {
            legendTitle10.draw(graphics2D15, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleAnchor.CENTER" + "'", str22.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D23);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        java.awt.Paint paint18 = barRenderer0.getSeriesFillPaint(3);
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double22 = labelBlock21.getWidth();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = textTitle24.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = textTitle24.getPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape28 = barRenderer27.getBaseShape();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.equal(shape31, shape34);
        barRenderer27.setBaseShape(shape31);
        java.awt.Stroke stroke38 = barRenderer27.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape47, (java.awt.Paint) color48);
        barRenderer39.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color48, false);
        boolean boolean52 = barRenderer39.getAutoPopulateSeriesShape();
        java.awt.Paint paint54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer39.setSeriesOutlinePaint((int) '4', paint54);
        barRenderer27.setBaseFillPaint(paint54);
        boolean boolean57 = textTitle24.equals((java.lang.Object) paint54);
        labelBlock21.setPaint(paint54);
        barRenderer0.setSeriesFillPaint((int) (byte) 0, paint54, false);
        java.awt.Font font62 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        barRenderer0.setSeriesItemLabelFont((int) '4', font62);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(font62);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 10.0d);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) pieDataset3, jFreeChart5);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
        int int4 = color3.getGreen();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleAnchor.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = axisChangeEvent1.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        axisChangeEvent1.setType(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        double double12 = numberAxis1.getFixedAutoRange();
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double17 = rectangleInsets16.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean19 = rectangleInsets16.equals((java.lang.Object) itemLabelAnchor18);
        labelBlock15.setPadding(rectangleInsets16);
        boolean boolean22 = rectangleInsets16.equals((java.lang.Object) 1.0f);
        numberAxis1.setLabelInsets(rectangleInsets16);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.lang.Object obj3 = labelBlock1.clone();
        java.awt.Font font4 = labelBlock1.getFont();
        labelBlock1.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape18, (java.awt.Paint) color19);
        barRenderer10.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color19, false);
        boolean boolean23 = barRenderer10.getAutoPopulateSeriesShape();
        java.awt.Paint paint24 = barRenderer10.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer10.getSeriesPositiveItemLabelPosition((int) (short) 1);
        boolean boolean27 = labelBlock1.equals((java.lang.Object) barRenderer10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color1 = java.awt.Color.PINK;
        boolean boolean2 = unitType0.equals((java.lang.Object) color1);
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray7 = null;
        float[] floatArray8 = java.awt.Color.RGBtoHSB((int) ' ', (int) (byte) 0, 175, floatArray7);
        try {
            float[] floatArray9 = color1.getColorComponents(colorSpace3, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=255,g=200,b=0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        double double14 = barRenderer0.getBase();
        org.jfree.chart.LegendItem legendItem17 = barRenderer0.getLegendItem((int) (byte) 1, 3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(legendItem17);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getTickMarkPaint();
        java.awt.Font font14 = numberAxis5.getLabelFont();
        numberAxis2.setLabelFont(font14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color18 = java.awt.Color.WHITE;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis17.isVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis17.valueToJava2D((double) (byte) 10, rectangle2D22, rectangleEdge23);
        java.awt.Paint paint25 = numberAxis17.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("EXPAND", font14, paint25);
        org.jfree.chart.text.TextFragment textFragment27 = textLine26.getLastTextFragment();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor30 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition31 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor29, textBlockAnchor30);
        org.jfree.chart.text.TextAnchor textAnchor32 = categoryLabelPosition31.getRotationAnchor();
        try {
            float float33 = textFragment27.calculateBaselineOffset(graphics2D28, textAnchor32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textFragment27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(textBlockAnchor30);
        org.junit.Assert.assertNotNull(textAnchor32);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Paint paint15 = barRenderer0.getItemLabelPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        boolean boolean17 = barRenderer0.removeAnnotation(categoryAnnotation16);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator18, true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener2 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener2);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 'a');
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        java.lang.String str10 = rectangleConstraint8.toString();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str10.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE2" + "'", str1.equals("ItemLabelAnchor.INSIDE2"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        java.awt.Paint paint10 = categoryAxis1.getLabelPaint();
        float float11 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultStatisticalCategoryDataset1.getGroup();
        java.util.List list3 = defaultStatisticalCategoryDataset1.getColumnKeys();
        boolean boolean4 = textBlockAnchor0.equals((java.lang.Object) defaultStatisticalCategoryDataset1);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(datasetGroup2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color14, false);
        org.jfree.chart.LegendItem legendItem19 = barRenderer0.getLegendItem(0, 175);
        java.awt.Paint paint21 = barRenderer0.lookupSeriesFillPaint((int) (short) 100);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = textBlock13.calculateDimensions(graphics2D14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str19 = rectangleAnchor18.toString();
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, Double.NaN, 0.0d, rectangleAnchor18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape24 = barRenderer23.getBaseShape();
        barRenderer23.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj29 = defaultDrawingSupplier28.clone();
        java.awt.Stroke stroke30 = defaultDrawingSupplier28.getNextStroke();
        barRenderer23.setSeriesStroke((int) 'a', stroke30);
        boolean boolean32 = barRenderer23.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer23);
        java.awt.Font font34 = legendTitle33.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle33.setLegendItemGraphicLocation(rectangleAnchor35);
        java.awt.geom.Rectangle2D rectangle2D37 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) 10.0f, 8.0d, rectangleAnchor35);
        org.jfree.chart.text.TextBlock textBlock38 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.Size2D size2D40 = textBlock38.calculateDimensions(graphics2D39);
        try {
            java.lang.Object obj41 = legendTitle10.draw(graphics2D12, rectangle2D37, (java.lang.Object) size2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleAnchor.CENTER" + "'", str19.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(size2D40);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        java.awt.Paint paint20 = barRenderer0.getSeriesFillPaint(8);
        boolean boolean21 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator6);
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.data.general.Dataset dataset10 = legendItem8.getDataset();
        java.lang.Comparable comparable11 = legendItem8.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertNull(comparable11);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TextAnchor.BASELINE_RIGHT", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("EXPAND", font11, (java.awt.Paint) color12, rectangleEdge13, horizontalAlignment14, verticalAlignment17, rectangleInsets18);
        textTitle19.setMargin(0.5d, 0.0d, 0.0d, (double) 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        textTitle17.setToolTipText("ItemLabelAnchor.INSIDE2");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 255, 0.0d, (double) (byte) 100, 0.05d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        java.awt.Paint paint14 = barRenderer0.getItemPaint((int) '4', 2);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color4 = java.awt.Color.PINK;
        boolean boolean5 = unitType3.equals((java.lang.Object) color4);
        objectList1.set((int) 'a', (java.lang.Object) boolean5);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        numberAxis1.setDownArrow(shape17);
        numberAxis1.setRangeAboutValue((double) 100L, 4.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        java.awt.Paint paint10 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 100, paint10);
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Paint paint16 = barRenderer0.lookupSeriesFillPaint(3);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberTickUnit12.toString();
        java.lang.String str14 = numberTickUnit12.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[size=1]" + "'", str13.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "[size=1]" + "'", str14.equals("[size=1]"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setAutoRangeMinimumSize((double) (byte) 1, true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        java.lang.String str9 = projectInfo7.getVersion();
        projectInfo7.setCopyright("DatasetRenderingOrder.FORWARD");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        double double10 = rectangleConstraint8.getHeight();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            barRenderer0.addAnnotation(categoryAnnotation15, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(layer16);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean6, jFreeChart7);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) (short) 100);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener3);
        int int5 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.lang.Object obj3 = labelBlock1.clone();
        java.awt.Font font4 = labelBlock1.getFont();
        double double5 = labelBlock1.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleAnchor.CENTER", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        numberAxis1.setLabelURL("poly");
        numberAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        objectList1.clear();
        objectList1.set(255, (java.lang.Object) 2);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color8 = java.awt.Color.WHITE;
        numberAxis7.setTickLabelPaint((java.awt.Paint) color8);
        numberAxis7.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat13 = null;
        numberAxis7.setNumberFormatOverride(numberFormat13);
        org.jfree.chart.plot.Plot plot15 = null;
        numberAxis7.setPlot(plot15);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape23, (java.awt.Paint) color24);
        numberAxis7.setDownArrow(shape23);
        boolean boolean27 = objectList1.equals((java.lang.Object) shape23);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem8.getFillPaintTransformer();
        java.awt.Shape shape11 = legendItem8.getLine();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener18 = null;
        try {
            barRenderer0.addChangeListener(rendererChangeListener18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateY((double) 15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) '#');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 10.0d);
        java.lang.Number number6 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) 255, (java.lang.Comparable) "Layer.FOREGROUND");
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(100.0d);
        double double3 = blockParams0.getTranslateY();
        double double4 = blockParams0.getTranslateX();
        double double5 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberAxis2.getLabelURL();
        java.awt.Paint paint14 = numberAxis2.getLabelPaint();
        boolean boolean15 = numberAxis2.isAxisLineVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Font font3 = textFragment1.getFont();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 1, (int) (short) 10, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor2, textAnchor3, (-1.0d));
        org.jfree.chart.axis.TickType tickType7 = numberTick6.getTickType();
        java.lang.String str8 = tickType7.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str4.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "MAJOR" + "'", str8.equals("MAJOR"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Paint paint15 = barRenderer0.getItemLabelPaint((int) (short) 0, (int) (byte) 1);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesStroke(2, stroke17, false);
        boolean boolean22 = barRenderer0.getItemCreateEntity(0, (int) (short) 0);
        java.awt.Paint paint25 = barRenderer0.getItemPaint(15, 1);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) (short) 100);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener3);
        try {
            java.lang.Comparable comparable6 = defaultStatisticalCategoryDataset0.getColumnKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        boolean boolean15 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color20 = java.awt.Color.darkGray;
        java.awt.Color color21 = java.awt.Color.getColor("hi!", color20);
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("", font18, (java.awt.Paint) color20);
        barRenderer0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color20);
        java.awt.Paint paint25 = barRenderer0.getSeriesPaint(255);
        java.awt.Stroke stroke27 = barRenderer0.getSeriesOutlineStroke(2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNull(stroke27);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getLabelPaint();
        numberAxis5.setAutoRangeStickyZero(false);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape22, (java.awt.Paint) color23);
        numberAxis5.setAxisLinePaint((java.awt.Paint) color23);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 100, (double) 10L, 0.2d, (double) (short) 100, (java.awt.Paint) color23);
        java.awt.Paint paint27 = blockBorder26.getPaint();
        try {
            java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Paint paint1 = textTitle0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getTickMarkPaint();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        try {
            numberAxis1.zoomRange((double) 10L, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getTickMarkPaint();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image11, "hi!", "ClassContext", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.awt.Image image17 = null;
        projectInfo7.setLogo(image17);
        org.jfree.chart.ui.Library[] libraryArray19 = projectInfo7.getOptionalLibraries();
        org.jfree.chart.axis.AxisState axisState21 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        axisState21.moveCursor(0.0d, rectangleEdge23);
        axisState21.cursorDown((double) 100L);
        java.util.List list27 = axisState21.getTicks();
        projectInfo7.setContributors(list27);
        org.junit.Assert.assertNotNull(libraryArray19);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color4 = java.awt.Color.WHITE;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis3.isVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3.valueToJava2D((double) (byte) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis3.getLabelPaint();
        java.awt.Paint paint12 = numberAxis3.getTickMarkPaint();
        keyedObjects0.addObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) numberAxis3);
        boolean boolean14 = numberAxis3.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.lang.String str12 = legendTitle10.getID();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        java.lang.String str19 = textTitle17.getText();
        java.lang.Object obj20 = textTitle17.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo21);
        double double23 = categoryItemRendererState22.getSeriesRunningTotal();
        boolean boolean24 = textTitle17.equals((java.lang.Object) categoryItemRendererState22);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getSeriesIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem8.getFillPaintTransformer();
        org.jfree.data.general.Dataset dataset11 = legendItem8.getDataset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = barRenderer12.getBaseShape();
        barRenderer12.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj18 = defaultDrawingSupplier17.clone();
        java.awt.Stroke stroke19 = defaultDrawingSupplier17.getNextStroke();
        barRenderer12.setSeriesStroke((int) 'a', stroke19);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = barRenderer12.getSeriesItemLabelGenerator((int) '4');
        java.awt.Color color23 = java.awt.Color.yellow;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color23);
        java.awt.Paint paint26 = barRenderer12.lookupSeriesFillPaint(0);
        boolean boolean27 = legendItem8.equals((java.lang.Object) barRenderer12);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNull(dataset11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        double double2 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier0, jFreeChart1, (int) '#', 10);
        chartProgressEvent4.setPercent(10);
        chartProgressEvent4.setType((int) '4');
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(15);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        barRenderer0.setSeriesOutlineStroke(500, stroke4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double4 = range3.getCentralValue();
        boolean boolean7 = range3.intersects((double) (byte) 100, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range3);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = rectangleConstraint8.getHeightConstraintType();
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double12 = range11.getCentralValue();
        boolean boolean15 = range11.intersects((double) (byte) 100, 100.0d);
        double double17 = range11.constrain((double) (short) 1);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range11, range18);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(10.0d, range1, lengthConstraintType9, 4.0d, range11, lengthConstraintType20);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5d + "'", double12 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(lengthConstraintType20);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = barRenderer0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        try {
            barRenderer0.setPlot(categoryPlot12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(drawingSupplier11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getSeriesIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem8.getFillPaintTransformer();
        org.jfree.data.general.Dataset dataset11 = legendItem8.getDataset();
        java.lang.String str12 = legendItem8.getLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNull(dataset11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        boolean boolean15 = datasetGroup4.equals((java.lang.Object) numberAxis6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis6.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color19 = java.awt.Color.WHITE;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = numberAxis18.isVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis18.valueToJava2D((double) (byte) 10, rectangle2D23, rectangleEdge24);
        java.awt.Paint paint26 = numberAxis18.getLabelPaint();
        numberAxis18.setAutoRangeStickyZero(false);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape35, (java.awt.Paint) color36);
        numberAxis18.setAxisLinePaint((java.awt.Paint) color36);
        numberAxis18.setPositiveArrowVisible(true);
        int int41 = numberTickUnit16.compareTo((java.lang.Object) numberAxis18);
        int int42 = keyedObjects0.getIndex((java.lang.Comparable) int41);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getUpperMargin();
        numberAxis44.setVerticalTickLabels(true);
        org.jfree.data.general.DatasetGroup datasetGroup48 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color51 = java.awt.Color.WHITE;
        numberAxis50.setTickLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis50.isVisible();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = numberAxis50.valueToJava2D((double) (byte) 10, rectangle2D55, rectangleEdge56);
        java.awt.Paint paint58 = numberAxis50.getTickMarkPaint();
        boolean boolean59 = datasetGroup48.equals((java.lang.Object) numberAxis50);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = numberAxis50.getTickUnit();
        java.lang.String str61 = numberTickUnit60.toString();
        double double62 = numberTickUnit60.getSize();
        java.lang.String str63 = numberTickUnit60.toString();
        org.jfree.chart.text.TextBlock textBlock64 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine65 = null;
        textBlock64.addLine(textLine65);
        org.jfree.chart.text.TextBlock textBlock67 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.util.Size2D size2D69 = textBlock67.calculateDimensions(graphics2D68);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment70 = textBlock67.getLineAlignment();
        textBlock64.setLineAlignment(horizontalAlignment70);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor73 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition74 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor72, textBlockAnchor73);
        org.jfree.chart.text.TextAnchor textAnchor75 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick77 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) numberTickUnit60, textBlock64, textBlockAnchor73, textAnchor75, (double) 10.0f);
        numberAxis44.setTickUnit(numberTickUnit60, false, false);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(numberTickUnit60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "[size=1]" + "'", str61.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "[size=1]" + "'", str63.equals("[size=1]"));
        org.junit.Assert.assertNotNull(size2D69);
        org.junit.Assert.assertNotNull(horizontalAlignment70);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(textBlockAnchor73);
        org.junit.Assert.assertNotNull(textAnchor75);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(0.0d, rectangleEdge3);
        axisState1.cursorDown((double) 100L);
        axisState1.cursorRight((double) (byte) 10);
        axisState1.setMax(0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        java.awt.Paint paint10 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 100, paint10);
        barRenderer0.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator16);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier0, jFreeChart1, (int) '#', 10);
        chartProgressEvent4.setPercent(10);
        chartProgressEvent4.setPercent((int) (short) 10);
        int int9 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock1, textBlockAnchor2, textAnchor3, (double) (-1L));
        double double6 = categoryTick5.getAngle();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) -1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        double double10 = numberAxis1.getLowerBound();
        numberAxis1.setAutoRange(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getSeriesIndex();
        java.lang.String str10 = legendItem8.getLabel();
        java.awt.Stroke stroke11 = legendItem8.getLineStroke();
        java.lang.String str12 = legendItem8.getToolTipText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100.0f);
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getCentralValue();
        boolean boolean8 = range4.intersects((double) (byte) 100, 100.0d);
        double double10 = range4.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range3, range4);
        double double13 = range4.constrain((double) 2);
        org.jfree.data.Range range14 = org.jfree.data.Range.combine(range0, range4);
        org.jfree.data.Range range17 = org.jfree.data.Range.expand(range4, (double) 35, 0.2d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ClassContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ClassContext, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 10.0d);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 1);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape5 = barRenderer4.getBaseShape();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean12 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape11);
        barRenderer4.setBaseShape(shape8);
        java.awt.Color color14 = java.awt.Color.orange;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj16 = defaultDrawingSupplier15.clone();
        java.awt.Stroke stroke17 = defaultDrawingSupplier15.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint21 = categoryAxis19.getTickLabelPaint((java.lang.Comparable) "poly");
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "VerticalAlignment.CENTER", "RangeType.FULL", shape8, (java.awt.Paint) color14, stroke17, paint21);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape8);
        java.lang.String str24 = chartEntity23.getShapeType();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "poly" + "'", str24.equals("poly"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Object obj2 = defaultStatisticalCategoryDataset0.clone();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultStatisticalCategoryDataset0.getGroup();
        try {
            java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue(3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(datasetGroup4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) (short) 100);
        defaultStatisticalCategoryDataset0.validateObject();
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) "CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier2, jFreeChart3, (int) '#', 10);
        java.awt.Stroke stroke7 = defaultDrawingSupplier2.getNextStroke();
        barRenderer0.setBaseStroke(stroke7);
        java.awt.Stroke stroke10 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = barRenderer12.getItemPaint((int) (short) 10, 0);
        java.awt.Font font29 = barRenderer12.getBaseItemLabelFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer12.getNegativeItemLabelPosition((int) (byte) 1, (int) (byte) 0);
        barRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition32);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        java.awt.Stroke stroke16 = barRenderer0.getSeriesOutlineStroke((int) (byte) -1);
        boolean boolean19 = barRenderer0.getItemVisible(1, (int) '4');
        double double20 = barRenderer0.getUpperClip();
        double double21 = barRenderer0.getLowerClip();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Font font4 = numberAxis1.getLabelFont();
        numberAxis1.setTickLabelsVisible(true);
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        boolean boolean8 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot9 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape11 = barRenderer10.getBaseShape();
        barRenderer10.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = barRenderer10.getLegendItems();
        boolean boolean15 = legendItem8.equals((java.lang.Object) barRenderer10);
        java.awt.Paint paint16 = legendItem8.getLinePaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAnchor0.equals(obj2);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.START" + "'", str1.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        java.awt.Font font17 = barRenderer0.getBaseItemLabelFont();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double22 = labelBlock21.getWidth();
        java.lang.Object obj23 = labelBlock21.clone();
        java.awt.Font font24 = labelBlock21.getFont();
        labelBlock21.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock21.getBounds();
        try {
            barRenderer0.drawOutline(graphics2D18, categoryPlot19, rectangle2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangle2D30);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = barRenderer0.getDrawingSupplier();
        org.jfree.chart.LegendItem legendItem14 = barRenderer0.getLegendItem(35, 175);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(drawingSupplier11);
        org.junit.Assert.assertNull(legendItem14);
    }
}

