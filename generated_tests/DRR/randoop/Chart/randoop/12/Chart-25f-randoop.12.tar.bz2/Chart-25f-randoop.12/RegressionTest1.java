import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=255,g=200,b=0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) (short) 100);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener3);
        try {
            java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue(8, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Shape shape12 = numberAxis1.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis1.getStandardTickUnits();
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, 1.0d, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        java.awt.Stroke stroke16 = barRenderer0.getSeriesOutlineStroke((int) (byte) -1);
        boolean boolean19 = barRenderer0.getItemVisible(1, (int) '4');
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer0.setSeriesPaint(2, (java.awt.Paint) color21, false);
        java.awt.Paint paint25 = barRenderer0.lookupSeriesPaint((int) '4');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = barRenderer0.getSeriesToolTipGenerator((int) '4');
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryToolTipGenerator27);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        int int6 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) int4);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis6.setLowerMargin(0.0d);
        boolean boolean9 = legendItemCollection4.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer12.setSeriesOutlinePaint((int) '4', paint27);
        barRenderer0.setBaseFillPaint(paint27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        barRenderer0.setBasePaint((java.awt.Paint) color30);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNull(itemLabelPosition33);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis3);
        boolean boolean5 = textBlock0.equals((java.lang.Object) categoryAxis3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) blockContainer1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.lang.String str12 = legendTitle10.getID();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str14 = rectangleAnchor13.toString();
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color21 = java.awt.Color.WHITE;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis20.isVisible();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis20.valueToJava2D((double) (byte) 10, rectangle2D25, rectangleEdge26);
        java.awt.Paint paint28 = numberAxis20.getTickMarkPaint();
        java.awt.Font font29 = numberAxis20.getLabelFont();
        numberAxis17.setLabelFont(font29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis17.getLabelInsets();
        legendTitle10.setLegendItemGraphicPadding(rectangleInsets31);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleAnchor.CENTER" + "'", str14.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color21 = java.awt.Color.WHITE;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis20.isVisible();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis20.valueToJava2D((double) (byte) 10, rectangle2D25, rectangleEdge26);
        java.awt.Paint paint28 = numberAxis20.getLabelPaint();
        numberAxis20.setAutoRangeStickyZero(false);
        boolean boolean31 = numberAxis20.isInverted();
        double double32 = numberAxis20.getUpperBound();
        boolean boolean33 = categoryItemEntity18.equals((java.lang.Object) numberAxis20);
        java.lang.String str34 = categoryItemEntity18.getURLText();
        org.jfree.data.general.DatasetGroup datasetGroup35 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color38 = java.awt.Color.WHITE;
        numberAxis37.setTickLabelPaint((java.awt.Paint) color38);
        boolean boolean40 = numberAxis37.isVisible();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = numberAxis37.valueToJava2D((double) (byte) 10, rectangle2D42, rectangleEdge43);
        java.awt.Paint paint45 = numberAxis37.getTickMarkPaint();
        boolean boolean46 = datasetGroup35.equals((java.lang.Object) numberAxis37);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit47 = numberAxis37.getTickUnit();
        java.lang.String str48 = numberTickUnit47.toString();
        double double49 = numberTickUnit47.getSize();
        java.lang.String str50 = numberTickUnit47.toString();
        org.jfree.chart.text.TextBlock textBlock51 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine52 = null;
        textBlock51.addLine(textLine52);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = textBlock54.calculateDimensions(graphics2D55);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment57 = textBlock54.getLineAlignment();
        textBlock51.setLineAlignment(horizontalAlignment57);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor60 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition61 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor59, textBlockAnchor60);
        org.jfree.chart.text.TextAnchor textAnchor62 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick64 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) numberTickUnit47, textBlock51, textBlockAnchor60, textAnchor62, (double) 10.0f);
        categoryItemEntity18.setColumnKey((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RangeType.NEGATIVE" + "'", str34.equals("RangeType.NEGATIVE"));
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(numberTickUnit47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "[size=1]" + "'", str48.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "[size=1]" + "'", str50.equals("[size=1]"));
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(horizontalAlignment57);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(textBlockAnchor60);
        org.junit.Assert.assertNotNull(textAnchor62);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.configure();
        java.awt.Color color10 = java.awt.Color.PINK;
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color10);
        java.awt.Font font12 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("");
        try {
            java.lang.Object obj5 = jFreeChartResources0.getObject("SortOrder.DESCENDING");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key SortOrder.DESCENDING");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.START" + "'", str1.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.START" + "'", str2.equals("CategoryAnchor.START"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.Object obj2 = textTitle1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle1.draw(graphics2D3, rectangle2D4);
        boolean boolean6 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle8.getVerticalAlignment();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        boolean boolean11 = verticalAlignment9.equals((java.lang.Object) categoryLabelPositions10);
        textTitle1.setVerticalAlignment(verticalAlignment9);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint(2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, false);
        int int13 = defaultStatisticalCategoryDataset9.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener14 = null;
        defaultStatisticalCategoryDataset9.addChangeListener(datasetChangeListener14);
        try {
            java.lang.String str17 = standardCategorySeriesLabelGenerator7.generateLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, 175);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 175, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        categoryItemEntity18.setColumnKey((java.lang.Comparable) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryItemEntity18.getDataset();
        java.lang.Object obj22 = categoryItemEntity18.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("ThreadContext", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("CategoryLabelEntity: category=null, tooltip=hi!, url=ThreadContext", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(0.0d, rectangleEdge3);
        axisState1.cursorDown((double) 100L);
        axisState1.cursorRight((double) (byte) 10);
        axisState1.setCursor((double) 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.axis.TickType tickType3 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape12, (java.awt.Paint) color13);
        barRenderer4.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color13, false);
        boolean boolean17 = barRenderer4.getAutoPopulateSeriesShape();
        java.awt.Paint paint19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer4.setSeriesOutlinePaint((int) '4', paint19);
        java.awt.Paint paint21 = barRenderer4.getBaseOutlinePaint();
        boolean boolean22 = tickType3.equals((java.lang.Object) paint21);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick28 = new org.jfree.chart.axis.NumberTick(tickType3, 0.0d, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", textAnchor25, textAnchor26, Double.NaN);
        try {
            org.jfree.chart.axis.NumberTick numberTick30 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0f, "java.awt.Color[r=255,g=200,b=0]", textAnchor2, textAnchor25, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickType3);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getTickMarkPaint();
        numberAxis1.setVisible(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = barRenderer12.getItemPaint((int) (short) 10, 0);
        numberAxis1.setTickMarkPaint(paint28);
        java.awt.Paint paint30 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.lang.Object obj3 = labelBlock1.clone();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, 0.0d, (double) (byte) 0, (double) 100L);
        labelBlock1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getCentralValue();
        boolean boolean16 = range12.intersects((double) (byte) 100, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range12);
        try {
            org.jfree.chart.util.Size2D size2D18 = labelBlock1.arrange(graphics2D10, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        numberAxis1.setDownArrow(shape17);
        numberAxis1.zoomRange((double) 1.0f, (double) 1);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("NOID", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("[size=1]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        java.awt.Font font20 = barRenderer0.getSeriesItemLabelFont(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = null;
        barRenderer0.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(font20);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image15, "hi!", "ClassContext", "hi!");
        java.lang.String str20 = projectInfo19.getLicenceName();
        projectInfo19.setLicenceText("hi!");
        java.awt.Image image23 = projectInfo19.getLogo();
        projectInfo19.setInfo("ClassContext");
        projectInfo19.setVersion("RangeType.NEGATIVE");
        java.awt.Image image31 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo35 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image31, "hi!", "ClassContext", "hi!");
        java.lang.String str36 = projectInfo35.getLicenceName();
        projectInfo35.setLicenceText("hi!");
        java.awt.Image image39 = projectInfo35.getLogo();
        projectInfo35.setInfo("ClassContext");
        projectInfo35.setVersion("RangeType.NEGATIVE");
        projectInfo19.addLibrary((org.jfree.chart.ui.Library) projectInfo35);
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo35);
        projectInfo7.setName("TextAnchor.BASELINE_RIGHT");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ClassContext" + "'", str20.equals("ClassContext"));
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ClassContext" + "'", str36.equals("ClassContext"));
        org.junit.Assert.assertNull(image39);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Object obj2 = defaultStatisticalCategoryDataset0.clone();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultStatisticalCategoryDataset0.getGroup();
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis0);
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        java.awt.Font font17 = barRenderer0.getBaseItemLabelFont();
        double double18 = barRenderer0.getLowerClip();
        java.awt.Paint paint21 = barRenderer0.getItemFillPaint(10, (-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer0.getURLGenerator((int) (byte) 100, 175);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        boolean boolean23 = barRenderer0.removeAnnotation(categoryAnnotation22);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getUpperBound();
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range12, (double) 1L);
        numberAxis2.setRange(range15, true, false);
        double double19 = numberAxis2.getUpperMargin();
        numberAxis2.setLabel("");
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (byte) -1, (java.lang.Number) 0.5d);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.5d + "'", number3.equals(0.5d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean14 = numberAxis1.equals((java.lang.Object) "hi!");
        java.text.NumberFormat numberFormat15 = null;
        numberAxis1.setNumberFormatOverride(numberFormat15);
        numberAxis1.setLabelToolTip("ItemLabelAnchor.INSIDE2");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape8);
        barRenderer1.setBaseShape(shape5);
        java.awt.Stroke stroke12 = barRenderer1.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        boolean boolean26 = barRenderer13.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer13.setSeriesOutlinePaint((int) '4', paint28);
        barRenderer1.setBaseFillPaint(paint28);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint28);
        java.awt.Color color36 = java.awt.Color.black;
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 10.0f, 1.0d, 0.2d, 1.0d, (java.awt.Paint) color36);
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getCentralValue();
        boolean boolean4 = range0.intersects((double) (byte) 100, 100.0d);
        double double6 = range0.constrain((double) (short) 1);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range0, 1.0E-8d);
        org.jfree.data.Range range11 = rectangleConstraint10.getHeightRange();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition2.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = categoryLabelPosition2.getCategoryAnchor();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) rectangleAnchor4, jFreeChart5, 2, (int) (short) -1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("SortOrder.DESCENDING", graphics2D1, (double) 10.0f, (float) (byte) -1, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        java.awt.Paint paint17 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer0.getNegativeItemLabelPosition((int) '4', (int) ' ');
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.configure();
        float float10 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        double double5 = itemLabelPosition4.getAngle();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.lang.Class class2 = null;
        try {
            java.util.EventListener[] eventListenerArray3 = valueMarker1.getListeners(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Font font4 = numberAxis1.getLabelFont();
        numberAxis1.setTickLabelsVisible(true);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.valueToJava2D((double) 10L, rectangle2D8, rectangleEdge9);
        numberAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle6.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle6.getPosition();
        textTitle4.setPosition(rectangleEdge8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle4.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement13 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment10, 100.0d, 1.0d);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        boolean boolean16 = labelBlock1.equals((java.lang.Object) "ClassContext");
        java.awt.Graphics2D graphics2D17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = labelBlock1.arrange(graphics2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "RangeType.FULL");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double double10 = range1.constrain((double) 2);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range1, (double) (byte) 100);
        java.lang.String str13 = range1.toString();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,1.0]" + "'", str13.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.setUpperMargin((double) (short) 0);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double10 = labelBlock9.getWidth();
        java.lang.Object obj11 = labelBlock9.clone();
        java.awt.Font font12 = labelBlock9.getFont();
        labelBlock9.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D18 = labelBlock9.getBounds();
        org.jfree.chart.util.UnitType unitType19 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock25 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = textBlock25.calculateDimensions(graphics2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str31 = rectangleAnchor30.toString();
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, Double.NaN, 0.0d, rectangleAnchor30);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets24.createOutsetRectangle(rectangle2D32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            org.jfree.chart.axis.AxisState axisState36 = categoryAxis1.draw(graphics2D6, 8.0d, rectangle2D18, rectangle2D32, rectangleEdge34, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleAnchor.CENTER" + "'", str31.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        java.lang.Comparable comparable2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity(comparable2, shape5, "hi!", "ThreadContext");
        boolean boolean9 = categoryLabelPositions1.equals((java.lang.Object) "hi!");
        boolean boolean10 = lineBorder0.equals((java.lang.Object) categoryLabelPositions1);
        java.awt.Stroke stroke11 = lineBorder0.getStroke();
        java.awt.Image image15 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo19 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image15, "hi!", "ClassContext", "hi!");
        java.awt.Image image23 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo27 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image23, "hi!", "ClassContext", "hi!");
        projectInfo19.addLibrary((org.jfree.chart.ui.Library) projectInfo27);
        java.awt.Image image29 = null;
        projectInfo19.setLogo(image29);
        org.jfree.chart.ui.Library[] libraryArray31 = projectInfo19.getOptionalLibraries();
        boolean boolean32 = lineBorder0.equals((java.lang.Object) libraryArray31);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(libraryArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.centerRange((double) 2);
        numberAxis1.setRangeAboutValue((double) (byte) 1, (double) 8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberTickUnit12.toString();
        double double14 = numberTickUnit12.getSize();
        java.lang.String str15 = numberTickUnit12.toString();
        org.jfree.chart.text.TextBlock textBlock16 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine17 = null;
        textBlock16.addLine(textLine17);
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock19.calculateDimensions(graphics2D20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textBlock19.getLineAlignment();
        textBlock16.setLineAlignment(horizontalAlignment22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor24, textBlockAnchor25);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick29 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) numberTickUnit12, textBlock16, textBlockAnchor25, textAnchor27, (double) 10.0f);
        java.awt.Font font32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE5", font32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color36 = java.awt.Color.WHITE;
        numberAxis35.setTickLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = numberAxis35.isVisible();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis35.valueToJava2D((double) (byte) 10, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getLabelPaint();
        java.awt.Paint paint44 = numberAxis35.getTickMarkPaint();
        textBlock16.addLine("RectangleAnchor.CENTER", font32, paint44);
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine();
        textBlock16.addLine(textLine46);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[size=1]" + "'", str13.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[size=1]" + "'", str15.equals("[size=1]"));
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) ' ', shape3, "", "TextAnchor.BASELINE_RIGHT");
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, (double) (short) 0, (double) 1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor10, textBlockAnchor11);
        org.jfree.chart.text.TextAnchor textAnchor13 = categoryLabelPosition12.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryLabelPosition12.getCategoryAnchor();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor14, (double) 100.0f, 0.2d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RangeType.NEGATIVE", "", "ThreadContext", "hi!", "");
        basicProjectInfo5.setLicenceName("ItemLabelAnchor.INSIDE2");
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        java.lang.String str9 = legendItem8.getLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Font font4 = numberAxis1.getLabelFont();
        numberAxis1.setTickLabelsVisible(true);
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        float float8 = numberAxis1.getTickMarkOutsideLength();
        numberAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        java.awt.Stroke stroke2 = lineBorder0.getStroke();
        java.awt.Paint paint3 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        java.util.List list3 = keyedObjects0.getKeys();
        try {
            keyedObjects0.removeValue(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getTickMarkPaint();
        java.awt.Font font14 = numberAxis5.getLabelFont();
        numberAxis2.setLabelFont(font14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color18 = java.awt.Color.WHITE;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis17.isVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis17.valueToJava2D((double) (byte) 10, rectangle2D22, rectangleEdge23);
        java.awt.Paint paint25 = numberAxis17.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("EXPAND", font14, paint25);
        org.jfree.chart.text.TextFragment textFragment27 = textLine26.getLastTextFragment();
        java.lang.String str28 = textFragment27.getText();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textFragment27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "EXPAND" + "'", str28.equals("EXPAND"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 1.0f, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = barRenderer0.getSeriesToolTipGenerator(100);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis1.setTickMarkStroke(stroke3);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color4 = java.awt.Color.WHITE;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis3.isVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3.valueToJava2D((double) (byte) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis3.getLabelPaint();
        java.awt.Paint paint12 = numberAxis3.getTickMarkPaint();
        keyedObjects0.addObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) numberAxis3);
        numberAxis3.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean(0, (java.lang.Boolean) true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean12 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.data.RangeType rangeType13 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis1.setMarkerBand(markerAxisBand14);
        double double16 = numberAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer0.getPositiveItemLabelPosition(2, (-1));
        java.awt.Font font26 = null;
        barRenderer0.setSeriesItemLabelFont((int) '#', font26, true);
        java.awt.Stroke stroke30 = null;
        barRenderer0.setSeriesStroke((int) (byte) 0, stroke30);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        try {
            textTitle1.setVerticalAlignment(verticalAlignment2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        barRenderer1.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj7 = defaultDrawingSupplier6.clone();
        java.awt.Stroke stroke8 = defaultDrawingSupplier6.getNextStroke();
        barRenderer1.setSeriesStroke((int) 'a', stroke8);
        boolean boolean10 = barRenderer1.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer1);
        java.awt.Font font12 = legendTitle11.getItemFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        java.awt.Paint paint28 = barRenderer13.getItemLabelPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.text.TextBlock textBlock29 = org.jfree.chart.text.TextUtilities.createTextBlock("35", font12, paint28);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(textBlock29);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        projectInfo7.setInfo("ClassContext");
        projectInfo7.setVersion("RangeType.NEGATIVE");
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image19, "hi!", "ClassContext", "hi!");
        java.lang.String str24 = projectInfo23.getLicenceName();
        projectInfo23.setLicenceText("hi!");
        java.awt.Image image27 = projectInfo23.getLogo();
        projectInfo23.setInfo("ClassContext");
        projectInfo23.setVersion("RangeType.NEGATIVE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo23);
        org.jfree.data.general.DatasetGroup datasetGroup33 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color36 = java.awt.Color.WHITE;
        numberAxis35.setTickLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = numberAxis35.isVisible();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis35.valueToJava2D((double) (byte) 10, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickMarkPaint();
        boolean boolean44 = datasetGroup33.equals((java.lang.Object) numberAxis35);
        org.jfree.data.Range range45 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double46 = range45.getUpperBound();
        org.jfree.data.Range range48 = org.jfree.data.Range.shift(range45, (double) 1L);
        numberAxis35.setRange(range48, true, false);
        java.lang.String str52 = range48.toString();
        boolean boolean53 = projectInfo7.equals((java.lang.Object) range48);
        double double54 = range48.getLength();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ClassContext" + "'", str24.equals("ClassContext"));
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Range[1.0,2.0]" + "'", str52.equals("Range[1.0,2.0]"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        boolean boolean2 = sortOrder0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer12.setSeriesOutlinePaint((int) '4', paint27);
        barRenderer0.setBaseFillPaint(paint27);
        boolean boolean30 = barRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint35 = categoryAxis33.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis33.setUpperMargin((double) (short) 0);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color42 = java.awt.Color.WHITE;
        numberAxis41.setTickLabelPaint((java.awt.Paint) color42);
        boolean boolean44 = numberAxis41.isVisible();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis41.valueToJava2D((double) (byte) 10, rectangle2D46, rectangleEdge47);
        java.awt.Shape shape49 = numberAxis41.getLeftArrow();
        boolean boolean50 = numberAxis41.isNegativeArrowVisible();
        numberAxis41.resizeRange(0.0d, (double) 8);
        org.jfree.chart.util.UnitType unitType55 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets(unitType55, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock61 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.util.Size2D size2D63 = textBlock61.calculateDimensions(graphics2D62);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str67 = rectangleAnchor66.toString();
        java.awt.geom.Rectangle2D rectangle2D68 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D63, Double.NaN, 0.0d, rectangleAnchor66);
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets60.createOutsetRectangle(rectangle2D68);
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment72 = textTitle71.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = textTitle71.getPosition();
        double double74 = numberAxis41.lengthToJava2D((double) (byte) 1, rectangle2D69, rectangleEdge73);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.TOP;
        double double76 = categoryAxis33.getCategoryEnd(175, 255, rectangle2D69, rectangleEdge75);
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState80 = barRenderer0.initialise(graphics2D31, rectangle2D69, categoryPlot77, (int) (byte) 10, plotRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(unitType55);
        org.junit.Assert.assertNotNull(size2D63);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "RectangleAnchor.CENTER" + "'", str67.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(verticalAlignment72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertEquals((double) double74, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertEquals((double) double76, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getSeriesItemLabelGenerator((int) '4');
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getLabelPaint();
        numberAxis2.setAutoRangeStickyZero(false);
        java.awt.Shape shape13 = numberAxis2.getRightArrow();
        boolean boolean14 = numberAxis2.isVerticalTickLabels();
        double double15 = numberAxis2.getUpperMargin();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        axisState18.moveCursor(0.0d, rectangleEdge20);
        axisState18.setCursor((double) 35);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        java.util.List list26 = numberAxis2.refreshTicks(graphics2D16, axisState18, rectangle2D24, rectangleEdge25);
        projectInfo0.setContributors(list26);
        org.jfree.chart.ui.Library[] libraryArray28 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(libraryArray28);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlock textBlock4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick8 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock4, textBlockAnchor5, textAnchor6, (double) (-1L));
        try {
            float float9 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        java.awt.Font font17 = barRenderer0.getBaseItemLabelFont();
        double double18 = barRenderer0.getLowerClip();
        java.awt.Paint paint21 = barRenderer0.getItemFillPaint(10, (-1));
        barRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke25 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean7 = categoryAxis1.equals((java.lang.Object) numberAxis6);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        labelBlock1.setToolTipText("");
        labelBlock1.setID("");
        labelBlock1.setURLText("RangeType.FULL");
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        projectInfo7.setInfo("ClassContext");
        java.lang.String str14 = projectInfo7.toString();
        projectInfo7.setLicenceName("");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ClassContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!" + "'", str14.equals(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ClassContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE5", font2);
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(4.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        java.lang.String str19 = textTitle17.getText();
        java.lang.Object obj20 = textTitle17.clone();
        textTitle17.setText("");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer12.setSeriesOutlinePaint((int) '4', paint27);
        barRenderer0.setBaseFillPaint(paint27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        barRenderer0.setBasePaint((java.awt.Paint) color30);
        java.awt.Stroke stroke33 = barRenderer0.getSeriesOutlineStroke(0);
        double double34 = barRenderer0.getMaximumBarWidth();
        boolean boolean35 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, 1.0d);
        size2D2.height = (short) 1;
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("CategoryAnchor.MIDDLE", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Stroke stroke14 = barRenderer0.lookupSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = barRenderer0.getToolTipGenerator(100, 3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        java.awt.Paint[] paintArray6 = null;
        java.awt.Paint[] paintArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray10 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape12 = barRenderer11.getBaseShape();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier13, jFreeChart14, (int) '#', 10);
        java.awt.Stroke stroke18 = defaultDrawingSupplier13.getNextStroke();
        barRenderer11.setBaseStroke(stroke18);
        java.awt.Stroke stroke21 = barRenderer11.lookupSeriesOutlineStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape23 = barRenderer22.getBaseShape();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.equal(shape26, shape29);
        barRenderer22.setBaseShape(shape26);
        java.awt.Stroke stroke33 = barRenderer22.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape42, (java.awt.Paint) color43);
        barRenderer34.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color43, false);
        boolean boolean47 = barRenderer34.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape49 = barRenderer48.getBaseShape();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean56 = org.jfree.chart.util.ShapeUtilities.equal(shape52, shape55);
        barRenderer48.setBaseShape(shape52);
        java.awt.Stroke stroke59 = barRenderer48.lookupSeriesOutlineStroke(3);
        barRenderer34.setBaseStroke(stroke59);
        java.awt.Stroke[] strokeArray61 = new java.awt.Stroke[] { stroke21, stroke33, stroke59 };
        java.awt.Shape[] shapeArray62 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier63 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray9, strokeArray10, strokeArray61, shapeArray62);
        java.awt.Stroke[] strokeArray64 = null;
        java.awt.Shape[] shapeArray65 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier66 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray7, strokeArray10, strokeArray64, shapeArray65);
        boolean boolean67 = rectangleInsets5.equals((java.lang.Object) strokeArray64);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(strokeArray61);
        org.junit.Assert.assertNotNull(shapeArray62);
        org.junit.Assert.assertNotNull(shapeArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("EXPAND", font15, (java.awt.Paint) color16, rectangleEdge17, horizontalAlignment18, verticalAlignment21, rectangleInsets22);
        double double24 = rectangleInsets22.getTop();
        boolean boolean25 = plotOrientation3.equals((java.lang.Object) rectangleInsets22);
        categoryPlot0.setOrientation(plotOrientation3);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color30 = java.awt.Color.WHITE;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis29.isVisible();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = numberAxis29.valueToJava2D((double) (byte) 10, rectangle2D34, rectangleEdge35);
        java.awt.Shape shape37 = numberAxis29.getLeftArrow();
        boolean boolean38 = numberAxis29.isNegativeArrowVisible();
        numberAxis29.resizeRange(0.0d, (double) 8);
        org.jfree.chart.util.UnitType unitType43 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets(unitType43, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock49 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.util.Size2D size2D51 = textBlock49.calculateDimensions(graphics2D50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str55 = rectangleAnchor54.toString();
        java.awt.geom.Rectangle2D rectangle2D56 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D51, Double.NaN, 0.0d, rectangleAnchor54);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets48.createOutsetRectangle(rectangle2D56);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = textTitle59.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = textTitle59.getPosition();
        double double62 = numberAxis29.lengthToJava2D((double) (byte) 1, rectangle2D57, rectangleEdge61);
        try {
            categoryPlot0.drawOutline(graphics2D27, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(unitType43);
        org.junit.Assert.assertNotNull(size2D51);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RectangleAnchor.CENTER" + "'", str55.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(verticalAlignment60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertEquals((double) double62, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 35);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Shape shape14 = numberAxis6.getLeftArrow();
        boolean boolean15 = numberAxis6.isNegativeArrowVisible();
        double double16 = numberAxis6.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        java.lang.Number number18 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) "MAJOR", (java.lang.Comparable) numberTickUnit17);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.2d, 0.2d);
        double double3 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getCentralValue();
        boolean boolean5 = range1.intersects((double) (byte) 100, 100.0d);
        double double7 = range1.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range9 = rectangleConstraint8.getWidthRange();
        org.jfree.data.Range range10 = rectangleConstraint8.getWidthRange();
        org.jfree.data.Range range11 = rectangleConstraint8.getWidthRange();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 2.0f);
        categoryAxis0.setVisible(true);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        boolean boolean26 = barRenderer13.getAutoPopulateSeriesShape();
        barRenderer13.removeAnnotations();
        boolean boolean28 = barRenderer13.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer13.getBasePositiveItemLabelPosition();
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition29);
        java.awt.Paint paint32 = barRenderer0.getSeriesItemLabelPaint((-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = barRenderer0.getSeriesURLGenerator((int) ' ');
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNull(categoryURLGenerator34);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.configure();
        numberAxis1.setFixedDimension(8.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        org.jfree.data.general.Dataset dataset10 = legendItemEntity7.getDataset();
        java.lang.String str11 = legendItemEntity7.getShapeType();
        java.lang.String str12 = legendItemEntity7.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str12.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(4.0d, (double) 100, (double) (byte) 0, (double) (byte) 1, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(0.0d, rectangleEdge3);
        axisState1.cursorDown((double) 100L);
        axisState1.cursorUp(0.5d);
        org.jfree.chart.axis.AxisCollection axisCollection9 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list10 = axisCollection9.getAxesAtTop();
        java.util.List list11 = axisCollection9.getAxesAtBottom();
        java.util.List list12 = axisCollection9.getAxesAtLeft();
        axisState1.setTicks(list12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = rectangleEdge15.equals((java.lang.Object) axisLocation16);
        axisState1.moveCursor((double) (byte) -1, rectangleEdge15);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        java.awt.Font font4 = numberAxis1.getLabelFont();
        numberAxis1.setTickLabelsVisible(true);
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        boolean boolean8 = numberAxis1.isNegativeArrowVisible();
        org.jfree.data.Range range9 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setLabelAngle((double) (byte) 1);
        double double6 = numberAxis1.getLabelAngle();
        boolean boolean7 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier4, jFreeChart5, (int) '#', 10);
        java.awt.Paint paint9 = defaultDrawingSupplier4.getNextOutlinePaint();
        textTitle1.setBackgroundPaint(paint9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle1.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getTickMarkPaint();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        try {
            numberAxis1.zoomRange((double) '4', 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (1.0E-8).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer0.getType();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot1.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color8 = java.awt.Color.WHITE;
        numberAxis7.setTickLabelPaint((java.awt.Paint) color8);
        boolean boolean10 = numberAxis7.isVisible();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis7.valueToJava2D((double) (byte) 10, rectangle2D12, rectangleEdge13);
        java.awt.Paint paint15 = numberAxis7.getTickMarkPaint();
        java.awt.Font font16 = numberAxis7.getLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle21.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("EXPAND", font16, (java.awt.Paint) color17, rectangleEdge18, horizontalAlignment19, verticalAlignment22, rectangleInsets23);
        double double25 = rectangleInsets23.getTop();
        boolean boolean26 = plotOrientation4.equals((java.lang.Object) rectangleInsets23);
        categoryPlot1.setOrientation(plotOrientation4);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        numberAxis1.setLabelToolTip("35");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        barRenderer1.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj7 = defaultDrawingSupplier6.clone();
        java.awt.Stroke stroke8 = defaultDrawingSupplier6.getNextStroke();
        barRenderer1.setSeriesStroke((int) 'a', stroke8);
        boolean boolean10 = barRenderer1.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer1);
        java.awt.Font font12 = legendTitle11.getItemFont();
        java.lang.String str13 = legendTitle11.getID();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str15 = rectangleAnchor14.toString();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor14);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) textBlockAnchor18);
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double21 = range20.getUpperBound();
        org.jfree.data.Range range23 = org.jfree.data.Range.shift(range20, (double) 1L);
        boolean boolean24 = textBlockAnchor17.equals((java.lang.Object) 1L);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor14, textBlockAnchor17);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int29 = defaultStatisticalCategoryDataset27.getColumnIndex((java.lang.Comparable) (short) 100);
        boolean boolean30 = categoryLabelPositions0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleAnchor.CENTER" + "'", str15.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.setLabelToolTip("ClassContext");
        boolean boolean6 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = categoryLabelPosition3.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = categoryLabelPosition3.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = categoryLabelPosition3.getWidthType();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("EXPAND", font15, (java.awt.Paint) color16, rectangleEdge17, horizontalAlignment18, verticalAlignment21, rectangleInsets22);
        double double24 = rectangleInsets22.getTop();
        boolean boolean25 = plotOrientation3.equals((java.lang.Object) rectangleInsets22);
        categoryPlot0.setOrientation(plotOrientation3);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot0.getRowRenderingOrder();
        try {
            categoryPlot0.mapDatasetToRangeAxis((int) (short) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(sortOrder27);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer0.getURLGenerator((int) (byte) 100, 175);
        barRenderer0.setMaximumBarWidth((double) 0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryURLGenerator21);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        boolean boolean9 = legendItem8.isLineVisible();
        boolean boolean10 = legendItem8.isShapeVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("EXPAND", font11, (java.awt.Paint) color12, rectangleEdge13, horizontalAlignment14, verticalAlignment17, rectangleInsets18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape22 = barRenderer21.getBaseShape();
        barRenderer21.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj27 = defaultDrawingSupplier26.clone();
        java.awt.Stroke stroke28 = defaultDrawingSupplier26.getNextStroke();
        barRenderer21.setSeriesStroke((int) 'a', stroke28);
        boolean boolean30 = barRenderer21.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer21);
        boolean boolean32 = rectangleEdge20.equals((java.lang.Object) legendTitle31);
        java.awt.Paint paint33 = legendTitle31.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(paint33);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Color color18 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color18);
        barRenderer0.setSeriesPaint(1, (java.awt.Paint) color18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape26 = barRenderer25.getBaseShape();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.equal(shape29, shape32);
        barRenderer25.setBaseShape(shape29);
        java.awt.Color color35 = java.awt.Color.orange;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj37 = defaultDrawingSupplier36.clone();
        java.awt.Stroke stroke38 = defaultDrawingSupplier36.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint42 = categoryAxis40.getTickLabelPaint((java.lang.Comparable) "poly");
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "VerticalAlignment.CENTER", "RangeType.FULL", shape29, (java.awt.Paint) color35, stroke38, paint42);
        barRenderer0.setBaseOutlineStroke(stroke38);
        java.awt.Font font46 = barRenderer0.getSeriesItemLabelFont(3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(font46);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape9, (java.awt.Paint) color10);
        barRenderer1.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color10, false);
        boolean boolean14 = barRenderer1.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer1.setSeriesOutlinePaint((int) '4', paint16);
        java.awt.Paint paint18 = barRenderer1.getBaseOutlinePaint();
        boolean boolean19 = tickType0.equals((java.lang.Object) paint18);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", textAnchor22, textAnchor23, Double.NaN);
        org.jfree.chart.text.TextAnchor textAnchor26 = numberTick25.getRotationAnchor();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        categoryAxis1.setCategoryLabelPositionOffset(35);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint7 = categoryAxis5.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis5.setUpperMargin((double) (short) 0);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color14 = java.awt.Color.WHITE;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = numberAxis13.isVisible();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis13.valueToJava2D((double) (byte) 10, rectangle2D18, rectangleEdge19);
        java.awt.Shape shape21 = numberAxis13.getLeftArrow();
        boolean boolean22 = numberAxis13.isNegativeArrowVisible();
        numberAxis13.resizeRange(0.0d, (double) 8);
        org.jfree.chart.util.UnitType unitType27 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets(unitType27, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock33 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.Size2D size2D35 = textBlock33.calculateDimensions(graphics2D34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str39 = rectangleAnchor38.toString();
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, Double.NaN, 0.0d, rectangleAnchor38);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets32.createOutsetRectangle(rectangle2D40);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = textTitle43.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = textTitle43.getPosition();
        double double46 = numberAxis13.lengthToJava2D((double) (byte) 1, rectangle2D41, rectangleEdge45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.TOP;
        double double48 = categoryAxis5.getCategoryEnd(175, 255, rectangle2D41, rectangleEdge47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj51 = defaultDrawingSupplier50.clone();
        java.awt.Stroke stroke52 = defaultDrawingSupplier50.getNextStroke();
        java.awt.Stroke stroke53 = defaultDrawingSupplier50.getNextOutlineStroke();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem(attributedString0, "NOID", "{0}", "RectangleAnchor.CENTER", (java.awt.Shape) rectangle2D41, (java.awt.Paint) color49, stroke53, (java.awt.Paint) color54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(unitType27);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleAnchor.CENTER" + "'", str39.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getHorizontalAlignment();
        java.lang.Object obj4 = textTitle1.clone();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.lang.Object obj2 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        numberAxis3.setLabelFont(font15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color19 = java.awt.Color.WHITE;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = numberAxis18.isVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis18.valueToJava2D((double) (byte) 10, rectangle2D23, rectangleEdge24);
        java.awt.Paint paint26 = numberAxis18.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("EXPAND", font15, paint26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape29 = barRenderer28.getBaseShape();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean36 = org.jfree.chart.util.ShapeUtilities.equal(shape32, shape35);
        barRenderer28.setBaseShape(shape32);
        java.awt.Stroke stroke39 = barRenderer28.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape48, (java.awt.Paint) color49);
        barRenderer40.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color49, false);
        boolean boolean53 = barRenderer40.getAutoPopulateSeriesShape();
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer40.setSeriesOutlinePaint((int) '4', paint55);
        barRenderer28.setBaseFillPaint(paint55);
        org.jfree.chart.text.TextMeasurer textMeasurer59 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock60 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[0.0,1.0]", font15, paint55, (float) (byte) 1, textMeasurer59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot1.getRangeAxis(0);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot1.clearAnnotations();
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100.0f);
        boolean boolean5 = range0.intersects((double) 0, (double) (short) 0);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.data.general.Dataset dataset10 = legendItem8.getDataset();
        java.awt.Shape shape11 = legendItem8.getShape();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        barRenderer0.setSeriesToolTipGenerator(2, categoryToolTipGenerator24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color26, false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = axisChangeEvent1.getType();
        java.lang.Object obj3 = null;
        boolean boolean4 = chartChangeEventType2.equals(obj3);
        java.lang.String str5 = chartChangeEventType2.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultStatisticalCategoryDataset0.getGroup();
        java.util.List list2 = defaultStatisticalCategoryDataset0.getColumnKeys();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.axis.TickUnits tickUnits6 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color9 = java.awt.Color.WHITE;
        numberAxis8.setTickLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = numberAxis8.isVisible();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis8.valueToJava2D((double) (byte) 10, rectangle2D13, rectangleEdge14);
        java.awt.Shape shape16 = numberAxis8.getLeftArrow();
        boolean boolean17 = numberAxis8.isNegativeArrowVisible();
        double double18 = numberAxis8.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis8.getTickUnit();
        tickUnits6.add((org.jfree.chart.axis.TickUnit) numberTickUnit19);
        java.lang.String str22 = numberTickUnit19.valueToString((double) 0.95f);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 10.0f, (java.lang.Number) 116.0d, (java.lang.Comparable) str22, (java.lang.Comparable) '#');
        try {
            org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        java.lang.String str12 = projectInfo7.getVersion();
        projectInfo7.setName("Layer.FOREGROUND");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image11, "hi!", "ClassContext", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image20, "hi!", "ClassContext", "hi!");
        java.awt.Image image28 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo32 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image28, "hi!", "ClassContext", "hi!");
        projectInfo24.addLibrary((org.jfree.chart.ui.Library) projectInfo32);
        java.lang.String str34 = projectInfo32.getLicenceName();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo32);
        projectInfo7.addOptionalLibrary("35");
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ClassContext" + "'", str34.equals("ClassContext"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        java.awt.Stroke stroke5 = barRenderer0.getSeriesOutlineStroke((int) (short) 1);
        int int6 = barRenderer0.getPassCount();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1);
        org.jfree.chart.axis.AxisCollection axisCollection6 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list7 = axisCollection6.getAxesAtTop();
        keyedObjects0.setObject((java.lang.Comparable) numberTickUnit5, (java.lang.Object) list7);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition4);
        double double6 = categoryLabelPosition4.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemURLGenerator();
        boolean boolean15 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 1);
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot17.getRangeAxis(0);
        int int20 = categoryPlot17.getBackgroundImageAlignment();
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot17);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeAxes();
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        boolean boolean15 = datasetGroup4.equals((java.lang.Object) numberAxis6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis6.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color19 = java.awt.Color.WHITE;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = numberAxis18.isVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis18.valueToJava2D((double) (byte) 10, rectangle2D23, rectangleEdge24);
        java.awt.Paint paint26 = numberAxis18.getLabelPaint();
        numberAxis18.setAutoRangeStickyZero(false);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape35, (java.awt.Paint) color36);
        numberAxis18.setAxisLinePaint((java.awt.Paint) color36);
        numberAxis18.setPositiveArrowVisible(true);
        int int41 = numberTickUnit16.compareTo((java.lang.Object) numberAxis18);
        int int42 = keyedObjects0.getIndex((java.lang.Comparable) int41);
        java.lang.Object obj44 = keyedObjects0.getObject((java.lang.Comparable) 10);
        java.lang.Comparable comparable46 = keyedObjects0.getKey(15);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertNull(comparable46);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor2, textAnchor3, (-1.0d));
        java.lang.String str7 = numberTick6.toString();
        java.lang.String str8 = numberTick6.getText();
        double double9 = numberTick6.getValue();
        org.jfree.chart.text.TextBlock textBlock10 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock10.calculateDimensions(graphics2D11);
        size2D12.width = 0.5d;
        double double15 = size2D12.height;
        size2D12.setWidth((double) (byte) -1);
        boolean boolean19 = size2D12.equals((java.lang.Object) (short) 1);
        boolean boolean20 = numberTick6.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str4.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.CENTER" + "'", str7.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleAnchor.CENTER" + "'", str8.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.CENTER" + "'", str2.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        java.awt.Paint paint14 = barRenderer0.getItemPaint((int) '4', 2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = barRenderer0.getDrawingSupplier();
        java.awt.Stroke stroke18 = barRenderer0.getItemStroke((int) (short) 0, 8);
        java.awt.Stroke stroke19 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getCentralValue();
        boolean boolean16 = range12.intersects((double) (byte) 100, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range12);
        boolean boolean18 = projectInfo7.equals((java.lang.Object) range12);
        java.awt.Image image19 = projectInfo7.getLogo();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(image19);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        barRenderer0.setBase((double) 10.0f);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        boolean boolean3 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape9, (java.awt.Paint) color10);
        barRenderer1.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color10, false);
        boolean boolean14 = barRenderer1.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer1.setSeriesOutlinePaint((int) '4', paint16);
        java.awt.Paint paint18 = barRenderer1.getBaseOutlinePaint();
        boolean boolean19 = tickType0.equals((java.lang.Object) paint18);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick25 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", textAnchor22, textAnchor23, Double.NaN);
        java.lang.Number number26 = numberTick25.getNumber();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) paint0, jFreeChart1, (int) '#', (int) '#');
        int int5 = chartProgressEvent4.getType();
        int int6 = chartProgressEvent4.getPercent();
        int int7 = chartProgressEvent4.getType();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        barRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis1.getTickUnit();
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double15 = range14.getCentralValue();
        boolean boolean18 = range14.intersects((double) (byte) 100, 100.0d);
        double double20 = range14.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range14);
        double double23 = range14.constrain((double) 2);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range14, (double) (byte) 100);
        numberAxis1.setDefaultAutoRange(range14);
        double double27 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor2, textAnchor3, (-1.0d));
        org.jfree.chart.axis.TickType tickType7 = numberTick6.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick6.getRotationAnchor();
        double double9 = numberTick6.getValue();
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list11 = axisCollection10.getAxesAtTop();
        java.util.List list12 = axisCollection10.getAxesAtBottom();
        java.util.List list13 = axisCollection10.getAxesAtLeft();
        java.util.List list14 = axisCollection10.getAxesAtTop();
        boolean boolean15 = numberTick6.equals((java.lang.Object) axisCollection10);
        org.jfree.chart.text.TextAnchor textAnchor16 = numberTick6.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str4.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape3, "hi!", "ThreadContext");
        java.lang.Object obj7 = categoryLabelEntity6.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getRowCount();
        int int2 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 1, 0.5f, textAnchor4, (double) (-1L), 0.5f, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        textTitle1.setWidth((double) 15);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        java.awt.Color color12 = java.awt.Color.gray;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = numberAxis2.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        java.lang.Object obj4 = keyedObjects0.getObject(3);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        java.lang.String str12 = datasetGroup0.getID();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape19, (java.awt.Paint) color20);
        int int22 = legendItem21.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = legendItem21.getFillPaintTransformer();
        legendItem21.setDatasetIndex((-1));
        boolean boolean26 = datasetGroup0.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "NOID" + "'", str12.equals("NOID"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier1, jFreeChart2, (int) '#', 10);
        chartProgressEvent5.setType(0);
        boolean boolean8 = itemLabelAnchor0.equals((java.lang.Object) chartProgressEvent5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getLabelPaint();
        numberAxis5.setAutoRangeStickyZero(false);
        boolean boolean16 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.RangeType rangeType17 = numberAxis5.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis5.setMarkerBand(markerAxisBand18);
        java.awt.Font font20 = numberAxis5.getTickLabelFont();
        numberAxis5.setVerticalTickLabels(true);
        org.jfree.data.Range range23 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rangeType17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean(175, (java.lang.Boolean) true);
        java.lang.Object obj4 = null;
        boolean boolean5 = booleanList0.equals(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot3.getDomainAxisLocation((int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation33, plotOrientation34);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setBasePaint(paint5, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        barRenderer0.notifyListeners(rendererChangeEvent8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color2 = color1.brighter();
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color2);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        java.awt.Shape shape16 = barRenderer0.getSeriesShape(500);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double21 = numberAxis20.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color24 = java.awt.Color.WHITE;
        numberAxis23.setTickLabelPaint((java.awt.Paint) color24);
        boolean boolean26 = numberAxis23.isVisible();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis23.valueToJava2D((double) (byte) 10, rectangle2D28, rectangleEdge29);
        java.awt.Paint paint31 = numberAxis23.getTickMarkPaint();
        java.awt.Font font32 = numberAxis23.getLabelFont();
        numberAxis20.setLabelFont(font32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color36 = java.awt.Color.WHITE;
        numberAxis35.setTickLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = numberAxis35.isVisible();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis35.valueToJava2D((double) (byte) 10, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine44 = new org.jfree.chart.text.TextLine("EXPAND", font32, paint43);
        org.jfree.chart.block.BlockBorder blockBorder45 = new org.jfree.chart.block.BlockBorder(paint43);
        barRenderer0.setSeriesFillPaint((int) (short) 0, paint43, true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color1 = java.awt.Color.PINK;
        boolean boolean2 = unitType0.equals((java.lang.Object) color1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getTickMarkPaint();
        boolean boolean14 = datasetGroup3.equals((java.lang.Object) numberAxis5);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis5.getTickUnit();
        java.lang.String str16 = numberTickUnit15.toString();
        double double17 = numberTickUnit15.getSize();
        java.lang.String str18 = numberTickUnit15.toString();
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine20 = null;
        textBlock19.addLine(textLine20);
        org.jfree.chart.text.TextBlock textBlock22 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = textBlock22.calculateDimensions(graphics2D23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = textBlock22.getLineAlignment();
        textBlock19.setLineAlignment(horizontalAlignment25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition29 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor27, textBlockAnchor28);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick32 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) numberTickUnit15, textBlock19, textBlockAnchor28, textAnchor30, (double) 10.0f);
        boolean boolean33 = unitType0.equals((java.lang.Object) textBlockAnchor28);
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[] doubleArray40 = new double[] {};
        double[] doubleArray41 = new double[] {};
        double[] doubleArray42 = new double[] {};
        double[] doubleArray43 = new double[] {};
        double[][] doubleArray44 = new double[][] { doubleArray38, doubleArray39, doubleArray40, doubleArray41, doubleArray42, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray44);
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ItemLabelAnchor.OUTSIDE5", doubleArray44);
        boolean boolean47 = textBlockAnchor28.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[size=1]" + "'", str16.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "[size=1]" + "'", str18.equals("[size=1]"));
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image11, "hi!", "ClassContext", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image20, "hi!", "ClassContext", "hi!");
        java.awt.Image image28 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo32 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image28, "hi!", "ClassContext", "hi!");
        projectInfo24.addLibrary((org.jfree.chart.ui.Library) projectInfo32);
        java.lang.String str34 = projectInfo32.getLicenceName();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo32);
        projectInfo7.setName("ItemLabelAnchor.INSIDE2");
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ClassContext" + "'", str34.equals("ClassContext"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis0);
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent3.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(jFreeChart4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis0);
        org.jfree.chart.JFreeChart jFreeChart4 = chartChangeEvent3.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent3.setType(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(jFreeChart4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        projectInfo7.setInfo("ClassContext");
        java.lang.String str14 = projectInfo7.toString();
        java.lang.String str15 = projectInfo7.getInfo();
        java.lang.String str16 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ClassContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!" + "'", str14.equals(" version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ClassContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ClassContext" + "'", str15.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color6 = java.awt.Color.WHITE;
        numberAxis5.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis5.isVisible();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis5.valueToJava2D((double) (byte) 10, rectangle2D10, rectangleEdge11);
        java.awt.Paint paint13 = numberAxis5.getTickMarkPaint();
        java.awt.Font font14 = numberAxis5.getLabelFont();
        numberAxis2.setLabelFont(font14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color18 = java.awt.Color.WHITE;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis17.isVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis17.valueToJava2D((double) (byte) 10, rectangle2D22, rectangleEdge23);
        java.awt.Paint paint25 = numberAxis17.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine("EXPAND", font14, paint25);
        org.jfree.chart.text.TextFragment textFragment27 = textLine26.getFirstTextFragment();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textFragment27);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        projectInfo7.setInfo("ClassContext");
        projectInfo7.addOptionalLibrary("java.awt.Color[r=255,g=200,b=0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType1 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str2 = categoryLabelWidthType1.toString();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getCentralValue();
        boolean boolean8 = range4.intersects((double) (byte) 100, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range4);
        boolean boolean10 = categoryLabelWidthType1.equals((java.lang.Object) range4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range4);
        org.junit.Assert.assertNotNull(categoryLabelWidthType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str2.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem8.getFillPaintTransformer();
        legendItem8.setDatasetIndex((-1));
        boolean boolean13 = legendItem8.isLineVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getLabelPaint();
        java.awt.Color color11 = java.awt.Color.gray;
        numberAxis2.setLabelPaint((java.awt.Paint) color11);
        org.jfree.data.KeyedObject keyedObject13 = new org.jfree.data.KeyedObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) color11);
        java.lang.Comparable comparable14 = keyedObject13.getKey();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setAutoRangeIncludesZero(false);
        numberAxis16.setLabelAngle((double) (byte) 1);
        double double21 = numberAxis16.getLabelAngle();
        boolean boolean22 = keyedObject13.equals((java.lang.Object) double21);
        java.lang.Comparable comparable23 = keyedObject13.getKey();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "CategoryAnchor.MIDDLE" + "'", comparable14.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + "CategoryAnchor.MIDDLE" + "'", comparable23.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        boolean boolean2 = categoryAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) (short) 100);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener3);
        java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) "RangeType.FULL", (java.lang.Comparable) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup9 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color12 = java.awt.Color.WHITE;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = numberAxis11.isVisible();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis11.valueToJava2D((double) (byte) 10, rectangle2D16, rectangleEdge17);
        java.awt.Paint paint19 = numberAxis11.getTickMarkPaint();
        boolean boolean20 = datasetGroup9.equals((java.lang.Object) numberAxis11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis11.getTickUnit();
        java.lang.String str22 = numberTickUnit21.toString();
        java.lang.String str24 = numberTickUnit21.valueToString((double) '#');
        java.lang.Number number25 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) " version hi!.\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ClassContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nhi!", (java.lang.Comparable) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "[size=1]" + "'", str22.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "35" + "'", str24.equals("35"));
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        size2D2.width = 0.5d;
        double double5 = size2D2.getHeight();
        size2D2.width = 1.0d;
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shapeArray5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        java.lang.Comparable comparable2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity8 = new org.jfree.chart.entity.CategoryLabelEntity(comparable2, shape5, "hi!", "ThreadContext");
        boolean boolean9 = categoryLabelPositions1.equals((java.lang.Object) "hi!");
        boolean boolean10 = lineBorder0.equals((java.lang.Object) categoryLabelPositions1);
        java.awt.Stroke stroke11 = lineBorder0.getStroke();
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, 0.0d, (double) (byte) 0, (double) 100L);
        java.awt.Paint paint17 = blockBorder16.getPaint();
        boolean boolean18 = lineBorder0.equals((java.lang.Object) paint17);
        java.awt.Stroke stroke19 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        java.awt.Color color12 = java.awt.Color.gray;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape15 = barRenderer14.getBaseShape();
        barRenderer14.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj20 = defaultDrawingSupplier19.clone();
        java.awt.Stroke stroke21 = defaultDrawingSupplier19.getNextStroke();
        barRenderer14.setSeriesStroke((int) 'a', stroke21);
        boolean boolean23 = barRenderer14.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer14);
        java.awt.Font font25 = legendTitle24.getItemFont();
        java.awt.Paint paint26 = legendTitle24.getItemPaint();
        numberAxis2.setLabelPaint(paint26);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(2.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("NOID");
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("EXPAND", font15, (java.awt.Paint) color16, rectangleEdge17, horizontalAlignment18, verticalAlignment21, rectangleInsets22);
        double double24 = rectangleInsets22.getTop();
        boolean boolean25 = plotOrientation3.equals((java.lang.Object) rectangleInsets22);
        categoryPlot0.setOrientation(plotOrientation3);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28, false);
        int int32 = defaultStatisticalCategoryDataset28.getColumnCount();
        categoryPlot0.setDataset(500, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28);
        categoryPlot0.setBackgroundImageAlignment((int) 'a');
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        java.lang.String str2 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RangeType.FULL" + "'", str2.equals("RangeType.FULL"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis6.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot8.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color15 = java.awt.Color.WHITE;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color15);
        boolean boolean17 = numberAxis14.isVisible();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis14.valueToJava2D((double) (byte) 10, rectangle2D19, rectangleEdge20);
        java.awt.Paint paint22 = numberAxis14.getTickMarkPaint();
        java.awt.Font font23 = numberAxis14.getLabelFont();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = textTitle28.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("EXPAND", font23, (java.awt.Paint) color24, rectangleEdge25, horizontalAlignment26, verticalAlignment29, rectangleInsets30);
        double double32 = rectangleInsets30.getTop();
        boolean boolean33 = plotOrientation11.equals((java.lang.Object) rectangleInsets30);
        categoryPlot8.setOrientation(plotOrientation11);
        numberAxis6.setPlot((org.jfree.chart.plot.Plot) categoryPlot8);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot8.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot8.getRenderer();
        java.lang.Object obj38 = textTitle1.draw(graphics2D3, rectangle2D4, (java.lang.Object) categoryItemRenderer37);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(legendItemCollection36);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleAnchor.CENTER");
        java.lang.String str2 = textFragment1.getText();
        float float3 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.CENTER" + "'", str2.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.darkGray;
        java.awt.Color color8 = java.awt.Color.getColor("hi!", color7);
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, (java.awt.Paint) color7);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        boolean boolean12 = textBlockAnchor10.equals((java.lang.Object) textBlockAnchor11);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock9, textBlockAnchor10, textAnchor13, (double) 10.0f);
        java.lang.Object obj16 = categoryTick15.clone();
        boolean boolean17 = labelBlock1.equals((java.lang.Object) categoryTick15);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double21 = numberAxis20.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color24 = java.awt.Color.WHITE;
        numberAxis23.setTickLabelPaint((java.awt.Paint) color24);
        boolean boolean26 = numberAxis23.isVisible();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis23.valueToJava2D((double) (byte) 10, rectangle2D28, rectangleEdge29);
        java.awt.Paint paint31 = numberAxis23.getTickMarkPaint();
        java.awt.Font font32 = numberAxis23.getLabelFont();
        numberAxis20.setLabelFont(font32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = numberAxis20.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double36 = rectangleInsets35.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor37 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean38 = rectangleInsets35.equals((java.lang.Object) itemLabelAnchor37);
        org.jfree.chart.util.UnitType unitType39 = rectangleInsets35.getUnitType();
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double42 = labelBlock41.getWidth();
        java.lang.Object obj43 = labelBlock41.clone();
        java.awt.Font font44 = labelBlock41.getFont();
        labelBlock41.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D50 = labelBlock41.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets35.createOutsetRectangle(rectangle2D50);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets34.createAdjustedRectangle(rectangle2D51, lengthAdjustmentType52, lengthAdjustmentType53);
        try {
            labelBlock1.draw(graphics2D18, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(unitType39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(lengthAdjustmentType52);
        org.junit.Assert.assertNotNull(lengthAdjustmentType53);
        org.junit.Assert.assertNotNull(rectangle2D54);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot3.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNull(valueAxis32);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) '#');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        int int16 = legendItem15.getSeriesIndex();
        java.awt.Stroke stroke17 = legendItem15.getOutlineStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke17);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        float float3 = categoryPlot0.getBackgroundImageAlpha();
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        numberAxis1.zoomRange((double) (byte) 0, (double) 0.0f);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        numberAxis1.setDownArrow(shape17);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity23 = new org.jfree.chart.entity.TickLabelEntity(shape17, "VerticalAlignment.CENTER", "");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape9, (java.awt.Paint) color10);
        barRenderer1.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color10, false);
        java.awt.Color color19 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color19);
        barRenderer1.setSeriesPaint(1, (java.awt.Paint) color19);
        boolean boolean22 = gradientPaintTransformType0.equals((java.lang.Object) barRenderer1);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot24.getRangeAxis(0);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot24.getRangeAxis(175);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double31 = numberAxis30.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color34 = java.awt.Color.WHITE;
        numberAxis33.setTickLabelPaint((java.awt.Paint) color34);
        boolean boolean36 = numberAxis33.isVisible();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis33.valueToJava2D((double) (byte) 10, rectangle2D38, rectangleEdge39);
        java.awt.Paint paint41 = numberAxis33.getTickMarkPaint();
        java.awt.Font font42 = numberAxis33.getLabelFont();
        numberAxis30.setLabelFont(font42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = numberAxis30.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double46 = rectangleInsets45.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor47 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean48 = rectangleInsets45.equals((java.lang.Object) itemLabelAnchor47);
        org.jfree.chart.util.UnitType unitType49 = rectangleInsets45.getUnitType();
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double52 = labelBlock51.getWidth();
        java.lang.Object obj53 = labelBlock51.clone();
        java.awt.Font font54 = labelBlock51.getFont();
        labelBlock51.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D60 = labelBlock51.getBounds();
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets45.createOutsetRectangle(rectangle2D60);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets44.createAdjustedRectangle(rectangle2D61, lengthAdjustmentType62, lengthAdjustmentType63);
        try {
            barRenderer1.drawBackground(graphics2D23, categoryPlot24, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.0d + "'", double46 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(unitType49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(lengthAdjustmentType62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType63);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        java.awt.Shape shape24 = barRenderer0.getItemShape((int) (byte) -1, (int) (byte) 1);
        java.awt.Paint paint25 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator26);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Color color18 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color18);
        barRenderer0.setSeriesPaint(1, (java.awt.Paint) color18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape26 = barRenderer25.getBaseShape();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.equal(shape29, shape32);
        barRenderer25.setBaseShape(shape29);
        java.awt.Color color35 = java.awt.Color.orange;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj37 = defaultDrawingSupplier36.clone();
        java.awt.Stroke stroke38 = defaultDrawingSupplier36.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint42 = categoryAxis40.getTickLabelPaint((java.lang.Comparable) "poly");
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "", "VerticalAlignment.CENTER", "RangeType.FULL", shape29, (java.awt.Paint) color35, stroke38, paint42);
        barRenderer0.setBaseOutlineStroke(stroke38);
        barRenderer0.setItemLabelAnchorOffset((double) 1);
        java.awt.Paint paint47 = barRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape10, (java.awt.Paint) color11);
        barRenderer2.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color11, false);
        boolean boolean15 = barRenderer2.getAutoPopulateSeriesShape();
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer2.setSeriesOutlinePaint((int) '4', paint17);
        java.awt.Paint paint19 = barRenderer2.getBaseOutlinePaint();
        valueMarker1.setPaint(paint19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis22.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot24.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color31 = java.awt.Color.WHITE;
        numberAxis30.setTickLabelPaint((java.awt.Paint) color31);
        boolean boolean33 = numberAxis30.isVisible();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis30.valueToJava2D((double) (byte) 10, rectangle2D35, rectangleEdge36);
        java.awt.Paint paint38 = numberAxis30.getTickMarkPaint();
        java.awt.Font font39 = numberAxis30.getLabelFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = textTitle44.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("EXPAND", font39, (java.awt.Paint) color40, rectangleEdge41, horizontalAlignment42, verticalAlignment45, rectangleInsets46);
        double double48 = rectangleInsets46.getTop();
        boolean boolean49 = plotOrientation27.equals((java.lang.Object) rectangleInsets46);
        categoryPlot24.setOrientation(plotOrientation27);
        numberAxis22.setPlot((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.LegendItemCollection legendItemCollection52 = categoryPlot24.getFixedLegendItems();
        categoryPlot24.clearRangeAxes();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot24);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 3.0d + "'", double48 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(legendItemCollection52);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint6 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis4.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float11 = categoryAxis4.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        categoryAxis4.addChangeListener(axisChangeListener12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState(1.0d);
        axisState16.cursorDown((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType19 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock25 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = textBlock25.calculateDimensions(graphics2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str31 = rectangleAnchor30.toString();
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, Double.NaN, 0.0d, rectangleAnchor30);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets24.createOutsetRectangle(rectangle2D32);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color37 = java.awt.Color.WHITE;
        numberAxis36.setTickLabelPaint((java.awt.Paint) color37);
        boolean boolean39 = numberAxis36.isVisible();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis36.valueToJava2D((double) (byte) 10, rectangle2D41, rectangleEdge42);
        java.awt.Paint paint44 = numberAxis36.getTickMarkPaint();
        java.awt.Font font45 = numberAxis36.getLabelFont();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = textTitle50.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("EXPAND", font45, (java.awt.Paint) color46, rectangleEdge47, horizontalAlignment48, verticalAlignment51, rectangleInsets52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge47);
        java.util.List list55 = categoryAxis4.refreshTicks(graphics2D14, axisState16, rectangle2D32, rectangleEdge54);
        categoryPlot0.setDomainAxis(categoryAxis4);
        categoryAxis4.setLabelURL("ItemLabelAnchor.OUTSIDE5");
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleAnchor.CENTER" + "'", str31.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(list55);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateX((double) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        double double6 = categoryAxis1.getUpperMargin();
        categoryAxis1.setCategoryMargin(2.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        float float3 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj5 = defaultDrawingSupplier4.clone();
        java.awt.Stroke stroke6 = defaultDrawingSupplier4.getNextStroke();
        categoryPlot0.setDomainGridlineStroke(stroke6);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.5f + "'", float3 == 0.5f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        categoryPlot3.mapDatasetToDomainAxis((int) (byte) 1, 0);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getLabelPaint();
        java.awt.Color color11 = java.awt.Color.gray;
        numberAxis2.setLabelPaint((java.awt.Paint) color11);
        org.jfree.data.KeyedObject keyedObject13 = new org.jfree.data.KeyedObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) color11);
        java.lang.Comparable comparable14 = keyedObject13.getKey();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color18 = java.awt.Color.WHITE;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis17.isVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis17.valueToJava2D((double) (byte) 10, rectangle2D22, rectangleEdge23);
        java.awt.Paint paint25 = numberAxis17.getLabelPaint();
        java.awt.Color color26 = java.awt.Color.gray;
        numberAxis17.setLabelPaint((java.awt.Paint) color26);
        org.jfree.data.KeyedObject keyedObject28 = new org.jfree.data.KeyedObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) color26);
        keyedObject13.setObject((java.lang.Object) color26);
        double[] doubleArray34 = new double[] {};
        double[] doubleArray35 = new double[] {};
        double[] doubleArray36 = new double[] {};
        double[] doubleArray37 = new double[] {};
        double[] doubleArray38 = new double[] {};
        double[] doubleArray39 = new double[] {};
        double[][] doubleArray40 = new double[][] { doubleArray34, doubleArray35, doubleArray36, doubleArray37, doubleArray38, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelWidthType.CATEGORY", "GradientPaintTransformType.HORIZONTAL", doubleArray40);
        boolean boolean43 = keyedObject13.equals((java.lang.Object) "CategoryLabelWidthType.CATEGORY");
        java.lang.Object obj44 = null;
        keyedObject13.setObject(obj44);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "CategoryAnchor.MIDDLE" + "'", comparable14.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberAxis2.getLabelURL();
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = numberAxis2.hasListener(eventListener14);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) ' ', shape19, "", "TextAnchor.BASELINE_RIGHT");
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, (double) (short) 0, (double) 1);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity28 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis2, shape25, "EXPAND", "RangeType.NEGATIVE");
        org.jfree.chart.axis.Axis axis29 = axisLabelEntity28.getAxis();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(axis29);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock1, textBlockAnchor2, textAnchor3, (double) (-1L));
        org.jfree.chart.text.TextBlock textBlock6 = categoryTick5.getLabel();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(textBlock6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement1 = new org.jfree.chart.block.BorderArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement1);
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement4 = new org.jfree.chart.block.BorderArrangement();
        blockContainer3.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double8 = range7.getCentralValue();
        boolean boolean11 = range7.intersects((double) (byte) 100, 100.0d);
        double double13 = range7.constrain((double) (short) 1);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range7, range14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        double double17 = rectangleConstraint15.getHeight();
        org.jfree.chart.util.Size2D size2D18 = borderArrangement1.arrange(blockContainer3, graphics2D6, rectangleConstraint15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = barRenderer19.getBaseShape();
        barRenderer19.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj25 = defaultDrawingSupplier24.clone();
        java.awt.Stroke stroke26 = defaultDrawingSupplier24.getNextStroke();
        barRenderer19.setSeriesStroke((int) 'a', stroke26);
        boolean boolean28 = barRenderer19.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint33 = categoryAxis31.getTickLabelPaint((java.lang.Comparable) "poly");
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder(paint33);
        legendTitle29.setFrame((org.jfree.chart.block.BlockFrame) blockBorder34);
        java.lang.Object obj36 = null;
        borderArrangement1.add((org.jfree.chart.block.Block) legendTitle29, obj36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.UnitType unitType39 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets(unitType39, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock45 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.util.Size2D size2D47 = textBlock45.calculateDimensions(graphics2D46);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str51 = rectangleAnchor50.toString();
        java.awt.geom.Rectangle2D rectangle2D52 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D47, Double.NaN, 0.0d, rectangleAnchor50);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets44.createOutsetRectangle(rectangle2D52);
        org.jfree.chart.block.LineBorder lineBorder54 = new org.jfree.chart.block.LineBorder();
        try {
            java.lang.Object obj55 = legendTitle29.draw(graphics2D38, rectangle2D53, (java.lang.Object) lineBorder54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(unitType39);
        org.junit.Assert.assertNotNull(size2D47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "RectangleAnchor.CENTER" + "'", str51.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D53);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = null;
        textBlock0.addLine(textLine1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        try {
            textBlock0.draw(graphics2D3, (float) 3, (float) (short) 1, textBlockAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.data.general.Dataset dataset10 = legendItem8.getDataset();
        java.lang.String str11 = legendItem8.getLabel();
        java.text.AttributedString attributedString12 = legendItem8.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNull(attributedString12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE5", font1);
        org.jfree.chart.text.TextFragment textFragment3 = null;
        textLine2.removeFragment(textFragment3);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(0.0d, rectangleEdge3);
        axisState1.cursorDown((double) 100L);
        java.util.List list7 = axisState1.getTicks();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) list7);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Shape shape12 = numberAxis1.getRightArrow();
        boolean boolean13 = numberAxis1.isVerticalTickLabels();
        double double14 = numberAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        axisState17.moveCursor(0.0d, rectangleEdge19);
        axisState17.setCursor((double) 35);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = numberAxis1.refreshTicks(graphics2D15, axisState17, rectangle2D23, rectangleEdge24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj27 = defaultDrawingSupplier26.clone();
        java.awt.Paint paint28 = defaultDrawingSupplier26.getNextOutlinePaint();
        numberAxis1.setTickLabelPaint(paint28);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity35 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape32, "{0}", "RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        java.awt.Paint paint10 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 100, paint10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = legendTitle12.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color33 = java.awt.Color.WHITE;
        numberAxis32.setTickLabelPaint((java.awt.Paint) color33);
        boolean boolean35 = numberAxis32.isVisible();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = numberAxis32.valueToJava2D((double) (byte) 10, rectangle2D37, rectangleEdge38);
        java.awt.Paint paint40 = numberAxis32.getLabelPaint();
        numberAxis32.setAutoRangeStickyZero(false);
        numberAxis32.setTickMarksVisible(true);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape47, 0.0d, 0.0f, 1.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity54 = new org.jfree.chart.entity.TickLabelEntity(shape51, "", "hi!");
        numberAxis32.setLeftArrow(shape51);
        categoryPlot3.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        org.jfree.chart.axis.ValueAxis valueAxis58 = categoryPlot3.getRangeAxis((int) (short) -1);
        org.jfree.data.general.DatasetGroup datasetGroup59 = categoryPlot3.getDatasetGroup();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertNull(datasetGroup59);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = barRenderer2.getBaseShape();
        barRenderer2.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj8 = defaultDrawingSupplier7.clone();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        barRenderer2.setSeriesStroke((int) 'a', stroke9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = barRenderer2.equals((java.lang.Object) textTitle19);
        int int21 = barRenderer2.getColumnCount();
        java.awt.Font font23 = barRenderer2.getSeriesItemLabelFont(3);
        boolean boolean24 = textFragment1.equals((java.lang.Object) barRenderer2);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            float float27 = textFragment1.calculateBaselineOffset(graphics2D25, textAnchor26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        java.awt.Paint paint18 = barRenderer0.getSeriesFillPaint(3);
        boolean boolean19 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        java.awt.Paint paint18 = barRenderer0.getSeriesFillPaint(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = barRenderer0.getSeriesURLGenerator((int) (short) 10);
        java.awt.Stroke stroke22 = barRenderer0.lookupSeriesStroke(500);
        java.awt.Stroke stroke25 = barRenderer0.getItemStroke((int) (byte) 0, (-1));
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("ItemLabelAnchor.OUTSIDE5", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE5" + "'", str1.equals("ItemLabelAnchor.INSIDE5"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE8" + "'", str1.equals("ItemLabelAnchor.INSIDE8"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getLabelPaint();
        java.awt.Color color11 = java.awt.Color.gray;
        numberAxis2.setLabelPaint((java.awt.Paint) color11);
        org.jfree.data.KeyedObject keyedObject13 = new org.jfree.data.KeyedObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) color11);
        java.lang.Comparable comparable14 = keyedObject13.getKey();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color18 = java.awt.Color.WHITE;
        numberAxis17.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis17.isVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis17.valueToJava2D((double) (byte) 10, rectangle2D22, rectangleEdge23);
        java.awt.Paint paint25 = numberAxis17.getLabelPaint();
        java.awt.Color color26 = java.awt.Color.gray;
        numberAxis17.setLabelPaint((java.awt.Paint) color26);
        org.jfree.data.KeyedObject keyedObject28 = new org.jfree.data.KeyedObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) color26);
        keyedObject13.setObject((java.lang.Object) color26);
        java.lang.Object obj30 = keyedObject13.clone();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "CategoryAnchor.MIDDLE" + "'", comparable14.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setBasePaint(paint5, false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color11 = java.awt.Color.WHITE;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color11);
        boolean boolean13 = numberAxis10.isVisible();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis10.valueToJava2D((double) (byte) 10, rectangle2D15, rectangleEdge16);
        java.awt.Paint paint18 = numberAxis10.getLabelPaint();
        numberAxis10.setAutoRangeStickyZero(false);
        java.awt.Shape shape21 = numberAxis10.getRightArrow();
        java.awt.Stroke stroke22 = numberAxis10.getTickMarkStroke();
        barRenderer0.setSeriesStroke(0, stroke22);
        barRenderer0.setBaseSeriesVisible(false, false);
        boolean boolean28 = barRenderer0.isSeriesItemLabelsVisible(175);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BorderArrangement borderArrangement1 = new org.jfree.chart.block.BorderArrangement();
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) borderArrangement1);
        java.util.List list3 = blockContainer0.getBlocks();
        java.lang.Object obj4 = blockContainer0.clone();
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = textBlock5.calculateDimensions(graphics2D6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textBlock5.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) 175, (double) 100);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement12);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        java.lang.Object obj3 = categoryPlot0.clone();
        java.awt.Image image4 = null;
        categoryPlot0.setBackgroundImage(image4);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberTickUnit12.toString();
        double double14 = numberTickUnit12.getSize();
        java.lang.String str15 = numberTickUnit12.toString();
        org.jfree.chart.text.TextBlock textBlock16 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine17 = null;
        textBlock16.addLine(textLine17);
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock19.calculateDimensions(graphics2D20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textBlock19.getLineAlignment();
        textBlock16.setLineAlignment(horizontalAlignment22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor24, textBlockAnchor25);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick29 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) numberTickUnit12, textBlock16, textBlockAnchor25, textAnchor27, (double) 10.0f);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        try {
            textBlock16.draw(graphics2D30, (float) (short) 0, 10.0f, textBlockAnchor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[size=1]" + "'", str13.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[size=1]" + "'", str15.equals("[size=1]"));
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Object obj2 = defaultStatisticalCategoryDataset0.clone();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultStatisticalCategoryDataset0.getGroup();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("EXPAND", font11, (java.awt.Paint) color12, rectangleEdge13, horizontalAlignment14, verticalAlignment17, rectangleInsets18);
        java.lang.String str20 = horizontalAlignment14.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "HorizontalAlignment.CENTER" + "'", str20.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getSeriesItemLabelGenerator((int) '4');
        java.awt.Color color11 = java.awt.Color.yellow;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color11);
        barRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 2, (-1.0d));
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.darkGray;
        java.awt.Color color5 = java.awt.Color.getColor("hi!", color4);
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        boolean boolean9 = textBlockAnchor7.equals((java.lang.Object) textBlockAnchor8);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick12 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock6, textBlockAnchor7, textAnchor10, (double) 10.0f);
        java.lang.String str13 = categoryTick12.getText();
        org.jfree.chart.text.TextBlock textBlock14 = categoryTick12.getLabel();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(textBlock14);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        java.lang.Comparable comparable3 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity(comparable3, shape6, "hi!", "ThreadContext");
        boolean boolean10 = categoryLabelPositions2.equals((java.lang.Object) "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions2, categoryLabelPosition13);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        categoryAxis1.setLowerMargin(1.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        size2D2.width = 0.5d;
        double double5 = size2D2.height;
        size2D2.setWidth((double) (byte) -1);
        boolean boolean9 = size2D2.equals((java.lang.Object) (short) 1);
        double double10 = size2D2.getWidth();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        java.lang.String str2 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EXPAND" + "'", str2.equals("EXPAND"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) jFreeChartResources0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        numberAxis1.setLabelURL("poly");
        numberAxis1.setLabelAngle((double) 255);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        barRenderer5.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color14, false);
        boolean boolean18 = barRenderer5.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = barRenderer19.getBaseShape();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.equal(shape23, shape26);
        barRenderer19.setBaseShape(shape23);
        java.awt.Stroke stroke30 = barRenderer19.lookupSeriesOutlineStroke(3);
        barRenderer5.setBaseStroke(stroke30);
        java.awt.Shape shape34 = barRenderer5.getItemShape(0, (int) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape44, (java.awt.Paint) color45);
        barRenderer36.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color45, false);
        boolean boolean49 = barRenderer36.getAutoPopulateSeriesShape();
        java.awt.Paint paint52 = barRenderer36.getItemPaint((int) (short) 10, 0);
        java.awt.Font font53 = barRenderer36.getBaseItemLabelFont();
        double double54 = barRenderer36.getLowerClip();
        java.awt.Paint paint57 = barRenderer36.getItemFillPaint(10, (-1));
        java.awt.Paint paint58 = barRenderer36.getBaseOutlinePaint();
        java.awt.Color color60 = java.awt.Color.LIGHT_GRAY;
        java.awt.Stroke stroke61 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer63 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape64 = barRenderer63.getBaseShape();
        barRenderer63.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier68 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj69 = defaultDrawingSupplier68.clone();
        java.awt.Stroke stroke70 = defaultDrawingSupplier68.getNextStroke();
        barRenderer63.setSeriesStroke((int) 'a', stroke70);
        barRenderer63.setAutoPopulateSeriesStroke(false);
        java.awt.Shape shape74 = barRenderer63.getBaseShape();
        org.jfree.chart.block.LineBorder lineBorder75 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke76 = lineBorder75.getStroke();
        java.awt.Stroke stroke77 = lineBorder75.getStroke();
        java.awt.Color color78 = java.awt.Color.LIGHT_GRAY;
        int int79 = color78.getTransparency();
        try {
            org.jfree.chart.LegendItem legendItem80 = new org.jfree.chart.LegendItem(attributedString0, "CategoryLabelWidthType.CATEGORY", "SortOrder.DESCENDING", "CategoryAnchor.START", true, shape34, true, paint58, false, (java.awt.Paint) color60, stroke61, true, shape74, stroke77, (java.awt.Paint) color78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) ' ', shape3, "", "TextAnchor.BASELINE_RIGHT");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int11 = defaultStatisticalCategoryDataset9.getColumnIndex((java.lang.Comparable) (short) 100);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener12 = null;
        defaultStatisticalCategoryDataset9.removeChangeListener(datasetChangeListener12);
        java.lang.Number number16 = defaultStatisticalCategoryDataset9.getValue((java.lang.Comparable) "RangeType.FULL", (java.lang.Comparable) (short) 10);
        java.lang.Object obj17 = defaultStatisticalCategoryDataset9.clone();
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, (java.lang.Comparable) 10L);
        org.jfree.data.general.DatasetGroup datasetGroup20 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color23 = java.awt.Color.WHITE;
        numberAxis22.setTickLabelPaint((java.awt.Paint) color23);
        boolean boolean25 = numberAxis22.isVisible();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis22.valueToJava2D((double) (byte) 10, rectangle2D27, rectangleEdge28);
        java.awt.Paint paint30 = numberAxis22.getTickMarkPaint();
        boolean boolean31 = datasetGroup20.equals((java.lang.Object) numberAxis22);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = numberAxis22.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color35 = java.awt.Color.WHITE;
        numberAxis34.setTickLabelPaint((java.awt.Paint) color35);
        boolean boolean37 = numberAxis34.isVisible();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = numberAxis34.valueToJava2D((double) (byte) 10, rectangle2D39, rectangleEdge40);
        java.awt.Paint paint42 = numberAxis34.getLabelPaint();
        numberAxis34.setAutoRangeStickyZero(false);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape51, (java.awt.Paint) color52);
        numberAxis34.setAxisLinePaint((java.awt.Paint) color52);
        numberAxis34.setPositiveArrowVisible(true);
        int int57 = numberTickUnit32.compareTo((java.lang.Object) numberAxis34);
        java.lang.Number number59 = defaultStatisticalCategoryDataset9.getStdDevValue((java.lang.Comparable) int57, (java.lang.Comparable) (short) -1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity62 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "Range[0.0,1.0]", "LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, (java.lang.Comparable) "Range[1.0,2.0]", (java.lang.Comparable) 1L);
        org.jfree.data.Range range64 = defaultStatisticalCategoryDataset9.getRangeBounds(true);
        org.jfree.data.Range range65 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(numberTickUnit32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNull(number59);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNull(range65);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        double double4 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color33 = java.awt.Color.WHITE;
        numberAxis32.setTickLabelPaint((java.awt.Paint) color33);
        boolean boolean35 = numberAxis32.isVisible();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = numberAxis32.valueToJava2D((double) (byte) 10, rectangle2D37, rectangleEdge38);
        java.awt.Paint paint40 = numberAxis32.getLabelPaint();
        numberAxis32.setAutoRangeStickyZero(false);
        numberAxis32.setTickMarksVisible(true);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape47, 0.0d, 0.0f, 1.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity54 = new org.jfree.chart.entity.TickLabelEntity(shape51, "", "hi!");
        numberAxis32.setLeftArrow(shape51);
        categoryPlot3.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = categoryPlot3.getOrientation();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(plotOrientation57);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Paint paint3 = valueMarker1.getPaint();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color12 = java.awt.Color.WHITE;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = numberAxis11.isVisible();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis11.valueToJava2D((double) (byte) 10, rectangle2D16, rectangleEdge17);
        java.awt.Paint paint19 = numberAxis11.getTickMarkPaint();
        numberAxis11.setVisible(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape30, (java.awt.Paint) color31);
        barRenderer22.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color31, false);
        boolean boolean35 = barRenderer22.getAutoPopulateSeriesShape();
        java.awt.Paint paint38 = barRenderer22.getItemPaint((int) (short) 10, 0);
        numberAxis11.setTickMarkPaint(paint38);
        boolean boolean40 = legendItemEntity7.equals((java.lang.Object) numberAxis11);
        java.lang.String str41 = legendItemEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Color color6 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color6);
        paintList0.setPaint(100, (java.awt.Paint) color6);
        java.awt.Paint paint10 = paintList0.getPaint(0);
        java.awt.Paint paint12 = paintList0.getPaint(10);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        java.lang.Object obj3 = categoryPlot0.clone();
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        barRenderer5.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color14, false);
        boolean boolean18 = barRenderer5.getAutoPopulateSeriesShape();
        java.awt.Paint paint20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer5.setSeriesOutlinePaint((int) '4', paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = barRenderer5.getBaseItemLabelGenerator();
        java.awt.Color color23 = java.awt.Color.orange;
        barRenderer5.setBaseItemLabelPaint((java.awt.Paint) color23, false);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5, true);
        java.awt.Paint paint28 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 1);
        java.awt.Shape shape19 = barRenderer0.getItemShape((int) (byte) -1, 0);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle2.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle2.getPosition();
        textTitle0.setPosition(rectangleEdge4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = textTitle0.getVerticalAlignment();
        boolean boolean7 = textTitle0.getNotify();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = textTitle0.getVerticalAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(verticalAlignment6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer0.getNegativeItemLabelPositionFallback();
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(itemLabelPosition17);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setLabelAngle((double) (byte) 1);
        double double6 = numberAxis1.getLabelAngle();
        numberAxis1.setUpperMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis1.getLabelInsets();
        double double11 = rectangleInsets9.calculateLeftOutset(4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets1.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean4 = rectangleInsets1.equals((java.lang.Object) itemLabelAnchor3);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets1.getUnitType();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double8 = labelBlock7.getWidth();
        java.lang.Object obj9 = labelBlock7.clone();
        java.awt.Font font10 = labelBlock7.getFont();
        labelBlock7.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets1.createOutsetRectangle(rectangle2D16);
        try {
            boolean boolean18 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint6 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis4.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float11 = categoryAxis4.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        categoryAxis4.addChangeListener(axisChangeListener12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState(1.0d);
        axisState16.cursorDown((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType19 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock25 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = textBlock25.calculateDimensions(graphics2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str31 = rectangleAnchor30.toString();
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, Double.NaN, 0.0d, rectangleAnchor30);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets24.createOutsetRectangle(rectangle2D32);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color37 = java.awt.Color.WHITE;
        numberAxis36.setTickLabelPaint((java.awt.Paint) color37);
        boolean boolean39 = numberAxis36.isVisible();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis36.valueToJava2D((double) (byte) 10, rectangle2D41, rectangleEdge42);
        java.awt.Paint paint44 = numberAxis36.getTickMarkPaint();
        java.awt.Font font45 = numberAxis36.getLabelFont();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = textTitle50.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("EXPAND", font45, (java.awt.Paint) color46, rectangleEdge47, horizontalAlignment48, verticalAlignment51, rectangleInsets52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge47);
        java.util.List list55 = categoryAxis4.refreshTicks(graphics2D14, axisState16, rectangle2D32, rectangleEdge54);
        categoryPlot0.setDomainAxis(categoryAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape59 = barRenderer58.getBaseShape();
        barRenderer58.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection62 = barRenderer58.getLegendItems();
        java.awt.Paint paint64 = barRenderer58.getSeriesFillPaint(2);
        boolean boolean65 = axisLocation57.equals((java.lang.Object) 2);
        java.lang.String str66 = axisLocation57.toString();
        categoryPlot0.setDomainAxisLocation(axisLocation57);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleAnchor.CENTER" + "'", str31.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(legendItemCollection62);
        org.junit.Assert.assertNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str66.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(rectangleEdge69);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator12 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator12);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Shape shape12 = numberAxis1.getRightArrow();
        boolean boolean13 = numberAxis1.isVerticalTickLabels();
        double double14 = numberAxis1.getUpperMargin();
        java.awt.Font font15 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color14, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = barRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator17);
        org.junit.Assert.assertNull(itemLabelPosition18);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer12.setSeriesOutlinePaint((int) '4', paint27);
        barRenderer0.setBaseFillPaint(paint27);
        double double30 = barRenderer0.getMinimumBarLength();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        double double33 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator34 = barRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator34);
        org.junit.Assert.assertNull(itemLabelPosition35);
        org.junit.Assert.assertNull(categoryItemLabelGenerator36);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis(175);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.Object obj2 = textTitle1.clone();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        textTitle1.draw(graphics2D3, rectangle2D4);
        boolean boolean6 = textTitle1.getExpandToFitSpace();
        java.lang.Object obj7 = textTitle1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition2.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = categoryLabelPosition2.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = categoryLabelPosition2.getWidthType();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = categoryLabelPosition2.getWidthType();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double8 = range7.getCentralValue();
        boolean boolean11 = range7.intersects((double) (byte) 100, 100.0d);
        double double13 = range7.constrain((double) (short) 1);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range7, range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range7, 1.0E-8d);
        boolean boolean18 = categoryLabelWidthType6.equals((java.lang.Object) rectangleConstraint17);
        org.jfree.data.Range range19 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint17.toRangeHeight(range19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRange(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot13.getRangeAxis(0);
        java.lang.Object obj16 = categoryPlot13.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color19 = color18.brighter();
        categoryPlot17.setNoDataMessagePaint((java.awt.Paint) color19);
        categoryPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot17);
        org.jfree.chart.util.SortOrder sortOrder22 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str23 = sortOrder22.toString();
        categoryPlot13.setColumnRenderingOrder(sortOrder22);
        int int25 = categoryPlot13.getDomainAxisCount();
        org.jfree.chart.util.UnitType unitType26 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets(unitType26, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock32 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.util.Size2D size2D34 = textBlock32.calculateDimensions(graphics2D33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str38 = rectangleAnchor37.toString();
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, Double.NaN, 0.0d, rectangleAnchor37);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets31.createOutsetRectangle(rectangle2D39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace43 = numberAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot13, rectangle2D39, rectangleEdge41, axisSpace42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "SortOrder.DESCENDING" + "'", str23.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(unitType26);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleAnchor.CENTER" + "'", str38.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color4 = java.awt.Color.WHITE;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis3.isVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3.valueToJava2D((double) (byte) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis3.getTickMarkPaint();
        numberAxis3.setVisible(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape22, (java.awt.Paint) color23);
        barRenderer14.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color23, false);
        boolean boolean27 = barRenderer14.getAutoPopulateSeriesShape();
        java.awt.Paint paint30 = barRenderer14.getItemPaint((int) (short) 10, 0);
        numberAxis3.setTickMarkPaint(paint30);
        valueMarker1.setLabelPaint(paint30);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '#');
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) "Range[0.0,1.0]", shape2, "hi!", "ItemLabelAnchor.INSIDE5");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        labelBlock1.setToolTipText("");
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock10.calculateDimensions(graphics2D11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str16 = rectangleAnchor15.toString();
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, Double.NaN, 0.0d, rectangleAnchor15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = barRenderer20.getBaseShape();
        barRenderer20.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj26 = defaultDrawingSupplier25.clone();
        java.awt.Stroke stroke27 = defaultDrawingSupplier25.getNextStroke();
        barRenderer20.setSeriesStroke((int) 'a', stroke27);
        boolean boolean29 = barRenderer20.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer20);
        java.awt.Font font31 = legendTitle30.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle30.setLegendItemGraphicLocation(rectangleAnchor32);
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) 10.0f, 8.0d, rectangleAnchor32);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double36 = rectangleInsets35.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor37 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean38 = rectangleInsets35.equals((java.lang.Object) itemLabelAnchor37);
        org.jfree.chart.util.UnitType unitType39 = rectangleInsets35.getUnitType();
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double42 = labelBlock41.getWidth();
        java.lang.Object obj43 = labelBlock41.clone();
        java.awt.Font font44 = labelBlock41.getFont();
        labelBlock41.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D50 = labelBlock41.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets35.createOutsetRectangle(rectangle2D50);
        boolean boolean52 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D34, rectangle2D51);
        java.awt.Shape shape59 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape59, (java.awt.Paint) color60);
        int int62 = legendItem61.getSeriesIndex();
        legendItem61.setSeriesKey((java.lang.Comparable) true);
        java.awt.Shape shape65 = legendItem61.getLine();
        try {
            java.lang.Object obj66 = labelBlock1.draw(graphics2D9, rectangle2D51, (java.lang.Object) legendItem61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleAnchor.CENTER" + "'", str16.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(unitType39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(shape65);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        int int2 = keyedObjects2D0.getColumnCount();
        java.lang.Comparable comparable3 = null;
        int int4 = keyedObjects2D0.getColumnIndex(comparable3);
        java.util.List list5 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getSeriesIndex();
        legendItem8.setSeriesKey((java.lang.Comparable) true);
        java.awt.Shape shape12 = legendItem8.getLine();
        boolean boolean13 = legendItem8.isShapeFilled();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = barRenderer0.getSeriesItemLabelGenerator((int) '4');
        double double11 = barRenderer0.getLowerClip();
        java.awt.Color color12 = java.awt.Color.cyan;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.plot.Plot plot31 = categoryPlot3.getRootPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot3.getFixedLegendItems();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertNull(legendItemCollection32);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        int int2 = keyedObjects2D0.getColumnCount();
        java.lang.Object obj3 = keyedObjects2D0.clone();
        java.util.List list4 = keyedObjects2D0.getColumnKeys();
        java.lang.Object obj5 = keyedObjects2D0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color33 = java.awt.Color.WHITE;
        numberAxis32.setTickLabelPaint((java.awt.Paint) color33);
        boolean boolean35 = numberAxis32.isVisible();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = numberAxis32.valueToJava2D((double) (byte) 10, rectangle2D37, rectangleEdge38);
        java.awt.Paint paint40 = numberAxis32.getLabelPaint();
        numberAxis32.setAutoRangeStickyZero(false);
        numberAxis32.setTickMarksVisible(true);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape47, 0.0d, 0.0f, 1.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity54 = new org.jfree.chart.entity.TickLabelEntity(shape51, "", "hi!");
        numberAxis32.setLeftArrow(shape51);
        categoryPlot3.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = null;
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str59 = layer58.toString();
        java.awt.Shape shape66 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color67 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape66, (java.awt.Paint) color67);
        int int69 = legendItem68.getSeriesIndex();
        legendItem68.setSeriesKey((java.lang.Comparable) true);
        boolean boolean72 = layer58.equals((java.lang.Object) true);
        try {
            categoryPlot3.addDomainMarker(categoryMarker57, layer58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Layer.FOREGROUND" + "'", str59.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color21 = java.awt.Color.WHITE;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis20.isVisible();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis20.valueToJava2D((double) (byte) 10, rectangle2D25, rectangleEdge26);
        java.awt.Paint paint28 = numberAxis20.getLabelPaint();
        numberAxis20.setAutoRangeStickyZero(false);
        boolean boolean31 = numberAxis20.isInverted();
        double double32 = numberAxis20.getUpperBound();
        boolean boolean33 = categoryItemEntity18.equals((java.lang.Object) numberAxis20);
        java.awt.Shape shape34 = numberAxis20.getUpArrow();
        numberAxis20.resizeRange(100.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getSeriesIndex();
        java.awt.Paint paint10 = legendItem8.getFillPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        boolean boolean15 = barRenderer0.getAutoPopulateSeriesStroke();
        boolean boolean16 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(itemLabelPosition17);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor2, textAnchor3, (-1.0d));
        org.jfree.chart.axis.TickType tickType7 = numberTick6.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick6.getRotationAnchor();
        double double9 = numberTick6.getValue();
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick6.getRotationAnchor();
        java.lang.Number number11 = numberTick6.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str4.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.0d + "'", number11.equals(2.0d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        int int2 = keyedObjects2D0.getColumnCount();
        java.lang.Object obj3 = keyedObjects2D0.clone();
        int int4 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        categoryPlot3.clearRangeAxes();
        int int33 = categoryPlot3.getDomainAxisCount();
        java.awt.Paint paint34 = categoryPlot3.getNoDataMessagePaint();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("CategoryAnchor.START");
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE5", font3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        textLine1.addFragment(textFragment5);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textFragment5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        java.awt.Stroke stroke4 = lineBorder2.getStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis7.setLowerMargin(0.0d);
        java.awt.Font font10 = categoryAxis7.getLabelFont();
        java.awt.Color color11 = java.awt.Color.white;
        java.awt.Color color12 = color11.darker();
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BASELINE_RIGHT", font10, (java.awt.Paint) color11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape15 = barRenderer14.getBaseShape();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean22 = org.jfree.chart.util.ShapeUtilities.equal(shape18, shape21);
        barRenderer14.setBaseShape(shape18);
        java.awt.Stroke stroke25 = barRenderer14.lookupSeriesOutlineStroke(3);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color1, stroke4, (java.awt.Paint) color11, stroke25, 0.0f);
        float[] floatArray31 = null;
        float[] floatArray32 = java.awt.Color.RGBtoHSB((int) (byte) -1, 10, 1, floatArray31);
        float[] floatArray33 = color11.getColorComponents(floatArray32);
        java.awt.color.ColorSpace colorSpace34 = null;
        float[] floatArray41 = new float[] { (-1), 100.0f, 10.0f };
        float[] floatArray42 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 1, (int) (byte) 1, floatArray41);
        try {
            float[] floatArray43 = color11.getComponents(colorSpace34, floatArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener5 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener5);
        defaultStatisticalCategoryDataset0.validateObject();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setBasePaint(paint5, false);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color11 = java.awt.Color.WHITE;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color11);
        boolean boolean13 = numberAxis10.isVisible();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis10.valueToJava2D((double) (byte) 10, rectangle2D15, rectangleEdge16);
        java.awt.Paint paint18 = numberAxis10.getLabelPaint();
        numberAxis10.setAutoRangeStickyZero(false);
        java.awt.Shape shape21 = numberAxis10.getRightArrow();
        java.awt.Stroke stroke22 = numberAxis10.getTickMarkStroke();
        barRenderer0.setSeriesStroke(0, stroke22);
        barRenderer0.setSeriesCreateEntities((int) ' ', (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        categoryItemEntity18.setColumnKey((java.lang.Comparable) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryItemEntity18.getDataset();
        java.lang.String str22 = categoryItemEntity18.getShapeCoords();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-3,-3,3,3" + "'", str22.equals("-3,-3,3,3"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.calculateRightOutset((double) 0);
        double double5 = rectangleInsets0.calculateTopOutset((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("EXPAND", font15, (java.awt.Paint) color16, rectangleEdge17, horizontalAlignment18, verticalAlignment21, rectangleInsets22);
        double double24 = rectangleInsets22.getTop();
        boolean boolean25 = plotOrientation3.equals((java.lang.Object) rectangleInsets22);
        categoryPlot0.setOrientation(plotOrientation3);
        categoryPlot0.setRangeCrosshairValue((double) 0.0f, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            categoryPlot0.handleClick(175, (int) '4', plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getCentralValue();
        boolean boolean4 = range0.intersects((double) (byte) 100, 100.0d);
        double double6 = range0.constrain((double) (short) 1);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range7);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand(range7, 8.0d, (double) 100);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor2, textAnchor3, (-1.0d));
        org.jfree.chart.axis.TickType tickType7 = numberTick6.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick6.getRotationAnchor();
        double double9 = numberTick6.getValue();
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list11 = axisCollection10.getAxesAtTop();
        java.util.List list12 = axisCollection10.getAxesAtBottom();
        java.util.List list13 = axisCollection10.getAxesAtLeft();
        java.util.List list14 = axisCollection10.getAxesAtTop();
        boolean boolean15 = numberTick6.equals((java.lang.Object) axisCollection10);
        java.lang.Number number16 = numberTick6.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str4.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.0d + "'", number16.equals(2.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image11, "hi!", "ClassContext", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        java.awt.Image image20 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo24 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image20, "hi!", "ClassContext", "hi!");
        java.awt.Image image28 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo32 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image28, "hi!", "ClassContext", "hi!");
        projectInfo24.addLibrary((org.jfree.chart.ui.Library) projectInfo32);
        java.lang.String str34 = projectInfo32.getLicenceName();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo32);
        org.jfree.chart.ui.Library[] libraryArray36 = projectInfo32.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ClassContext" + "'", str34.equals("ClassContext"));
        org.junit.Assert.assertNotNull(libraryArray36);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = categoryItemRendererState1.getInfo();
        org.jfree.chart.entity.EntityCollection entityCollection4 = categoryItemRendererState1.getEntityCollection();
        categoryItemRendererState1.setBarWidth(0.05d);
        double double7 = categoryItemRendererState1.getBarWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertNull(entityCollection4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot3.getRenderer();
        java.lang.String str33 = categoryPlot3.getPlotType();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Category Plot" + "'", str33.equals("Category Plot"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(0.0d, rectangleEdge3);
        axisState1.cursorDown((double) 100L);
        axisState1.cursorUp(0.5d);
        double double9 = axisState1.getMax();
        double double10 = axisState1.getCursor();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.5d + "'", double10 == 99.5d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        java.lang.Object obj3 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color6 = color5.brighter();
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color6);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock10.calculateDimensions(graphics2D11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str16 = rectangleAnchor15.toString();
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, Double.NaN, 0.0d, rectangleAnchor15);
        try {
            categoryPlot0.drawBackground(graphics2D9, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleAnchor.CENTER" + "'", str16.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        java.awt.Image image12 = null;
        projectInfo7.setLogo(image12);
        java.lang.String str14 = projectInfo7.getName();
        projectInfo7.setLicenceText("35");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        java.lang.String str10 = legendItemEntity7.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str10.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image11, "hi!", "ClassContext", "hi!");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo15);
        projectInfo7.setName("RangeType.POSITIVE");
        projectInfo7.setCopyright("VerticalAlignment.CENTER");
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 1L, 4.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        java.awt.Stroke stroke16 = barRenderer0.getSeriesOutlineStroke((int) (byte) -1);
        boolean boolean19 = barRenderer0.getItemVisible(1, (int) '4');
        double double20 = barRenderer0.getUpperClip();
        double double21 = barRenderer0.getBase();
        boolean boolean22 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.awt.Paint paint12 = legendTitle10.getItemPaint();
        java.awt.Paint paint13 = legendTitle10.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle10.getLegendItemGraphicPadding();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color17 = java.awt.Color.WHITE;
        numberAxis16.setTickLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = numberAxis16.isVisible();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis16.valueToJava2D((double) (byte) 10, rectangle2D21, rectangleEdge22);
        java.awt.Paint paint24 = numberAxis16.getLabelPaint();
        numberAxis16.setAutoRangeStickyZero(false);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape33, (java.awt.Paint) color34);
        numberAxis16.setAxisLinePaint((java.awt.Paint) color34);
        legendTitle10.setBackgroundPaint((java.awt.Paint) color34);
        java.awt.Font font38 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendTitle10.setItemFont(font38);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis0);
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.lang.String str12 = legendTitle10.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle10.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean12 = numberAxis1.isAutoTickUnitSelection();
        org.jfree.data.RangeType rangeType13 = numberAxis1.getRangeType();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis1.setMarkerBand(markerAxisBand14);
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image19, "hi!", "ClassContext", "hi!");
        java.lang.String str24 = projectInfo23.getLicenceName();
        projectInfo23.setLicenceText("hi!");
        java.awt.Image image27 = projectInfo23.getLogo();
        projectInfo23.setInfo("ClassContext");
        projectInfo23.setVersion("RangeType.NEGATIVE");
        java.awt.Image image35 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo39 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image35, "hi!", "ClassContext", "hi!");
        java.lang.String str40 = projectInfo39.getLicenceName();
        projectInfo39.setLicenceText("hi!");
        java.awt.Image image43 = projectInfo39.getLogo();
        projectInfo39.setInfo("ClassContext");
        projectInfo39.setVersion("RangeType.NEGATIVE");
        projectInfo23.addLibrary((org.jfree.chart.ui.Library) projectInfo39);
        org.jfree.data.general.DatasetGroup datasetGroup49 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color52 = java.awt.Color.WHITE;
        numberAxis51.setTickLabelPaint((java.awt.Paint) color52);
        boolean boolean54 = numberAxis51.isVisible();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = numberAxis51.valueToJava2D((double) (byte) 10, rectangle2D56, rectangleEdge57);
        java.awt.Paint paint59 = numberAxis51.getTickMarkPaint();
        boolean boolean60 = datasetGroup49.equals((java.lang.Object) numberAxis51);
        org.jfree.data.Range range61 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double62 = range61.getUpperBound();
        org.jfree.data.Range range64 = org.jfree.data.Range.shift(range61, (double) 1L);
        numberAxis51.setRange(range64, true, false);
        java.lang.String str68 = range64.toString();
        boolean boolean69 = projectInfo23.equals((java.lang.Object) range64);
        numberAxis1.setRange(range64);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ClassContext" + "'", str24.equals("ClassContext"));
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ClassContext" + "'", str40.equals("ClassContext"));
        org.junit.Assert.assertNull(image43);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Range[1.0,2.0]" + "'", str68.equals("Range[1.0,2.0]"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape9, (java.awt.Paint) color10);
        barRenderer1.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color10, false);
        boolean boolean14 = barRenderer1.getAutoPopulateSeriesShape();
        barRenderer1.removeAnnotations();
        java.awt.Stroke stroke17 = barRenderer1.getSeriesOutlineStroke((int) (byte) -1);
        boolean boolean20 = barRenderer1.getItemVisible(1, (int) '4');
        double double21 = barRenderer1.getUpperClip();
        boolean boolean22 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) barRenderer1);
        java.lang.Object obj23 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        double double31 = numberAxis1.getUpperBound();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.05d + "'", double31 == 1.05d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = categoryPlot0.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryDataset5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        textTitle17.setText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.jfree.chart.text.TextBlock textBlock21 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine22 = null;
        textBlock21.addLine(textLine22);
        org.jfree.chart.text.TextBlock textBlock24 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.Size2D size2D26 = textBlock24.calculateDimensions(graphics2D25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textBlock24.getLineAlignment();
        textBlock21.setLineAlignment(horizontalAlignment27);
        textTitle17.setTextAlignment(horizontalAlignment27);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.lang.Object obj3 = labelBlock1.clone();
        java.awt.Font font4 = labelBlock1.getFont();
        java.lang.Object obj5 = labelBlock1.clone();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock7.calculateDimensions(graphics2D8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str13 = rectangleAnchor12.toString();
        java.awt.geom.Rectangle2D rectangle2D14 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, Double.NaN, 0.0d, rectangleAnchor12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = barRenderer17.getBaseShape();
        barRenderer17.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj23 = defaultDrawingSupplier22.clone();
        java.awt.Stroke stroke24 = defaultDrawingSupplier22.getNextStroke();
        barRenderer17.setSeriesStroke((int) 'a', stroke24);
        boolean boolean26 = barRenderer17.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer17);
        java.awt.Font font28 = legendTitle27.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle27.setLegendItemGraphicLocation(rectangleAnchor29);
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) 10.0f, 8.0d, rectangleAnchor29);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double33 = rectangleInsets32.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean35 = rectangleInsets32.equals((java.lang.Object) itemLabelAnchor34);
        org.jfree.chart.util.UnitType unitType36 = rectangleInsets32.getUnitType();
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double39 = labelBlock38.getWidth();
        java.lang.Object obj40 = labelBlock38.clone();
        java.awt.Font font41 = labelBlock38.getFont();
        labelBlock38.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D47 = labelBlock38.getBounds();
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets32.createOutsetRectangle(rectangle2D47);
        boolean boolean49 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D31, rectangle2D48);
        try {
            labelBlock1.draw(graphics2D6, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleAnchor.CENTER" + "'", str13.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(unitType36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        barRenderer5.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color14, false);
        boolean boolean18 = barRenderer5.getAutoPopulateSeriesShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = barRenderer19.getBaseShape();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.equal(shape23, shape26);
        barRenderer19.setBaseShape(shape23);
        java.awt.Stroke stroke30 = barRenderer19.lookupSeriesOutlineStroke(3);
        barRenderer5.setBaseStroke(stroke30);
        java.awt.Paint paint33 = barRenderer5.lookupSeriesOutlinePaint((int) '4');
        barRenderer0.setBasePaint(paint33, false);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesPaint(15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = barRenderer0.getURLGenerator((-1), (int) (short) 1);
        boolean boolean6 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) '4', (double) (short) 10, 8.0d, (double) 'a', (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape5 = barRenderer4.getBaseShape();
        barRenderer4.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj10 = defaultDrawingSupplier9.clone();
        java.awt.Stroke stroke11 = defaultDrawingSupplier9.getNextStroke();
        barRenderer4.setSeriesStroke((int) 'a', stroke11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = null;
        barRenderer4.setBaseToolTipGenerator(categoryToolTipGenerator13, false);
        java.awt.Color color18 = java.awt.Color.darkGray;
        java.awt.Color color19 = java.awt.Color.getColor("hi!", color18);
        barRenderer4.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color19);
        java.awt.Paint paint22 = barRenderer4.getSeriesFillPaint(3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = barRenderer4.getSeriesURLGenerator((int) (short) 10);
        java.awt.Stroke stroke26 = barRenderer4.lookupSeriesStroke(500);
        barRenderer0.setBaseOutlineStroke(stroke26);
        barRenderer0.setItemMargin((double) 1.0f);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(categoryURLGenerator24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(2, (int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        java.awt.Color color10 = java.awt.Color.gray;
        numberAxis1.setLabelPaint((java.awt.Paint) color10);
        float[] floatArray12 = null;
        float[] floatArray13 = color10.getColorComponents(floatArray12);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("EXPAND", font15, (java.awt.Paint) color16, rectangleEdge17, horizontalAlignment18, verticalAlignment21, rectangleInsets22);
        double double24 = rectangleInsets22.getTop();
        boolean boolean25 = plotOrientation3.equals((java.lang.Object) rectangleInsets22);
        categoryPlot0.setOrientation(plotOrientation3);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot0.getRowRenderingOrder();
        java.awt.Image image28 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis30);
        int int32 = categoryAxis30.getMaximumCategoryLabelLines();
        categoryPlot0.setDomainAxis(1, categoryAxis30);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = barRenderer12.getItemPaint((int) (short) 10, 0);
        java.awt.Font font29 = barRenderer12.getBaseItemLabelFont();
        double double30 = barRenderer12.getLowerClip();
        java.awt.Paint paint33 = barRenderer12.getItemFillPaint(10, (-1));
        java.awt.Paint paint34 = barRenderer12.getBaseOutlinePaint();
        legendTitle10.setBackgroundPaint(paint34);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color12 = java.awt.Color.WHITE;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = numberAxis11.isVisible();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis11.valueToJava2D((double) (byte) 10, rectangle2D16, rectangleEdge17);
        java.awt.Paint paint19 = numberAxis11.getTickMarkPaint();
        numberAxis11.setVisible(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape30, (java.awt.Paint) color31);
        barRenderer22.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color31, false);
        boolean boolean35 = barRenderer22.getAutoPopulateSeriesShape();
        java.awt.Paint paint38 = barRenderer22.getItemPaint((int) (short) 10, 0);
        numberAxis11.setTickMarkPaint(paint38);
        boolean boolean40 = legendItemEntity7.equals((java.lang.Object) numberAxis11);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset41 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset41);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset41, false);
        int int45 = defaultStatisticalCategoryDataset41.getColumnCount();
        legendItemEntity7.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset41);
        try {
            java.lang.Number number49 = defaultStatisticalCategoryDataset41.getMeanValue((int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        categoryPlot3.clearRangeAxes();
        int int33 = categoryPlot3.getDomainAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 15);
        java.awt.Paint paint36 = valueMarker35.getLabelPaint();
        categoryPlot3.setRangeGridlinePaint(paint36);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color33 = java.awt.Color.WHITE;
        numberAxis32.setTickLabelPaint((java.awt.Paint) color33);
        boolean boolean35 = numberAxis32.isVisible();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = numberAxis32.valueToJava2D((double) (byte) 10, rectangle2D37, rectangleEdge38);
        java.awt.Paint paint40 = numberAxis32.getLabelPaint();
        numberAxis32.setAutoRangeStickyZero(false);
        numberAxis32.setTickMarksVisible(true);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape47, 0.0d, 0.0f, 1.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity54 = new org.jfree.chart.entity.TickLabelEntity(shape51, "", "hi!");
        numberAxis32.setLeftArrow(shape51);
        categoryPlot3.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        java.awt.Paint paint57 = categoryPlot3.getRangeGridlinePaint();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.plot.Plot plot31 = categoryPlot3.getRootPlot();
        categoryPlot3.setRangeCrosshairValue(100.0d);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(plot31);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis3.setLowerMargin(0.0d);
        java.awt.Font font6 = categoryAxis3.getLabelFont();
        java.awt.Color color7 = java.awt.Color.white;
        java.awt.Color color8 = color7.darker();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BASELINE_RIGHT", font6, (java.awt.Paint) color7);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("", font6);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(textBlock9);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) Double.NaN, (java.lang.Number) Double.NaN);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        boolean boolean16 = labelBlock1.equals((java.lang.Object) "ClassContext");
        java.lang.String str17 = labelBlock1.getURLText();
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        java.lang.Comparable comparable20 = null;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity26 = new org.jfree.chart.entity.CategoryLabelEntity(comparable20, shape23, "hi!", "ThreadContext");
        boolean boolean27 = categoryLabelPositions19.equals((java.lang.Object) "hi!");
        boolean boolean28 = lineBorder18.equals((java.lang.Object) categoryLabelPositions19);
        java.awt.Stroke stroke29 = lineBorder18.getStroke();
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, 0.0d, (double) (byte) 0, (double) 100L);
        java.awt.Paint paint35 = blockBorder34.getPaint();
        boolean boolean36 = lineBorder18.equals((java.lang.Object) paint35);
        java.awt.Paint paint37 = lineBorder18.getPaint();
        boolean boolean38 = labelBlock1.equals((java.lang.Object) lineBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape11 = barRenderer10.getBaseShape();
        barRenderer10.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = barRenderer10.getLegendItems();
        boolean boolean15 = legendItem8.equals((java.lang.Object) barRenderer10);
        java.lang.Comparable comparable16 = legendItem8.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(comparable16);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str2 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 2.0f);
        categoryAxis0.configure();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        org.jfree.data.general.Dataset dataset10 = legendItemEntity7.getDataset();
        java.lang.String str11 = legendItemEntity7.getShapeType();
        org.jfree.data.general.Dataset dataset12 = legendItemEntity7.getDataset();
        java.lang.Comparable comparable13 = legendItemEntity7.getSeriesKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
        org.junit.Assert.assertNull(dataset12);
        org.junit.Assert.assertNull(comparable13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        double double3 = textTitle0.getContentXOffset();
        java.lang.String str4 = textTitle0.getText();
        java.awt.Paint paint5 = textTitle0.getBackgroundPaint();
        textTitle0.setNotify(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint6 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis4.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float11 = categoryAxis4.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        categoryAxis4.addChangeListener(axisChangeListener12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState(1.0d);
        axisState16.cursorDown((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType19 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock25 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = textBlock25.calculateDimensions(graphics2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str31 = rectangleAnchor30.toString();
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, Double.NaN, 0.0d, rectangleAnchor30);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets24.createOutsetRectangle(rectangle2D32);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color37 = java.awt.Color.WHITE;
        numberAxis36.setTickLabelPaint((java.awt.Paint) color37);
        boolean boolean39 = numberAxis36.isVisible();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis36.valueToJava2D((double) (byte) 10, rectangle2D41, rectangleEdge42);
        java.awt.Paint paint44 = numberAxis36.getTickMarkPaint();
        java.awt.Font font45 = numberAxis36.getLabelFont();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = textTitle50.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("EXPAND", font45, (java.awt.Paint) color46, rectangleEdge47, horizontalAlignment48, verticalAlignment51, rectangleInsets52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge47);
        java.util.List list55 = categoryAxis4.refreshTicks(graphics2D14, axisState16, rectangle2D32, rectangleEdge54);
        categoryPlot0.setDomainAxis(categoryAxis4);
        boolean boolean57 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleAnchor.CENTER" + "'", str31.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Color color18 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color18);
        barRenderer0.setSeriesPaint(1, (java.awt.Paint) color18);
        int int21 = color18.getRGB();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-20561) + "'", int21 == (-20561));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        barRenderer0.setSeriesToolTipGenerator(2, categoryToolTipGenerator24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = legendTitle26.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlock textBlock28 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = textBlock28.calculateDimensions(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str34 = rectangleAnchor33.toString();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, Double.NaN, 0.0d, rectangleAnchor33);
        org.jfree.data.Range range36 = null;
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double38 = range37.getCentralValue();
        boolean boolean41 = range37.intersects((double) (byte) 100, 100.0d);
        double double43 = range37.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint(range36, range37);
        double double46 = range37.constrain((double) 2);
        org.jfree.data.Range range48 = org.jfree.data.Range.shift(range37, (double) (byte) 100);
        boolean boolean49 = rectangleAnchor33.equals((java.lang.Object) range37);
        legendTitle26.setLegendItemGraphicLocation(rectangleAnchor33);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleAnchor.CENTER" + "'", str34.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.5d + "'", double38 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.awt.Color color2 = java.awt.Color.getColor("1", 15);
        int int3 = color2.getGreen();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        java.lang.Comparable comparable1 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity7 = new org.jfree.chart.entity.CategoryLabelEntity(comparable1, shape4, "hi!", "ThreadContext");
        boolean boolean8 = categoryLabelPositions0.equals((java.lang.Object) "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor16, textBlockAnchor17);
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryLabelPosition18.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = categoryLabelPosition18.getCategoryAnchor();
        double double21 = categoryLabelPosition18.getAngle();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str28 = textAnchor27.toString();
        org.jfree.chart.axis.NumberTick numberTick30 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor26, textAnchor27, (-1.0d));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition34 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor32, textBlockAnchor33);
        org.jfree.chart.text.TextAnchor textAnchor35 = categoryLabelPosition34.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = categoryLabelPosition34.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType37 = categoryLabelPosition34.getWidthType();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition39 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor22, textBlockAnchor23, textAnchor26, Double.NaN, categoryLabelWidthType37, (float) 3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions40 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition11, categoryLabelPosition15, categoryLabelPosition18, categoryLabelPosition39);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str28.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(categoryLabelWidthType37);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint6 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis4.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float11 = categoryAxis4.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        categoryAxis4.addChangeListener(axisChangeListener12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState16 = new org.jfree.chart.axis.AxisState(1.0d);
        axisState16.cursorDown((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType19 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock25 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.util.Size2D size2D27 = textBlock25.calculateDimensions(graphics2D26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str31 = rectangleAnchor30.toString();
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, Double.NaN, 0.0d, rectangleAnchor30);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets24.createOutsetRectangle(rectangle2D32);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color37 = java.awt.Color.WHITE;
        numberAxis36.setTickLabelPaint((java.awt.Paint) color37);
        boolean boolean39 = numberAxis36.isVisible();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis36.valueToJava2D((double) (byte) 10, rectangle2D41, rectangleEdge42);
        java.awt.Paint paint44 = numberAxis36.getTickMarkPaint();
        java.awt.Font font45 = numberAxis36.getLabelFont();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = textTitle50.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("EXPAND", font45, (java.awt.Paint) color46, rectangleEdge47, horizontalAlignment48, verticalAlignment51, rectangleInsets52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge47);
        java.util.List list55 = categoryAxis4.refreshTicks(graphics2D14, axisState16, rectangle2D32, rectangleEdge54);
        categoryPlot0.setDomainAxis(categoryAxis4);
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape59 = barRenderer58.getBaseShape();
        barRenderer58.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection62 = barRenderer58.getLegendItems();
        java.awt.Paint paint64 = barRenderer58.getSeriesFillPaint(2);
        boolean boolean65 = axisLocation57.equals((java.lang.Object) 2);
        java.lang.String str66 = axisLocation57.toString();
        categoryPlot0.setDomainAxisLocation(axisLocation57);
        java.awt.Image image68 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleAnchor.CENTER" + "'", str31.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(legendItemCollection62);
        org.junit.Assert.assertNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str66.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(image68);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("DatasetRenderingOrder.FORWARD");
        java.util.Set<java.lang.String> strSet6 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet7 = jFreeChartResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration8 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertNotNull(strEnumeration8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis1.getTickUnit();
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double15 = range14.getCentralValue();
        boolean boolean18 = range14.intersects((double) (byte) 100, 100.0d);
        double double20 = range14.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range14);
        double double23 = range14.constrain((double) 2);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range14, (double) (byte) 100);
        numberAxis1.setDefaultAutoRange(range14);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(tickUnitSource27);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint(2);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        boolean boolean10 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        textTitle1.setExpandToFitSpace(false);
        double double4 = textTitle1.getContentXOffset();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets2.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean5 = rectangleInsets2.equals((java.lang.Object) itemLabelAnchor4);
        labelBlock1.setPadding(rectangleInsets2);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        boolean boolean16 = labelBlock1.equals((java.lang.Object) "ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = labelBlock1.getMargin();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        java.awt.Paint paint14 = barRenderer0.getItemPaint((int) '4', 2);
        barRenderer0.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getRotationAnchor();
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3, textAnchor5, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeListener axisChangeListener9 = null;
        categoryAxis1.addChangeListener(axisChangeListener9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(1.0d);
        axisState13.cursorDown((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType16 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock22 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.util.Size2D size2D24 = textBlock22.calculateDimensions(graphics2D23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str28 = rectangleAnchor27.toString();
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, Double.NaN, 0.0d, rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets21.createOutsetRectangle(rectangle2D29);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color34 = java.awt.Color.WHITE;
        numberAxis33.setTickLabelPaint((java.awt.Paint) color34);
        boolean boolean36 = numberAxis33.isVisible();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis33.valueToJava2D((double) (byte) 10, rectangle2D38, rectangleEdge39);
        java.awt.Paint paint41 = numberAxis33.getTickMarkPaint();
        java.awt.Font font42 = numberAxis33.getLabelFont();
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = textTitle47.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("EXPAND", font42, (java.awt.Paint) color43, rectangleEdge44, horizontalAlignment45, verticalAlignment48, rectangleInsets49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge44);
        java.util.List list52 = categoryAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D29, rectangleEdge51);
        categoryAxis1.setCategoryLabelPositionOffset((int) (short) 1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleAnchor.CENTER" + "'", str28.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(list52);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer12.setSeriesOutlinePaint((int) '4', paint27);
        barRenderer0.setBaseFillPaint(paint27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        barRenderer0.setBasePaint((java.awt.Paint) color30);
        java.awt.Stroke stroke33 = barRenderer0.getSeriesOutlineStroke(0);
        double double34 = barRenderer0.getMaximumBarWidth();
        barRenderer0.setSeriesVisible(10, (java.lang.Boolean) false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot39.getRangeAxis(0);
        int int42 = categoryPlot39.getBackgroundImageAlignment();
        categoryPlot39.setAnchorValue(1.0d);
        boolean boolean45 = barRenderer0.hasListener((java.util.EventListener) categoryPlot39);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis6.configure();
        java.awt.Paint paint8 = numberAxis6.getTickLabelPaint();
        barRenderer0.setBaseFillPaint(paint8, false);
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        numberAxis1.setStandardTickUnits(tickUnitSource3);
        numberAxis1.configure();
        float float6 = numberAxis1.getTickMarkOutsideLength();
        boolean boolean7 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) (short) 100);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener3);
        java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) "RangeType.FULL", (java.lang.Comparable) (short) 10);
        java.lang.Object obj8 = defaultStatisticalCategoryDataset0.clone();
        java.lang.Comparable comparable9 = null;
        java.lang.Number number11 = defaultStatisticalCategoryDataset0.getValue(comparable9, (java.lang.Comparable) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(0.0d, rectangleEdge3);
        axisState1.cursorDown((double) 100L);
        java.util.List list7 = axisState1.getTicks();
        axisState1.cursorLeft((double) 10);
        double double10 = axisState1.getMax();
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = categoryPlot0.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge((int) '#');
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer0.getPositiveItemLabelPosition(2, (-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator25);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double4 = range3.getCentralValue();
        boolean boolean7 = range3.intersects((double) (byte) 100, 100.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range3);
        boolean boolean9 = categoryLabelWidthType0.equals((java.lang.Object) range3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape18, (java.awt.Paint) color19);
        barRenderer10.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color19, false);
        boolean boolean23 = barRenderer10.getAutoPopulateSeriesShape();
        java.awt.Paint paint25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer10.setSeriesOutlinePaint((int) '4', paint25);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = barRenderer10.getBaseItemLabelGenerator();
        barRenderer10.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = barRenderer10.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        barRenderer10.setSeriesToolTipGenerator(2, categoryToolTipGenerator34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer10);
        java.awt.Font font37 = legendTitle36.getItemFont();
        org.jfree.chart.block.BlockContainer blockContainer38 = legendTitle36.getItemContainer();
        boolean boolean39 = categoryLabelWidthType0.equals((java.lang.Object) legendTitle36);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryItemLabelGenerator27);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(blockContainer38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape12, (java.awt.Paint) color13);
        barRenderer4.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color13, false);
        boolean boolean17 = barRenderer4.getAutoPopulateSeriesShape();
        java.awt.Paint paint18 = barRenderer4.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer4.getSeriesPositiveItemLabelPosition((int) (short) 1);
        java.awt.Shape shape23 = barRenderer4.getItemShape((int) (byte) -1, 0);
        java.awt.Paint paint24 = null;
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke28 = lineBorder27.getStroke();
        java.awt.Stroke stroke29 = lineBorder27.getStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis32.setLowerMargin(0.0d);
        java.awt.Font font35 = categoryAxis32.getLabelFont();
        java.awt.Color color36 = java.awt.Color.white;
        java.awt.Color color37 = color36.darker();
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BASELINE_RIGHT", font35, (java.awt.Paint) color36);
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape40 = barRenderer39.getBaseShape();
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean47 = org.jfree.chart.util.ShapeUtilities.equal(shape43, shape46);
        barRenderer39.setBaseShape(shape43);
        java.awt.Stroke stroke50 = barRenderer39.lookupSeriesOutlineStroke(3);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color26, stroke29, (java.awt.Paint) color36, stroke50, 0.0f);
        java.lang.Comparable comparable57 = null;
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity63 = new org.jfree.chart.entity.CategoryLabelEntity(comparable57, shape60, "hi!", "ThreadContext");
        org.jfree.chart.entity.ChartEntity chartEntity64 = new org.jfree.chart.entity.ChartEntity(shape60);
        org.jfree.chart.renderer.category.BarRenderer barRenderer65 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape73 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color74 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape73, (java.awt.Paint) color74);
        barRenderer65.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color74, false);
        boolean boolean78 = barRenderer65.getAutoPopulateSeriesShape();
        java.awt.Paint paint81 = barRenderer65.getItemPaint((int) (short) 10, 0);
        java.awt.Font font82 = barRenderer65.getBaseItemLabelFont();
        double double83 = barRenderer65.getLowerClip();
        java.awt.Paint paint86 = barRenderer65.getItemFillPaint(10, (-1));
        barRenderer65.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke89 = barRenderer65.getBaseOutlineStroke();
        java.awt.Color color90 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color91 = color90.brighter();
        org.jfree.chart.LegendItem legendItem92 = new org.jfree.chart.LegendItem("Range[1.0,2.0]", "AxisLabelEntity: label = hi!", "Layer.FOREGROUND", "ItemLabelAnchor.INSIDE5", shape60, stroke89, (java.awt.Paint) color90);
        try {
            org.jfree.chart.LegendItem legendItem93 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "RangeType.POSITIVE", "35", "Range[1.0,2.0]", shape23, paint24, stroke29, (java.awt.Paint) color90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(textBlock38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(paint86);
        org.junit.Assert.assertNotNull(stroke89);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertNotNull(color91);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) textBlockAnchor7);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double10 = range9.getCentralValue();
        double double11 = range9.getLowerBound();
        boolean boolean12 = textBlockAnchor7.equals((java.lang.Object) double11);
        textBlock0.draw(graphics2D3, (float) (-20561), 1.0f, textBlockAnchor7, (float) (short) 0, 0.0f, (double) 35);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock1, textBlockAnchor2, textAnchor3, (double) (-1L));
        java.lang.String str6 = categoryTick5.getText();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        barRenderer0.removeAnnotations();
        java.awt.Stroke stroke16 = barRenderer0.getSeriesOutlineStroke((int) (byte) -1);
        boolean boolean19 = barRenderer0.getItemVisible(1, (int) '4');
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        barRenderer0.setSeriesPaint(2, (java.awt.Paint) color21, false);
        org.jfree.chart.LegendItem legendItem26 = barRenderer0.getLegendItem((int) '4', 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator28, true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(legendItem26);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.lang.Object obj3 = labelBlock1.clone();
        java.awt.Font font4 = labelBlock1.getFont();
        labelBlock1.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D10 = labelBlock1.getBounds();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        java.awt.Stroke stroke9 = legendItem8.getOutlineStroke();
        int int10 = legendItem8.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        java.awt.Stroke stroke11 = barRenderer0.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer12.setSeriesOutlinePaint((int) '4', paint27);
        barRenderer0.setBaseFillPaint(paint27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        barRenderer0.setBasePaint((java.awt.Paint) color30);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = barRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation35 = null;
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            barRenderer0.addAnnotation(categoryAnnotation35, layer36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
        org.junit.Assert.assertNotNull(layer36);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        java.awt.Color color18 = java.awt.Color.PINK;
        org.jfree.chart.block.BlockBorder blockBorder19 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (byte) 100, (double) '4', 1.0d, (java.awt.Paint) color18);
        barRenderer0.setSeriesPaint(1, (java.awt.Paint) color18);
        boolean boolean22 = barRenderer0.isSeriesItemLabelsVisible((int) (short) 1);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        java.lang.String str19 = textTitle17.getText();
        java.lang.String str20 = textTitle17.getToolTipText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        int int19 = barRenderer0.getColumnCount();
        java.awt.Font font21 = barRenderer0.getSeriesItemLabelFont(3);
        org.jfree.chart.util.UnitType unitType22 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets(unitType22, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock28 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = textBlock28.calculateDimensions(graphics2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str34 = rectangleAnchor33.toString();
        java.awt.geom.Rectangle2D rectangle2D35 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D30, Double.NaN, 0.0d, rectangleAnchor33);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets27.createOutsetRectangle(rectangle2D35);
        barRenderer0.setBaseShape((java.awt.Shape) rectangle2D36);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double39 = rectangleInsets38.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor40 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean41 = rectangleInsets38.equals((java.lang.Object) itemLabelAnchor40);
        org.jfree.chart.util.UnitType unitType42 = rectangleInsets38.getUnitType();
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double45 = labelBlock44.getWidth();
        java.lang.Object obj46 = labelBlock44.clone();
        java.awt.Font font47 = labelBlock44.getFont();
        labelBlock44.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D53 = labelBlock44.getBounds();
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets38.createOutsetRectangle(rectangle2D53);
        boolean boolean55 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D36, rectangle2D54);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleAnchor.CENTER" + "'", str34.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection4.addAll(legendItemCollection5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = barRenderer7.getBaseShape();
        barRenderer7.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = barRenderer7.getLegendItems();
        legendItemCollection4.addAll(legendItemCollection11);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberAxis2.getLabelURL();
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = numberAxis2.hasListener(eventListener14);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) ' ', shape19, "", "TextAnchor.BASELINE_RIGHT");
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, (double) (short) 0, (double) 1);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity28 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis2, shape25, "EXPAND", "RangeType.NEGATIVE");
        java.lang.String str29 = axisLabelEntity28.toString();
        org.jfree.chart.axis.Axis axis30 = axisLabelEntity28.getAxis();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisLabelEntity: label = hi!" + "'", str29.equals("AxisLabelEntity: label = hi!"));
        org.junit.Assert.assertNotNull(axis30);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        barRenderer0.setSeriesToolTipGenerator(2, categoryToolTipGenerator24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.block.BlockContainer blockContainer27 = legendTitle26.getItemContainer();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(blockContainer27);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        size2D2.width = 100.0f;
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 1);
        java.awt.Shape shape19 = barRenderer0.getItemShape((int) (byte) -1, 0);
        org.jfree.chart.ChartColor chartColor23 = new org.jfree.chart.ChartColor((int) ' ', 1, 0);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) chartColor23);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(paint9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image3, "hi!", "ClassContext", "hi!");
        java.lang.String str8 = projectInfo7.getLicenceName();
        projectInfo7.setLicenceText("hi!");
        java.awt.Image image11 = projectInfo7.getLogo();
        projectInfo7.setInfo("ClassContext");
        projectInfo7.setVersion("RangeType.NEGATIVE");
        java.awt.Image image19 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo23 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "hi!", image19, "hi!", "ClassContext", "hi!");
        java.lang.String str24 = projectInfo23.getLicenceName();
        projectInfo23.setLicenceText("hi!");
        java.awt.Image image27 = projectInfo23.getLogo();
        projectInfo23.setInfo("ClassContext");
        projectInfo23.setVersion("RangeType.NEGATIVE");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo23);
        org.jfree.data.general.DatasetGroup datasetGroup33 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color36 = java.awt.Color.WHITE;
        numberAxis35.setTickLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = numberAxis35.isVisible();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis35.valueToJava2D((double) (byte) 10, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getTickMarkPaint();
        boolean boolean44 = datasetGroup33.equals((java.lang.Object) numberAxis35);
        org.jfree.data.Range range45 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double46 = range45.getUpperBound();
        org.jfree.data.Range range48 = org.jfree.data.Range.shift(range45, (double) 1L);
        numberAxis35.setRange(range48, true, false);
        java.lang.String str52 = range48.toString();
        boolean boolean53 = projectInfo7.equals((java.lang.Object) range48);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint(range48, (double) 8);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ClassContext" + "'", str8.equals("ClassContext"));
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "ClassContext" + "'", str24.equals("ClassContext"));
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Range[1.0,2.0]" + "'", str52.equals("Range[1.0,2.0]"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle10.setLegendItemGraphicLocation(rectangleAnchor12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double17 = range16.getCentralValue();
        boolean boolean20 = range16.intersects((double) (byte) 100, 100.0d);
        double double22 = range16.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range15, range16);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint23.toUnconstrainedWidth();
        double double25 = rectangleConstraint24.getWidth();
        org.jfree.chart.util.Size2D size2D26 = legendTitle10.arrange(graphics2D14, rectangleConstraint24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        legendTitle10.setBackgroundPaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        java.awt.Paint paint10 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 100, paint10);
        java.awt.Font font12 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        barRenderer0.setBaseItemLabelFont(font12, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape23, (java.awt.Paint) color24);
        barRenderer15.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color24, false);
        boolean boolean28 = barRenderer15.getAutoPopulateSeriesShape();
        java.awt.Paint paint31 = barRenderer15.getItemPaint((int) (short) 10, 0);
        java.awt.Font font32 = barRenderer15.getBaseItemLabelFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = barRenderer15.getNegativeItemLabelPosition((int) (byte) 1, (int) (byte) 0);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition35);
        barRenderer0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color21 = java.awt.Color.WHITE;
        numberAxis20.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis20.isVisible();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis20.valueToJava2D((double) (byte) 10, rectangle2D25, rectangleEdge26);
        java.awt.Paint paint28 = numberAxis20.getLabelPaint();
        numberAxis20.setAutoRangeStickyZero(false);
        boolean boolean31 = numberAxis20.isInverted();
        double double32 = numberAxis20.getUpperBound();
        boolean boolean33 = categoryItemEntity18.equals((java.lang.Object) numberAxis20);
        java.awt.Paint paint34 = numberAxis20.getTickMarkPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape43, (java.awt.Paint) color44);
        barRenderer35.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color44, false);
        boolean boolean48 = barRenderer35.getAutoPopulateSeriesShape();
        java.awt.Paint paint51 = barRenderer35.getItemPaint((int) (short) 10, 0);
        java.awt.Font font52 = barRenderer35.getBaseItemLabelFont();
        double double53 = barRenderer35.getLowerClip();
        java.awt.Paint paint56 = barRenderer35.getItemFillPaint(10, (-1));
        barRenderer35.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke59 = barRenderer35.getBaseOutlineStroke();
        numberAxis20.setTickMarkStroke(stroke59);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("EXPAND", font11, (java.awt.Paint) color12, rectangleEdge13, horizontalAlignment14, verticalAlignment17, rectangleInsets18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets18, (java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        org.jfree.data.general.Dataset dataset10 = legendItemEntity7.getDataset();
        java.lang.String str11 = legendItemEntity7.getShapeType();
        org.jfree.data.general.Dataset dataset12 = legendItemEntity7.getDataset();
        java.lang.String str13 = legendItemEntity7.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
        org.junit.Assert.assertNull(dataset12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str13.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle16.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("EXPAND", font11, (java.awt.Paint) color12, rectangleEdge13, horizontalAlignment14, verticalAlignment17, rectangleInsets18);
        double double21 = rectangleInsets18.calculateRightInset((double) (byte) -1);
        java.lang.String str22 = rectangleInsets18.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str22.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        boolean boolean10 = numberAxis1.isNegativeArrowVisible();
        double double11 = numberAxis1.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis1.getTickUnit();
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double15 = range14.getCentralValue();
        boolean boolean18 = range14.intersects((double) (byte) 100, 100.0d);
        double double20 = range14.constrain((double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range14);
        double double23 = range14.constrain((double) 2);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range14, (double) (byte) 100);
        numberAxis1.setDefaultAutoRange(range14);
        boolean boolean27 = numberAxis1.isVisible();
        java.lang.String str28 = numberAxis1.getLabel();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        java.util.List list3 = keyedObjects0.getKeys();
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        boolean boolean15 = datasetGroup4.equals((java.lang.Object) numberAxis6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis6.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color19 = java.awt.Color.WHITE;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = numberAxis18.isVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis18.valueToJava2D((double) (byte) 10, rectangle2D23, rectangleEdge24);
        java.awt.Paint paint26 = numberAxis18.getLabelPaint();
        numberAxis18.setAutoRangeStickyZero(false);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape35, (java.awt.Paint) color36);
        numberAxis18.setAxisLinePaint((java.awt.Paint) color36);
        numberAxis18.setPositiveArrowVisible(true);
        int int41 = numberTickUnit16.compareTo((java.lang.Object) numberAxis18);
        int int42 = keyedObjects0.getIndex((java.lang.Comparable) int41);
        java.lang.Object obj44 = keyedObjects0.getObject((java.lang.Comparable) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer45 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape46 = barRenderer45.getBaseShape();
        barRenderer45.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj51 = defaultDrawingSupplier50.clone();
        java.awt.Stroke stroke52 = defaultDrawingSupplier50.getNextStroke();
        barRenderer45.setSeriesStroke((int) 'a', stroke52);
        java.awt.Paint paint55 = null;
        barRenderer45.setSeriesOutlinePaint((int) (byte) 100, paint55);
        barRenderer45.setSeriesVisible((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean60 = keyedObjects0.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ClassContext", "RangeType.NEGATIVE", categoryDataset13, (java.lang.Comparable) 0.0d, (java.lang.Comparable) 3);
        categoryItemEntity18.setColumnKey((java.lang.Comparable) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryItemEntity18.getDataset();
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset21, (java.lang.Comparable) 10.0d);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset23, (java.lang.Comparable) 2.0f, 0.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertNotNull(pieDataset26);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.String str8 = legendItemEntity7.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str8.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.util.List list2 = keyedObjects2D0.getRowKeys();
        java.lang.Object obj3 = null;
        boolean boolean4 = keyedObjects2D0.equals(obj3);
        try {
            java.lang.Comparable comparable6 = keyedObjects2D0.getRowKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.centerRange((double) 2);
        java.awt.Shape shape4 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        numberAxis1.setStandardTickUnits(tickUnitSource3);
        numberAxis1.configure();
        float float6 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.TickUnits tickUnits7 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Shape shape17 = numberAxis9.getLeftArrow();
        boolean boolean18 = numberAxis9.isNegativeArrowVisible();
        double double19 = numberAxis9.getLowerBound();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = numberAxis9.getTickUnit();
        tickUnits7.add((org.jfree.chart.axis.TickUnit) numberTickUnit20);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        tickUnits7.add((org.jfree.chart.axis.TickUnit) numberTickUnit22);
        numberAxis1.setTickUnit(numberTickUnit22, false, true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(numberTickUnit22);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Shape shape12 = numberAxis1.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis1.getStandardTickUnits();
        numberAxis1.setLabelAngle(1.0E-8d);
        boolean boolean16 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape11 = barRenderer10.getBaseShape();
        barRenderer10.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = barRenderer10.getLegendItems();
        boolean boolean15 = legendItem8.equals((java.lang.Object) barRenderer10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem8);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.lang.Comparable comparable4 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity10 = new org.jfree.chart.entity.CategoryLabelEntity(comparable4, shape7, "hi!", "ThreadContext");
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape20, (java.awt.Paint) color21);
        barRenderer12.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color21, false);
        boolean boolean25 = barRenderer12.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = barRenderer12.getItemPaint((int) (short) 10, 0);
        java.awt.Font font29 = barRenderer12.getBaseItemLabelFont();
        double double30 = barRenderer12.getLowerClip();
        java.awt.Paint paint33 = barRenderer12.getItemFillPaint(10, (-1));
        barRenderer12.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke36 = barRenderer12.getBaseOutlineStroke();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color38 = color37.brighter();
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("Range[1.0,2.0]", "AxisLabelEntity: label = hi!", "Layer.FOREGROUND", "ItemLabelAnchor.INSIDE5", shape7, stroke36, (java.awt.Paint) color37);
        java.awt.color.ColorSpace colorSpace40 = color37.getColorSpace();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(colorSpace40);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection4.addAll(legendItemCollection5);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape13, (java.awt.Paint) color14);
        legendItemCollection5.add(legendItem15);
        legendItem15.setDatasetIndex((int) '#');
        legendItem15.setDatasetIndex((-1));
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.lang.String str2 = textFragment1.getText();
        java.lang.Object obj3 = null;
        boolean boolean4 = textFragment1.equals(obj3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            textFragment1.draw(graphics2D5, (float) 35, 0.0f, textAnchor8, 2.0f, (float) 0, 0.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double2 = labelBlock1.getWidth();
        java.awt.Font font3 = labelBlock1.getFont();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleAnchor.CENTER");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        try {
            float float7 = textFragment1.calculateBaselineOffset(graphics2D3, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.CENTER" + "'", str2.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = barRenderer2.getBaseShape();
        barRenderer2.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj8 = defaultDrawingSupplier7.clone();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        barRenderer2.setSeriesStroke((int) 'a', stroke9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = barRenderer2.equals((java.lang.Object) textTitle19);
        int int21 = barRenderer2.getColumnCount();
        java.awt.Font font23 = barRenderer2.getSeriesItemLabelFont(3);
        boolean boolean24 = textFragment1.equals((java.lang.Object) barRenderer2);
        float float25 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getCentralValue();
        boolean boolean4 = range0.intersects((double) (byte) 100, 100.0d);
        double double6 = range0.constrain((double) (short) 1);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range0, 1.0E-8d);
        double double11 = rectangleConstraint10.getHeight();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getCentralValue();
        boolean boolean16 = range12.intersects((double) (byte) 100, 100.0d);
        double double18 = range12.constrain((double) (short) 1);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range12, range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint10.toRangeHeight(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint10.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-8d + "'", double11 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        java.lang.Comparable comparable3 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity(comparable3, shape6, "hi!", "ThreadContext");
        boolean boolean10 = categoryLabelPositions2.equals((java.lang.Object) "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions2, categoryLabelPosition13);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
        java.awt.Paint paint16 = categoryAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape8);
        barRenderer1.setBaseShape(shape5);
        java.awt.Stroke stroke12 = barRenderer1.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        boolean boolean26 = barRenderer13.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer13.setSeriesOutlinePaint((int) '4', paint28);
        barRenderer1.setBaseFillPaint(paint28);
        double double31 = barRenderer1.getMinimumBarLength();
        barRenderer1.setBaseSeriesVisibleInLegend(true);
        java.awt.Font font36 = barRenderer1.getItemLabelFont(3, (int) 'a');
        java.awt.Paint paint37 = null;
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer41 = new org.jfree.chart.text.G2TextMeasurer(graphics2D40);
        try {
            org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("-3,-3,3,3", font36, paint37, (float) (short) 1, 2, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        java.awt.Paint paint10 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 100, paint10);
        try {
            barRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        double double32 = categoryPlot3.getAnchorValue();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean9 = legendItemEntity7.equals((java.lang.Object) categoryAnchor8);
        org.jfree.data.general.Dataset dataset10 = legendItemEntity7.getDataset();
        java.lang.String str11 = legendItemEntity7.getShapeType();
        java.lang.String str12 = legendItemEntity7.getURLText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(dataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean9 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape8);
        barRenderer1.setBaseShape(shape5);
        java.awt.Stroke stroke12 = barRenderer1.lookupSeriesOutlineStroke(3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape21, (java.awt.Paint) color22);
        barRenderer13.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color22, false);
        boolean boolean26 = barRenderer13.getAutoPopulateSeriesShape();
        java.awt.Paint paint28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer13.setSeriesOutlinePaint((int) '4', paint28);
        barRenderer1.setBaseFillPaint(paint28);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint28);
        double double33 = rectangleInsets0.trimHeight((double) 15);
        double double35 = rectangleInsets0.calculateLeftInset(99.5d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 15.0d + "'", double33 == 15.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean8 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape7);
        barRenderer0.setBaseShape(shape4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Paint paint13 = barRenderer0.lookupSeriesOutlinePaint((int) 'a');
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean6 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape5);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.String str8 = legendItemEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1,1,-1,1,-1,-1,1,-1,1,1,-1,1,-1,-1,1,-1,1,1,-1,1,-1,-1,1,-1,1,-1" + "'", str8.equals("1,1,-1,1,-1,-1,1,-1,1,1,-1,1,-1,-1,1,-1,1,1,-1,1,-1,-1,1,-1,1,-1"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape3, "hi!", "ThreadContext");
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        double double7 = rectangleInsets5.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis1.setLowerMargin(0.0d);
        java.awt.Font font4 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle10.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = textTitle10.getPosition();
        double double13 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor5, (int) (byte) 100, 0, rectangle2D8, rectangleEdge12);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        double double10 = numberAxis1.getLowerBound();
        try {
            numberAxis1.setRangeWithMargins((double) 100L, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (32.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.util.Layer layer3 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str4 = layer3.toString();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape11, (java.awt.Paint) color12);
        int int14 = legendItem13.getSeriesIndex();
        legendItem13.setSeriesKey((java.lang.Comparable) true);
        boolean boolean17 = layer3.equals((java.lang.Object) true);
        java.util.Collection collection18 = categoryPlot0.getRangeMarkers(0, layer3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(layer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Layer.FOREGROUND" + "'", str4.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, 1.0d);
        size2D2.height = (short) 0;
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint14 = barRenderer0.getBaseFillPaint();
        boolean boolean15 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis6.configure();
        java.awt.Paint paint8 = numberAxis6.getTickLabelPaint();
        barRenderer0.setBaseFillPaint(paint8, false);
        java.awt.Stroke stroke11 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean3 = rectangleInsets0.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot5.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color12 = java.awt.Color.WHITE;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = numberAxis11.isVisible();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis11.valueToJava2D((double) (byte) 10, rectangle2D16, rectangleEdge17);
        java.awt.Paint paint19 = numberAxis11.getTickMarkPaint();
        java.awt.Font font20 = numberAxis11.getLabelFont();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = textTitle25.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("EXPAND", font20, (java.awt.Paint) color21, rectangleEdge22, horizontalAlignment23, verticalAlignment26, rectangleInsets27);
        double double29 = rectangleInsets27.getTop();
        boolean boolean30 = plotOrientation8.equals((java.lang.Object) rectangleInsets27);
        categoryPlot5.setOrientation(plotOrientation8);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation4, plotOrientation8);
        boolean boolean33 = rectangleInsets0.equals((java.lang.Object) plotOrientation8);
        double double35 = rectangleInsets0.extendHeight((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35 == 3.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color4 = java.awt.Color.WHITE;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean6 = numberAxis3.isVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis3.valueToJava2D((double) (byte) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis3.getLabelPaint();
        java.awt.Paint paint12 = numberAxis3.getTickMarkPaint();
        keyedObjects0.addObject((java.lang.Comparable) "CategoryAnchor.MIDDLE", (java.lang.Object) numberAxis3);
        java.awt.Paint paint14 = numberAxis3.getTickLabelPaint();
        float float15 = numberAxis3.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        java.awt.Font font17 = barRenderer0.getBaseItemLabelFont();
        double double18 = barRenderer0.getLowerClip();
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = textBlock3.calculateDimensions(graphics2D4);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(size2D5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint16 = barRenderer0.getItemPaint((int) (short) 10, 0);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator17 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator17);
        java.awt.Font font20 = barRenderer0.getSeriesItemLabelFont(0);
        barRenderer0.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, true);
        barRenderer0.setItemMargin((double) 15);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(font20);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        java.lang.Comparable comparable4 = null;
        int int5 = defaultStatisticalCategoryDataset0.getColumnIndex(comparable4);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        barRenderer1.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj7 = defaultDrawingSupplier6.clone();
        java.awt.Stroke stroke8 = defaultDrawingSupplier6.getNextStroke();
        barRenderer1.setSeriesStroke((int) 'a', stroke8);
        boolean boolean10 = barRenderer1.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer1);
        java.awt.Font font12 = legendTitle11.getItemFont();
        java.lang.String str13 = legendTitle11.getID();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str15 = rectangleAnchor14.toString();
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor14);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) textBlockAnchor18);
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double21 = range20.getUpperBound();
        org.jfree.data.Range range23 = org.jfree.data.Range.shift(range20, (double) 1L);
        boolean boolean24 = textBlockAnchor17.equals((java.lang.Object) 1L);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor14, textBlockAnchor17);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition25);
        float float27 = categoryLabelPosition25.getWidthRatio();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleAnchor.CENTER" + "'", str15.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.95f + "'", float27 == 0.95f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.util.List list2 = keyedObjects2D0.getRowKeys();
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) "CategoryLabelWidthType.CATEGORY");
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = axisChangeEvent6.getType();
        org.jfree.chart.JFreeChart jFreeChart8 = axisChangeEvent6.getChart();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = axisChangeEvent10.getType();
        java.lang.Object obj12 = null;
        boolean boolean13 = chartChangeEventType11.equals(obj12);
        axisChangeEvent6.setType(chartChangeEventType11);
        keyedObjects2D0.addObject((java.lang.Object) chartChangeEventType11, (java.lang.Comparable) 100, (java.lang.Comparable) "[size=1]");
        keyedObjects2D0.removeColumn((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNull(jFreeChart8);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.Comparable comparable0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity6 = new org.jfree.chart.entity.CategoryLabelEntity(comparable0, shape3, "hi!", "ThreadContext");
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape3);
        java.lang.String str8 = chartEntity7.toString();
        java.lang.Object obj9 = chartEntity7.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartEntity: tooltip = null" + "'", str8.equals("ChartEntity: tooltip = null"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition2.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = categoryLabelPosition2.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = categoryLabelPosition2.getWidthType();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = categoryLabelPosition2.getWidthType();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double8 = range7.getCentralValue();
        boolean boolean11 = range7.intersects((double) (byte) 100, 100.0d);
        double double13 = range7.constrain((double) (short) 1);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range7, range14);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range7, 1.0E-8d);
        boolean boolean18 = categoryLabelWidthType6.equals((java.lang.Object) rectangleConstraint17);
        double double19 = rectangleConstraint17.getWidth();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        int int3 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setAnchorValue(1.0d);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        valueMarker1.setValue((double) 8);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Shape shape12 = numberAxis1.getRightArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis1.getStandardTickUnits();
        java.awt.Stroke stroke14 = numberAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        textTitle17.setText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        textTitle17.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = textTitle1.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis1.isVisible();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis1.valueToJava2D((double) (byte) 10, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis1.getLabelPaint();
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean12 = numberAxis1.isInverted();
        double double13 = numberAxis1.getUpperBound();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double15 = range14.getCentralValue();
        boolean boolean18 = range14.intersects((double) (byte) 100, 100.0d);
        double double20 = range14.constrain((double) (short) 1);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range14, range21);
        numberAxis1.setDefaultAutoRange(range21);
        numberAxis1.setUpperBound((double) 0.95f);
        java.lang.String str26 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis1.setLowerMargin(0.0d);
        double double4 = categoryAxis1.getFixedDimension();
        categoryAxis1.setCategoryLabelPositionOffset(15);
        java.awt.Paint paint7 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape7, (java.awt.Paint) color8);
        boolean boolean10 = lengthConstraintType0.equals((java.lang.Object) legendItem9);
        org.jfree.data.general.Dataset dataset11 = legendItem9.getDataset();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(dataset11);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        java.awt.Color color14 = java.awt.Color.darkGray;
        java.awt.Color color15 = java.awt.Color.getColor("hi!", color14);
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        boolean boolean18 = barRenderer0.equals((java.lang.Object) textTitle17);
        java.awt.Paint paint20 = barRenderer0.getSeriesFillPaint(8);
        boolean boolean21 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot1.getRangeAxis(0);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot1.getRangeAxisEdge();
        categoryPlot1.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot1.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        categoryPlot0.setDomainAxisLocation(axisLocation9);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        int int11 = legendItem10.getSeriesIndex();
        legendItem10.setSeriesKey((java.lang.Comparable) true);
        boolean boolean14 = layer0.equals((java.lang.Object) true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        java.lang.String str17 = numberAxis16.getLabelToolTip();
        boolean boolean18 = layer0.equals((java.lang.Object) numberAxis16);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str4 = textAnchor3.toString();
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 2.0d, "RectangleAnchor.CENTER", textAnchor2, textAnchor3, (-1.0d));
        org.jfree.chart.axis.TickType tickType7 = numberTick6.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick6.getRotationAnchor();
        double double9 = numberTick6.getValue();
        org.jfree.chart.axis.AxisCollection axisCollection10 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list11 = axisCollection10.getAxesAtTop();
        java.util.List list12 = axisCollection10.getAxesAtBottom();
        java.util.List list13 = axisCollection10.getAxesAtLeft();
        java.util.List list14 = axisCollection10.getAxesAtTop();
        boolean boolean15 = numberTick6.equals((java.lang.Object) axisCollection10);
        java.util.List list16 = axisCollection10.getAxesAtTop();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str4.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        float float31 = categoryPlot3.getBackgroundImageAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot3.getRangeAxis();
        java.lang.String str33 = categoryPlot3.getNoDataMessage();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getCentralValue();
        org.jfree.data.Range range16 = org.jfree.data.Range.expand(range12, (double) 1, (double) 0.0f);
        numberAxis2.setRange(range16);
        java.lang.String str18 = numberAxis2.getLabel();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.5d + "'", double13 == 0.5d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis0);
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        boolean boolean5 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer0.getPositiveItemLabelPosition(2, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[][] doubleArray10 = new double[][] { doubleArray4, doubleArray5, doubleArray6, doubleArray7, doubleArray8, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "RangeType.NEGATIVE", doubleArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ItemLabelAnchor.OUTSIDE5", doubleArray10);
        org.jfree.data.KeyToGroupMap keyToGroupMap13 = null;
        try {
            org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset12, keyToGroupMap13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("EXPAND", font15, (java.awt.Paint) color16, rectangleEdge17, horizontalAlignment18, verticalAlignment21, rectangleInsets22);
        double double24 = rectangleInsets22.getTop();
        boolean boolean25 = plotOrientation3.equals((java.lang.Object) rectangleInsets22);
        categoryPlot0.setOrientation(plotOrientation3);
        categoryPlot0.setWeight((int) ' ');
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("1", graphics2D1, 10.0f, (float) (short) -1, textAnchor4, (double) (-1), (float) '#', 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape6, (java.awt.Paint) color7);
        int int9 = legendItem8.getDatasetIndex();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape11 = barRenderer10.getBaseShape();
        barRenderer10.setBase((double) (short) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = barRenderer10.getLegendItems();
        boolean boolean15 = legendItem8.equals((java.lang.Object) barRenderer10);
        boolean boolean16 = legendItem8.isShapeVisible();
        java.lang.Comparable comparable17 = legendItem8.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(comparable17);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.centerRange((double) 2);
        org.jfree.data.RangeType rangeType4 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str5 = rangeType4.toString();
        numberAxis1.setRangeType(rangeType4);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RangeType.NEGATIVE" + "'", str5.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape3 = barRenderer2.getBaseShape();
        barRenderer2.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj8 = defaultDrawingSupplier7.clone();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        barRenderer2.setSeriesStroke((int) 'a', stroke9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        barRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        java.awt.Color color16 = java.awt.Color.darkGray;
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color16);
        barRenderer2.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = barRenderer2.equals((java.lang.Object) textTitle19);
        int int21 = barRenderer2.getColumnCount();
        java.awt.Font font23 = barRenderer2.getSeriesItemLabelFont(3);
        boolean boolean24 = textFragment1.equals((java.lang.Object) barRenderer2);
        java.awt.Font font25 = textFragment1.getFont();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.configure();
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock18 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = textBlock18.calculateDimensions(graphics2D19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str24 = rectangleAnchor23.toString();
        java.awt.geom.Rectangle2D rectangle2D25 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, Double.NaN, 0.0d, rectangleAnchor23);
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets17.createOutsetRectangle(rectangle2D25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double28 = categoryAxis1.getCategoryStart((-1), 35, rectangle2D25, rectangleEdge27);
        java.lang.String str29 = categoryAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleAnchor.CENTER" + "'", str24.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = categoryItemRendererState1.getInfo();
        double double4 = categoryItemRendererState1.getSeriesRunningTotal();
        double double5 = categoryItemRendererState1.getBarWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape8, (java.awt.Paint) color9);
        barRenderer0.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color9, false);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer0.setSeriesOutlinePaint((int) '4', paint15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        barRenderer0.setSeriesToolTipGenerator(2, categoryToolTipGenerator24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Paint paint27 = null;
        legendTitle26.setBackgroundPaint(paint27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = legendTitle26.getPosition();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator17);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int1 = color0.getAlpha();
        float[] floatArray5 = null;
        float[] floatArray6 = java.awt.Color.RGBtoHSB((int) ' ', (int) (byte) 0, 175, floatArray5);
        try {
            float[] floatArray7 = color0.getRGBComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        int int3 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.setAnchorValue(1.0d);
        java.awt.Stroke stroke6 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean3 = rectangleInsets0.equals((java.lang.Object) itemLabelAnchor2);
        java.lang.String str4 = itemLabelAnchor2.toString();
        org.jfree.chart.axis.TickType tickType5 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape14, (java.awt.Paint) color15);
        barRenderer6.setSeriesOutlinePaint((int) (short) 100, (java.awt.Paint) color15, false);
        boolean boolean19 = barRenderer6.getAutoPopulateSeriesShape();
        java.awt.Paint paint21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        barRenderer6.setSeriesOutlinePaint((int) '4', paint21);
        java.awt.Paint paint23 = barRenderer6.getBaseOutlinePaint();
        boolean boolean24 = tickType5.equals((java.lang.Object) paint23);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick30 = new org.jfree.chart.axis.NumberTick(tickType5, 0.0d, "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", textAnchor27, textAnchor28, Double.NaN);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor28);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ItemLabelAnchor.INSIDE11" + "'", str4.equals("ItemLabelAnchor.INSIDE11"));
        org.junit.Assert.assertNotNull(tickType5);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        java.awt.Stroke stroke6 = lineBorder4.getStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis9.setLowerMargin(0.0d);
        java.awt.Font font12 = categoryAxis9.getLabelFont();
        java.awt.Color color13 = java.awt.Color.white;
        java.awt.Color color14 = color13.darker();
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BASELINE_RIGHT", font12, (java.awt.Paint) color13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape17 = barRenderer16.getBaseShape();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean24 = org.jfree.chart.util.ShapeUtilities.equal(shape20, shape23);
        barRenderer16.setBaseShape(shape20);
        java.awt.Stroke stroke27 = barRenderer16.lookupSeriesOutlineStroke(3);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 0, (java.awt.Paint) color3, stroke6, (java.awt.Paint) color13, stroke27, 0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 0.5f, (java.awt.Paint) color1, stroke6);
        java.lang.Object obj31 = valueMarker30.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot3.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color10 = java.awt.Color.WHITE;
        numberAxis9.setTickLabelPaint((java.awt.Paint) color10);
        boolean boolean12 = numberAxis9.isVisible();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis9.valueToJava2D((double) (byte) 10, rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = numberAxis9.getTickMarkPaint();
        java.awt.Font font18 = numberAxis9.getLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = textTitle23.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("EXPAND", font18, (java.awt.Paint) color19, rectangleEdge20, horizontalAlignment21, verticalAlignment24, rectangleInsets25);
        double double27 = rectangleInsets25.getTop();
        boolean boolean28 = plotOrientation6.equals((java.lang.Object) rectangleInsets25);
        categoryPlot3.setOrientation(plotOrientation6);
        numberAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot3.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint35 = categoryAxis33.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis33.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float40 = categoryAxis33.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeListener axisChangeListener41 = null;
        categoryAxis33.addChangeListener(axisChangeListener41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.AxisState axisState45 = new org.jfree.chart.axis.AxisState(1.0d);
        axisState45.cursorDown((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType48 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = new org.jfree.chart.util.RectangleInsets(unitType48, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock54 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.util.Size2D size2D56 = textBlock54.calculateDimensions(graphics2D55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str60 = rectangleAnchor59.toString();
        java.awt.geom.Rectangle2D rectangle2D61 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D56, Double.NaN, 0.0d, rectangleAnchor59);
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets53.createOutsetRectangle(rectangle2D61);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color66 = java.awt.Color.WHITE;
        numberAxis65.setTickLabelPaint((java.awt.Paint) color66);
        boolean boolean68 = numberAxis65.isVisible();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis65.valueToJava2D((double) (byte) 10, rectangle2D70, rectangleEdge71);
        java.awt.Paint paint73 = numberAxis65.getTickMarkPaint();
        java.awt.Font font74 = numberAxis65.getLabelFont();
        java.awt.Color color75 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment77 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle79 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment80 = textTitle79.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle82 = new org.jfree.chart.title.TextTitle("EXPAND", font74, (java.awt.Paint) color75, rectangleEdge76, horizontalAlignment77, verticalAlignment80, rectangleInsets81);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge76);
        java.util.List list84 = categoryAxis33.refreshTicks(graphics2D43, axisState45, rectangle2D61, rectangleEdge83);
        categoryPlot3.setDomainAxis(categoryAxis33);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
        org.junit.Assert.assertNotNull(unitType48);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "RectangleAnchor.CENTER" + "'", str60.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(horizontalAlignment77);
        org.junit.Assert.assertNotNull(verticalAlignment80);
        org.junit.Assert.assertNotNull(rectangleInsets81);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertNotNull(list84);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation8 = axisLocation7.getOpposite();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color11 = java.awt.Color.WHITE;
        numberAxis10.setTickLabelPaint((java.awt.Paint) color11);
        boolean boolean13 = numberAxis10.isVisible();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis10.valueToJava2D((double) (byte) 10, rectangle2D15, rectangleEdge16);
        java.awt.Shape shape18 = numberAxis10.getLeftArrow();
        boolean boolean19 = axisLocation7.equals((java.lang.Object) shape18);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint14 = categoryAxis12.getTickLabelPaint((java.lang.Comparable) "poly");
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(paint14);
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D18 = legendTitle10.arrange(graphics2D17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = legendTitle10.getVerticalAlignment();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine2 = null;
        textBlock1.addLine(textLine2);
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = textBlock4.calculateDimensions(graphics2D5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textBlock4.getLineAlignment();
        textBlock1.setLineAlignment(horizontalAlignment7);
        java.lang.String str9 = horizontalAlignment7.toString();
        boolean boolean10 = shapeList0.equals((java.lang.Object) horizontalAlignment7);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("", "ClassContext", "hi!", "ClassContext", shape17, (java.awt.Paint) color18);
        int int20 = legendItem19.getSeriesIndex();
        legendItem19.setSeriesKey((java.lang.Comparable) true);
        java.awt.Shape shape23 = legendItem19.getLine();
        boolean boolean24 = horizontalAlignment7.equals((java.lang.Object) legendItem19);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "HorizontalAlignment.CENTER" + "'", str9.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.plot.Plot plot12 = null;
        numberAxis2.setPlot(plot12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(100.0d);
        double double3 = blockParams0.getTranslateY();
        blockParams0.setTranslateX(0.0d);
        double double6 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color7 = java.awt.Color.WHITE;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color7);
        boolean boolean9 = numberAxis6.isVisible();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis6.valueToJava2D((double) (byte) 10, rectangle2D11, rectangleEdge12);
        java.awt.Paint paint14 = numberAxis6.getTickMarkPaint();
        java.awt.Font font15 = numberAxis6.getLabelFont();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle20.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("EXPAND", font15, (java.awt.Paint) color16, rectangleEdge17, horizontalAlignment18, verticalAlignment21, rectangleInsets22);
        double double24 = rectangleInsets22.getTop();
        boolean boolean25 = plotOrientation3.equals((java.lang.Object) rectangleInsets22);
        categoryPlot0.setOrientation(plotOrientation3);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot0.getRowRenderingOrder();
        java.awt.Image image28 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis30);
        int int32 = categoryAxis30.getMaximumCategoryLabelLines();
        categoryPlot0.setDomainAxis(1, categoryAxis30);
        java.awt.Paint paint34 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "ThreadContext", textBlock1, textBlockAnchor2, textAnchor3, (double) (-1L));
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) defaultDrawingSupplier6, jFreeChart7, (int) '#', 10);
        chartProgressEvent10.setPercent(10);
        boolean boolean13 = categoryTick5.equals((java.lang.Object) chartProgressEvent10);
        java.lang.Comparable comparable14 = categoryTick5.getCategory();
        java.lang.Comparable comparable15 = categoryTick5.getCategory();
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryTick5.getTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "ThreadContext" + "'", comparable14.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "ThreadContext" + "'", comparable15.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = textBlock5.calculateDimensions(graphics2D6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str11 = rectangleAnchor10.toString();
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, Double.NaN, 0.0d, rectangleAnchor10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape16 = barRenderer15.getBaseShape();
        barRenderer15.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj21 = defaultDrawingSupplier20.clone();
        java.awt.Stroke stroke22 = defaultDrawingSupplier20.getNextStroke();
        barRenderer15.setSeriesStroke((int) 'a', stroke22);
        boolean boolean24 = barRenderer15.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer15);
        java.awt.Font font26 = legendTitle25.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle25.setLegendItemGraphicLocation(rectangleAnchor27);
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, (double) 10.0f, 8.0d, rectangleAnchor27);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double31 = rectangleInsets30.getTop();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor32 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        boolean boolean33 = rectangleInsets30.equals((java.lang.Object) itemLabelAnchor32);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        double double37 = labelBlock36.getWidth();
        java.lang.Object obj38 = labelBlock36.clone();
        java.awt.Font font39 = labelBlock36.getFont();
        labelBlock36.setMargin(1.0E-8d, (double) (short) 100, 10.0d, (double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets30.createOutsetRectangle(rectangle2D45);
        boolean boolean47 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D29, rectangle2D46);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color50 = java.awt.Color.WHITE;
        numberAxis49.setTickLabelPaint((java.awt.Paint) color50);
        boolean boolean52 = numberAxis49.isVisible();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = numberAxis49.valueToJava2D((double) (byte) 10, rectangle2D54, rectangleEdge55);
        java.awt.Shape shape57 = numberAxis49.getLeftArrow();
        boolean boolean58 = numberAxis49.isNegativeArrowVisible();
        numberAxis49.resizeRange(0.0d, (double) 8);
        org.jfree.chart.util.UnitType unitType63 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = new org.jfree.chart.util.RectangleInsets(unitType63, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock69 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.util.Size2D size2D71 = textBlock69.calculateDimensions(graphics2D70);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str75 = rectangleAnchor74.toString();
        java.awt.geom.Rectangle2D rectangle2D76 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D71, Double.NaN, 0.0d, rectangleAnchor74);
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets68.createOutsetRectangle(rectangle2D76);
        org.jfree.chart.title.TextTitle textTitle79 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment80 = textTitle79.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = textTitle79.getPosition();
        double double82 = numberAxis49.lengthToJava2D((double) (byte) 1, rectangle2D77, rectangleEdge81);
        boolean boolean83 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge81);
        try {
            java.util.List list84 = categoryAxis0.refreshTicks(graphics2D2, axisState4, rectangle2D46, rectangleEdge81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleAnchor.CENTER" + "'", str11.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(unitType63);
        org.junit.Assert.assertNotNull(size2D71);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "RectangleAnchor.CENTER" + "'", str75.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(verticalAlignment80);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.lang.String str12 = legendTitle10.getID();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color19 = java.awt.Color.WHITE;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = numberAxis18.isVisible();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis18.valueToJava2D((double) (byte) 10, rectangle2D23, rectangleEdge24);
        java.awt.Paint paint26 = numberAxis18.getTickMarkPaint();
        java.awt.Font font27 = numberAxis18.getLabelFont();
        numberAxis15.setLabelFont(font27);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color31 = java.awt.Color.WHITE;
        numberAxis30.setTickLabelPaint((java.awt.Paint) color31);
        boolean boolean33 = numberAxis30.isVisible();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis30.valueToJava2D((double) (byte) 10, rectangle2D35, rectangleEdge36);
        java.awt.Paint paint38 = numberAxis30.getTickMarkPaint();
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("EXPAND", font27, paint38);
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder(paint38);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape42 = barRenderer41.getBaseShape();
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) -1, (float) (short) 1);
        boolean boolean49 = org.jfree.chart.util.ShapeUtilities.equal(shape45, shape48);
        barRenderer41.setBaseShape(shape45);
        java.awt.Stroke stroke52 = barRenderer41.lookupSeriesOutlineStroke(3);
        java.awt.Paint paint55 = barRenderer41.getItemPaint((int) '4', 2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier56 = barRenderer41.getDrawingSupplier();
        java.awt.Stroke stroke59 = barRenderer41.getItemStroke((int) (short) 0, 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double62 = rectangleInsets60.extendWidth((double) 100.0f);
        org.jfree.chart.block.LineBorder lineBorder63 = new org.jfree.chart.block.LineBorder(paint38, stroke59, rectangleInsets60);
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) lineBorder63);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNull(drawingSupplier56);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 116.0d + "'", double62 == 116.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        barRenderer0.setBase((double) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        barRenderer0.setSeriesStroke((int) 'a', stroke7);
        boolean boolean9 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Font font11 = legendTitle10.getItemFont();
        java.awt.Paint paint12 = legendTitle10.getItemPaint();
        legendTitle10.setHeight((double) (byte) 10);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberTickUnit12.toString();
        double double14 = numberTickUnit12.getSize();
        java.lang.String str15 = numberTickUnit12.toString();
        org.jfree.chart.text.TextBlock textBlock16 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine17 = null;
        textBlock16.addLine(textLine17);
        org.jfree.chart.text.TextBlock textBlock19 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = textBlock19.calculateDimensions(graphics2D20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textBlock19.getLineAlignment();
        textBlock16.setLineAlignment(horizontalAlignment22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor24, textBlockAnchor25);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryTick categoryTick29 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) numberTickUnit12, textBlock16, textBlockAnchor25, textAnchor27, (double) 10.0f);
        java.awt.Font font32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("ItemLabelAnchor.OUTSIDE5", font32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color36 = java.awt.Color.WHITE;
        numberAxis35.setTickLabelPaint((java.awt.Paint) color36);
        boolean boolean38 = numberAxis35.isVisible();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis35.valueToJava2D((double) (byte) 10, rectangle2D40, rectangleEdge41);
        java.awt.Paint paint43 = numberAxis35.getLabelPaint();
        java.awt.Paint paint44 = numberAxis35.getTickMarkPaint();
        textBlock16.addLine("RectangleAnchor.CENTER", font32, paint44);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle47 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment50 = textTitle49.getVerticalAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = textTitle49.getPosition();
        textTitle47.setPosition(rectangleEdge51);
        double double53 = textTitle47.getHeight();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = textTitle47.getTextAlignment();
        textTitle46.setHorizontalAlignment(horizontalAlignment54);
        textBlock16.setLineAlignment(horizontalAlignment54);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[size=1]" + "'", str13.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[size=1]" + "'", str15.equals("[size=1]"));
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(verticalAlignment50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = categoryLabelPosition2.getWidthType();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color3 = java.awt.Color.WHITE;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis2.isVisible();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis2.valueToJava2D((double) (byte) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis2.getTickMarkPaint();
        boolean boolean11 = datasetGroup0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis2.getTickUnit();
        java.lang.String str13 = numberAxis2.getLabelURL();
        numberAxis2.setAutoRangeMinimumSize((double) 4);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        axisState18.moveCursor(0.0d, rectangleEdge20);
        axisState18.setCursor((double) 35);
        axisState18.cursorDown((double) 255);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        textTitle26.setExpandToFitSpace(false);
        double double29 = textTitle26.getContentXOffset();
        java.lang.String str30 = textTitle26.getText();
        java.awt.Paint paint31 = textTitle26.getBackgroundPaint();
        boolean boolean32 = textTitle26.getExpandToFitSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        categoryAxis34.setLowerMargin(0.0d);
        double double37 = categoryAxis34.getFixedDimension();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("RangeType.NEGATIVE");
        java.awt.Paint paint43 = categoryAxis41.getTickLabelPaint((java.lang.Comparable) "poly");
        categoryAxis41.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        categoryAxis41.setMaximumCategoryLabelWidthRatio((float) 1L);
        float float48 = categoryAxis41.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.event.AxisChangeListener axisChangeListener49 = null;
        categoryAxis41.addChangeListener(axisChangeListener49);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.axis.AxisState axisState53 = new org.jfree.chart.axis.AxisState(1.0d);
        axisState53.cursorDown((double) (-1.0f));
        org.jfree.chart.util.UnitType unitType56 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = new org.jfree.chart.util.RectangleInsets(unitType56, (double) (short) -1, 0.0d, (-1.0d), (double) (byte) -1);
        org.jfree.chart.text.TextBlock textBlock62 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.util.Size2D size2D64 = textBlock62.calculateDimensions(graphics2D63);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str68 = rectangleAnchor67.toString();
        java.awt.geom.Rectangle2D rectangle2D69 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D64, Double.NaN, 0.0d, rectangleAnchor67);
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets61.createOutsetRectangle(rectangle2D69);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Color color74 = java.awt.Color.WHITE;
        numberAxis73.setTickLabelPaint((java.awt.Paint) color74);
        boolean boolean76 = numberAxis73.isVisible();
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = null;
        double double80 = numberAxis73.valueToJava2D((double) (byte) 10, rectangle2D78, rectangleEdge79);
        java.awt.Paint paint81 = numberAxis73.getTickMarkPaint();
        java.awt.Font font82 = numberAxis73.getLabelFont();
        java.awt.Color color83 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment85 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle87 = new org.jfree.chart.title.TextTitle("hi!");
        org.jfree.chart.util.VerticalAlignment verticalAlignment88 = textTitle87.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets89 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle90 = new org.jfree.chart.title.TextTitle("EXPAND", font82, (java.awt.Paint) color83, rectangleEdge84, horizontalAlignment85, verticalAlignment88, rectangleInsets89);
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge84);
        java.util.List list92 = categoryAxis41.refreshTicks(graphics2D51, axisState53, rectangle2D69, rectangleEdge91);
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double94 = categoryAxis34.getCategoryMiddle((int) (short) 1, 10, rectangle2D69, rectangleEdge93);
        textTitle26.setBounds(rectangle2D69);
        org.jfree.chart.util.RectangleEdge rectangleEdge96 = null;
        java.util.List list97 = numberAxis2.refreshTicks(graphics2D16, axisState18, rectangle2D69, rectangleEdge96);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 1.0f + "'", float48 == 1.0f);
        org.junit.Assert.assertNotNull(unitType56);
        org.junit.Assert.assertNotNull(size2D64);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "RectangleAnchor.CENTER" + "'", str68.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertNotNull(horizontalAlignment85);
        org.junit.Assert.assertNotNull(verticalAlignment88);
        org.junit.Assert.assertNotNull(rectangleInsets89);
        org.junit.Assert.assertNotNull(rectangleEdge91);
        org.junit.Assert.assertNotNull(list92);
        org.junit.Assert.assertNotNull(rectangleEdge93);
        org.junit.Assert.assertEquals((double) double94, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list97);
    }
}

