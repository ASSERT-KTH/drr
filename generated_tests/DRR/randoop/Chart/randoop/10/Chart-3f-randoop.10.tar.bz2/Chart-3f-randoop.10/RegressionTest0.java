import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = null;
        try {
            timeSeries3.add(timeSeriesDataItem4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 10 + "'", comparable6.equals((short) 10));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries3.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int3 = year0.compareTo((java.lang.Object) 1.0d);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        int int7 = year4.compareTo((java.lang.Object) 1.0d);
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        try {
            timeSeries3.update(4, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1559372400000L, seriesChangeInfo1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(timeSeriesDataItem8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean15 = year13.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.next();
        int int17 = year13.getYear();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        long long2 = year1.getLastMillisecond();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61820208000001L) + "'", long2 == (-61820208000001L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        long long12 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = null;
        try {
            timeSeries3.add(timeSeriesDataItem7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 10 + "'", comparable6.equals((short) 10));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        try {
            timeSeries3.delete(0, 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        try {
            timeSeries3.delete((int) (short) -1, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        long long2 = year1.getLastMillisecond();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61820208000001L) + "'", long2 == (-61820208000001L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        try {
            java.lang.Number number13 = timeSeries3.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date3, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        try {
            timeSeries3.delete(11, 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.setDomainDescription("10-June-2019");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        long long2 = year1.getLastMillisecond();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61820208000001L) + "'", long2 == (-61820208000001L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.lang.Class class0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date4, timeZone7);
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone9);
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        try {
            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date4, timeZone11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        boolean boolean8 = timeSeries3.isEmpty();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
//        java.lang.String str12 = regularTimePeriod11.toString();
//        try {
//            timeSeries3.update(regularTimePeriod11, (java.lang.Number) 1L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-June-2019" + "'", str12.equals("9-June-2019"));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        try {
            timeSeries3.update((int) '4', (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183483430L + "'", long2 == 1560183483430L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560183483430L + "'", long3 == 1560183483430L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183483430L + "'", long4 == 1560183483430L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("9-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean7 = timeSeries3.equals((java.lang.Object) (byte) 100);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries8.addChangeListener(seriesChangeListener10);
        try {
            timeSeries8.update(0, (java.lang.Number) 1560183484014L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        timeSeries3.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy((int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        try {
            timeSeries13.delete(4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent5.getSummary();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNull(seriesChangeInfo9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setMaximumItemAge((long) 100);
        try {
            timeSeries3.setMaximumItemAge((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.lang.String str12 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        timeSeries3.setDescription("hi!");
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        boolean boolean15 = fixedMillisecond12.equals((java.lang.Object) month13);
        long long16 = month13.getFirstMillisecond();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 10 + "'", comparable6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries11.removeAgedItems(false);
        timeSeries11.removeAgedItems(1560183481404L, false);
        try {
            timeSeries11.update((-1), (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        timeSeries3.removeAgedItems(false);
        try {
            timeSeries3.setMaximumItemAge((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        long long13 = timeSeries11.getMaximumItemAge();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.util.Collection collection18 = timeSeries16.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.lang.String str26 = timeSeries24.getRangeDescription();
        try {
            timeSeries24.delete(11, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setRangeDescription("10");
        try {
            timeSeries3.setMaximumItemAge((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date3, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.util.Collection collection17 = timeSeries15.getTimePeriods();
        try {
            boolean boolean18 = timeSeriesDataItem11.equals((java.lang.Object) collection17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "", "hi!");
        try {
            java.lang.Number number5 = timeSeries3.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) month10);
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "", "hi!");
        try {
            timeSeries3.update((int) (byte) 10, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str21 = month17.toString();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month17.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        long long4 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        boolean boolean10 = month2.equals((java.lang.Object) comparable9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 10 + "'", comparable9.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries20.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        int int3 = day0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.lang.Class<?> wildcardClass3 = fixedMillisecond0.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183491053L + "'", long2 == 1560183491053L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1560183482051L);
        boolean boolean7 = timeSeriesDataItem5.equals((java.lang.Object) (byte) 100);
        java.lang.Number number8 = null;
        timeSeriesDataItem5.setValue(number8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        java.lang.String str11 = timeSeries3.getDescription();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        timeSeries3.removeAgedItems(1562097599999L, false);
        timeSeries3.setMaximumItemCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection22);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, "", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.util.Collection collection28 = timeSeries26.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries32);
        double double35 = timeSeries34.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        boolean boolean39 = fixedMillisecond37.equals((java.lang.Object) month38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        int int42 = month40.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries43);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) 10 + "'", comparable33.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(timeSeries44);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        int int4 = month0.getYearValue();
        int int5 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.util.Collection collection18 = timeSeries16.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        timeSeries3.setMaximumItemCount(0);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries3.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        java.util.Collection collection13 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        java.lang.String str14 = timeSeries11.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries11.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        double double10 = timeSeries3.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560183481917L, true);
//        java.lang.String str17 = timeSeries3.getDomainDescription();
//        int int18 = timeSeries3.getItemCount();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183492951L + "'", long13 == 1560183492951L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        long long3 = regularTimePeriod1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1563303599999L + "'", long3 == 1563303599999L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 24234L, "2019", "10-June-2019");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "10-June-2019");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent4.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone7);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date3, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setDescription("June 2019");
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.lang.Class<?> wildcardClass3 = fixedMillisecond0.getClass();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
//        int int6 = month4.getYearValue();
//        java.util.Date date7 = month4.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone9);
//        java.util.TimeZone timeZone11 = null;
//        java.util.Locale locale12 = null;
//        try {
//            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date7, timeZone11, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183493888L + "'", long2 == 1560183493888L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
//        try {
//            timeSeries3.add(regularTimePeriod4, (double) 1559372400000L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183495018L + "'", long2 == 1560183495018L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        try {
            timeSeries3.update(9999, (java.lang.Number) 1560150000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        boolean boolean29 = timeSeries20.isEmpty();
//        try {
//            timeSeries20.delete((int) (short) -1, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183495359L + "'", long27 == 1560183495359L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        boolean boolean6 = timeSeriesDataItem5.isSelected();
        boolean boolean8 = timeSeriesDataItem5.equals((java.lang.Object) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        int int6 = year4.compareTo((java.lang.Object) (-1.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        java.util.Collection collection13 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        java.lang.String str14 = timeSeries11.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) month17);
        long long19 = fixedMillisecond16.getMiddleMillisecond();
        long long20 = fixedMillisecond16.getFirstMillisecond();
        timeSeries11.setKey((java.lang.Comparable) long20);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries11.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        java.util.Calendar calendar32 = null;
//        try {
//            long long33 = year28.getLastMillisecond(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getStart();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183496274L + "'", long4 == 1560183496274L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        timeSeries3.removeAgedItems(1560183489662L, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getFirstMillisecond();
//        int int34 = year32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
//        java.lang.Number number36 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) year32);
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = year32.getFirstMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0f + "'", number36.equals(0.0f));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month15.next();
        java.util.Date date22 = regularTimePeriod21.getEnd();
        java.util.TimeZone timeZone23 = null;
        java.util.Locale locale24 = null;
        try {
            org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 10);
        long long7 = month1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            java.util.Collection collection10 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.lang.String str4 = year0.toString();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        timeSeries3.setNotify(true);
        double double13 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        java.util.Collection collection10 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable15 = timeSeries14.getKey();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries14);
//        double double17 = timeSeries16.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) month20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
//        int int24 = month22.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month20, (org.jfree.data.time.RegularTimePeriod) month22);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        boolean boolean31 = fixedMillisecond28.equals((java.lang.Object) month29);
//        long long32 = fixedMillisecond28.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond28.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond28.previous();
//        long long36 = fixedMillisecond28.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560183498564L + "'", long32 == 1560183498564L);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560183498564L + "'", long36 == 1560183498564L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
//        try {
//            int int5 = timeSeries3.getIndex(regularTimePeriod4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183498959L + "'", long2 == 1560183498959L);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        boolean boolean13 = timeSeries11.getNotify();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        boolean boolean7 = year5.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        long long35 = day33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        long long41 = year40.getFirstMillisecond();
//        int int42 = year40.getYear();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) year40);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries32);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries43);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        boolean boolean6 = timeSeries5.getNotify();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        int int8 = year1.compareTo((java.lang.Object) timeSeries5);
        long long9 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61820208000001L) + "'", long9 == (-61820208000001L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        java.lang.String str14 = year10.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod16);
        java.util.Calendar calendar18 = null;
        try {
            year10.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        timeSeries3.setDescription("10-June-2019");
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        double double10 = timeSeries3.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560183481917L, true);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond11.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        fixedMillisecond11.peg(calendar19);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
//        try {
//            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) calendar19, seriesChangeInfo21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183500240L + "'", long13 == 1560183500240L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560183500240L + "'", long18 == 1560183500240L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timeSeries3.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries3.add(regularTimePeriod9, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        long long32 = year28.getFirstMillisecond();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.util.TimeZone timeZone6 = null;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries8.addChangeListener(seriesChangeListener11);
//        java.lang.Comparable comparable13 = timeSeries8.getKey();
//        timeSeries8.setMaximumItemAge((long) 100);
//        java.lang.Comparable comparable16 = timeSeries8.getKey();
//        int int17 = fixedMillisecond0.compareTo((java.lang.Object) comparable16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond0.getFirstMillisecond(calendar18);
//        long long20 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183500695L + "'", long4 == 1560183500695L);
//        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) 10 + "'", comparable13.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) 10 + "'", comparable16.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560183500695L + "'", long19 == 1560183500695L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560183500695L + "'", long20 == 1560183500695L);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        java.lang.Object obj12 = timeSeriesDataItem10.clone();
        boolean boolean13 = month0.equals((java.lang.Object) timeSeriesDataItem10);
        java.util.Calendar calendar14 = null;
        try {
            month0.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Comparable comparable20 = timeSeries17.getKey();
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.String str22 = timeSeries17.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        boolean boolean25 = year23.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeriesDataItem28.getPeriod();
        boolean boolean30 = timeSeriesDataItem28.isSelected();
        timeSeries17.add(timeSeriesDataItem28);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str21 = month17.toString();
        int int22 = month17.getYearValue();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        java.lang.String str13 = timeSeries11.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries11.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        double double7 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 10 + "'", comparable5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        java.lang.Object obj19 = timeSeriesDataItem17.clone();
        timeSeries10.add(timeSeriesDataItem17, true);
        timeSeries3.add(timeSeriesDataItem17, true);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) (short) 0);
        try {
            timeSeries3.add(timeSeriesDataItem27, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (short) 10 + "'", comparable11.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        double double10 = timeSeries3.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560183481917L, true);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond11.getMiddleMillisecond(calendar17);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183502226L + "'", long13 == 1560183502226L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560183502226L + "'", long18 == 1560183502226L);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1560183482051L);
        java.lang.String str6 = month2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        boolean boolean8 = timeSeries3.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2018");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
//        boolean boolean38 = fixedMillisecond35.equals((java.lang.Object) month36);
//        long long39 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        int int41 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
//        long long42 = month33.getSerialIndex();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183503822L + "'", long39 == 1560183503822L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 24234L + "'", long42 == 24234L);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.util.Collection collection18 = timeSeries16.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        java.lang.String str26 = timeSeries24.getRangeDescription();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        java.util.Date date29 = day27.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        java.lang.String str31 = month30.toString();
        try {
            timeSeries24.update((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) 1560183483521L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "June 2019" + "'", str31.equals("June 2019"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        long long10 = year4.getMiddleMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        int int2 = day0.compareTo(obj1);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
//        java.lang.Comparable comparable9 = timeSeries6.getKey();
//        timeSeries6.setDescription("hi!");
//        int int12 = day0.compareTo((java.lang.Object) timeSeries6);
//        long long13 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 10 + "'", comparable9.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        timeSeries3.setDescription("hi!");
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 10 + "'", comparable6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        boolean boolean7 = year5.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        boolean boolean15 = fixedMillisecond12.equals((java.lang.Object) month13);
//        long long16 = fixedMillisecond12.getSerialIndex();
//        java.lang.Number number17 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getSerialIndex();
//        java.lang.Object obj21 = null;
//        int int22 = day18.compareTo(obj21);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.util.Collection collection28 = timeSeries26.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable33 = timeSeries32.getKey();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries32);
//        timeSeries34.removeAgedItems(false);
//        timeSeries34.removeAgedItems(1560183481404L, false);
//        int int40 = day18.compareTo((java.lang.Object) false);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 1560183501791L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560183506138L + "'", long16 == 1560183506138L);
//        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (byte) 10 + "'", number17.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNull(class27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) 10 + "'", comparable33.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = month6.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 10);
        int int8 = month1.compareTo((java.lang.Object) "2018");
        java.lang.Object obj9 = null;
        boolean boolean10 = month1.equals(obj9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month1, seriesChangeInfo11);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Value", "org.jfree.data.time.TimePeriodFormatException: hi!", "");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) date11);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date11, timeZone14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) date11);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183491194L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560183491194L + "'", long3 == 1560183491194L);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener12);
        timeSeries9.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener20);
        boolean boolean22 = timeSeries19.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
        long long27 = month24.getLastMillisecond();
        int int28 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries9.addAndOrUpdate(timeSeries19);
        try {
            timeSeries9.update((int) (byte) 1, (java.lang.Number) 1560183502139L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo7);
        java.lang.Object obj9 = seriesChangeEvent5.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent5.getSummary();
        java.lang.Object obj11 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(seriesChangeInfo10);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
//        long long4 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getStart();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond5.getLastMillisecond(calendar7);
//        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) long8);
//        long long10 = fixedMillisecond1.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183508975L + "'", long8 == 1560183508975L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        java.lang.Object obj8 = timeSeries3.clone();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        java.lang.Object obj6 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=July 2019]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=July 2019]"));
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.util.Calendar calendar7 = null;
//        try {
//            month6.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year13 = month8.getYear();
        java.util.Calendar calendar14 = null;
        try {
            year13.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean7 = timeSeries3.equals((java.lang.Object) (byte) 100);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo7);
        java.lang.Object obj9 = seriesChangeEvent5.getSource();
        java.lang.String str10 = seriesChangeEvent5.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent5.getSummary();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(seriesChangeInfo11);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
//        boolean boolean38 = fixedMillisecond35.equals((java.lang.Object) month36);
//        long long39 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        int int41 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries9.getDataItem(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183511993L + "'", long39 == 1560183511993L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        boolean boolean8 = timeSeriesDataItem5.isSelected();
        java.lang.Number number9 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 10 + "'", number9.equals((byte) 10));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
//        timeSeries3.setDomainDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        java.util.Collection collection18 = timeSeries16.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable23 = timeSeries22.getKey();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
//        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
//        java.lang.String str26 = timeSeries24.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        java.util.Collection collection32 = timeSeries30.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable37 = timeSeries36.getKey();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries30.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        java.util.Collection collection44 = timeSeries42.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable49 = timeSeries48.getKey();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries42.addAndOrUpdate(timeSeries48);
//        double double51 = timeSeries50.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        boolean boolean55 = fixedMillisecond53.equals((java.lang.Object) month54);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month56.next();
//        int int58 = month56.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) month56);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month60.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month63.next();
//        boolean boolean65 = fixedMillisecond62.equals((java.lang.Object) month63);
//        long long66 = fixedMillisecond62.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries59.createCopy((org.jfree.data.time.RegularTimePeriod) month60, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
//        int int68 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) month60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month60.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries24.getDataItem(regularTimePeriod69);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries24.getDataItem((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNull(class17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertNull(class31);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + (short) 10 + "'", comparable37.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNull(class43);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + (short) 10 + "'", comparable49.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560183512079L + "'", long66 == 1560183512079L);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNull(timeSeriesDataItem70);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable15 = timeSeries14.getKey();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection20 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.util.List list21 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries19);
        java.lang.String str23 = timeSeries19.getDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = null;
        try {
            java.util.Collection collection25 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setMaximumItemAge((long) 100);
        java.lang.Comparable comparable11 = timeSeries3.getKey();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (short) 10 + "'", comparable11.equals((short) 10));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy(9999, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        java.lang.String str14 = year10.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries17.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getLastMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        timeSeries3.setNotify(true);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        java.util.Date date14 = day12.getEnd();
//        java.lang.String str15 = day12.toString();
//        long long16 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 1560236399999L);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = day12.getFirstMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        long long6 = day0.getLastMillisecond();
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year13 = month8.getYear();
        int int14 = year13.getYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        java.lang.String str32 = month26.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month26.previous();
//        int int34 = month26.getYearValue();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        timeSeries3.setRangeDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries3.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        boolean boolean32 = timeSeries20.getNotify();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        boolean boolean35 = year33.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) (byte) 10);
//        timeSeriesDataItem38.setSelected(true);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
//        org.jfree.data.time.Year year43 = month41.getYear();
//        java.util.Date date44 = month41.getStart();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
//        int int46 = timeSeriesDataItem38.compareTo((java.lang.Object) date44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date44);
//        java.lang.Number number48 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        java.lang.Comparable comparable53 = timeSeries52.getKey();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
//        org.jfree.data.time.Year year56 = month54.getYear();
//        int int57 = month54.getMonth();
//        java.lang.Number number58 = null;
//        timeSeries52.add((org.jfree.data.time.RegularTimePeriod) month54, number58, false);
//        long long61 = month54.getFirstMillisecond();
//        int int62 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
//        timeSeries20.setNotify(false);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.0f + "'", number48.equals(0.0f));
//        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + (short) 10 + "'", comparable53.equals((short) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1559372400000L + "'", long61 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setMaximumItemAge(10L);
        boolean boolean11 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean11);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone5 = null;
//        try {
//            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183515866L + "'", long2 == 1560183515866L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = year0.getStart();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 24234L, "2019", "10-June-2019");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        java.util.Date date6 = day4.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        java.lang.Number number9 = null;
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month8, number9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        boolean boolean14 = fixedMillisecond11.equals((java.lang.Object) month12);
        long long15 = month12.getLastMillisecond();
        int int17 = month12.compareTo((java.lang.Object) 10);
        int int19 = month12.compareTo((java.lang.Object) "2018");
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 0.0f, false);
        int int23 = month12.getYearValue();
        org.jfree.data.time.Year year24 = month12.getYear();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year24.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertNotNull(year24);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10");
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries17.addChangeListener(seriesChangeListener20);
        java.lang.Comparable comparable22 = timeSeries17.getKey();
        timeSeries17.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
        boolean boolean28 = fixedMillisecond25.equals((java.lang.Object) month26);
        long long29 = month26.getLastMillisecond();
        int int31 = month26.compareTo((java.lang.Object) 10);
        int int33 = month26.compareTo((java.lang.Object) "2018");
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month26, (double) 0.0f, false);
        int int37 = month26.getYearValue();
        org.jfree.data.time.Year year38 = month26.getYear();
        try {
            timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year38, (java.lang.Number) 1560183503822L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertNotNull(year38);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month8.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries13.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable15 = timeSeries14.getKey();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection20 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.util.List list21 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries19);
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.createCopy(9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        timeSeries3.removeAgedItems(false);
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        try {
            timeSeries3.update(0, (java.lang.Number) 1560183493697L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        boolean boolean32 = timeSeries20.getNotify();
//        timeSeries20.removeAgedItems(1560183491194L, false);
//        try {
//            timeSeries20.update((-9999), (java.lang.Number) 1560183488832L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getMiddleMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183517357L + "'", long7 == 1560183517357L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        boolean boolean6 = year4.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
//        int int8 = year4.getYear();
//        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        boolean boolean12 = year10.equals((java.lang.Object) 10L);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        java.util.Collection collection18 = timeSeries16.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable23 = timeSeries22.getKey();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
//        double double25 = timeSeries24.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) month28);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.next();
//        int int32 = month30.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) month30);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month30);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable39 = timeSeries38.getKey();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection44 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        boolean boolean47 = year45.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
//        java.lang.String str49 = year45.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) year45, regularTimePeriod51);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
//        int int55 = month53.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class60 = timeSeries59.getTimePeriodClass();
//        java.util.Collection collection61 = timeSeries59.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable66 = timeSeries65.getKey();
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries59.addAndOrUpdate(timeSeries65);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class72 = timeSeries71.getTimePeriodClass();
//        java.util.Collection collection73 = timeSeries71.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable78 = timeSeries77.getKey();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries71.addAndOrUpdate(timeSeries77);
//        double double80 = timeSeries79.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month83 = new org.jfree.data.time.Month();
//        boolean boolean84 = fixedMillisecond82.equals((java.lang.Object) month83);
//        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = month85.next();
//        int int87 = month85.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries79.createCopy((org.jfree.data.time.RegularTimePeriod) month83, (org.jfree.data.time.RegularTimePeriod) month85);
//        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = month89.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond91 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = month92.next();
//        boolean boolean94 = fixedMillisecond91.equals((java.lang.Object) month92);
//        long long95 = fixedMillisecond91.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries96 = timeSeries88.createCopy((org.jfree.data.time.RegularTimePeriod) month89, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond91);
//        int int97 = timeSeries65.getIndex((org.jfree.data.time.RegularTimePeriod) month89);
//        org.jfree.data.time.TimeSeries timeSeries98 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) month53, (org.jfree.data.time.RegularTimePeriod) month89);
//        timeSeries3.setKey((java.lang.Comparable) month53);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(class17);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (short) 10 + "'", comparable39.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertNull(class60);
//        org.junit.Assert.assertNotNull(collection61);
//        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + (short) 10 + "'", comparable66.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertNull(class72);
//        org.junit.Assert.assertNotNull(collection73);
//        org.junit.Assert.assertTrue("'" + comparable78 + "' != '" + (short) 10 + "'", comparable78.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 2019 + "'", int87 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 1560183517604L + "'", long95 == 1560183517604L);
//        org.junit.Assert.assertNotNull(timeSeries96);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + (-1) + "'", int97 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries98);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries13.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(collection16);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date2, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        java.lang.String str13 = timeSeries11.getDescription();
        timeSeries11.removeAgedItems(1560183484014L, false);
        java.lang.String str17 = timeSeries11.getDescription();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.util.Collection collection28 = timeSeries26.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries32);
        double double35 = timeSeries34.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        boolean boolean39 = fixedMillisecond37.equals((java.lang.Object) month38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        int int42 = month40.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries43);
        java.util.List list45 = timeSeries43.getItems();
        java.lang.Object obj46 = timeSeries43.clone();
        timeSeries43.removeAgedItems(1560236399999L, true);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) 10 + "'", comparable33.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(obj46);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        double double4 = timeSeries3.getMaxY();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183520497L + "'", long2 == 1560183520497L);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone7);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        java.lang.String str8 = day5.toString();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.previous();
//        boolean boolean11 = fixedMillisecond0.equals((java.lang.Object) day5);
//        long long12 = day5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183520535L + "'", long2 == 1560183520535L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183520535L + "'", long4 == 1560183520535L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        boolean boolean4 = timeSeries3.getNotify();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        int int7 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        long long2 = year1.getLastMillisecond();
        java.lang.String str3 = year1.toString();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61820208000001L) + "'", long2 == (-61820208000001L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries11.setNotify(true);
        int int14 = timeSeries11.getMaximumItemCount();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        int int4 = month0.getYearValue();
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str5, "10-June-2019", "10-June-2019");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
//        boolean boolean38 = fixedMillisecond35.equals((java.lang.Object) month36);
//        long long39 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        int int41 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
//        java.util.Calendar calendar42 = null;
//        try {
//            long long43 = month33.getLastMillisecond(calendar42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183520693L + "'", long39 == 1560183520693L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        java.lang.String str5 = month3.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (byte) 10);
        timeSeriesDataItem19.setSelected(true);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
        org.jfree.data.time.Year year24 = month22.getYear();
        java.util.Date date25 = month22.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        int int27 = timeSeriesDataItem19.compareTo((java.lang.Object) date25);
        int int28 = timeSeriesDataItem5.compareTo((java.lang.Object) date25);
        java.util.TimeZone timeZone29 = null;
        java.util.Locale locale30 = null;
        try {
            org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date25, timeZone29, locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183491194L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        int int2 = day0.compareTo(obj1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        java.lang.Comparable comparable9 = timeSeries6.getKey();
        timeSeries6.setDescription("hi!");
        int int12 = day0.compareTo((java.lang.Object) timeSeries6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries6.add(regularTimePeriod13, (java.lang.Number) 1560183486650L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 10 + "'", comparable9.equals((short) 10));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener12);
        int int14 = timeSeries9.getItemCount();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        boolean boolean14 = fixedMillisecond11.equals((java.lang.Object) month12);
        long long15 = month12.getLastMillisecond();
        int int17 = month12.compareTo((java.lang.Object) 10);
        int int19 = month12.compareTo((java.lang.Object) "2018");
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 0.0f, false);
        java.util.Date date23 = month12.getEnd();
        long long24 = month12.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getYear();
//        int int5 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = year0.getStart();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) date11);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        try {
            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection10 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.next();
        java.lang.String str15 = year11.toString();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year11, regularTimePeriod17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(1, year11);
        int int20 = month19.getYearValue();
        int int21 = month19.getMonth();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 10 + "'", comparable5.equals((short) 10));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent5.getSummary();
        java.lang.String str9 = seriesChangeEvent5.toString();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        boolean boolean7 = year5.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        long long35 = day33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        long long41 = year40.getFirstMillisecond();
//        int int42 = year40.getYear();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) year40);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        long long45 = year44.getFirstMillisecond();
//        int int46 = year44.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year44.previous();
//        java.lang.Number number48 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) year44);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
//        java.util.Date date51 = day49.getEnd();
//        java.lang.String str52 = day49.toString();
//        long long53 = day49.getLastMillisecond();
//        java.util.Date date54 = day49.getEnd();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 1560183496274L);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        java.lang.Object obj59 = null;
//        int int60 = day58.compareTo(obj59);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timeSeries64.removePropertyChangeListener(propertyChangeListener65);
//        java.lang.Comparable comparable67 = timeSeries64.getKey();
//        timeSeries64.setDescription("hi!");
//        int int70 = day58.compareTo((java.lang.Object) timeSeries64);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
//        boolean boolean74 = fixedMillisecond72.equals((java.lang.Object) month73);
//        long long75 = fixedMillisecond72.getMiddleMillisecond();
//        java.util.Calendar calendar76 = null;
//        long long77 = fixedMillisecond72.getMiddleMillisecond(calendar76);
//        timeSeries64.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (java.lang.Number) (byte) 100, false);
//        int int81 = timeSeriesDataItem57.compareTo((java.lang.Object) false);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries3.addOrUpdate(timeSeriesDataItem57);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.0f + "'", number48.equals(0.0f));
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10-June-2019" + "'", str52.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560236399999L + "'", long53 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + (short) 10 + "'", comparable67.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1L + "'", long75 == 1L);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1L + "'", long77 == 1L);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 10);
        int int8 = month1.compareTo((java.lang.Object) "2018");
        int int9 = month1.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        boolean boolean12 = year10.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
//        java.lang.String str14 = year10.toString();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        int int20 = month18.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.util.Collection collection26 = timeSeries24.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable31 = timeSeries30.getKey();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries24.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
//        java.util.Collection collection38 = timeSeries36.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable43 = timeSeries42.getKey();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries36.addAndOrUpdate(timeSeries42);
//        double double45 = timeSeries44.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) month48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        int int52 = month50.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month50);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
//        boolean boolean59 = fixedMillisecond56.equals((java.lang.Object) month57);
//        long long60 = fixedMillisecond56.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        int int62 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) month54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month18.next();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNull(class25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (short) 10 + "'", comparable31.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + (short) 10 + "'", comparable43.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560183522245L + "'", long60 == 1560183522245L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.util.Collection collection13 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries11);
//        double double14 = timeSeries11.getMinY();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        java.util.Date date17 = day15.getEnd();
//        long long18 = day15.getMiddleMillisecond();
//        java.util.Date date19 = day15.getEnd();
//        java.lang.String str20 = day15.toString();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day15.previous();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560193199999L + "'", long18 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year13 = month8.getYear();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year13.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.util.Collection collection28 = timeSeries26.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries32);
        double double35 = timeSeries34.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        boolean boolean39 = fixedMillisecond37.equals((java.lang.Object) month38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        int int42 = month40.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean47 = year45.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries3.addOrUpdate(regularTimePeriod48, (java.lang.Number) (short) 1);
        java.lang.Object obj51 = timeSeries3.clone();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) 10 + "'", comparable33.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(obj51);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        boolean boolean6 = timeSeries5.getNotify();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        int int8 = year1.compareTo((java.lang.Object) timeSeries5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year1.previous();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy(2, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        timeSeries9.setDomainDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries17.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.Comparable comparable20 = timeSeries17.getKey();
//        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
//        java.util.Date date24 = day22.getEnd();
//        java.lang.String str25 = day22.toString();
//        long long26 = day22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day22.previous();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day22, (double) (short) -1, true);
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = day22.getLastMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        java.lang.Object obj12 = timeSeries3.clone();
        timeSeries3.setMaximumItemCount(12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries3.addChangeListener(seriesChangeListener15);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getFirstMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getMiddleMillisecond(calendar6);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560183523766L + "'", long5 == 1560183523766L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183523766L + "'", long7 == 1560183523766L);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        boolean boolean12 = year10.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
//        java.lang.String str14 = year10.toString();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        int int20 = month18.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.util.Collection collection26 = timeSeries24.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable31 = timeSeries30.getKey();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries24.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
//        java.util.Collection collection38 = timeSeries36.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable43 = timeSeries42.getKey();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries36.addAndOrUpdate(timeSeries42);
//        double double45 = timeSeries44.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) month48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        int int52 = month50.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month50);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
//        boolean boolean59 = fixedMillisecond56.equals((java.lang.Object) month57);
//        long long60 = fixedMillisecond56.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        int int62 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) month54);
//        java.util.Calendar calendar64 = null;
//        try {
//            long long65 = month54.getFirstMillisecond(calendar64);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNull(class25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (short) 10 + "'", comparable31.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + (short) 10 + "'", comparable43.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560183523791L + "'", long60 == 1560183523791L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries63);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) propertyChangeListener4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries20.setMaximumItemAge((long) 10);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries20.getDataItem(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183523862L + "'", long27 == 1560183523862L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 10);
        int int8 = month1.compareTo((java.lang.Object) "2018");
        java.lang.Object obj9 = null;
        boolean boolean10 = month1.equals(obj9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 10);
        int int8 = month1.compareTo((java.lang.Object) "2018");
        int int9 = month1.getYearValue();
        long long10 = month1.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month1.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        long long6 = year5.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            year4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560183491194L);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183491194L + "'", long2 == 1560183491194L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        int int9 = year6.compareTo((java.lang.Object) 1560183479708L);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 2147483647);
//        timeSeriesDataItem4.setSelected(true);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        double double10 = timeSeries3.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560183481917L, true);
//        java.lang.String str17 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.previous();
//        long long21 = day18.getSerialIndex();
//        int int22 = day18.getYear();
//        int int23 = day18.getDayOfMonth();
//        long long24 = day18.getSerialIndex();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 11);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183524186L + "'", long13 == 1560183524186L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10L);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.util.Collection collection18 = timeSeries16.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
        double double25 = timeSeries24.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) month28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.next();
        int int32 = month30.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month30.previous();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem11.getPeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100.0d);
        long long3 = year0.getMiddleMillisecond();
        java.util.Date date4 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) date11);
        java.lang.Number number14 = timeSeriesDataItem5.getValue();
        java.lang.Number number15 = timeSeriesDataItem5.getValue();
        java.lang.Object obj16 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (byte) 10 + "'", number14.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 10 + "'", number15.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        int int4 = month1.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        boolean boolean6 = timeSeries5.getNotify();
        java.util.Collection collection7 = timeSeries5.getTimePeriods();
        int int8 = year1.compareTo((java.lang.Object) timeSeries5);
        java.util.List list9 = timeSeries5.getItems();
        java.util.List list10 = timeSeries5.getItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        java.lang.Object obj12 = timeSeriesDataItem10.clone();
        boolean boolean13 = month0.equals((java.lang.Object) timeSeriesDataItem10);
        int int15 = month0.compareTo((java.lang.Object) 1560183502139L);
        int int16 = month0.getYearValue();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month0.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1560183482051L);
        boolean boolean7 = timeSeriesDataItem5.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        int int10 = year8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        java.lang.String str12 = regularTimePeriod11.toString();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) regularTimePeriod11);
        boolean boolean14 = timeSeriesDataItem5.isSelected();
        timeSeriesDataItem5.setValue((java.lang.Number) 1560183483683L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2018" + "'", str12.equals("2018"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(7, 4);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable19 = timeSeries18.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection24 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        double double25 = timeSeries18.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1560183481917L, true);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond26.getMiddleMillisecond(calendar32);
//        java.util.Calendar calendar34 = null;
//        fixedMillisecond26.peg(calendar34);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        int int37 = month14.getMonth();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (short) 10 + "'", comparable19.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560183524745L + "'", long28 == 1560183524745L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560183524745L + "'", long33 == 1560183524745L);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.util.Collection collection18 = timeSeries16.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
        try {
            int int27 = timeSeries24.getIndex(regularTimePeriod26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection25);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        double double10 = timeSeries3.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560183481917L, true);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.getDataItem(regularTimePeriod19);
//        java.lang.Object obj21 = timeSeriesDataItem20.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem20.getPeriod();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183524978L + "'", long13 == 1560183524978L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getMonth();
//        java.lang.Object obj5 = null;
//        int int6 = day0.compareTo(obj5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        long long9 = day6.getFirstMillisecond();
//        long long10 = day6.getLastMillisecond();
//        int int11 = day0.compareTo((java.lang.Object) day6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month1.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 1560183488436L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
        long long29 = fixedMillisecond26.getMiddleMillisecond();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond26.getMiddleMillisecond(calendar30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond26.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1560183481224L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo7);
        java.lang.Object obj9 = seriesChangeEvent5.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent5.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo11);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(seriesChangeInfo10);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 2147483647);
//        java.lang.Object obj5 = timeSeriesDataItem4.clone();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertNotNull(obj5);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 5, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        boolean boolean14 = fixedMillisecond11.equals((java.lang.Object) month12);
        long long15 = month12.getLastMillisecond();
        int int17 = month12.compareTo((java.lang.Object) 10);
        int int19 = month12.compareTo((java.lang.Object) "2018");
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 0.0f, false);
        timeSeries3.setDescription("10");
        java.lang.Class class25 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(class25);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        java.lang.Object obj19 = timeSeriesDataItem17.clone();
        timeSeries10.add(timeSeriesDataItem17, true);
        timeSeries3.add(timeSeriesDataItem17, true);
        java.lang.Number number24 = timeSeriesDataItem17.getValue();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries28.addChangeListener(seriesChangeListener31);
        java.lang.Comparable comparable33 = timeSeries28.getKey();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener34);
        timeSeries28.setDomainDescription("hi!");
        java.util.Collection collection38 = timeSeries28.getTimePeriods();
        java.lang.Comparable comparable39 = timeSeries28.getKey();
        boolean boolean40 = timeSeriesDataItem17.equals((java.lang.Object) timeSeries28);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (short) 10 + "'", comparable11.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) 10 + "'", number24.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) 10 + "'", comparable33.equals((short) 10));
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (short) 10 + "'", comparable39.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
//        boolean boolean38 = fixedMillisecond35.equals((java.lang.Object) month36);
//        long long39 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        int int41 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month33.next();
//        java.lang.String str43 = month33.toString();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183525437L + "'", long39 == 1560183525437L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "June 2019" + "'", str43.equals("June 2019"));
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries11.getDataItem(regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (byte) 10);
        timeSeriesDataItem19.setSelected(true);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.previous();
        org.jfree.data.time.Year year24 = month22.getYear();
        java.util.Date date25 = month22.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        int int27 = timeSeriesDataItem19.compareTo((java.lang.Object) date25);
        int int28 = timeSeriesDataItem5.compareTo((java.lang.Object) date25);
        java.util.TimeZone timeZone29 = null;
        try {
            org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date25, timeZone29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        double double10 = timeSeries3.getMaxY();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Object obj12 = null;
        int int13 = day11.compareTo(obj12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Comparable comparable20 = timeSeries17.getKey();
        timeSeries17.setDescription("hi!");
        int int23 = day11.compareTo((java.lang.Object) timeSeries17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) month26);
        long long28 = fixedMillisecond25.getMiddleMillisecond();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getMiddleMillisecond(calendar29);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (byte) 100, false);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries17);
        java.util.Collection collection35 = timeSeries34.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries34.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Year year3 = month1.getYear();
        java.lang.Class<?> wildcardClass4 = year3.getClass();
        java.lang.Class class5 = null;
        java.lang.Class class6 = null;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Date date9 = day7.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date9, timeZone12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date9);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date9, timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int4);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        java.util.List list10 = timeSeries8.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries8.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.lang.Comparable comparable5 = timeSeries3.getKey();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 10 + "'", comparable5.equals((short) 10));
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) day13);
//        try {
//            timeSeries11.delete((int) (byte) 10, 4, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        long long12 = timeSeries9.getMaximumItemAge();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timeSeries3.getDescription();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
//        boolean boolean11 = fixedMillisecond8.equals((java.lang.Object) month9);
//        long long12 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries16.addChangeListener(seriesChangeListener19);
//        java.lang.Comparable comparable21 = timeSeries16.getKey();
//        timeSeries16.setMaximumItemAge((long) 100);
//        java.lang.Comparable comparable24 = timeSeries16.getKey();
//        int int25 = fixedMillisecond8.compareTo((java.lang.Object) comparable24);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond8.getFirstMillisecond(calendar26);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond8.getMiddleMillisecond(calendar28);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy(regularTimePeriod7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183527333L + "'", long12 == 1560183527333L);
//        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) 10 + "'", comparable21.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (short) 10 + "'", comparable24.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183527333L + "'", long27 == 1560183527333L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560183527333L + "'", long29 == 1560183527333L);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 2019);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
//        boolean boolean38 = fixedMillisecond35.equals((java.lang.Object) month36);
//        long long39 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        int int41 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener42);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560183527363L + "'", long39 == 1560183527363L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        int int8 = month5.getMonth();
        java.lang.Number number9 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month5, number9, false);
        double double12 = timeSeries3.getMinY();
        java.lang.String str13 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Date date3 = day1.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date3, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        int int2 = month0.getYearValue();
        java.util.Date date3 = month0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        long long6 = month5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        double double10 = timeSeries3.getMinY();
        java.lang.Number number12 = null;
        try {
            timeSeries3.update(0, number12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1560183482051L);
        boolean boolean7 = timeSeriesDataItem5.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        int int10 = year8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        java.lang.String str12 = regularTimePeriod11.toString();
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) regularTimePeriod11);
        timeSeriesDataItem5.setValue((java.lang.Number) 1560183488134L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2018" + "'", str12.equals("2018"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.lang.String str4 = year0.toString();
        java.util.Date date5 = year0.getEnd();
        int int7 = year0.compareTo((java.lang.Object) true);
        long long8 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.lang.String str4 = month3.toString();
        long long5 = month3.getFirstMillisecond();
        org.jfree.data.time.Year year6 = month3.getYear();
        long long7 = year6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 09:18:40 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.addChangeListener(seriesChangeListener14);
        java.lang.Comparable comparable16 = timeSeries11.getKey();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener17);
        timeSeries11.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        java.util.Collection collection26 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable31 = timeSeries30.getKey();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries24.addAndOrUpdate(timeSeries30);
        java.util.Collection collection33 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        int int34 = timeSeriesDataItem5.compareTo((java.lang.Object) collection33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) 10 + "'", comparable16.equals((short) 10));
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (short) 10 + "'", comparable31.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener29);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183529451L + "'", long27 == 1560183529451L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("10");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.String str6 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 10" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 10"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getFirstMillisecond();
//        int int34 = year32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
//        java.lang.Number number36 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) year32);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.previous();
//        java.util.Date date39 = day37.getEnd();
//        java.lang.String str40 = day37.toString();
//        long long41 = day37.getLastMillisecond();
//        java.util.Date date42 = day37.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 1560183496274L);
//        long long46 = day43.getSerialIndex();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0f + "'", number36.equals(0.0f));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries11.removeAgedItems(false);
        timeSeries11.removeAgedItems(1560183481404L, false);
        timeSeries11.setDomainDescription("2018");
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        int int10 = timeSeries3.getItemCount();
        java.lang.Class class11 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries15.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getFirstMillisecond();
//        int int34 = year32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
//        java.lang.Number number36 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) year32);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.previous();
//        java.util.Date date39 = day37.getEnd();
//        java.lang.String str40 = day37.toString();
//        long long41 = day37.getLastMillisecond();
//        java.util.Date date42 = day37.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 1560183496274L);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.Object obj47 = null;
//        int int48 = day46.compareTo(obj47);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timeSeries52.removePropertyChangeListener(propertyChangeListener53);
//        java.lang.Comparable comparable55 = timeSeries52.getKey();
//        timeSeries52.setDescription("hi!");
//        int int58 = day46.compareTo((java.lang.Object) timeSeries52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
//        boolean boolean62 = fixedMillisecond60.equals((java.lang.Object) month61);
//        long long63 = fixedMillisecond60.getMiddleMillisecond();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond60.getMiddleMillisecond(calendar64);
//        timeSeries52.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (java.lang.Number) (byte) 100, false);
//        int int69 = timeSeriesDataItem45.compareTo((java.lang.Object) false);
//        boolean boolean71 = timeSeriesDataItem45.equals((java.lang.Object) 1560183488566L);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0f + "'", number36.equals(0.0f));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + (short) 10 + "'", comparable55.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.data.time.Year year4 = month2.getYear();
        int int5 = day0.compareTo((java.lang.Object) month2);
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        java.lang.Object obj19 = timeSeriesDataItem17.clone();
        timeSeries10.add(timeSeriesDataItem17, true);
        timeSeries3.add(timeSeriesDataItem17, true);
        timeSeriesDataItem17.setSelected(false);
        java.lang.Number number26 = timeSeriesDataItem17.getValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (short) 10 + "'", comparable11.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 10 + "'", number26.equals((byte) 10));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        java.util.Collection collection10 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable15 = timeSeries14.getKey();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries14);
//        timeSeries16.removeAgedItems(false);
//        timeSeries16.removeAgedItems(1560183481404L, false);
//        int int22 = day0.compareTo((java.lang.Object) false);
//        long long23 = day0.getFirstMillisecond();
//        java.lang.String str24 = day0.toString();
//        java.lang.String str25 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560150000000L + "'", long23 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        long long29 = fixedMillisecond23.getFirstMillisecond();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183531538L + "'", long27 == 1560183531538L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560183531538L + "'", long29 == 1560183531538L);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.util.TimeZone timeZone7 = null;
//        java.util.Locale locale8 = null;
//        try {
//            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date5, timeZone7, locale8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "");
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getLastMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183531719L + "'", long2 == 1560183531719L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183531719L + "'", long7 == 1560183531719L);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        java.lang.String str13 = timeSeries11.getDescription();
        timeSeries11.removeAgedItems((long) 1, false);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate(regularTimePeriod19, (java.lang.Number) 1560183523158L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
//        long long11 = fixedMillisecond7.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries15.addChangeListener(seriesChangeListener18);
//        java.lang.Comparable comparable20 = timeSeries15.getKey();
//        timeSeries15.setMaximumItemAge((long) 100);
//        java.lang.Comparable comparable23 = timeSeries15.getKey();
//        int int24 = fixedMillisecond7.compareTo((java.lang.Object) comparable23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond7.getFirstMillisecond(calendar25);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond7.getMiddleMillisecond(calendar27);
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond7.peg(calendar29);
//        boolean boolean31 = month6.equals((java.lang.Object) calendar29);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183532104L + "'", long11 == 1560183532104L);
//        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183532104L + "'", long26 == 1560183532104L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560183532104L + "'", long28 == 1560183532104L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getMonth();
        java.lang.String str4 = month0.toString();
        java.lang.Object obj5 = null;
        int int6 = month0.compareTo(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        double double10 = timeSeries3.getMaxY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.next();
//        java.util.Calendar calendar7 = null;
//        long long8 = regularTimePeriod6.getMiddleMillisecond(calendar7);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560183532287L + "'", long8 == 1560183532287L);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        boolean boolean19 = timeSeriesDataItem17.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate(timeSeriesDataItem17);
        boolean boolean21 = timeSeriesDataItem20.isSelected();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        java.util.Date date7 = day5.getEnd();
//        java.lang.String str8 = day5.toString();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.previous();
//        boolean boolean11 = fixedMillisecond0.equals((java.lang.Object) day5);
//        long long12 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar13 = null;
//        fixedMillisecond0.peg(calendar13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183532361L + "'", long2 == 1560183532361L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183532361L + "'", long4 == 1560183532361L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183532361L + "'", long12 == 1560183532361L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 10);
        long long7 = month1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month1, (java.lang.Number) 9223372036854775807L);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month1.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        int int4 = month1.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int4);
        try {
            timeSeries5.update(0, (java.lang.Number) 1560183481917L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        java.util.Calendar calendar8 = null;
        try {
            day5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        java.lang.Object obj12 = timeSeriesDataItem10.clone();
        timeSeries3.add(timeSeriesDataItem10, true);
        java.util.List list15 = timeSeries3.getItems();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) list15, seriesChangeInfo16);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(list15);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries8.addChangeListener(seriesChangeListener11);
//        java.lang.Comparable comparable13 = timeSeries8.getKey();
//        timeSeries8.setMaximumItemAge((long) 100);
//        java.lang.Comparable comparable16 = timeSeries8.getKey();
//        int int17 = fixedMillisecond0.compareTo((java.lang.Object) comparable16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond0.getFirstMillisecond(calendar18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond0.getMiddleMillisecond(calendar20);
//        java.util.Calendar calendar22 = null;
//        fixedMillisecond0.peg(calendar22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond0.next();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        boolean boolean31 = year29.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
//        int int33 = year29.getYear();
//        boolean boolean34 = timeSeries28.equals((java.lang.Object) year29);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
//        java.util.Collection collection40 = timeSeries38.getTimePeriods();
//        java.util.Collection collection41 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries38);
//        boolean boolean42 = fixedMillisecond0.equals((java.lang.Object) timeSeries28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month44.next();
//        boolean boolean46 = fixedMillisecond43.equals((java.lang.Object) month44);
//        java.util.Calendar calendar47 = null;
//        fixedMillisecond43.peg(calendar47);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond43.getFirstMillisecond(calendar49);
//        long long51 = fixedMillisecond43.getSerialIndex();
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond43.getMiddleMillisecond(calendar52);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond43.getFirstMillisecond(calendar54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183532557L + "'", long4 == 1560183532557L);
//        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) 10 + "'", comparable13.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) 10 + "'", comparable16.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560183532557L + "'", long19 == 1560183532557L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560183532557L + "'", long21 == 1560183532557L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNull(class39);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560183532567L + "'", long50 == 1560183532567L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560183532567L + "'", long51 == 1560183532567L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560183532567L + "'", long53 == 1560183532567L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560183532567L + "'", long55 == 1560183532567L);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timeSeries3.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        int int13 = year9.getYear();
        java.lang.Number number14 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, number14, true);
        java.lang.String str17 = year9.toString();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        java.util.Collection collection10 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable15 = timeSeries14.getKey();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries14);
//        timeSeries14.fireSeriesChanged();
//        int int18 = day0.compareTo((java.lang.Object) timeSeries14);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
//        java.util.Collection collection24 = timeSeries22.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable29 = timeSeries28.getKey();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries22.addAndOrUpdate(timeSeries28);
//        double double31 = timeSeries30.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        boolean boolean35 = fixedMillisecond33.equals((java.lang.Object) month34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
//        int int38 = month36.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) month36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month34.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod40, (java.lang.Number) 100L);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
//        int int45 = timeSeriesDataItem42.compareTo((java.lang.Object) month43);
//        int int46 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) month43);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (short) 10 + "'", comparable29.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        java.lang.Class<?> wildcardClass23 = timeSeries3.getClass();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        timeSeries3.setMaximumItemAge(1560183479708L);
        timeSeries3.setDescription("9-June-2019");
        try {
            timeSeries3.update((int) '4', (java.lang.Number) 1560183514641L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        int int7 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.String str3 = year2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        timeSeries3.setRangeDescription("");
        double double13 = timeSeries3.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1560183486581L);
        int int19 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable throwable4 = null;
        try {
            seriesException1.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean14 = month8.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month8.previous();
        long long16 = month8.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = day21.getLastMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        int int2 = year0.getYear();
        int int3 = year0.getYear();
        long long4 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        java.lang.Object obj17 = timeSeriesDataItem15.clone();
        timeSeries8.add(timeSeriesDataItem15, true);
        boolean boolean20 = timeSeriesDataItem15.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem15.getPeriod();
        boolean boolean22 = year0.equals((java.lang.Object) timeSeriesDataItem15);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.util.Collection collection28 = timeSeries26.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries32);
        double double35 = timeSeries34.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        boolean boolean39 = fixedMillisecond37.equals((java.lang.Object) month38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        int int42 = month40.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month38.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod44, (java.lang.Number) 100L);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        int int48 = timeSeriesDataItem15.compareTo((java.lang.Object) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 10 + "'", comparable9.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) 10 + "'", comparable33.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        java.lang.String str14 = year10.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod16);
        java.lang.Object obj18 = timeSeries3.clone();
        timeSeries3.setMaximumItemCount((int) ' ');
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(obj18);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
//        timeSeries3.setDomainDescription("hi!");
//        java.util.Collection collection13 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        long long17 = day14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18, "org.jfree.data.time.TimePeriodFormatException: ", "hi!");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(6, 2019);
        java.lang.Object obj5 = null;
        int int6 = month4.compareTo(obj5);
        long long7 = month4.getMiddleMillisecond();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection10 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.next();
        java.lang.String str15 = year11.toString();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year11, regularTimePeriod17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(1, year11);
        int int20 = month19.getYearValue();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month19.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 10 + "'", comparable5.equals((short) 10));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        int int4 = year1.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, year1);
        int int6 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        boolean boolean14 = fixedMillisecond11.equals((java.lang.Object) month12);
        long long15 = month12.getLastMillisecond();
        int int17 = month12.compareTo((java.lang.Object) 10);
        int int19 = month12.compareTo((java.lang.Object) "2018");
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 0.0f, false);
        timeSeries3.setDescription("10");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        timeSeries3.setRangeDescription("2018");
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        double double29 = timeSeries28.getMinY();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        java.util.Date date32 = day30.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date32);
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month37, (double) 100);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        boolean boolean42 = year40.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) (byte) 10);
//        timeSeriesDataItem45.setSelected(true);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month48.previous();
//        org.jfree.data.time.Year year50 = month48.getYear();
//        java.util.Date date51 = month48.getStart();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
//        int int53 = timeSeriesDataItem45.compareTo((java.lang.Object) date51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        boolean boolean56 = year54.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year54.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year54, (java.lang.Number) (byte) 10);
//        timeSeriesDataItem59.setSelected(true);
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.previous();
//        org.jfree.data.time.Year year64 = month62.getYear();
//        java.util.Date date65 = month62.getStart();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
//        int int67 = timeSeriesDataItem59.compareTo((java.lang.Object) date65);
//        int int68 = timeSeriesDataItem45.compareTo((java.lang.Object) date65);
//        try {
//            timeSeries28.add(timeSeriesDataItem45, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183536018L + "'", long27 == 1560183536018L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) month2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond1.getClass();
        long long8 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        int int10 = timeSeries3.getItemCount();
//        boolean boolean11 = timeSeries3.getNotify();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        boolean boolean14 = year12.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        java.lang.Object obj19 = timeSeriesDataItem17.clone();
//        boolean boolean20 = timeSeriesDataItem17.isSelected();
//        timeSeries3.add(timeSeriesDataItem17, true);
//        java.util.List list23 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
//        java.util.Collection collection29 = timeSeries27.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable34 = timeSeries33.getKey();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries27.addAndOrUpdate(timeSeries33);
//        double double36 = timeSeries35.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) month39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
//        int int43 = month41.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month39, (org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.previous();
//        long long47 = day45.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 0.0f);
//        java.util.Collection collection50 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries44);
//        java.lang.String str51 = timeSeries3.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertNull(class28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (short) 10 + "'", comparable34.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 43626L + "'", long47 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.Date date6 = day5.getEnd();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.setDomainDescription("10-June-2019");
        java.util.List list14 = timeSeries9.getItems();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year13 = month8.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        org.jfree.data.time.Year year16 = month14.getYear();
        java.util.Date date17 = month14.getStart();
        int int18 = year13.compareTo((java.lang.Object) month14);
        org.jfree.data.time.Year year19 = month14.getYear();
        int int21 = year19.compareTo((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        java.util.Date date5 = month1.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        timeSeries3.setRangeDescription("");
        timeSeries3.setDescription("Time");
        java.lang.Object obj15 = null;
        boolean boolean16 = timeSeries3.equals(obj15);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries8.removePropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries8.addChangeListener(seriesChangeListener11);
//        java.lang.Comparable comparable13 = timeSeries8.getKey();
//        timeSeries8.setMaximumItemAge((long) 100);
//        java.lang.Comparable comparable16 = timeSeries8.getKey();
//        int int17 = fixedMillisecond0.compareTo((java.lang.Object) comparable16);
//        long long18 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183537048L + "'", long4 == 1560183537048L);
//        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (short) 10 + "'", comparable13.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + (short) 10 + "'", comparable16.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560183537048L + "'", long18 == 1560183537048L);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        java.util.Collection collection10 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable15 = timeSeries14.getKey();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries14);
//        timeSeries14.fireSeriesChanged();
//        int int18 = day0.compareTo((java.lang.Object) timeSeries14);
//        int int19 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        int int10 = timeSeries3.getItemCount();
//        boolean boolean11 = timeSeries3.getNotify();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        boolean boolean14 = year12.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        java.lang.Object obj19 = timeSeriesDataItem17.clone();
//        boolean boolean20 = timeSeriesDataItem17.isSelected();
//        timeSeries3.add(timeSeriesDataItem17, true);
//        java.util.List list23 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
//        java.util.Collection collection29 = timeSeries27.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable34 = timeSeries33.getKey();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries27.addAndOrUpdate(timeSeries33);
//        double double36 = timeSeries35.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) month39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
//        int int43 = month41.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) month39, (org.jfree.data.time.RegularTimePeriod) month41);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.previous();
//        long long47 = day45.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 0.0f);
//        java.util.Collection collection50 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries44);
//        timeSeries3.setMaximumItemCount(0);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeries3.getTimePeriod((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertNull(class28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + (short) 10 + "'", comparable34.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 43626L + "'", long47 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(collection50);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        java.util.List list10 = timeSeries8.getItems();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNull(class4);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(7, 4);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable19 = timeSeries18.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection24 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        double double25 = timeSeries18.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1560183481917L, true);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond26.getMiddleMillisecond(calendar32);
//        java.util.Calendar calendar34 = null;
//        fixedMillisecond26.peg(calendar34);
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable41 = timeSeries40.getKey();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection46 = timeSeries40.getTimePeriodsUniqueToOtherSeries(timeSeries45);
//        int int47 = timeSeries45.getItemCount();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day48.previous();
//        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) day48, (java.lang.Number) 2, true);
//        boolean boolean54 = month14.equals((java.lang.Object) timeSeries45);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        boolean boolean57 = year55.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year55.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) (byte) 10);
//        timeSeriesDataItem60.setSelected(true);
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month63.previous();
//        org.jfree.data.time.Year year65 = month63.getYear();
//        java.util.Date date66 = month63.getStart();
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date66);
//        int int68 = timeSeriesDataItem60.compareTo((java.lang.Object) date66);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries45.addOrUpdate(timeSeriesDataItem60);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (short) 10 + "'", comparable19.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560183537227L + "'", long28 == 1560183537227L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560183537227L + "'", long33 == 1560183537227L);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + (short) 10 + "'", comparable41.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        int int7 = month6.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        long long5 = fixedMillisecond0.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = fixedMillisecond0.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183537300L + "'", long4 == 1560183537300L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560183537300L + "'", long5 == 1560183537300L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getLastMillisecond();
        int int4 = year2.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        java.util.Collection collection10 = timeSeries8.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable15 = timeSeries14.getKey();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries14);
        double double17 = timeSeries16.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) month20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        int int24 = month22.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) month20, (org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month20.next();
        java.util.Date date27 = regularTimePeriod26.getEnd();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date27, timeZone28);
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date30, timeZone31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod32);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond0, seriesChangeInfo6);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent7.getSummary();
//        java.lang.Object obj9 = seriesChangeEvent7.getSource();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183537433L + "'", long4 == 1560183537433L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560183537433L + "'", long5 == 1560183537433L);
//        org.junit.Assert.assertNull(seriesChangeInfo8);
//        org.junit.Assert.assertNotNull(obj9);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
        boolean boolean17 = fixedMillisecond14.equals((java.lang.Object) month15);
        long long18 = month15.getLastMillisecond();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month15, (double) 0.0f);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) (byte) 10);
        timeSeriesDataItem26.setSelected(true);
        try {
            timeSeries9.add(timeSeriesDataItem26, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        long long5 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond0, seriesChangeInfo6);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent7.getSummary();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent7.getSummary();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183537541L + "'", long4 == 1560183537541L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560183537541L + "'", long5 == 1560183537541L);
//        org.junit.Assert.assertNull(seriesChangeInfo8);
//        org.junit.Assert.assertNull(seriesChangeInfo9);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getMonth();
        long long4 = month0.getMiddleMillisecond();
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        timeSeries3.removeAgedItems(false);
        double double10 = timeSeries3.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent5.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent5.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo10);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(seriesChangeInfo8);
        org.junit.Assert.assertNull(seriesChangeInfo9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) (byte) 10);
        timeSeriesDataItem8.setSelected(true);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        org.jfree.data.time.Year year13 = month11.getYear();
        java.util.Date date14 = month11.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        int int16 = timeSeriesDataItem8.compareTo((java.lang.Object) date14);
        int int17 = fixedMillisecond1.compareTo((java.lang.Object) int16);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        double double29 = timeSeries28.getMinY();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        java.util.Date date32 = day30.getEnd();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date32);
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month37, (double) 100);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        boolean boolean42 = year40.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) (byte) 10);
//        timeSeriesDataItem45.setSelected(true);
//        try {
//            timeSeries28.add(timeSeriesDataItem45);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183537911L + "'", long27 == 1560183537911L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        java.lang.Class<?> wildcardClass3 = year2.getClass();
//        java.lang.Class class4 = null;
//        java.lang.Class class5 = null;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
//        java.util.Date date8 = day6.getEnd();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date8, timeZone11);
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date8, timeZone13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date8);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date8, timeZone16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        java.util.Date date21 = day19.getEnd();
//        java.lang.String str22 = day19.toString();
//        long long23 = day19.getLastMillisecond();
//        java.util.Date date24 = day19.getEnd();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date24, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
//        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
//        boolean boolean9 = month4.equals((java.lang.Object) wildcardClass8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month4.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183538376L + "'", long7 == 1560183538376L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        double double12 = timeSeries11.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod21, (java.lang.Number) 100L);
        java.util.Date date24 = regularTimePeriod21.getEnd();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries10.addOrUpdate(timeSeriesDataItem17);
        try {
            timeSeries3.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNull(class11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener8);
//        java.lang.Comparable comparable10 = timeSeries7.getKey();
//        timeSeries7.setDescription("hi!");
//        boolean boolean13 = timeSeries7.getNotify();
//        timeSeries7.setRangeDescription("");
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate19);
//        timeSeries3.setKey((java.lang.Comparable) serialDate19);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183538544L + "'", long2 == 1560183538544L);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(serialDate19);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getFirstMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 0L);
        long long7 = month1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        boolean boolean4 = timeSeries3.getNotify();
        int int5 = timeSeries3.getItemCount();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond23.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond23.previous();
//        long long31 = fixedMillisecond23.getSerialIndex();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond23.getMiddleMillisecond(calendar32);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183538743L + "'", long27 == 1560183538743L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560183538743L + "'", long31 == 1560183538743L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560183538743L + "'", long33 == 1560183538743L);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) 'a', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        timeSeriesDataItem5.setSelected(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.Year year10 = month8.getYear();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = timeSeriesDataItem5.compareTo((java.lang.Object) date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date11);
        java.util.TimeZone timeZone15 = null;
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date11, timeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        org.jfree.data.time.Year year4 = month2.getYear();
//        java.lang.Class<?> wildcardClass5 = year4.getClass();
//        java.lang.Class class6 = null;
//        java.lang.Class class7 = null;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        java.util.Date date10 = day8.getEnd();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date10, timeZone13);
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date10);
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone18);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        java.util.Date date23 = day21.getEnd();
//        java.lang.String str24 = day21.toString();
//        long long25 = day21.getLastMillisecond();
//        java.util.Date date26 = day21.getEnd();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date26, timeZone28);
//        int int30 = year1.compareTo((java.lang.Object) timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        int int4 = year1.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(11, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        java.lang.String str7 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Comparable comparable20 = timeSeries17.getKey();
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        double double22 = timeSeries17.getMinY();
        timeSeries17.clear();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        java.lang.Object obj12 = timeSeries3.clone();
        timeSeries3.setMaximumItemCount(12);
        boolean boolean15 = timeSeries3.getNotify();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        timeSeries3.setDescription("hi!");
        boolean boolean9 = timeSeries3.getNotify();
        timeSeries3.setMaximumItemAge(1560183502226L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 10 + "'", comparable6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
//        timeSeries3.setDomainDescription("hi!");
//        java.util.Collection collection13 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        long long17 = day14.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = day14.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.setDomainDescription("hi!");
        java.util.Collection collection13 = timeSeries3.getTimePeriods();
        java.lang.Comparable comparable14 = timeSeries3.getKey();
        java.lang.String str15 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem21.getPeriod();
        java.lang.Object obj23 = timeSeriesDataItem21.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.addOrUpdate(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (short) 10 + "'", comparable14.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        boolean boolean7 = timeSeriesDataItem5.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj9 = timeSeriesDataItem5.clone();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        int int18 = year14.getYear();
        boolean boolean19 = timeSeries13.equals((java.lang.Object) year14);
        long long20 = year14.getMiddleMillisecond();
        int int21 = timeSeriesDataItem5.compareTo((java.lang.Object) long20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        java.lang.Class<?> wildcardClass7 = date2.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date2, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        timeSeries3.setMaximumItemAge((long) 100);
//        timeSeries3.setNotify(false);
//        double double13 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        java.util.Collection collection19 = timeSeries17.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable24 = timeSeries23.getKey();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries17.addAndOrUpdate(timeSeries23);
//        double double26 = timeSeries25.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) month29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.next();
//        int int33 = month31.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) month29, (org.jfree.data.time.RegularTimePeriod) month31);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
//        long long37 = day35.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.previous();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = year42.getYear();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) month40, (org.jfree.data.time.RegularTimePeriod) year42);
//        long long46 = month40.getFirstMillisecond();
//        java.lang.Number number47 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month40);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (short) 10 + "'", comparable24.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
//        org.junit.Assert.assertNull(number47);
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        java.lang.String str5 = day0.toString();
//        java.lang.String str6 = day0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        double double10 = timeSeries3.getMinY();
        boolean boolean11 = timeSeries3.getNotify();
        double double12 = timeSeries3.getMaxY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries3.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        timeSeries3.removeAgedItems(false);
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        timeSeries3.setNotify(true);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        java.util.Date date14 = day12.getEnd();
//        java.lang.String str15 = day12.toString();
//        long long16 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 1560236399999L);
//        int int19 = day12.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day12.previous();
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener9);
        timeSeries3.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.util.Collection collection18 = timeSeries16.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries16.addAndOrUpdate(timeSeries22);
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        try {
            timeSeries3.update(8, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        java.util.Date date8 = day6.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.previous();
        timeSeries3.add(regularTimePeriod11, 0.0d, true);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 24234L, "2019", "10-June-2019");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        timeSeries3.setKey((java.lang.Comparable) 1560183481224L);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 24234L + "'", comparable4.equals(24234L));
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.fireSeriesChanged();
//        long long30 = timeSeries28.getMaximumItemAge();
//        timeSeries28.setRangeDescription("June 2019");
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries36.removePropertyChangeListener(propertyChangeListener37);
//        boolean boolean39 = timeSeries36.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable44 = timeSeries43.getKey();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        boolean boolean47 = year45.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year45.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeriesDataItem50.getPeriod();
//        java.lang.Object obj52 = timeSeriesDataItem50.clone();
//        timeSeries43.add(timeSeriesDataItem50, true);
//        timeSeries36.add(timeSeriesDataItem50, true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener57 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener57);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries36.addChangeListener(seriesChangeListener59);
//        java.util.Collection collection61 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries36);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183540236L + "'", long27 == 1560183540236L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + (short) 10 + "'", comparable44.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertNotNull(collection61);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.util.Date date6 = year0.getStart();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        java.lang.String str3 = year0.toString();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        int int2 = day0.compareTo(obj1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
//        boolean boolean12 = fixedMillisecond9.equals((java.lang.Object) month10);
//        long long13 = month10.getLastMillisecond();
//        int int15 = month10.compareTo((java.lang.Object) 10);
//        int int17 = month10.compareTo((java.lang.Object) "2018");
//        int int18 = month10.getYearValue();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 1560183520535L, false);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable26 = timeSeries25.getKey();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection31 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        double double32 = timeSeries25.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 1560183481917L, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond33.next();
//        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (short) 10 + "'", comparable26.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560183540916L + "'", long35 == 1560183540916L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable9 = timeSeries8.getKey();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection14 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        boolean boolean17 = year15.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.next();
//        java.lang.String str19 = year15.toString();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) year15, regularTimePeriod21);
//        java.lang.Number number23 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod21, number23);
//        int int25 = fixedMillisecond0.compareTo((java.lang.Object) regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183541019L + "'", long4 == 1560183541019L);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 10 + "'", comparable9.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        int int8 = month5.getMonth();
        java.lang.Number number9 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month5, number9, false);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        int int20 = year16.getYear();
        boolean boolean21 = timeSeries15.equals((java.lang.Object) year16);
        double double22 = timeSeries15.getMinY();
        boolean boolean23 = timeSeries15.getNotify();
        double double24 = timeSeries15.getMaxY();
        boolean boolean25 = month5.equals((java.lang.Object) double24);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
//        java.lang.Class<?> wildcardClass8 = fixedMillisecond5.getClass();
//        boolean boolean9 = month4.equals((java.lang.Object) wildcardClass8);
//        int int10 = month4.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183541211L + "'", long7 == 1560183541211L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond10);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond10);
//        int int15 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond10);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560183541238L + "'", long7 == 1560183541238L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560183541238L + "'", long9 == 1560183541238L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560183541240L + "'", long12 == 1560183541240L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        java.util.Date date5 = day0.getEnd();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year13 = month8.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        org.jfree.data.time.Year year16 = month14.getYear();
        java.util.Date date17 = month14.getStart();
        int int18 = year13.compareTo((java.lang.Object) month14);
        int int20 = year13.compareTo((java.lang.Object) 1560183520497L);
        int int21 = year13.getYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        int int10 = timeSeries3.getItemCount();
        boolean boolean11 = timeSeries3.getNotify();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        java.lang.Object obj19 = timeSeriesDataItem17.clone();
        boolean boolean20 = timeSeriesDataItem17.isSelected();
        timeSeries3.add(timeSeriesDataItem17, true);
        java.util.List list23 = timeSeries3.getItems();
        try {
            timeSeries3.delete(2019, (int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.List list5 = timeSeries3.getItems();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemCount(2147483647);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries3.createCopy(2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = day0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        java.lang.Class class6 = null;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        java.util.Date date9 = day7.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9);
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date9, timeZone13);
        boolean boolean15 = month5.equals((java.lang.Object) regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        java.util.Collection collection12 = timeSeries9.getTimePeriods();
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        timeSeries3.removeAgedItems(false);
        double double10 = timeSeries3.getMinY();
        timeSeries3.clear();
        org.jfree.data.time.TimeSeries timeSeries12 = null;
        try {
            java.util.Collection collection13 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        double double8 = timeSeries3.getMinY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.lang.Class<?> wildcardClass12 = fixedMillisecond9.getClass();
//        long long13 = fixedMillisecond9.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1560183493697L);
//        java.lang.String str16 = fixedMillisecond9.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 1560183500695L);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = fixedMillisecond9.equals(obj19);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183541676L + "'", long11 == 1560183541676L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183541676L + "'", long13 == 1560183541676L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Mon Jun 10 09:19:01 PDT 2019" + "'", str16.equals("Mon Jun 10 09:19:01 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 24234L, "2019", "10-June-2019");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        try {
            timeSeries3.update(12, (java.lang.Number) 1560183500695L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        java.lang.String str14 = year10.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod16);
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(collection18);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
//        boolean boolean26 = fixedMillisecond23.equals((java.lang.Object) month24);
//        long long27 = fixedMillisecond23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month30.next();
//        int int32 = month30.getYearValue();
//        java.util.Date date33 = month30.getEnd();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) month35);
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560183541793L + "'", long27 == 1560183541793L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        timeSeries3.setNotify(true);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        java.util.Date date14 = day12.getEnd();
//        java.lang.String str15 = day12.toString();
//        long long16 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 1560236399999L);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        int int21 = month19.getYearValue();
//        java.util.Date date22 = month19.getEnd();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
//        int int25 = day12.compareTo((java.lang.Object) year23);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        boolean boolean6 = timeSeries3.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
//        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
//        long long11 = month8.getLastMillisecond();
//        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        boolean boolean16 = fixedMillisecond13.equals((java.lang.Object) month14);
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond13.getFirstMillisecond(calendar19);
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond13.peg(calendar21);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond13.getFirstMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond13.getLastMillisecond(calendar25);
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1560183503822L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560183542177L + "'", long20 == 1560183542177L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560183542177L + "'", long24 == 1560183542177L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560183542177L + "'", long26 == 1560183542177L);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1560183522245L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        int int8 = year4.getYear();
        boolean boolean9 = timeSeries3.equals((java.lang.Object) year4);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        double double17 = timeSeries13.getMinY();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries13.createCopy(5, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) year11);
        int int14 = year11.compareTo((java.lang.Object) 1560183479708L);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) month25);
        long long27 = fixedMillisecond24.getMiddleMillisecond();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond24.getMiddleMillisecond(calendar30);
        int int32 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
        org.jfree.data.time.Year year36 = month34.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 1560183500338L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) month10);
        long long12 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond9.getMiddleMillisecond(calendar15);
        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.List list18 = timeSeries3.getItems();
        timeSeries3.removeAgedItems(1560183481404L, true);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener22);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        boolean boolean10 = fixedMillisecond7.equals((java.lang.Object) month8);
        long long11 = month8.getLastMillisecond();
        int int12 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year13 = month8.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
        boolean boolean21 = timeSeriesDataItem19.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem19.getPeriod();
        boolean boolean23 = year13.equals((java.lang.Object) regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1561964399999L + "'", long11 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.util.Collection collection15 = timeSeries13.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries19);
        java.util.Collection collection22 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.util.Collection collection28 = timeSeries26.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries32);
        double double35 = timeSeries34.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        boolean boolean39 = fixedMillisecond37.equals((java.lang.Object) month38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        int int42 = month40.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries3.addAndOrUpdate(timeSeries43);
        try {
            timeSeries44.delete((int) (short) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (short) 10 + "'", comparable33.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(timeSeries44);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        java.util.Collection collection10 = timeSeries8.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable15 = timeSeries14.getKey();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries14);
//        timeSeries16.removeAgedItems(false);
//        timeSeries16.removeAgedItems(1560183481404L, false);
//        int int22 = day0.compareTo((java.lang.Object) false);
//        long long23 = day0.getFirstMillisecond();
//        java.lang.String str24 = day0.toString();
//        long long25 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560150000000L + "'", long23 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        java.lang.Object obj4 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=July 2019]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=July 2019]"));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.setDomainDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Comparable comparable20 = timeSeries17.getKey();
        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.String str22 = timeSeries17.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable27 = timeSeries26.getKey();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection32 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        int int33 = timeSeries26.getItemCount();
        boolean boolean34 = timeSeries26.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener35);
        boolean boolean37 = timeSeries17.equals((java.lang.Object) timeSeries26);
        java.lang.Class class38 = timeSeries17.getTimePeriodClass();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (short) 10 + "'", comparable27.equals((short) 10));
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(class38);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (double) 10.0f);
        long long16 = year10.getLastMillisecond();
        long long17 = year10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year9 = month7.getYear();
        int int10 = month7.getMonth();
        long long11 = month7.getMiddleMillisecond();
        java.lang.String str12 = month7.toString();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 1560183499789L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        int int5 = day0.getYear();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        java.lang.Comparable comparable6 = timeSeries3.getKey();
//        timeSeries3.setDescription("hi!");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        java.util.Date date11 = day9.getEnd();
//        java.lang.String str12 = day9.toString();
//        long long13 = day9.getLastMillisecond();
//        java.util.Date date14 = day9.getEnd();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 1560183490292L);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.createCopy(11, 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 10 + "'", comparable6.equals((short) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Comparable comparable15 = timeSeries14.getKey();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.util.Collection collection20 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.util.List list21 = timeSeries19.getItems();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries19);
        try {
            timeSeries22.delete((-9999), 9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + (short) 10 + "'", comparable15.equals((short) 10));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }
}

