import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test01");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        boolean boolean7 = year5.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
//        boolean boolean15 = fixedMillisecond12.equals((java.lang.Object) month13);
//        long long16 = fixedMillisecond12.getSerialIndex();
//        java.lang.Number number17 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond12.next();
//        long long19 = fixedMillisecond12.getFirstMillisecond();
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560183575637L + "'", long16 == 1560183575637L);
//        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (byte) 10 + "'", number17.equals((byte) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560183575637L + "'", long19 == 1560183575637L);
//    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timeSeries3.getKey();
        timeSeries3.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        boolean boolean14 = fixedMillisecond11.equals((java.lang.Object) month12);
        long long15 = month12.getLastMillisecond();
        int int17 = month12.compareTo((java.lang.Object) 10);
        int int19 = month12.compareTo((java.lang.Object) "2018");
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 0.0f, false);
        java.lang.Number number24 = timeSeries3.getValue(0);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.0d + "'", number24.equals(0.0d));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        timeSeries9.setDomainDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries17.removePropertyChangeListener(propertyChangeListener18);
//        java.lang.Comparable comparable20 = timeSeries17.getKey();
//        java.util.Collection collection21 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
//        java.util.Date date24 = day22.getEnd();
//        java.lang.String str25 = day22.toString();
//        long long26 = day22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day22.previous();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day22, (double) (short) -1, true);
//        long long31 = day22.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long31, "2018", "Mon Jun 10 09:19:07 PDT 2019");
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test05");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        double double10 = timeSeries3.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560183481917L, true);
//        long long17 = fixedMillisecond11.getMiddleMillisecond();
//        java.util.Date date18 = fixedMillisecond11.getStart();
//        java.util.TimeZone timeZone19 = null;
//        try {
//            org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183575787L + "'", long13 == 1560183575787L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560183575787L + "'", long17 == 1560183575787L);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) month10);
        long long12 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond9.getMiddleMillisecond(calendar15);
        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.List list18 = timeSeries3.getItems();
        boolean boolean19 = timeSeries3.isEmpty();
        java.lang.Object obj20 = timeSeries3.clone();
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(obj20);
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test07");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183575824L + "'", long2 == 1560183575824L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560183575824L + "'", long3 == 1560183575824L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        timeSeries3.removeAgedItems(false);
        java.util.List list10 = timeSeries3.getItems();
        boolean boolean11 = timeSeries3.getNotify();
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test09");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        double double8 = timeSeries3.getMinY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.lang.Class<?> wildcardClass12 = fixedMillisecond9.getClass();
//        long long13 = fixedMillisecond9.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1560183493697L);
//        java.util.List list16 = timeSeries3.getItems();
//        double double17 = timeSeries3.getMinY();
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560183575850L + "'", long11 == 1560183575850L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560183575850L + "'", long13 == 1560183575850L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.560183493697E12d + "'", double17 == 1.560183493697E12d);
//    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.removeChangeListener(seriesChangeListener6);
        timeSeries3.setMaximumItemAge(1560183545109L);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Date date3 = month0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.Date date6 = day5.getEnd();
        long long7 = day5.getSerialIndex();
        int int8 = day5.getMonth();
        int int9 = day5.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43617L + "'", long7 == 43617L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.util.Date date4 = day2.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        boolean boolean8 = year1.equals((java.lang.Object) month7);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        timeSeries3.setNotify(true);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        java.util.Date date14 = day12.getEnd();
//        java.lang.String str15 = day12.toString();
//        long long16 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 1560236399999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
//        boolean boolean22 = fixedMillisecond19.equals((java.lang.Object) month20);
//        long long23 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener28);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries27.addChangeListener(seriesChangeListener30);
//        java.lang.Comparable comparable32 = timeSeries27.getKey();
//        timeSeries27.setMaximumItemAge((long) 100);
//        java.lang.Comparable comparable35 = timeSeries27.getKey();
//        int int36 = fixedMillisecond19.compareTo((java.lang.Object) comparable35);
//        long long37 = fixedMillisecond19.getLastMillisecond();
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond19);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560183575944L + "'", long23 == 1560183575944L);
//        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + (short) 10 + "'", comparable32.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (short) 10 + "'", comparable35.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560183575944L + "'", long37 == 1560183575944L);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        org.jfree.data.time.Year year7 = month5.getYear();
        int int8 = month5.getMonth();
        java.lang.Number number9 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month5, number9, false);
        double double12 = timeSeries3.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 0);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        java.lang.Comparable comparable21 = timeSeries19.getKey();
        java.lang.String str22 = timeSeries19.getRangeDescription();
        timeSeries19.fireSeriesChanged();
        int int24 = fixedMillisecond14.compareTo((java.lang.Object) timeSeries19);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (short) 10 + "'", comparable20.equals((short) 10));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (short) 10 + "'", comparable21.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test15");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
//        java.lang.String str4 = month2.toString();
//        boolean boolean5 = day0.equals((java.lang.Object) str4);
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.Class<?> wildcardClass3 = year2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 10L);
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 1563303599999L);
        timeSeriesDataItem5.setValue((java.lang.Number) 1560183485152L);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries11.addChangeListener(seriesChangeListener14);
        boolean boolean16 = timeSeries11.isEmpty();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean16);
        boolean boolean18 = timeSeriesDataItem5.equals((java.lang.Object) boolean16);
        java.lang.Object obj19 = null;
        int int20 = timeSeriesDataItem5.compareTo(obj19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test18");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        timeSeries3.setMaximumItemAge((long) 100);
//        java.lang.Comparable comparable11 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.util.Collection collection17 = timeSeries15.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable22 = timeSeries21.getKey();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries15.addAndOrUpdate(timeSeries21);
//        double double24 = timeSeries23.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) month27);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        int int31 = month29.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month29);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        long long35 = day33.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.previous();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        long long41 = year40.getFirstMillisecond();
//        int int42 = year40.getYear();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) month38, (org.jfree.data.time.RegularTimePeriod) year40);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        long long45 = year44.getFirstMillisecond();
//        int int46 = year44.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year44.previous();
//        java.lang.Number number48 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) year44);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day49.previous();
//        java.util.Date date51 = day49.getEnd();
//        java.lang.String str52 = day49.toString();
//        long long53 = day49.getLastMillisecond();
//        java.util.Date date54 = day49.getEnd();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 1560183496274L);
//        java.lang.Number number58 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, number58);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class64 = timeSeries63.getTimePeriodClass();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries63);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener66 = null;
//        timeSeries63.addChangeListener(seriesChangeListener66);
//        timeSeries63.removeAgedItems(false);
//        java.beans.PropertyChangeListener propertyChangeListener70 = null;
//        timeSeries63.removePropertyChangeListener(propertyChangeListener70);
//        int int72 = timeSeries63.getMaximumItemCount();
//        int int73 = day55.compareTo((java.lang.Object) int72);
//        java.util.Calendar calendar74 = null;
//        try {
//            long long75 = day55.getFirstMillisecond(calendar74);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (short) 10 + "'", comparable11.equals((short) 10));
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (short) 10 + "'", comparable22.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.0f + "'", number48.equals(0.0f));
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10-June-2019" + "'", str52.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560236399999L + "'", long53 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertNull(class64);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2147483647 + "'", int72 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
        boolean boolean19 = timeSeriesDataItem17.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate(timeSeriesDataItem17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem17.getPeriod();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.String str8 = timeSeries3.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        int int13 = year9.getYear();
        java.lang.Number number14 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year9, number14, true);
        timeSeries3.setNotify(false);
        timeSeries3.setNotify(false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test21");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable10 = timeSeries9.getKey();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        double double12 = timeSeries11.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) month15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month15, (org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        long long23 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 0.0f);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.previous();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getFirstMillisecond();
//        int int30 = year28.getYear();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year28);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getFirstMillisecond();
//        int int34 = year32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year32.previous();
//        java.lang.Number number36 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) year32);
//        java.lang.Comparable comparable37 = timeSeries31.getKey();
//        long long38 = timeSeries31.getMaximumItemAge();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries31.getDataItem(2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 10 + "'", comparable10.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0f + "'", number36.equals(0.0f));
//        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + "Overwritten values from: 10" + "'", comparable37.equals("Overwritten values from: 10"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test22");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getFirstMillisecond();
//        long long6 = day0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass7 = day0.getClass();
//        java.lang.Object obj8 = null;
//        int int9 = day0.compareTo(obj8);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test23");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560183576235L + "'", long2 == 1560183576235L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560183576235L + "'", long4 == 1560183576235L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560183576235L + "'", long5 == 1560183576235L);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        timeSeries3.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timeSeries3.getMaximumItemCount();
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test25");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        java.lang.Comparable comparable8 = timeSeries3.getKey();
//        timeSeries3.setMaximumItemAge((long) 100);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond13.getClass();
//        long long17 = fixedMillisecond13.getLastMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond13.getFirstMillisecond(calendar18);
//        long long20 = fixedMillisecond13.getLastMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1560183561854L, false);
//        java.lang.Class class24 = timeSeries3.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 10 + "'", comparable8.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560183576258L + "'", long15 == 1560183576258L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560183576258L + "'", long17 == 1560183576258L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560183576258L + "'", long19 == 1560183576258L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560183576258L + "'", long20 == 1560183576258L);
//        org.junit.Assert.assertNotNull(class24);
//    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test26");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Object obj1 = null;
//        int int2 = day0.compareTo(obj1);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
//        java.lang.Comparable comparable9 = timeSeries6.getKey();
//        timeSeries6.setDescription("hi!");
//        int int12 = day0.compareTo((java.lang.Object) timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
//        boolean boolean19 = timeSeries16.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable24 = timeSeries23.getKey();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        boolean boolean27 = year25.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year25.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem30.getPeriod();
//        java.lang.Object obj32 = timeSeriesDataItem30.clone();
//        timeSeries23.add(timeSeriesDataItem30, true);
//        timeSeries16.add(timeSeriesDataItem30, true);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
//        java.util.Date date40 = day38.getEnd();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date40, timeZone43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date40);
//        int int46 = year45.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year45, (double) 1560183481635L);
//        int int49 = day0.compareTo((java.lang.Object) timeSeries16);
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timeSeries16.removePropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class56 = timeSeries55.getTimePeriodClass();
//        java.util.Collection collection57 = timeSeries55.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable62 = timeSeries61.getKey();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries55.addAndOrUpdate(timeSeries61);
//        double double64 = timeSeries63.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
//        boolean boolean68 = fixedMillisecond66.equals((java.lang.Object) month67);
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = month69.next();
//        int int71 = month69.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries63.createCopy((org.jfree.data.time.RegularTimePeriod) month67, (org.jfree.data.time.RegularTimePeriod) month69);
//        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month73.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month76.next();
//        boolean boolean78 = fixedMillisecond75.equals((java.lang.Object) month76);
//        long long79 = fixedMillisecond75.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries72.createCopy((org.jfree.data.time.RegularTimePeriod) month73, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = fixedMillisecond75.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = fixedMillisecond75.previous();
//        long long83 = fixedMillisecond75.getSerialIndex();
//        java.util.Date date84 = fixedMillisecond75.getTime();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (double) 1560183481404L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 10 + "'", comparable9.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (short) 10 + "'", comparable24.equals((short) 10));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNull(class56);
//        org.junit.Assert.assertNotNull(collection57);
//        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + (short) 10 + "'", comparable62.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560183576293L + "'", long79 == 1560183576293L);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560183576293L + "'", long83 == 1560183576293L);
//        org.junit.Assert.assertNotNull(date84);
//    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        boolean boolean12 = year10.equals((java.lang.Object) 10L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
//        java.lang.String str14 = year10.toString();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        int int20 = month18.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.util.Collection collection26 = timeSeries24.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable31 = timeSeries30.getKey();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries24.addAndOrUpdate(timeSeries30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
//        java.util.Collection collection38 = timeSeries36.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
//        java.lang.Comparable comparable43 = timeSeries42.getKey();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries36.addAndOrUpdate(timeSeries42);
//        double double45 = timeSeries44.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 1);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
//        boolean boolean49 = fixedMillisecond47.equals((java.lang.Object) month48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        int int52 = month50.getYearValue();
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) month48, (org.jfree.data.time.RegularTimePeriod) month50);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
//        boolean boolean59 = fixedMillisecond56.equals((java.lang.Object) month57);
//        long long60 = fixedMillisecond56.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries53.createCopy((org.jfree.data.time.RegularTimePeriod) month54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        int int62 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month18, (org.jfree.data.time.RegularTimePeriod) month54);
//        double double64 = timeSeries3.getMaxY();
//        try {
//            java.lang.Number number66 = timeSeries3.getValue(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNull(class25);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (short) 10 + "'", comparable31.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + (short) 10 + "'", comparable43.equals((short) 10));
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560183576322L + "'", long60 == 1560183576322L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560183529451L, "org.jfree.data.event.SeriesChangeEvent[source=July 2019]", "org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener12);
        boolean boolean14 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        boolean boolean18 = fixedMillisecond15.equals((java.lang.Object) month16);
        long long19 = month16.getLastMillisecond();
        int int20 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        boolean boolean22 = month16.equals((java.lang.Object) (byte) 100);
        boolean boolean23 = timeSeries3.equals((java.lang.Object) month16);
        org.jfree.data.time.Year year24 = month16.getYear();
        java.util.Date date25 = month16.getEnd();
        org.jfree.data.time.Year year26 = month16.getYear();
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(year26);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.TimeZone timeZone6 = null;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener5);
        long long7 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 1);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) month10);
        long long12 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getMiddleMillisecond(calendar13);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond9.getMiddleMillisecond(calendar15);
        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond9.getMiddleMillisecond(calendar18);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) month1);
        long long4 = month1.getLastMillisecond();
        int int6 = month1.compareTo((java.lang.Object) 10);
        java.util.Date date7 = month1.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.next();
        java.lang.String str12 = year8.toString();
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        boolean boolean15 = month1.equals((java.lang.Object) month14);
        long long16 = month14.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }
}

