import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean12 = timeSeries11.getNotify();
        java.lang.Comparable comparable13 = timeSeries11.getKey();
        java.util.Collection collection14 = timeSeries11.getTimePeriods();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class9, (java.lang.Object) timeSeries11);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean23 = timeSeries22.getNotify();
        java.lang.Comparable comparable24 = timeSeries22.getKey();
        java.util.Collection collection25 = timeSeries22.getTimePeriods();
        boolean boolean26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class20, (java.lang.Object) timeSeries22);
        java.net.URL uRL27 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class20);
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", class9, class20);
        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class4, class20);
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class4);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100 + "'", comparable24.equals(100));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(uRL27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(obj30);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        long long8 = day5.getLastMillisecond();
//        long long9 = day5.getFirstMillisecond();
//        long long10 = day5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440035796L + "'", long2 == 1560440035796L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean21 = spreadsheetDate2.isOnOrBefore(serialDate20);
        try {
            org.jfree.data.time.SerialDate serialDate23 = serialDate20.getPreviousDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries13);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries14.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.addChangeListener(seriesChangeListener14);
        timeSeries12.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int19 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.lang.Class class22 = timeSeries18.getTimePeriodClass();
        int int23 = timeSeries18.getMaximumItemCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries1);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries1.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.previous();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440035996L + "'", long19 == 1560440035996L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440035999L + "'", long26 == 1560440035999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str3 = spreadsheetDate2.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean6 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
//        int int13 = day12.getMonth();
//        org.jfree.data.time.SerialDate serialDate14 = day12.getSerialDate();
//        boolean boolean15 = spreadsheetDate5.isAfter(serialDate14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getFirstMillisecond(calendar17);
//        java.util.Date date19 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19);
//        int int22 = day21.getMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day21.getSerialDate();
//        boolean boolean24 = spreadsheetDate5.isOnOrBefore(serialDate23);
//        try {
//            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, (org.jfree.data.time.SerialDate) spreadsheetDate5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(str3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440036167L + "'", long9 == 1560440036167L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560440036198L + "'", long18 == 1560440036198L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560439985071L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
//        java.lang.Number number9 = timeSeriesDataItem6.getValue();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440036213L + "'", long2 == 1560440036213L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1560439985071L + "'", number9.equals(1560439985071L));
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Date date11 = fixedMillisecond9.getStart();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        timeSeries13.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9);
//        java.util.Date date24 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean33 = spreadsheetDate30.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        boolean boolean39 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        int int40 = spreadsheetDate37.getDayOfMonth();
//        int int41 = spreadsheetDate37.toSerial();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean44 = spreadsheetDate37.isOn(serialDate43);
//        int int45 = year28.compareTo((java.lang.Object) serialDate43);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440036244L + "'", long21 == 1560440036244L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560439993235L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1560439993235L + "'", obj2.equals(1560439993235L));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1560439993235L + "'", obj3.equals(1560439993235L));
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getMiddleMillisecond();
//        long long7 = year4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440037105L + "'", long2 == 1560440037105L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        boolean boolean5 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(0);
        try {
            java.lang.Number number9 = timeSeries1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(4, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        long long10 = day5.getFirstMillisecond();
//        long long11 = day5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440037143L + "'", long2 == 1560440037143L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int11 = spreadsheetDate8.getDayOfMonth();
//        int int12 = spreadsheetDate8.toSerial();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.addAndOrUpdate(timeSeries19);
//        boolean boolean21 = spreadsheetDate8.equals((java.lang.Object) timeSeries20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate(regularTimePeriod25, (double) 5);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getFirstMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date35);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date35, timeZone38);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date35);
//        java.lang.Class<?> wildcardClass41 = date35.getClass();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod25, (java.lang.Class) wildcardClass41);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440037200L + "'", long24 == 1560440037200L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440037202L + "'", long34 == 1560440037202L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean12 = timeSeries11.getNotify();
        java.lang.Comparable comparable13 = timeSeries11.getKey();
        java.util.Collection collection14 = timeSeries11.getTimePeriods();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class9, (java.lang.Object) timeSeries11);
        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class9);
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Monday", class5, class9);
        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Time", class9);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(uRL6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(classLoader16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(inputStream18);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean9 = fixedMillisecond5.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getRangeDescription();
//        int int14 = fixedMillisecond5.compareTo((java.lang.Object) str13);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, class18);
//        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class18);
//        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getFirstMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getTime();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date26, timeZone27);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440022817L, "February", "9-January-1900", class18);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(uRL21);
//        org.junit.Assert.assertNull(uRL22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440037802L + "'", long25 == 1560440037802L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            month0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440037973L + "'", long2 == 1560440037973L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        int int15 = month14.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440038312L + "'", long9 == 1560440038312L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int16 = spreadsheetDate13.getDayOfMonth();
        int int17 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean20 = spreadsheetDate13.isOn(serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate22.getDayOfWeek();
        java.lang.String str27 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean39 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean40 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int41 = spreadsheetDate31.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        int int46 = fixedMillisecond44.compareTo((java.lang.Object) fixedMillisecond45);
        boolean boolean48 = fixedMillisecond44.equals((java.lang.Object) false);
        boolean boolean49 = spreadsheetDate43.equals((java.lang.Object) false);
        boolean boolean50 = spreadsheetDate31.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean52 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, 10);
        boolean boolean53 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.util.Date date54 = spreadsheetDate13.toDate();
        boolean boolean55 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        java.util.Date date56 = spreadsheetDate13.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        java.lang.String str9 = day5.toString();
//        java.lang.String str10 = day5.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440038717L + "'", long2 == 1560440038717L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        timeSeries9.removeAgedItems(1560439989592L, false);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond5.getClass();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond5.peg(calendar10);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean6 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean9 = spreadsheetDate2.isOnOrBefore(serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
//        int int7 = day6.getMonth();
//        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
//        long long9 = day6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long9, class12);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Time", class12);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440038877L + "'", long3 == 1560440038877L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNull(inputStream15);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        int int6 = fixedMillisecond4.compareTo((java.lang.Object) fixedMillisecond5);
//        boolean boolean8 = fixedMillisecond4.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        java.lang.String str12 = timeSeries10.getRangeDescription();
//        int int13 = fixedMillisecond4.compareTo((java.lang.Object) str12);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
//        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, class17);
//        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class17);
//        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date25, timeZone26);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class17);
//        java.io.InputStream inputStream29 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class17);
//        java.net.URL uRL30 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", class17);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNull(uRL20);
//        org.junit.Assert.assertNull(uRL21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440038946L + "'", long24 == 1560440038946L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(inputStream29);
//        org.junit.Assert.assertNull(uRL30);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, number7);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list11 = timeSeries10.getItems();
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        int int18 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond14);
//        java.util.Date date19 = fixedMillisecond14.getEnd();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond14.getFirstMillisecond(calendar20);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440039065L + "'", long2 == 1560440039065L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440039067L + "'", long21 == 1560440039067L);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
//        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.lang.String str26 = timeSeries24.getRangeDescription();
//        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
//        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean37 = timeSeries36.getNotify();
//        java.lang.Class class38 = timeSeries36.getTimePeriodClass();
//        timeSeries36.clear();
//        java.lang.String str40 = timeSeries36.getRangeDescription();
//        int int41 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond42.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date45);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 1560439985071L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem48.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem48.getPeriod();
//        try {
//            timeSeries36.add(timeSeriesDataItem48);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560440039350L + "'", long44 == 1560440039350L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list5 = timeSeries4.getItems();
//        timeSeries4.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) fixedMillisecond9);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        boolean boolean12 = timeSeries4.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener13);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.addAndOrUpdate(timeSeries16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        int int26 = timeSeries16.getIndex(regularTimePeriod25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
//        int int33 = day32.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day32.next();
//        java.util.Date date35 = day32.getStart();
//        long long36 = day32.getFirstMillisecond();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries37 = timeSeries1.createCopy(regularTimePeriod25, (org.jfree.data.time.RegularTimePeriod) day32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440039434L + "'", long20 == 1560440039434L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560440039436L + "'", long29 == 1560440039436L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 13 + "'", int33 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        long long6 = year4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440039513L + "'", long2 == 1560440039513L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Date date11 = fixedMillisecond9.getStart();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        timeSeries13.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9);
//        java.util.Date date24 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean30 = timeSeries29.getNotify();
//        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
//        timeSeries29.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        int int35 = fixedMillisecond33.compareTo((java.lang.Object) fixedMillisecond34);
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond34.getFirstMillisecond(calendar36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 9);
//        java.util.Date date40 = fixedMillisecond34.getTime();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class44 = timeSeries43.getTimePeriodClass();
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond46.getFirstMillisecond(calendar47);
//        java.util.Date date49 = fixedMillisecond46.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date49);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date49, timeZone52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date40, timeZone52);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date11, timeZone52);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440039584L + "'", long21 == 1560440039584L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440039587L + "'", long37 == 1560440039587L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560440039589L + "'", long48 == 1560440039589L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean42 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        int int43 = spreadsheetDate40.getDayOfMonth();
//        int int44 = spreadsheetDate40.toSerial();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean47 = spreadsheetDate40.isOn(serialDate46);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries49.addAndOrUpdate(timeSeries51);
//        boolean boolean53 = spreadsheetDate40.equals((java.lang.Object) timeSeries52);
//        java.lang.Object obj54 = timeSeries52.clone();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day55);
//        int int57 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries3.addOrUpdate(regularTimePeriod58, (double) 1560440020836L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440040605L + "'", long19 == 1560440040605L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440040632L + "'", long26 == 1560440040632L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        java.lang.String str33 = spreadsheetDate8.toString();
        int int34 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int37 = spreadsheetDate36.getYYYY();
        int int38 = spreadsheetDate36.getMonth();
        int int39 = spreadsheetDate36.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate40 = null;
        try {
            boolean boolean42 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate40, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1-January-1900" + "'", str33.equals("1-January-1900"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = month6.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440040683L + "'", long4 == 1560440040683L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        java.util.Date date7 = day5.getStart();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        java.util.Calendar calendar9 = null;
//        try {
//            year8.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440040725L + "'", long2 == 1560440040725L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Comparable comparable3 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        long long6 = fixedMillisecond4.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getMiddleMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440040738L + "'", long6 == 1560440040738L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440040738L + "'", long8 == 1560440040738L);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Date date8 = fixedMillisecond6.getStart();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        long long10 = day9.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440040753L + "'", long2 == 1560440040753L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        long long10 = day5.getSerialIndex();
//        java.lang.String str11 = day5.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440040781L + "'", long2 == 1560440040781L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        int int15 = month14.getYearValue();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = month14.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440040811L + "'", long9 == 1560440040811L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        int int7 = day5.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440040939L + "'", long2 == 1560440040939L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        int int13 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond9.getMiddleMillisecond(calendar14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond9.getMiddleMillisecond(calendar16);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440040958L + "'", long11 == 1560440040958L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440040958L + "'", long15 == 1560440040958L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440040958L + "'", long17 == 1560440040958L);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        int int4 = fixedMillisecond2.compareTo((java.lang.Object) fixedMillisecond3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
//        java.lang.String str10 = timeSeries8.getRangeDescription();
//        int int11 = fixedMillisecond2.compareTo((java.lang.Object) str10);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, class15);
//        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class15);
//        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getTime();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class15);
//        java.lang.Object obj27 = seriesChangeEvent26.getSource();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(uRL18);
//        org.junit.Assert.assertNull(uRL19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440040995L + "'", long22 == 1560440040995L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(obj27);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        long long7 = day5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440041387L + "'", long2 == 1560440041387L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getFirstMillisecond();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "February" + "'", str1.equals("February"));
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        long long18 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond0.getFirstMillisecond(calendar19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560440041481L + "'", long18 == 1560440041481L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440041481L + "'", long20 == 1560440041481L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate7.getDayOfWeek();
        java.lang.String str12 = spreadsheetDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int26 = spreadsheetDate16.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
        boolean boolean33 = fixedMillisecond29.equals((java.lang.Object) false);
        boolean boolean34 = spreadsheetDate28.equals((java.lang.Object) false);
        boolean boolean35 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean37 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 10);
        int int38 = spreadsheetDate14.getYYYY();
        java.lang.String str39 = spreadsheetDate14.toString();
        boolean boolean40 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean43 = timeSeries42.getNotify();
        java.lang.Comparable comparable44 = timeSeries42.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        try {
            int int47 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries42);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1-January-1900" + "'", str39.equals("1-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 100 + "'", comparable44.equals(100));
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str2 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        int int11 = spreadsheetDate7.getDayOfWeek();
//        java.lang.String str12 = spreadsheetDate7.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        boolean boolean25 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        int int26 = spreadsheetDate16.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
//        boolean boolean33 = fixedMillisecond29.equals((java.lang.Object) false);
//        boolean boolean34 = spreadsheetDate28.equals((java.lang.Object) false);
//        boolean boolean35 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        boolean boolean37 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 10);
//        int int38 = spreadsheetDate14.getYYYY();
//        java.lang.String str39 = spreadsheetDate14.toString();
//        boolean boolean40 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str44 = spreadsheetDate43.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean47 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate43);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        boolean boolean54 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries56.addAndOrUpdate(timeSeries58);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries61.addAndOrUpdate(timeSeries63);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
//        timeSeries63.addChangeListener(seriesChangeListener65);
//        timeSeries63.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
//        int int71 = fixedMillisecond69.compareTo((java.lang.Object) fixedMillisecond70);
//        boolean boolean73 = fixedMillisecond69.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class76 = timeSeries75.getTimePeriodClass();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        int int78 = fixedMillisecond69.compareTo((java.lang.Object) str77);
//        java.util.Calendar calendar79 = null;
//        long long80 = fixedMillisecond69.getMiddleMillisecond(calendar79);
//        boolean boolean82 = fixedMillisecond69.equals((java.lang.Object) 1560439986416L);
//        int int83 = timeSeries63.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69);
//        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries59.addAndOrUpdate(timeSeries63);
//        try {
//            int int85 = spreadsheetDate14.compareTo((java.lang.Object) timeSeries59);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1-January-1900" + "'", str39.equals("1-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNull(str44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(class76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Value" + "'", str77.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560440041586L + "'", long80 == 1560440041586L);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries84);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int11 = spreadsheetDate8.getDayOfMonth();
//        int int12 = spreadsheetDate8.toSerial();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.addAndOrUpdate(timeSeries19);
//        boolean boolean21 = spreadsheetDate8.equals((java.lang.Object) timeSeries20);
//        java.lang.Object obj22 = timeSeries20.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getFirstMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
//        int int29 = day28.getMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day28.getSerialDate();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) (-2208873600001L), false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440041613L + "'", long25 == 1560440041613L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(serialDate30);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month2);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        java.util.Calendar calendar14 = null;
//        try {
//            year13.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440041771L + "'", long9 == 1560440041771L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 0L);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        long long6 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getLastMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440041809L + "'", long6 == 1560440041809L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440041809L + "'", long8 == 1560440041809L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.List list4 = timeSeries1.getItems();
        boolean boolean5 = timeSeries1.isEmpty();
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        timeSeries1.removeAgedItems(false);
        java.lang.String str9 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(str9);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1);
//        java.util.Calendar calendar24 = null;
//        try {
//            year19.peg(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440042303L + "'", long9 == 1560440042303L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440042304L + "'", long17 == 1560440042304L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        int int5 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        boolean boolean7 = year4.equals((java.lang.Object) 1560439992798L);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year4.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440042866L + "'", long2 == 1560440042866L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = month14.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440043433L + "'", long9 == 1560440043433L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean16 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int17 = spreadsheetDate14.getDayOfMonth();
//        boolean boolean18 = year4.equals((java.lang.Object) int17);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440043452L + "'", long2 == 1560440043452L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize(class2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date7);
//        int int13 = month12.getMonth();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440043527L + "'", long6 == 1560440043527L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.addAndOrUpdate(timeSeries8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries8.addChangeListener(seriesChangeListener10);
//        timeSeries8.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        int int23 = fixedMillisecond14.compareTo((java.lang.Object) str22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond14.getMiddleMillisecond(calendar24);
//        boolean boolean27 = fixedMillisecond14.equals((java.lang.Object) 1560439986416L);
//        int int28 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.addAndOrUpdate(timeSeries8);
//        try {
//            java.lang.Number number31 = timeSeries8.getValue((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Value" + "'", str22.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440043646L + "'", long25 == 1560440043646L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        java.lang.String str9 = day5.toString();
//        long long10 = day5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440043666L + "'", long2 == 1560440043666L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12);
//        int int15 = day14.getMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.next();
//        java.lang.Number number18 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440044188L + "'", long11 == 1560440044188L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str5 = spreadsheetDate4.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean8 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        boolean boolean21 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate12);
//        int int23 = spreadsheetDate12.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27);
//        int int30 = day29.getMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day29.getSerialDate();
//        boolean boolean32 = spreadsheetDate12.isOnOrBefore(serialDate31);
//        boolean boolean33 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate34);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440044266L + "'", long26 == 1560440044266L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int12 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
        boolean boolean19 = fixedMillisecond15.equals((java.lang.Object) false);
        boolean boolean20 = spreadsheetDate14.equals((java.lang.Object) false);
        boolean boolean21 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean32 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        try {
            org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str2 = spreadsheetDate1.getDescription();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str6 = spreadsheetDate5.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean9 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(4);
//        boolean boolean12 = spreadsheetDate5.isOnOrBefore(serialDate11);
//        int int13 = spreadsheetDate5.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        boolean boolean25 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean32 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        int int33 = spreadsheetDate29.getDayOfWeek();
//        java.lang.String str34 = spreadsheetDate29.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        boolean boolean47 = spreadsheetDate38.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        int int48 = spreadsheetDate38.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        int int53 = fixedMillisecond51.compareTo((java.lang.Object) fixedMillisecond52);
//        boolean boolean55 = fixedMillisecond51.equals((java.lang.Object) false);
//        boolean boolean56 = spreadsheetDate50.equals((java.lang.Object) false);
//        boolean boolean57 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        boolean boolean59 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, (org.jfree.data.time.SerialDate) spreadsheetDate38, 10);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addDays(3, (org.jfree.data.time.SerialDate) spreadsheetDate36);
//        boolean boolean62 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate60, 10);
//        boolean boolean63 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440044898L + "'", long2 == 1560440044898L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440044907L + "'", long38 == 1560440044907L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440044907L + "'", long40 == 1560440044907L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440044907L + "'", long41 == 1560440044907L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        java.util.Date date9 = fixedMillisecond5.getEnd();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        java.lang.String str33 = spreadsheetDate8.toString();
        java.lang.String str34 = spreadsheetDate8.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1-January-1900" + "'", str33.equals("1-January-1900"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1-January-1900" + "'", str34.equals("1-January-1900"));
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
//        java.lang.String str9 = month6.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440045460L + "'", long4 == 1560440045460L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        java.lang.String str5 = timeSeries1.getDescription();
        boolean boolean6 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str6 = spreadsheetDate5.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str12 = spreadsheetDate11.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean15 = spreadsheetDate11.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate19.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean26 = timeSeries25.getNotify();
        java.lang.Comparable comparable27 = timeSeries25.getKey();
        java.util.Collection collection28 = timeSeries25.getTimePeriods();
        java.lang.Object obj29 = timeSeries25.clone();
        boolean boolean30 = spreadsheetDate19.equals(obj29);
        int int31 = spreadsheetDate19.getDayOfMonth();
        boolean boolean32 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean37 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean43 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str46 = spreadsheetDate45.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean49 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate34.equals((java.lang.Object) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 9 + "'", int31 == 9);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(serialDate51);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemAge(1560440024529L);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list3 = timeSeries2.getItems();
        timeSeries2.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.lang.Class<?> wildcardClass10 = fixedMillisecond6.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Last", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        long long6 = month5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.previous();
//        long long9 = month5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440046088L + "'", long2 == 1560440046088L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24234L + "'", long9 == 24234L);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean3 = timeSeries2.getNotify();
//        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
//        timeSeries2.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 9);
//        timeSeries2.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        java.lang.Class<?> wildcardClass19 = date18.getClass();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
//        int int21 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
//        try {
//            org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(0, year20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440046168L + "'", long10 == 1560440046168L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440046169L + "'", long17 == 1560440046169L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int34 = day33.getYear();
//        java.util.Date date35 = day33.getStart();
//        java.lang.String str36 = day33.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        boolean boolean48 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str51 = spreadsheetDate50.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean54 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean55 = spreadsheetDate39.equals((java.lang.Object) spreadsheetDate50);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate50);
//        java.lang.Class<?> wildcardClass57 = serialDate56.getClass();
//        boolean boolean58 = day33.equals((java.lang.Object) wildcardClass57);
//        long long59 = day33.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1-January-1900" + "'", str36.equals("1-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNull(str51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-2208873600001L) + "'", long59 == (-2208873600001L));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        timeSeries1.removeAgedItems(1L, true);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 9223372036854775807L);
        int int12 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate(regularTimePeriod13, (java.lang.Number) 1560439985071L);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean11 = timeSeries10.getNotify();
        java.lang.Comparable comparable12 = timeSeries10.getKey();
        java.util.Collection collection13 = timeSeries10.getTimePeriods();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class8, (java.lang.Object) timeSeries10);
        java.lang.ClassLoader classLoader15 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class8);
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Monday", class4, class8);
        java.lang.ClassLoader classLoader17 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class8);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader17);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader17);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100 + "'", comparable12.equals(100));
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(classLoader15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(classLoader17);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean12 = timeSeries11.getNotify();
        java.lang.Comparable comparable13 = timeSeries11.getKey();
        java.util.Collection collection14 = timeSeries11.getTimePeriods();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class9, (java.lang.Object) timeSeries11);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class9);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean23 = timeSeries22.getNotify();
        java.lang.Comparable comparable24 = timeSeries22.getKey();
        java.util.Collection collection25 = timeSeries22.getTimePeriods();
        boolean boolean26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class20, (java.lang.Object) timeSeries22);
        java.net.URL uRL27 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ClassContext", class20);
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", class9, class20);
        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", class4, class20);
        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Oct", class20);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 100 + "'", comparable24.equals(100));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(uRL27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(inputStream30);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        long long6 = month5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month5.previous();
//        java.util.Calendar calendar10 = null;
//        try {
//            month5.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440046687L + "'", long2 == 1560440046687L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        int int4 = fixedMillisecond2.compareTo((java.lang.Object) fixedMillisecond3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) false);
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.addAndOrUpdate(timeSeries11);
//        boolean boolean13 = spreadsheetDate1.equals((java.lang.Object) timeSeries9);
//        java.lang.Class class14 = timeSeries9.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class14);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean12 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int21 = spreadsheetDate18.getDayOfMonth();
//        int int22 = spreadsheetDate18.toSerial();
//        boolean boolean23 = day5.equals((java.lang.Object) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str26 = spreadsheetDate25.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean29 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        int int35 = spreadsheetDate31.getDayOfWeek();
//        java.lang.String str36 = spreadsheetDate31.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean48 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        boolean boolean49 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        int int50 = spreadsheetDate40.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        int int55 = fixedMillisecond53.compareTo((java.lang.Object) fixedMillisecond54);
//        boolean boolean57 = fixedMillisecond53.equals((java.lang.Object) false);
//        boolean boolean58 = spreadsheetDate52.equals((java.lang.Object) false);
//        boolean boolean59 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
//        boolean boolean61 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate40, 10);
//        int int62 = spreadsheetDate38.getYYYY();
//        java.lang.String str63 = spreadsheetDate38.toString();
//        boolean boolean64 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean65 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        spreadsheetDate18.setDescription("Value");
//        boolean boolean69 = spreadsheetDate18.equals((java.lang.Object) 1560439990709L);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean69);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440046945L + "'", long2 == 1560440046945L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1900 + "'", int62 == 1900);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1-January-1900" + "'", str63.equals("1-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.lang.String str5 = year4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440047227L + "'", long2 == 1560440047227L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.lang.Object obj6 = null;
        boolean boolean7 = timeSeries1.equals(obj6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.lang.String str5 = year4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        long long7 = year4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440047294L + "'", long2 == 1560440047294L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        timeSeries1.removeAgedItems(1L, true);
        java.lang.Object obj9 = timeSeries1.clone();
        int int10 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-435), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -435");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries2.clear();
        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("", class4);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(uRL5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        java.util.List list6 = timeSeries1.getItems();
        try {
            java.util.Collection collection7 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        java.lang.String str4 = month0.toString();
        long long5 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Nearest");
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate13.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean20 = timeSeries19.getNotify();
        java.lang.Comparable comparable21 = timeSeries19.getKey();
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        java.lang.Object obj23 = timeSeries19.clone();
        boolean boolean24 = spreadsheetDate13.equals(obj23);
        java.util.Date date25 = spreadsheetDate13.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int30 = spreadsheetDate28.getMonth();
        int int31 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int32 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 100 + "'", comparable21.equals(100));
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int2 = timeSeries1.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
//        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries9.clear();
//        java.lang.Object obj11 = timeSeries9.clone();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries9.addPropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.next();
//        int int22 = day19.getYear();
//        int int23 = day19.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day19.next();
//        java.lang.Number number25 = null;
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day19, number25);
//        java.lang.Number number27 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440048498L + "'", long16 == 1560440048498L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(number27);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        java.lang.Comparable comparable10 = timeSeries1.getKey();
//        int int11 = timeSeries1.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries1.clear();
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100 + "'", comparable10.equals(100));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560439991935L, "October", "1-January-1900", class5);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(4);
        java.lang.String str2 = serialDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        java.lang.String str26 = timeSeries24.getRangeDescription();
        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Object obj37 = seriesChangeEvent36.getSource();
        boolean boolean38 = timeSeriesDataItem17.equals(obj37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem17.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem17.getPeriod();
        timeSeriesDataItem17.setValue((java.lang.Number) 1560440023798L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + obj37 + "' != '" + (-1) + "'", obj37.equals((-1)));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        boolean boolean3 = timeSeries1.isEmpty();
//        boolean boolean4 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getFirstMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond6.getLastMillisecond(calendar12);
//        int int15 = fixedMillisecond6.compareTo((java.lang.Object) 1560439989916L);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440048845L + "'", long9 == 1560440048845L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440048845L + "'", long11 == 1560440048845L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440048845L + "'", long13 == 1560440048845L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate10 = day5.getSerialDate();
//        long long11 = day5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440048904L + "'", long2 == 1560440048904L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int11 = spreadsheetDate8.getDayOfMonth();
//        int int12 = spreadsheetDate8.toSerial();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.addAndOrUpdate(timeSeries19);
//        boolean boolean21 = spreadsheetDate8.equals((java.lang.Object) timeSeries20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate(regularTimePeriod25, (double) 5);
//        java.util.List list28 = timeSeries20.getItems();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440048933L + "'", long24 == 1560440048933L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(list28);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        int int12 = fixedMillisecond10.compareTo((java.lang.Object) fixedMillisecond11);
        boolean boolean14 = fixedMillisecond10.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.lang.String str18 = timeSeries16.getRangeDescription();
        int int19 = fixedMillisecond10.compareTo((java.lang.Object) str18);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        boolean boolean24 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond10, class23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) (short) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean32 = spreadsheetDate29.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        int int33 = spreadsheetDate29.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean36 = timeSeries35.getNotify();
        java.lang.Comparable comparable37 = timeSeries35.getKey();
        java.util.Collection collection38 = timeSeries35.getTimePeriods();
        java.lang.Object obj39 = timeSeries35.clone();
        boolean boolean40 = spreadsheetDate29.equals(obj39);
        boolean boolean41 = timeSeriesDataItem27.equals((java.lang.Object) spreadsheetDate29);
        java.lang.Object obj42 = timeSeriesDataItem27.clone();
        try {
            timeSeries3.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100 + "'", comparable37.equals(100));
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("February");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int21 = spreadsheetDate11.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) fixedMillisecond25);
        boolean boolean28 = fixedMillisecond24.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) false);
        boolean boolean30 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11, 10);
        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) spreadsheetDate9, (java.lang.Object) 1560439995821L);
        java.util.Date date35 = spreadsheetDate9.toDate();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int21 = spreadsheetDate18.getDayOfMonth();
//        int int22 = spreadsheetDate18.toSerial();
//        boolean boolean23 = day5.equals((java.lang.Object) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str26 = spreadsheetDate25.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean29 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        int int35 = spreadsheetDate31.getDayOfWeek();
//        java.lang.String str36 = spreadsheetDate31.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean48 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        boolean boolean49 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        int int50 = spreadsheetDate40.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        int int55 = fixedMillisecond53.compareTo((java.lang.Object) fixedMillisecond54);
//        boolean boolean57 = fixedMillisecond53.equals((java.lang.Object) false);
//        boolean boolean58 = spreadsheetDate52.equals((java.lang.Object) false);
//        boolean boolean59 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
//        boolean boolean61 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate40, 10);
//        int int62 = spreadsheetDate38.getYYYY();
//        java.lang.String str63 = spreadsheetDate38.toString();
//        boolean boolean64 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean65 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        int int67 = spreadsheetDate25.getYYYY();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440049332L + "'", long2 == 1560440049332L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1900 + "'", int62 == 1900);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1-January-1900" + "'", str63.equals("1-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1900 + "'", int67 == 1900);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getFirstMillisecond(calendar17);
//        java.util.Date date19 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19);
//        int int22 = day21.getDayOfMonth();
//        java.lang.Number number23 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        long long24 = timeSeries15.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560440049671L + "'", long18 == 1560440049671L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
        int int2 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int22 = spreadsheetDate19.toSerial();
        boolean boolean23 = timeSeries1.equals((java.lang.Object) spreadsheetDate19);
        int int24 = spreadsheetDate19.getDayOfMonth();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        java.lang.String str7 = serialDate5.getDescription();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440049966L + "'", long2 == 1560440049966L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(str7);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate10.toSerial();
        org.jfree.data.time.SerialDate serialDate33 = null;
        try {
            org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate10.getEndOfCurrentMonth(serialDate33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440050237L + "'", long4 == 1560440050237L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440050237L + "'", long6 == 1560440050237L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440050237L + "'", long9 == 1560440050237L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int24 = spreadsheetDate21.getDayOfMonth();
        int int25 = spreadsheetDate21.toSerial();
        boolean boolean26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) spreadsheetDate2, (java.lang.Object) int25);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1900);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        long long7 = day5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        long long9 = day5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440050311L + "'", long2 == 1560440050311L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440050345L + "'", long2 == 1560440050345L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440050345L + "'", long4 == 1560440050345L);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Object obj11 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.setRangeDescription("2019");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
        org.junit.Assert.assertNull(timeSeriesDataItem5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
        int int10 = fixedMillisecond6.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.next();
        java.lang.Number number23 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) month20);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.addAndOrUpdate(timeSeries27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries27.addChangeListener(seriesChangeListener29);
        timeSeries27.fireSeriesChanged();
        long long32 = timeSeries27.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.util.Date date35 = fixedMillisecond33.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries38.removeChangeListener(seriesChangeListener40);
        java.util.List list42 = timeSeries38.getItems();
        int int43 = year36.compareTo((java.lang.Object) list42);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month20, (org.jfree.data.time.RegularTimePeriod) year36);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(timeSeries44);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560439983669L, class4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day7);
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1560439983669L, (java.lang.Object) day7);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        int int13 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560440007671L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list26 = timeSeries25.getItems();
//        timeSeries25.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        boolean boolean33 = timeSeries25.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day44.next();
//        int int47 = timeSeries37.getIndex(regularTimePeriod46);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, regularTimePeriod46);
//        long long49 = fixedMillisecond20.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440050991L + "'", long11 == 1560440050991L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440050992L + "'", long16 == 1560440050992L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440050993L + "'", long22 == 1560440050993L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(list26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440050995L + "'", long41 == 1560440050995L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560440050993L + "'", long49 == 1560440050993L);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries2.clear();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.addAndOrUpdate(timeSeries8);
        java.lang.Class class10 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("June 2019", class10);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(uRL11);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        long long6 = year5.getFirstMillisecond();
//        try {
//            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 100, year5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440051329L + "'", long3 == 1560440051329L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries1.setDomainDescription("Last");
//        java.util.Collection collection23 = timeSeries1.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440051361L + "'", long9 == 1560440051361L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440051362L + "'", long16 == 1560440051362L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(collection23);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Thu Jun 13 08:33:00 PDT 2019");
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list18 = timeSeries17.getItems();
//        timeSeries17.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        int int23 = fixedMillisecond21.compareTo((java.lang.Object) fixedMillisecond22);
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        boolean boolean25 = timeSeries17.isEmpty();
//        timeSeries17.setDomainDescription("ThreadContext");
//        java.util.List list28 = timeSeries17.getItems();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.addAndOrUpdate(timeSeries17);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list32 = timeSeries31.getItems();
//        timeSeries31.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        int int37 = fixedMillisecond35.compareTo((java.lang.Object) fixedMillisecond36);
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 1560439980698L);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries17.getDataItem(2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(list18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(list32);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        int int10 = timeSeries1.getMaximumItemCount();
//        java.util.List list11 = timeSeries1.getItems();
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//        org.junit.Assert.assertNotNull(list11);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        int int45 = fixedMillisecond43.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond44.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond44.getTime();
//        int int49 = year4.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Date date50 = year4.getEnd();
//        java.util.Calendar calendar51 = null;
//        try {
//            year4.peg(calendar51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440051515L + "'", long2 == 1560440051515L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440051518L + "'", long38 == 1560440051518L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440051518L + "'", long40 == 1560440051518L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440051518L + "'", long41 == 1560440051518L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560440051522L + "'", long47 == 1560440051522L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(date50);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        long long10 = day5.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
//        int int17 = day16.getMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        long long19 = day16.getFirstMillisecond();
//        boolean boolean20 = day5.equals((java.lang.Object) long19);
//        long long21 = day5.getFirstMillisecond();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day5.getFirstMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440052067L + "'", long2 == 1560440052067L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440052092L + "'", long13 == 1560440052092L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        boolean boolean5 = timeSeries1.getNotify();
        java.lang.Object obj6 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        long long5 = fixedMillisecond1.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440052124L + "'", long4 == 1560440052124L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440052124L + "'", long5 == 1560440052124L);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        long long6 = month5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.previous();
//        long long9 = month5.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list12 = timeSeries11.getItems();
//        timeSeries11.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        boolean boolean19 = timeSeries11.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries11.addAndOrUpdate(timeSeries23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getFirstMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getTime();
//        java.util.Date date29 = fixedMillisecond25.getTime();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date29);
//        java.lang.Number number32 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, number32);
//        timeSeries24.setKey((java.lang.Comparable) timeSeriesDataItem33);
//        boolean boolean35 = month5.equals((java.lang.Object) timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440052146L + "'", long2 == 1560440052146L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440052151L + "'", long27 == 1560440052151L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getYYYY();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        java.lang.Class<?> wildcardClass5 = date4.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
//        long long7 = year6.getFirstMillisecond();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(5, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.next();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440052543L + "'", long3 == 1560440052543L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            year4.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440052571L + "'", long2 == 1560440052571L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        int int10 = fixedMillisecond6.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
//        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        long long18 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        int int21 = fixedMillisecond19.compareTo((java.lang.Object) fixedMillisecond20);
//        boolean boolean23 = fixedMillisecond19.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
//        java.lang.String str27 = timeSeries25.getRangeDescription();
//        int int28 = fixedMillisecond19.compareTo((java.lang.Object) str27);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
//        boolean boolean33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class32);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19, class32);
//        java.util.Calendar calendar35 = null;
//        fixedMillisecond19.peg(calendar35);
//        long long37 = fixedMillisecond19.getMiddleMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond19.getFirstMillisecond(calendar38);
//        long long40 = fixedMillisecond19.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 43629L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1560439979754L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean51 = spreadsheetDate48.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean56 = spreadsheetDate53.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        boolean boolean57 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate48);
//        int int59 = spreadsheetDate48.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getFirstMillisecond(calendar61);
//        java.util.Date date63 = fixedMillisecond60.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date63);
//        int int66 = day65.getMonth();
//        org.jfree.data.time.SerialDate serialDate67 = day65.getSerialDate();
//        boolean boolean68 = spreadsheetDate48.isOnOrBefore(serialDate67);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean73 = spreadsheetDate70.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate72);
//        int int74 = spreadsheetDate70.getDayOfWeek();
//        java.lang.String str75 = spreadsheetDate70.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str79 = spreadsheetDate78.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean82 = spreadsheetDate78.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate81);
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate78);
//        boolean boolean84 = spreadsheetDate70.isAfter(serialDate83);
//        org.jfree.data.time.SerialDate serialDate85 = spreadsheetDate48.getEndOfCurrentMonth(serialDate83);
//        int int86 = fixedMillisecond19.compareTo((java.lang.Object) serialDate85);
//        org.jfree.data.time.SerialDate serialDate88 = serialDate85.getPreviousDayOfWeek(4);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440052721L + "'", long37 == 1560440052721L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440052721L + "'", long39 == 1560440052721L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440052721L + "'", long40 == 1560440052721L);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1900 + "'", int59 == 1900);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560440052726L + "'", long62 == 1560440052726L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 3 + "'", int74 == 3);
//        org.junit.Assert.assertNull(str75);
//        org.junit.Assert.assertNull(str79);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
//        org.junit.Assert.assertNotNull(serialDate88);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int2 = timeSeries1.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
//        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        timeSeries1.setRangeDescription("Monday");
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list11 = timeSeries10.getItems();
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        boolean boolean18 = timeSeries10.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries10.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries10.addAndOrUpdate(timeSeries22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27);
//        int int30 = day29.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
//        int int32 = timeSeries22.getIndex(regularTimePeriod31);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod31, (double) 1560440020836L);
//        timeSeries1.add(regularTimePeriod31, (double) 1560440040738L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440053520L + "'", long26 == 1560440053520L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Comparable comparable3 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        boolean boolean6 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond8.getFirstMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond8.getMiddleMillisecond(calendar12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond8.previous();
//        try {
//            timeSeries1.add(regularTimePeriod14, (double) 1560439994169L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440053667L + "'", long11 == 1560440053667L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440053667L + "'", long13 == 1560440053667L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean12 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate9.getDayOfWeek();
        java.lang.String str14 = spreadsheetDate9.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int28 = spreadsheetDate18.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        int int33 = fixedMillisecond31.compareTo((java.lang.Object) fixedMillisecond32);
        boolean boolean35 = fixedMillisecond31.equals((java.lang.Object) false);
        boolean boolean36 = spreadsheetDate30.equals((java.lang.Object) false);
        boolean boolean37 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean39 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18, 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays(3, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays(11, serialDate41);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year4.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440053875L + "'", long2 == 1560440053875L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list16 = timeSeries15.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        java.lang.Class class20 = timeSeries15.getTimePeriodClass();
//        boolean boolean21 = timeSeries15.isEmpty();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440054015L + "'", long9 == 1560440054015L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        timeSeries1.setDomainDescription("Time");
        timeSeries1.removeAgedItems(1560440041809L, true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int3, class7);
        java.lang.String str10 = timeSeries9.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Date date8 = fixedMillisecond6.getStart();
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond6.peg(calendar9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440054145L + "'", long2 == 1560440054145L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.getDayOfMonth();
        int int12 = spreadsheetDate8.toSerial();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate17.getDayOfWeek();
        java.lang.String str22 = spreadsheetDate17.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean29 = spreadsheetDate26.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean35 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int36 = spreadsheetDate26.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
        int int41 = fixedMillisecond39.compareTo((java.lang.Object) fixedMillisecond40);
        boolean boolean43 = fixedMillisecond39.equals((java.lang.Object) false);
        boolean boolean44 = spreadsheetDate38.equals((java.lang.Object) false);
        boolean boolean45 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean47 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate26, 10);
        boolean boolean48 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.util.Date date49 = spreadsheetDate8.toDate();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date49);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
//        long long33 = year29.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440054412L + "'", long19 == 1560440054412L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440054413L + "'", long26 == 1560440054413L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int34 = day33.getYear();
        java.util.Date date35 = day33.getStart();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        java.lang.String str37 = day36.toString();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = day36.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1-January-1900" + "'", str37.equals("1-January-1900"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        timeSeries1.setMaximumItemAge(43629L);
        java.lang.Object obj14 = timeSeries1.clone();
        java.util.List list15 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(list15);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12);
//        int int15 = day14.getMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.next();
//        java.lang.Number number18 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440054690L + "'", long11 == 1560440054690L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 9999);
//        timeSeriesDataItem8.setValue((java.lang.Number) 1560440002058L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem8.getPeriod();
//        java.lang.Object obj12 = timeSeriesDataItem8.clone();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440054785L + "'", long2 == 1560440054785L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(obj12);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list18 = timeSeries17.getItems();
//        timeSeries17.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        int int23 = fixedMillisecond21.compareTo((java.lang.Object) fixedMillisecond22);
//        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        boolean boolean25 = timeSeries17.isEmpty();
//        timeSeries17.setDomainDescription("ThreadContext");
//        java.util.List list28 = timeSeries17.getItems();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.addAndOrUpdate(timeSeries17);
//        try {
//            timeSeries29.delete(100, 2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(list18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int34 = spreadsheetDate8.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        java.lang.Object obj3 = timeSeries1.clone();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        int int14 = day11.getYear();
//        int int15 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
//        java.lang.Number number17 = null;
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day11, number17);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener19);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440054979L + "'", long8 == 1560440054979L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        int int13 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560440007671L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list26 = timeSeries25.getItems();
//        timeSeries25.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        boolean boolean33 = timeSeries25.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day44.next();
//        int int47 = timeSeries37.getIndex(regularTimePeriod46);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, regularTimePeriod46);
//        boolean boolean49 = timeSeries48.isEmpty();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440055028L + "'", long11 == 1560440055028L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440055029L + "'", long16 == 1560440055029L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440055029L + "'", long22 == 1560440055029L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(list26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440055032L + "'", long41 == 1560440055032L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        int int5 = timeSeries3.getItemCount();
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean5 = timeSeries4.getNotify();
        java.lang.Comparable comparable6 = timeSeries4.getKey();
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class2, (java.lang.Object) timeSeries4);
        java.lang.String str9 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge(1560439986394L);
        java.lang.Comparable comparable12 = timeSeries4.getKey();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener13);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries4.createCopy((-2199), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 100 + "'", comparable6.equals(100));
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 100 + "'", comparable12.equals(100));
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        java.util.Date date19 = fixedMillisecond15.getTime();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date19);
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        timeSeries14.setKey((java.lang.Comparable) timeSeriesDataItem23);
//        timeSeries14.setMaximumItemCount(2019);
//        int int27 = timeSeries14.getItemCount();
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440055403L + "'", long17 == 1560440055403L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries2.clear();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.addAndOrUpdate(timeSeries7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries2.addAndOrUpdate(timeSeries8);
        java.lang.Class class10 = timeSeries2.getTimePeriodClass();
        java.lang.String str11 = timeSeries2.getRangeDescription();
        java.lang.Class class12 = timeSeries2.getTimePeriodClass();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class12);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("June 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        java.util.Date date4 = month0.getStart();
        long long5 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        java.lang.Object obj3 = timeSeries1.clone();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        int int14 = day11.getYear();
//        int int15 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
//        java.lang.Number number17 = null;
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day11, number17);
//        int int19 = day11.getMonth();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440055861L + "'", long8 == 1560440055861L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        int int12 = month8.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        int int3 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond2);
//        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getRangeDescription();
//        int int10 = fixedMillisecond1.compareTo((java.lang.Object) str9);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (short) 1);
//        long long19 = fixedMillisecond1.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean27 = timeSeries26.getNotify();
//        java.lang.Comparable comparable28 = timeSeries26.getKey();
//        java.util.Collection collection29 = timeSeries26.getTimePeriods();
//        boolean boolean30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class24, (java.lang.Object) timeSeries26);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "June 2019", "", class24);
//        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Nearest", class24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440055946L + "'", long19 == 1560440055946L);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 100 + "'", comparable28.equals(100));
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(uRL32);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int12 = spreadsheetDate9.getDayOfMonth();
        int int13 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean16 = spreadsheetDate9.isOn(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int22 = spreadsheetDate18.getDayOfWeek();
        java.lang.String str23 = spreadsheetDate18.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int37 = spreadsheetDate27.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        int int42 = fixedMillisecond40.compareTo((java.lang.Object) fixedMillisecond41);
        boolean boolean44 = fixedMillisecond40.equals((java.lang.Object) false);
        boolean boolean45 = spreadsheetDate39.equals((java.lang.Object) false);
        boolean boolean46 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean48 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27, 10);
        boolean boolean49 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date50 = spreadsheetDate9.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean3 = timeSeries2.getNotify();
        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond8);
        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.lang.String str15 = timeSeries13.getRangeDescription();
        int int16 = fixedMillisecond7.compareTo((java.lang.Object) str15);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class20);
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class20);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class20);
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", class4, class20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(uRL23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        int int3 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1900, 2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        java.lang.String str26 = timeSeries24.getRangeDescription();
        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean37 = timeSeries36.getNotify();
        java.lang.Class class38 = timeSeries36.getTimePeriodClass();
        timeSeries36.clear();
        java.lang.String str40 = timeSeries36.getRangeDescription();
        int int41 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries36);
        boolean boolean43 = timeSeriesDataItem17.equals((java.lang.Object) 1560439986394L);
        java.lang.Number number44 = timeSeriesDataItem17.getValue();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list47 = timeSeries46.getItems();
        timeSeries46.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
        int int52 = fixedMillisecond50.compareTo((java.lang.Object) fixedMillisecond51);
        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        int int54 = timeSeriesDataItem17.compareTo((java.lang.Object) fixedMillisecond50);
        java.util.Date date55 = fixedMillisecond50.getTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (short) 1 + "'", number44.equals((short) 1));
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date55);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean38 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        boolean boolean44 = spreadsheetDate35.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate35);
//        int int46 = spreadsheetDate35.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond47.getFirstMillisecond(calendar48);
//        java.util.Date date50 = fixedMillisecond47.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
//        int int53 = day52.getMonth();
//        org.jfree.data.time.SerialDate serialDate54 = day52.getSerialDate();
//        boolean boolean55 = spreadsheetDate35.isOnOrBefore(serialDate54);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean60 = spreadsheetDate57.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean65 = spreadsheetDate62.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        boolean boolean66 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        boolean boolean67 = spreadsheetDate35.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        org.jfree.data.time.SerialDate serialDate68 = null;
//        try {
//            boolean boolean69 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, serialDate68);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560440056636L + "'", long49 == 1560440056636L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2958465, (-435), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1);
//        long long24 = year19.getSerialIndex();
//        int int25 = year19.getYear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440056849L + "'", long9 == 1560440056849L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440056850L + "'", long17 == 1560440056850L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Comparable comparable3 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean8 = timeSeries7.getNotify();
//        java.lang.Comparable comparable9 = timeSeries7.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        long long12 = fixedMillisecond10.getFirstMillisecond();
//        boolean boolean13 = timeSeries1.equals((java.lang.Object) long12);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440056916L + "'", long12 == 1560440056916L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.String str17 = timeSeries15.getRangeDescription();
//        int int18 = fixedMillisecond9.compareTo((java.lang.Object) str17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond9.getMiddleMillisecond(calendar19);
//        boolean boolean22 = fixedMillisecond9.equals((java.lang.Object) 1560439986416L);
//        int int23 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean29 = spreadsheetDate26.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        boolean boolean35 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate26);
//        int int37 = spreadsheetDate26.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getFirstMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond38.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41);
//        int int44 = day43.getMonth();
//        org.jfree.data.time.SerialDate serialDate45 = day43.getSerialDate();
//        boolean boolean46 = spreadsheetDate26.isOnOrBefore(serialDate45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean51 = spreadsheetDate48.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        int int52 = spreadsheetDate48.getDayOfWeek();
//        java.lang.String str53 = spreadsheetDate48.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str57 = spreadsheetDate56.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean60 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate56);
//        boolean boolean62 = spreadsheetDate48.isAfter(serialDate61);
//        org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate26.getEndOfCurrentMonth(serialDate61);
//        boolean boolean64 = timeSeries3.equals((java.lang.Object) serialDate61);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440056939L + "'", long20 == 1560440056939L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440056965L + "'", long40 == 1560440056965L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
//        org.junit.Assert.assertNull(str53);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        boolean boolean5 = timeSeries1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        java.lang.Object obj3 = timeSeries1.clone();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
//        int int14 = day11.getYear();
//        int int15 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.next();
//        java.lang.Number number17 = null;
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day11, number17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond19.getFirstMillisecond(calendar20);
//        java.util.Date date22 = fixedMillisecond19.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
//        int int25 = day24.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.next();
//        int int27 = day24.getYear();
//        int int28 = day24.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day24.next();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list32 = timeSeries31.getItems();
//        timeSeries31.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        int int37 = fixedMillisecond35.compareTo((java.lang.Object) fixedMillisecond36);
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.lang.Class<?> wildcardClass39 = fixedMillisecond35.getClass();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond35.getMiddleMillisecond(calendar40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond35.previous();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day24, regularTimePeriod42);
//        org.jfree.data.time.TimeSeries timeSeries44 = null;
//        try {
//            java.util.Collection collection45 = timeSeries43.getTimePeriodsUniqueToOtherSeries(timeSeries44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440057410L + "'", long8 == 1560440057410L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440057413L + "'", long21 == 1560440057413L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 13 + "'", int28 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(list32);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440057444L + "'", long41 == 1560440057444L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeSeries43);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        java.lang.String str4 = month0.toString();
        int int5 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        java.lang.String str3 = timeSeries1.getRangeDescription();
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 1560439979754L);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean8 = timeSeries7.getNotify();
//        java.lang.Class class9 = timeSeries7.getTimePeriodClass();
//        timeSeries7.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        int int13 = fixedMillisecond11.compareTo((java.lang.Object) fixedMillisecond12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 9);
//        java.util.Date date18 = fixedMillisecond12.getTime();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18, timeZone19);
//        java.lang.Number number21 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month20);
//        java.util.Date date22 = month20.getEnd();
//        long long23 = month20.getSerialIndex();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440057489L + "'", long15 == 1560440057489L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean5 = timeSeries4.getNotify();
//        java.lang.Comparable comparable6 = timeSeries4.getKey();
//        java.util.Collection collection7 = timeSeries4.getTimePeriods();
//        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class2, (java.lang.Object) timeSeries4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond10);
//        int int13 = fixedMillisecond9.compareTo((java.lang.Object) 0L);
//        long long14 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-460));
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean19 = timeSeries18.getNotify();
//        java.lang.Class class20 = timeSeries18.getTimePeriodClass();
//        timeSeries18.clear();
//        timeSeries18.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        int int27 = fixedMillisecond23.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond23.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
//        int int33 = fixedMillisecond29.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1560440023080L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 100 + "'", comparable6.equals(100));
//        org.junit.Assert.assertNotNull(collection7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440057561L + "'", long14 == 1560440057561L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(timeSeries34);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
//        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.lang.String str26 = timeSeries24.getRangeDescription();
//        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
//        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
//        timeSeries33.setMaximumItemAge(1560440025647L);
//        timeSeries33.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getFirstMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond38.getTime();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        long long43 = year42.getFirstMillisecond();
//        long long44 = year42.getMiddleMillisecond();
//        long long45 = year42.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int48 = timeSeries47.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries47.addPropertyChangeListener(propertyChangeListener49);
//        timeSeries47.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        java.lang.Comparable comparable53 = timeSeries47.getKey();
//        java.util.List list54 = timeSeries47.getItems();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
//        timeSeries47.addChangeListener(seriesChangeListener55);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries58.addAndOrUpdate(timeSeries60);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener62 = null;
//        timeSeries60.addChangeListener(seriesChangeListener62);
//        timeSeries60.fireSeriesChanged();
//        long long65 = timeSeries60.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries60.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        java.util.Date date68 = fixedMillisecond66.getStart();
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean71 = timeSeries70.getNotify();
//        java.lang.Class class72 = timeSeries70.getTimePeriodClass();
//        timeSeries70.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
//        int int76 = fixedMillisecond74.compareTo((java.lang.Object) fixedMillisecond75);
//        java.util.Calendar calendar77 = null;
//        long long78 = fixedMillisecond75.getFirstMillisecond(calendar77);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries70.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (double) 9);
//        java.util.Date date81 = fixedMillisecond75.getTime();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month83 = new org.jfree.data.time.Month(date81, timeZone82);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date68, timeZone82);
//        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month(date68);
//        java.lang.Number number86 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) month85);
//        boolean boolean87 = year42.equals((java.lang.Object) month85);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month85, (double) 1560440014507L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440057621L + "'", long40 == 1560440057621L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1562097599999L + "'", long44 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + 1.0f + "'", comparable53.equals(1.0f));
//        org.junit.Assert.assertNotNull(list54);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 9223372036854775807L + "'", long65 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertNotNull(class72);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560440057626L + "'", long78 == 1560440057626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(number86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem89);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        int int18 = fixedMillisecond14.compareTo((java.lang.Object) 0L);
//        long long19 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getTime();
//        java.util.Date date24 = fixedMillisecond20.getTime();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        long long26 = timeSeries25.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440058518L + "'", long9 == 1560440058518L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440058519L + "'", long19 == 1560440058519L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440058520L + "'", long22 == 1560440058520L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        java.lang.Comparable comparable10 = timeSeries1.getKey();
//        try {
//            java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) comparable10);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100 + "'", comparable10.equals(100));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=-1]");
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        java.util.Date date5 = fixedMillisecond1.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        java.util.Date date9 = fixedMillisecond7.getStart();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.lang.String str11 = serialDate10.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', serialDate10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440058608L + "'", long3 == 1560440058608L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560439984118L);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries1.setDomainDescription("Last");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries1.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440058631L + "'", long9 == 1560440058631L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440058632L + "'", long16 == 1560440058632L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.getDayOfMonth();
        int int12 = spreadsheetDate8.toSerial();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.addAndOrUpdate(timeSeries19);
        boolean boolean21 = spreadsheetDate8.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.util.Date date23 = month22.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        long long25 = month22.getFirstMillisecond();
        java.lang.Number number26 = null;
        try {
            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month22, number26);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (7) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.addAndOrUpdate(timeSeries8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries8.addChangeListener(seriesChangeListener10);
//        timeSeries8.fireSeriesChanged();
//        long long13 = timeSeries8.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        java.util.Date date16 = fixedMillisecond14.getStart();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean19 = timeSeries18.getNotify();
//        java.lang.Class class20 = timeSeries18.getTimePeriodClass();
//        timeSeries18.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        int int24 = fixedMillisecond22.compareTo((java.lang.Object) fixedMillisecond23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 9);
//        java.util.Date date29 = fixedMillisecond23.getTime();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29, timeZone30);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date16, timeZone30);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean35 = timeSeries34.getNotify();
//        java.lang.Class class36 = timeSeries34.getTimePeriodClass();
//        timeSeries34.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        int int40 = fixedMillisecond38.compareTo((java.lang.Object) fixedMillisecond39);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond39.getFirstMillisecond(calendar41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 9);
//        java.util.Date date45 = fixedMillisecond39.getTime();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize(class49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond51.getFirstMillisecond(calendar52);
//        java.util.Date date54 = fixedMillisecond51.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date54);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date54, timeZone57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date45, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date16, timeZone57);
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440058747L + "'", long2 == 1560440058747L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440058751L + "'", long26 == 1560440058751L);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560440058753L + "'", long42 == 1560440058753L);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560440058755L + "'", long53 == 1560440058755L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(class61);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440059622L + "'", long2 == 1560440059622L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean8 = spreadsheetDate1.isOnOrBefore(serialDate7);
        java.lang.String str9 = spreadsheetDate1.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-January-1900" + "'", str9.equals("9-January-1900"));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440059905L + "'", long2 == 1560440059905L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        java.util.Date date5 = fixedMillisecond0.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar7 = null;
        try {
            day6.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        timeSeries1.clear();
        java.util.List list6 = timeSeries1.getItems();
        timeSeries1.removeAgedItems((long) 'a', true);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list12 = timeSeries11.getItems();
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries1.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12);
//        int int15 = day14.getMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.next();
//        java.lang.Number number18 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        boolean boolean19 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
//        long long26 = fixedMillisecond20.getFirstMillisecond();
//        java.lang.Object obj27 = null;
//        int int28 = fixedMillisecond20.compareTo(obj27);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 9);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440060273L + "'", long11 == 1560440060273L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440060298L + "'", long22 == 1560440060298L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440060298L + "'", long25 == 1560440060298L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440060298L + "'", long26 == 1560440060298L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        long long6 = month5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month5.previous();
//        int int9 = month5.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440060317L + "'", long2 == 1560440060317L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440060361L + "'", long2 == 1560440060361L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12);
//        int int15 = day14.getMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day14.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.next();
//        java.lang.Number number18 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.String str19 = day14.toString();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440060398L + "'", long11 == 1560440060398L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str20 = spreadsheetDate19.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean23 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean24 = spreadsheetDate8.equals((java.lang.Object) spreadsheetDate19);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean29 = spreadsheetDate26.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int30 = spreadsheetDate26.getDayOfWeek();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean33 = timeSeries32.getNotify();
//        java.lang.Comparable comparable34 = timeSeries32.getKey();
//        java.util.Collection collection35 = timeSeries32.getTimePeriods();
//        java.lang.Object obj36 = timeSeries32.clone();
//        boolean boolean37 = spreadsheetDate26.equals(obj36);
//        boolean boolean38 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        boolean boolean39 = year4.equals((java.lang.Object) boolean38);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440060518L + "'", long2 == 1560440060518L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 100 + "'", comparable34.equals(100));
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.getDayOfMonth();
        int int12 = spreadsheetDate8.toSerial();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.addAndOrUpdate(timeSeries19);
        boolean boolean21 = spreadsheetDate8.equals((java.lang.Object) timeSeries20);
        java.lang.Object obj22 = timeSeries20.clone();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day23);
        java.util.Calendar calendar25 = null;
        try {
            day23.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1);
//        java.lang.Class class24 = timeSeries1.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440060691L + "'", long9 == 1560440060691L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440060692L + "'", long17 == 1560440060692L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(class24);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (-2199));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560440014759L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str4 = spreadsheetDate3.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean7 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-435), (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate8);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        int int10 = fixedMillisecond6.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
//        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 9223372036854775807L);
//        int int21 = month18.getMonth();
//        java.util.Date date22 = month18.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
//        java.lang.String str31 = timeSeries29.getRangeDescription();
//        int int32 = fixedMillisecond23.compareTo((java.lang.Object) str31);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class36);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond23, class36);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list41 = timeSeries40.getItems();
//        timeSeries40.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        int int46 = fixedMillisecond44.compareTo((java.lang.Object) fixedMillisecond45);
//        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        boolean boolean48 = timeSeries40.isEmpty();
//        timeSeries40.setDomainDescription("ThreadContext");
//        java.util.List list51 = timeSeries40.getItems();
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries38.addAndOrUpdate(timeSeries40);
//        int int53 = month18.compareTo((java.lang.Object) timeSeries40);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) 1560439991971L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        int int58 = fixedMillisecond56.compareTo((java.lang.Object) fixedMillisecond57);
//        boolean boolean60 = fixedMillisecond56.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class63 = timeSeries62.getTimePeriodClass();
//        java.lang.String str64 = timeSeries62.getRangeDescription();
//        int int65 = fixedMillisecond56.compareTo((java.lang.Object) str64);
//        int int67 = fixedMillisecond56.compareTo((java.lang.Object) ' ');
//        boolean boolean68 = month18.equals((java.lang.Object) fixedMillisecond56);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(list51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Value" + "'", str64.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        java.util.Date date19 = fixedMillisecond15.getTime();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date19);
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        timeSeries14.setKey((java.lang.Comparable) timeSeriesDataItem23);
//        timeSeries14.setMaximumItemCount(2019);
//        timeSeries14.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
//        timeSeries14.setRangeDescription("");
//        java.lang.Object obj31 = timeSeries14.clone();
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440061699L + "'", long17 == 1560440061699L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(obj31);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        int int13 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560440007671L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list26 = timeSeries25.getItems();
//        timeSeries25.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        boolean boolean33 = timeSeries25.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day44.next();
//        int int47 = timeSeries37.getIndex(regularTimePeriod46);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, regularTimePeriod46);
//        timeSeries7.setMaximumItemAge(1560439982500L);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440061830L + "'", long11 == 1560440061830L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440061831L + "'", long16 == 1560440061831L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440061831L + "'", long22 == 1560440061831L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(list26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440061834L + "'", long41 == 1560440061834L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries48);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        long long6 = year5.getFirstMillisecond();
//        long long7 = year5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.previous();
//        int int9 = year5.getYear();
//        java.lang.String str10 = year5.toString();
//        try {
//            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(2958465, year5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440062117L + "'", long3 == 1560440062117L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 9999);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 1560440008543L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem8.getPeriod();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440062129L + "'", long2 == 1560440062129L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int21 = spreadsheetDate18.getDayOfMonth();
//        int int22 = spreadsheetDate18.toSerial();
//        boolean boolean23 = day5.equals((java.lang.Object) spreadsheetDate18);
//        java.lang.String str24 = spreadsheetDate18.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        boolean boolean36 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        int int38 = spreadsheetDate27.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        int int45 = day44.getMonth();
//        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
//        boolean boolean47 = spreadsheetDate27.isOnOrBefore(serialDate46);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean52 = spreadsheetDate49.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        int int53 = spreadsheetDate49.getDayOfWeek();
//        java.lang.String str54 = spreadsheetDate49.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str58 = spreadsheetDate57.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean61 = spreadsheetDate57.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate57);
//        boolean boolean63 = spreadsheetDate49.isAfter(serialDate62);
//        org.jfree.data.time.SerialDate serialDate64 = spreadsheetDate27.getEndOfCurrentMonth(serialDate62);
//        boolean boolean65 = spreadsheetDate18.isOnOrAfter(serialDate62);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440062169L + "'", long2 == 1560440062169L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-January-1900" + "'", str24.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440062197L + "'", long41 == 1560440062197L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 3 + "'", int53 == 3);
//        org.junit.Assert.assertNull(str54);
//        org.junit.Assert.assertNull(str58);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (-1), 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.addAndOrUpdate(timeSeries8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries8.addChangeListener(seriesChangeListener10);
//        timeSeries8.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        int int23 = fixedMillisecond14.compareTo((java.lang.Object) str22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond14.getMiddleMillisecond(calendar24);
//        boolean boolean27 = fixedMillisecond14.equals((java.lang.Object) 1560439986416L);
//        int int28 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries31.clear();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.addAndOrUpdate(timeSeries36);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries31.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        int int43 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean48 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        int int49 = spreadsheetDate45.getDayOfWeek();
//        java.lang.String str50 = spreadsheetDate45.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean62 = spreadsheetDate59.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
//        boolean boolean63 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
//        int int64 = spreadsheetDate54.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        int int69 = fixedMillisecond67.compareTo((java.lang.Object) fixedMillisecond68);
//        boolean boolean71 = fixedMillisecond67.equals((java.lang.Object) false);
//        boolean boolean72 = spreadsheetDate66.equals((java.lang.Object) false);
//        boolean boolean73 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate66);
//        boolean boolean75 = spreadsheetDate45.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate52, (org.jfree.data.time.SerialDate) spreadsheetDate54, 10);
//        int int76 = spreadsheetDate52.getYYYY();
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate52);
//        int int78 = day77.getYear();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) day77);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Value" + "'", str22.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440062694L + "'", long25 == 1560440062694L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440062698L + "'", long41 == 1560440062698L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 3 + "'", int49 == 3);
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1900 + "'", int76 == 1900);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1900 + "'", int78 == 1900);
//        org.junit.Assert.assertNotNull(timeSeries79);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int10 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
//        java.lang.Comparable comparable12 = timeSeries9.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        java.util.Date date17 = fixedMillisecond13.getTime();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date17);
//        java.lang.Number number20 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list24 = timeSeries23.getItems();
//        timeSeries23.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        int int29 = fixedMillisecond27.compareTo((java.lang.Object) fixedMillisecond28);
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        int int31 = fixedMillisecond19.compareTo((java.lang.Object) fixedMillisecond27);
//        try {
//            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1560440040781L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1.0f + "'", comparable12.equals(1.0f));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440064630L + "'", long15 == 1560440064630L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        int int45 = fixedMillisecond43.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond44.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond44.getTime();
//        int int49 = year4.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Calendar calendar50 = null;
//        try {
//            long long51 = year4.getLastMillisecond(calendar50);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440064651L + "'", long2 == 1560440064651L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440064654L + "'", long38 == 1560440064654L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440064654L + "'", long40 == 1560440064654L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440064654L + "'", long41 == 1560440064654L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560440064662L + "'", long47 == 1560440064662L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        int int12 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1);
//        long long24 = year19.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean28 = timeSeries27.getNotify();
//        java.lang.Class class29 = timeSeries27.getTimePeriodClass();
//        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", class29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19, class29);
//        long long32 = year19.getFirstMillisecond();
//        java.util.Calendar calendar33 = null;
//        try {
//            year19.peg(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440064706L + "'", long9 == 1560440064706L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440064707L + "'", long17 == 1560440064707L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNull(obj30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(11, (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        java.util.Date date7 = fixedMillisecond3.getTime();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date7);
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list14 = timeSeries13.getItems();
//        timeSeries13.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        int int21 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond17);
//        java.util.Date date22 = fixedMillisecond17.getEnd();
//        boolean boolean23 = fixedMillisecond1.equals((java.lang.Object) date22);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440064742L + "'", long5 == 1560440064742L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date21, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date12, timeZone24);
//        long long27 = day26.getMiddleMillisecond();
//        java.util.Calendar calendar28 = null;
//        try {
//            day26.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440064856L + "'", long9 == 1560440064856L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440064858L + "'", long20 == 1560440064858L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560452399999L + "'", long27 == 1560452399999L);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        int int13 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        timeSeries7.removeAgedItems(true);
//        long long16 = timeSeries7.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440064886L + "'", long11 == 1560440064886L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int34 = day33.getYear();
//        java.util.Date date35 = day33.getStart();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
//        int int37 = month36.getYearValue();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list16 = timeSeries15.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        int int20 = timeSeries15.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        int int23 = fixedMillisecond21.compareTo((java.lang.Object) fixedMillisecond22);
//        boolean boolean25 = fixedMillisecond21.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
//        java.lang.String str29 = timeSeries27.getRangeDescription();
//        int int30 = fixedMillisecond21.compareTo((java.lang.Object) str29);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
//        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21, class34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (short) 1);
//        long long39 = fixedMillisecond21.getLastMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond21.getFirstMillisecond(calendar40);
//        java.lang.Number number42 = null;
//        try {
//            timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number42, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440065030L + "'", long9 == 1560440065030L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440065037L + "'", long39 == 1560440065037L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440065037L + "'", long41 == 1560440065037L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean5 = timeSeries4.getNotify();
        java.lang.Class class6 = timeSeries4.getTimePeriodClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: hi!", class6);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=-1]", class6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNull(inputStream8);
        org.junit.Assert.assertNull(uRL9);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        java.lang.Class<?> wildcardClass8 = date7.getClass();
//        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Following", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440015802L, "Time", "Thu Jun 13 08:34:19 PDT 2019", (java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440065090L + "'", long6 == 1560440065090L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(uRL9);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setDomainDescription("ThreadContext");
//        java.util.List list12 = timeSeries1.getItems();
//        java.lang.Object obj13 = timeSeries1.clone();
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertNotNull(obj13);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str16 = spreadsheetDate15.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean21 = spreadsheetDate2.isOnOrBefore(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int27 = spreadsheetDate23.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean30 = timeSeries29.getNotify();
        java.lang.Comparable comparable31 = timeSeries29.getKey();
        java.util.Collection collection32 = timeSeries29.getTimePeriods();
        java.lang.Object obj33 = timeSeries29.clone();
        boolean boolean34 = spreadsheetDate23.equals(obj33);
        java.util.Date date35 = spreadsheetDate23.toDate();
        boolean boolean36 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int37 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate50 = null;
        try {
            int int51 = spreadsheetDate2.compare(serialDate50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 100 + "'", comparable31.equals(100));
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        java.util.Date date5 = fixedMillisecond1.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        java.util.Date date9 = fixedMillisecond7.getStart();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
//        java.lang.String str11 = serialDate10.toString();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(1, serialDate10);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440065176L + "'", long3 == 1560440065176L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        long long8 = day5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440065215L + "'", long2 == 1560440065215L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        boolean boolean3 = timeSeries1.isEmpty();
//        boolean boolean4 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        boolean boolean21 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        int int22 = spreadsheetDate19.toSerial();
//        boolean boolean23 = timeSeries1.equals((java.lang.Object) spreadsheetDate19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        int int26 = fixedMillisecond24.compareTo((java.lang.Object) fixedMillisecond25);
//        boolean boolean28 = fixedMillisecond24.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        java.lang.String str32 = timeSeries30.getRangeDescription();
//        int int33 = fixedMillisecond24.compareTo((java.lang.Object) str32);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
//        boolean boolean38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class37);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond24, class37);
//        java.util.Calendar calendar40 = null;
//        fixedMillisecond24.peg(calendar40);
//        long long42 = fixedMillisecond24.getMiddleMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond24.getFirstMillisecond(calendar43);
//        long long45 = fixedMillisecond24.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 43629L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 1560439979754L);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560440065242L + "'", long42 == 1560440065242L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560440065242L + "'", long44 == 1560440065242L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560440065242L + "'", long45 == 1560440065242L);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        boolean boolean3 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day5.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440065293L + "'", long2 == 1560440065293L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        int int10 = day5.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440065304L + "'", long2 == 1560440065304L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries1.setDomainDescription("Last");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond24.getMiddleMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond24.getTime();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440065364L + "'", long9 == 1560440065364L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440065365L + "'", long16 == 1560440065365L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440065367L + "'", long27 == 1560440065367L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560440065367L + "'", long29 == 1560440065367L);
//        org.junit.Assert.assertNotNull(date30);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9, (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        long long6 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440065403L + "'", long6 == 1560440065403L);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
//        java.util.Calendar calendar33 = null;
//        try {
//            long long34 = year29.getLastMillisecond(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440065426L + "'", long19 == 1560440065426L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440065427L + "'", long26 == 1560440065427L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 6);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int34 = day33.getYear();
        java.util.Date date35 = day33.getStart();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(regularTimePeriod37);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440065572L + "'", long2 == 1560440065572L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 9223372036854775807L);
//        int int8 = month5.getMonth();
//        java.lang.String str9 = month5.toString();
//        long long10 = month5.getFirstMillisecond();
//        boolean boolean12 = month5.equals((java.lang.Object) 1560440022654L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) fixedMillisecond14);
//        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
//        java.lang.String str21 = timeSeries19.getRangeDescription();
//        int int22 = fixedMillisecond13.compareTo((java.lang.Object) str21);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
//        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond13, class26);
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond13.peg(calendar29);
//        long long31 = fixedMillisecond13.getMiddleMillisecond();
//        long long32 = fixedMillisecond13.getMiddleMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond13.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) fixedMillisecond37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        java.lang.String str44 = timeSeries42.getRangeDescription();
//        int int45 = fixedMillisecond36.compareTo((java.lang.Object) str44);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
//        boolean boolean50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond36, class49);
//        java.util.Calendar calendar52 = null;
//        fixedMillisecond36.peg(calendar52);
//        long long54 = fixedMillisecond36.getMiddleMillisecond();
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond36.getFirstMillisecond(calendar55);
//        long long57 = fixedMillisecond36.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 43629L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1560439979754L);
//        try {
//            timeSeries35.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560440065611L + "'", long31 == 1560440065611L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560440065611L + "'", long32 == 1560440065611L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440065611L + "'", long34 == 1560440065611L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Value" + "'", str44.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560440065615L + "'", long54 == 1560440065615L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560440065615L + "'", long56 == 1560440065615L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560440065615L + "'", long57 == 1560440065615L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int2 = timeSeries1.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
//        timeSeries1.removeAgedItems(0L, false);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getStart();
//        java.lang.String str10 = month8.toString();
//        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
//        timeSeries1.setDomainDescription("Time");
//        java.lang.String str14 = timeSeries1.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond17.getTime();
//        java.util.Date date21 = fixedMillisecond17.getTime();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        long long25 = fixedMillisecond23.getMiddleMillisecond();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440065653L + "'", long19 == 1560440065653L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440065653L + "'", long25 == 1560440065653L);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean8 = timeSeries7.getNotify();
        java.lang.Comparable comparable9 = timeSeries7.getKey();
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Object obj11 = timeSeries7.clone();
        boolean boolean12 = spreadsheetDate1.equals(obj11);
        try {
            org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate1.getFollowingDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setDomainDescription("ThreadContext");
//        java.util.List list12 = timeSeries1.getItems();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int15 = timeSeries14.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries14.addPropertyChangeListener(propertyChangeListener16);
//        timeSeries14.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        timeSeries14.fireSeriesChanged();
//        java.lang.Comparable comparable21 = timeSeries14.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        long long27 = year26.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 1560440029979L);
//        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
//        java.util.Date date31 = month30.getStart();
//        java.lang.String str32 = month30.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.next();
//        long long34 = month30.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year26, (org.jfree.data.time.RegularTimePeriod) month30);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 1.0f + "'", comparable21.equals(1.0f));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440065689L + "'", long24 == 1560440065689L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 24234L + "'", long34 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getMonth();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str17 = spreadsheetDate16.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean20 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean22 = spreadsheetDate3.isOnOrBefore(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean27 = spreadsheetDate24.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int28 = spreadsheetDate24.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean31 = timeSeries30.getNotify();
        java.lang.Comparable comparable32 = timeSeries30.getKey();
        java.util.Collection collection33 = timeSeries30.getTimePeriods();
        java.lang.Object obj34 = timeSeries30.clone();
        boolean boolean35 = spreadsheetDate24.equals(obj34);
        java.util.Date date36 = spreadsheetDate24.toDate();
        boolean boolean37 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int38 = spreadsheetDate3.toSerial();
        int int39 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 100 + "'", comparable32.equals(100));
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(serialDate40);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        long long8 = day5.getLastMillisecond();
//        java.lang.String str9 = day5.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440066092L + "'", long2 == 1560440066092L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int34 = day33.getYear();
        java.util.Date date35 = day33.getStart();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        long long37 = day36.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208916800001L) + "'", long37 == (-2208916800001L));
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
//        int int3 = month0.getMonth();
//        java.util.Date date4 = month0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean9 = fixedMillisecond5.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getRangeDescription();
//        int int14 = fixedMillisecond5.compareTo((java.lang.Object) str13);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, class18);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list23 = timeSeries22.getItems();
//        timeSeries22.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        int int28 = fixedMillisecond26.compareTo((java.lang.Object) fixedMillisecond27);
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        boolean boolean30 = timeSeries22.isEmpty();
//        timeSeries22.setDomainDescription("ThreadContext");
//        java.util.List list33 = timeSeries22.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries20.addAndOrUpdate(timeSeries22);
//        int int35 = month0.compareTo((java.lang.Object) timeSeries22);
//        org.jfree.data.time.Year year36 = month0.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(list33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(year36);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        long long7 = year4.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.addAndOrUpdate(timeSeries11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        timeSeries11.fireSeriesChanged();
//        long long16 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        boolean boolean19 = year4.equals((java.lang.Object) fixedMillisecond17);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440066427L + "'", long2 == 1560440066427L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean25 = spreadsheetDate1.isAfter(serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean30 = spreadsheetDate27.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean35 = spreadsheetDate32.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        int int37 = spreadsheetDate34.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int43 = spreadsheetDate39.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean46 = timeSeries45.getNotify();
        java.lang.Comparable comparable47 = timeSeries45.getKey();
        java.util.Collection collection48 = timeSeries45.getTimePeriods();
        java.lang.Object obj49 = timeSeries45.clone();
        boolean boolean50 = spreadsheetDate39.equals(obj49);
        java.util.Date date51 = spreadsheetDate39.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        int int56 = spreadsheetDate54.getMonth();
        int int57 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate54);
        int int58 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean59 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 100 + "'", comparable47.equals(100));
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.addAndOrUpdate(timeSeries8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries8.addChangeListener(seriesChangeListener10);
//        timeSeries8.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        int int23 = fixedMillisecond14.compareTo((java.lang.Object) str22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond14.getMiddleMillisecond(calendar24);
//        boolean boolean27 = fixedMillisecond14.equals((java.lang.Object) 1560439986416L);
//        int int28 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.addAndOrUpdate(timeSeries8);
//        int int30 = timeSeries8.getMaximumItemCount();
//        java.lang.Class class31 = timeSeries8.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Value" + "'", str22.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440066817L + "'", long25 == 1560440066817L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
//        org.junit.Assert.assertNotNull(class31);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        timeSeries1.setDomainDescription("Time");
        java.util.List list14 = timeSeries1.getItems();
        boolean boolean15 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        java.lang.String str26 = timeSeries24.getRangeDescription();
        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean37 = timeSeries36.getNotify();
        java.lang.Class class38 = timeSeries36.getTimePeriodClass();
        timeSeries36.clear();
        java.lang.String str40 = timeSeries36.getRangeDescription();
        int int41 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries36);
        boolean boolean43 = timeSeriesDataItem17.equals((java.lang.Object) 1560439986394L);
        timeSeriesDataItem17.setValue((java.lang.Number) 1560439993091L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeriesDataItem17.getPeriod();
        java.lang.Object obj47 = timeSeriesDataItem17.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 0);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "August 0" + "'", str4.equals("August 0"));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440067152L + "'", long4 == 1560440067152L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list18 = timeSeries17.getItems();
        timeSeries17.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) fixedMillisecond22);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        boolean boolean25 = timeSeries17.isEmpty();
        timeSeries17.setDomainDescription("ThreadContext");
        java.util.List list28 = timeSeries17.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list32 = timeSeries31.getItems();
        timeSeries31.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        int int37 = fixedMillisecond35.compareTo((java.lang.Object) fixedMillisecond36);
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 1560439980698L);
        java.lang.Object obj41 = timeSeries17.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate19.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean26 = timeSeries25.getNotify();
        java.lang.Comparable comparable27 = timeSeries25.getKey();
        java.util.Collection collection28 = timeSeries25.getTimePeriods();
        java.lang.Object obj29 = timeSeries25.clone();
        boolean boolean30 = spreadsheetDate19.equals(obj29);
        boolean boolean31 = timeSeriesDataItem17.equals((java.lang.Object) spreadsheetDate19);
        java.lang.Object obj32 = timeSeriesDataItem17.clone();
        java.lang.Object obj33 = timeSeriesDataItem17.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(obj33);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        int int4 = fixedMillisecond2.compareTo((java.lang.Object) fixedMillisecond3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) false);
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.addAndOrUpdate(timeSeries11);
//        boolean boolean13 = spreadsheetDate1.equals((java.lang.Object) timeSeries9);
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries9.addPropertyChangeListener(propertyChangeListener14);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries9.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("ThreadContext");
        java.lang.String str12 = timeSeries1.getDescription();
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond5.getClass();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond5.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond5.previous();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond5.getLastMillisecond(calendar13);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440067666L + "'", long11 == 1560440067666L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440067666L + "'", long14 == 1560440067666L);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        int int5 = fixedMillisecond3.compareTo((java.lang.Object) fixedMillisecond4);
//        boolean boolean7 = fixedMillisecond3.equals((java.lang.Object) false);
//        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.addAndOrUpdate(timeSeries12);
//        boolean boolean14 = spreadsheetDate2.equals((java.lang.Object) timeSeries10);
//        int int15 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        boolean boolean27 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean36 = timeSeries35.getNotify();
//        java.lang.Comparable comparable37 = timeSeries35.getKey();
//        java.util.Collection collection38 = timeSeries35.getTimePeriods();
//        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class33, (java.lang.Object) timeSeries35);
//        java.lang.ClassLoader classLoader40 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class33);
//        boolean boolean41 = spreadsheetDate30.equals((java.lang.Object) class33);
//        int int42 = spreadsheetDate30.getMonth();
//        boolean boolean43 = spreadsheetDate2.isInRange(serialDate28, (org.jfree.data.time.SerialDate) spreadsheetDate30);
//        try {
//            org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 100 + "'", comparable37.equals(100));
//        org.junit.Assert.assertNotNull(collection38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(classLoader40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560439989191L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str8 = spreadsheetDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate4.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
        boolean boolean19 = fixedMillisecond15.equals((java.lang.Object) false);
        boolean boolean20 = spreadsheetDate14.equals((java.lang.Object) false);
        boolean boolean21 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1);
//        long long24 = year19.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean28 = timeSeries27.getNotify();
//        java.lang.Class class29 = timeSeries27.getTimePeriodClass();
//        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", class29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19, class29);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize(class29);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440067764L + "'", long9 == 1560440067764L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440067766L + "'", long17 == 1560440067766L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNull(obj30);
//        org.junit.Assert.assertNotNull(class32);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.addAndOrUpdate(timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.addAndOrUpdate(timeSeries25);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries29.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440067916L + "'", long9 == 1560440067916L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440067922L + "'", long17 == 1560440067922L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries1.add(regularTimePeriod5, (java.lang.Number) 1560440019137L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((-2199));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        int int34 = fixedMillisecond32.compareTo((java.lang.Object) fixedMillisecond33);
//        int int36 = fixedMillisecond32.compareTo((java.lang.Object) 0L);
//        long long37 = fixedMillisecond32.getMiddleMillisecond();
//        java.util.Calendar calendar38 = null;
//        fixedMillisecond32.peg(calendar38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 1.0f);
//        java.util.Calendar calendar42 = null;
//        fixedMillisecond32.peg(calendar42);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560440023789L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440067971L + "'", long19 == 1560440067971L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440067972L + "'", long26 == 1560440067972L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440067973L + "'", long37 == 1560440067973L);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        int int8 = year4.compareTo((java.lang.Object) 1560440009393L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440067990L + "'", long2 == 1560440067990L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 08:34:14 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1560439985071L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
//        int int10 = year0.compareTo((java.lang.Object) regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440068020L + "'", long4 == 1560440068020L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
//        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.lang.String str26 = timeSeries24.getRangeDescription();
//        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
//        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean37 = timeSeries36.getNotify();
//        java.lang.Class class38 = timeSeries36.getTimePeriodClass();
//        timeSeries36.clear();
//        java.lang.String str40 = timeSeries36.getRangeDescription();
//        int int41 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries36);
//        java.lang.String str42 = timeSeries36.getRangeDescription();
//        java.lang.Comparable comparable43 = timeSeries36.getKey();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Value" + "'", str42.equals("Value"));
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 100 + "'", comparable43.equals(100));
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        java.util.Date date3 = month2.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list8 = timeSeries7.getItems();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        int int13 = fixedMillisecond11.compareTo((java.lang.Object) fixedMillisecond12);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        boolean boolean15 = timeSeries7.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener16);
//        timeSeries7.setMaximumItemAge(43629L);
//        java.lang.Object obj20 = timeSeries7.clone();
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
//        int int30 = day27.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day27.next();
//        timeSeries21.add(regularTimePeriod31, (java.lang.Number) 1560440010857L, false);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(number5);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440068225L + "'", long24 == 1560440068225L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 0L);
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1.0f);
//        long long10 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440068448L + "'", long5 == 1560440068448L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440068448L + "'", long10 == 1560440068448L);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int34 = day33.getYear();
        java.util.Date date35 = day33.getStart();
        java.lang.String str36 = day33.toString();
        java.lang.String str37 = day33.toString();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = day33.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1-January-1900" + "'", str36.equals("1-January-1900"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1-January-1900" + "'", str37.equals("1-January-1900"));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int13 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        boolean boolean22 = spreadsheetDate2.isOnOrBefore(serialDate21);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean25 = timeSeries24.getNotify();
//        java.lang.Class class26 = timeSeries24.getTimePeriodClass();
//        java.lang.Object obj27 = null;
//        boolean boolean28 = timeSeries24.equals(obj27);
//        timeSeries24.removeAgedItems(1L, true);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 9223372036854775807L);
//        int int35 = month32.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries24.addOrUpdate(regularTimePeriod36, (java.lang.Number) 1560439985071L);
//        java.util.List list39 = timeSeries24.getItems();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries41.addAndOrUpdate(timeSeries43);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries43.addChangeListener(seriesChangeListener45);
//        timeSeries43.fireSeriesChanged();
//        long long48 = timeSeries43.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries43.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        java.lang.String str52 = fixedMillisecond49.toString();
//        long long53 = fixedMillisecond49.getMiddleMillisecond();
//        try {
//            int int54 = spreadsheetDate2.compareTo((java.lang.Object) fixedMillisecond49);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440068489L + "'", long16 == 1560440068489L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(list39);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Thu Jun 13 08:34:28 PDT 2019" + "'", str52.equals("Thu Jun 13 08:34:28 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560440068505L + "'", long53 == 1560440068505L);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        long long5 = day4.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208182400001L) + "'", long5 == (-2208182400001L));
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        int int13 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560440007671L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list26 = timeSeries25.getItems();
//        timeSeries25.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
//        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        boolean boolean33 = timeSeries25.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries25.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.addAndOrUpdate(timeSeries37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        java.util.Date date42 = fixedMillisecond39.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        int int45 = day44.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day44.next();
//        int int47 = timeSeries37.getIndex(regularTimePeriod46);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, regularTimePeriod46);
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener49);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440068543L + "'", long11 == 1560440068543L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440068544L + "'", long16 == 1560440068544L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440068544L + "'", long22 == 1560440068544L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(list26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440068549L + "'", long41 == 1560440068549L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries48);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        boolean boolean3 = timeSeries1.isEmpty();
//        boolean boolean4 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
//        java.util.Collection collection9 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
//        java.lang.String str13 = fixedMillisecond10.toString();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        long long15 = fixedMillisecond10.getLastMillisecond();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440068936L + "'", long12 == 1560440068936L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Thu Jun 13 08:34:28 PDT 2019" + "'", str13.equals("Thu Jun 13 08:34:28 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440068936L + "'", long15 == 1560440068936L);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
//        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.lang.String str26 = timeSeries24.getRangeDescription();
//        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
//        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean37 = timeSeries36.getNotify();
//        java.lang.Class class38 = timeSeries36.getTimePeriodClass();
//        timeSeries36.clear();
//        java.lang.String str40 = timeSeries36.getRangeDescription();
//        int int41 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries36);
//        boolean boolean43 = timeSeriesDataItem17.equals((java.lang.Object) 1560439986394L);
//        java.lang.Number number44 = timeSeriesDataItem17.getValue();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list47 = timeSeries46.getItems();
//        timeSeries46.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        int int52 = fixedMillisecond50.compareTo((java.lang.Object) fixedMillisecond51);
//        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        int int54 = timeSeriesDataItem17.compareTo((java.lang.Object) fixedMillisecond50);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries56.addAndOrUpdate(timeSeries58);
//        int int60 = timeSeries58.getMaximumItemCount();
//        boolean boolean61 = timeSeries58.isEmpty();
//        timeSeries58.clear();
//        timeSeries58.setNotify(true);
//        boolean boolean65 = timeSeriesDataItem17.equals((java.lang.Object) true);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (short) 1 + "'", number44.equals((short) 1));
//        org.junit.Assert.assertNotNull(list47);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems(1560439995341L, false);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean8 = spreadsheetDate1.isOnOrBefore(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate30 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate31 = null;
        try {
            boolean boolean32 = spreadsheetDate10.isAfter(serialDate31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate30);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.addAndOrUpdate(timeSeries12);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.addChangeListener(seriesChangeListener14);
//        timeSeries12.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int19 = timeSeries18.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries18);
//        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        java.lang.Class class22 = timeSeries18.getTimePeriodClass();
//        try {
//            timeSeries18.delete((int) (byte) 10, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertNotNull(class22);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        int int4 = fixedMillisecond2.compareTo((java.lang.Object) fixedMillisecond3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) false);
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) false);
//        int int8 = spreadsheetDate1.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertNotNull(serialDate34);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            year5.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440069461L + "'", long2 == 1560440069461L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        java.lang.String str3 = timeSeries1.getRangeDescription();
//        boolean boolean5 = timeSeries1.equals((java.lang.Object) 1560439979754L);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean8 = timeSeries7.getNotify();
//        java.lang.Class class9 = timeSeries7.getTimePeriodClass();
//        timeSeries7.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        int int13 = fixedMillisecond11.compareTo((java.lang.Object) fixedMillisecond12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 9);
//        java.util.Date date18 = fixedMillisecond12.getTime();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18, timeZone19);
//        java.lang.Number number21 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month20);
//        java.util.Date date22 = month20.getEnd();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440069474L + "'", long15 == 1560440069474L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(serialDate23);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1900);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        java.lang.Object obj2 = timeSeries1.clone();
        int int3 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("ThreadContext");
        java.util.List list12 = timeSeries1.getItems();
        java.lang.Comparable comparable13 = timeSeries1.getKey();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 100 + "'", comparable13.equals(100));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        java.util.Calendar calendar43 = null;
//        try {
//            long long44 = year4.getLastMillisecond(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440069680L + "'", long2 == 1560440069680L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440069683L + "'", long38 == 1560440069683L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440069683L + "'", long40 == 1560440069683L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440069683L + "'", long41 == 1560440069683L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int19 = spreadsheetDate1.getDayOfMonth();
        int int20 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list16 = timeSeries15.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        java.lang.Class class20 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean23 = timeSeries22.getNotify();
//        java.lang.Class class24 = timeSeries22.getTimePeriodClass();
//        timeSeries22.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        int int28 = fixedMillisecond26.compareTo((java.lang.Object) fixedMillisecond27);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getFirstMillisecond(calendar29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9);
//        timeSeries22.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        int int37 = fixedMillisecond35.compareTo((java.lang.Object) fixedMillisecond36);
//        int int39 = fixedMillisecond35.compareTo((java.lang.Object) 0L);
//        long long40 = fixedMillisecond35.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getFirstMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        java.util.Date date45 = fixedMillisecond41.getTime();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        java.lang.Number number47 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, number47);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeries15.getTimePeriod(2958465);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440069742L + "'", long9 == 1560440069742L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440069745L + "'", long30 == 1560440069745L);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440069748L + "'", long40 == 1560440069748L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560440069749L + "'", long43 == 1560440069749L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener10);
//        timeSeries1.setMaximumItemAge(43629L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.next();
//        java.lang.Number number23 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440069769L + "'", long16 == 1560440069769L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(number23);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setDescription("August 0");
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean8 = timeSeries7.getNotify();
        java.lang.Comparable comparable9 = timeSeries7.getKey();
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Object obj11 = timeSeries7.clone();
        boolean boolean12 = spreadsheetDate1.equals(obj11);
        java.util.Date date13 = spreadsheetDate1.toDate();
        java.lang.String str14 = spreadsheetDate1.getDescription();
        java.lang.Object obj15 = null;
        try {
            int int16 = spreadsheetDate1.compareTo(obj15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        java.util.List list6 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        java.lang.String str26 = timeSeries24.getRangeDescription();
        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean37 = timeSeries36.getNotify();
        java.lang.Class class38 = timeSeries36.getTimePeriodClass();
        timeSeries36.clear();
        java.lang.String str40 = timeSeries36.getRangeDescription();
        int int41 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries36);
        boolean boolean43 = timeSeriesDataItem17.equals((java.lang.Object) 1560439986394L);
        timeSeriesDataItem17.setValue((java.lang.Number) 1560439993091L);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class48 = timeSeries47.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean51 = timeSeries50.getNotify();
        java.lang.Comparable comparable52 = timeSeries50.getKey();
        java.util.Collection collection53 = timeSeries50.getTimePeriods();
        boolean boolean54 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class48, (java.lang.Object) timeSeries50);
        java.lang.String str55 = timeSeries50.getDescription();
        timeSeries50.setMaximumItemAge(1560439986394L);
        java.lang.Comparable comparable58 = timeSeries50.getKey();
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener59);
        boolean boolean61 = timeSeriesDataItem17.equals((java.lang.Object) propertyChangeListener59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100 + "'", comparable52.equals(100));
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + comparable58 + "' != '" + 100 + "'", comparable58.equals(100));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, 8, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Date date11 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        int int13 = year12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-456));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
//        long long9 = year4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440070229L + "'", long2 == 1560440070229L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setDomainDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        java.lang.Class<?> wildcardClass16 = date15.getClass();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year17);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.addAndOrUpdate(timeSeries23);
//        int int25 = timeSeries23.getItemCount();
//        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        try {
//            java.lang.Number number28 = timeSeries1.getValue(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440070265L + "'", long14 == 1560440070265L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(collection26);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(1560440005938L);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) 1560440016670L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getMiddleMillisecond();
//        long long7 = year4.getFirstMillisecond();
//        boolean boolean9 = year4.equals((java.lang.Object) 1560439994106L);
//        java.util.Calendar calendar10 = null;
//        try {
//            year4.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440070336L + "'", long2 == 1560440070336L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test346");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
//        long long10 = day5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440070350L + "'", long2 == 1560440070350L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        java.lang.Class<?> wildcardClass5 = date4.getClass();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
//        long long7 = year6.getFirstMillisecond();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(5, year6);
//        int int9 = year6.getYear();
//        int int10 = year6.getYear();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440070374L + "'", long3 == 1560440070374L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("9-January-1900", class3);
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class3);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(classLoader5);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) false);
//        java.lang.Number number11 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries3.addChangeListener(seriesChangeListener12);
//        java.lang.String str14 = timeSeries3.getDescription();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertNull(str14);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 4, 1900);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = regularTimePeriod9.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440070504L + "'", long2 == 1560440070504L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440070515L + "'", long4 == 1560440070515L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440070515L + "'", long6 == 1560440070515L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getFirstMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getTime();
//        java.util.Date date36 = fixedMillisecond32.getTime();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date36);
//        java.util.Date date39 = fixedMillisecond38.getTime();
//        java.util.Date date40 = fixedMillisecond38.getStart();
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
//        boolean boolean42 = spreadsheetDate10.isOn(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440070533L + "'", long34 == 1560440070533L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str19 = spreadsheetDate18.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate7.equals((java.lang.Object) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.lang.Class<?> wildcardClass25 = serialDate24.getClass();
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("June", (java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "ClassContext", "Thu Jun 13 08:33:34 PDT 2019", (java.lang.Class) wildcardClass25);
        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNull(inputStream26);
        org.junit.Assert.assertNull(uRL28);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: Value");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: Value"));
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.addAndOrUpdate(timeSeries8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries8.addChangeListener(seriesChangeListener10);
//        timeSeries8.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        int int23 = fixedMillisecond14.compareTo((java.lang.Object) str22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond14.getMiddleMillisecond(calendar24);
//        boolean boolean27 = fixedMillisecond14.equals((java.lang.Object) 1560439986416L);
//        int int28 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.addAndOrUpdate(timeSeries8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
//        java.util.Date date33 = fixedMillisecond30.getTime();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries38.clear();
//        java.lang.Object obj40 = timeSeries38.clone();
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getFirstMillisecond(calendar44);
//        java.util.Date date46 = fixedMillisecond43.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46);
//        int int49 = day48.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day48.next();
//        int int51 = day48.getYear();
//        int int52 = day48.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day48.next();
//        java.lang.Number number54 = null;
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) day48, number54);
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries4.createCopy(regularTimePeriod36, (org.jfree.data.time.RegularTimePeriod) day48);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Value" + "'", str22.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440070788L + "'", long25 == 1560440070788L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560440070790L + "'", long32 == 1560440070790L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(obj40);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560440070792L + "'", long45 == 1560440070792L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 13 + "'", int49 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 13 + "'", int52 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeSeries56);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Date date11 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        boolean boolean21 = fixedMillisecond17.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        java.lang.String str25 = timeSeries23.getRangeDescription();
//        int int26 = fixedMillisecond17.compareTo((java.lang.Object) str25);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
//        boolean boolean31 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, class30);
//        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class30);
//        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getFirstMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getTime();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date38, timeZone39);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class30);
//        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class30);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "Last", "2019", class30);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(uRL33);
//        org.junit.Assert.assertNull(uRL34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440071529L + "'", long37 == 1560440071529L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(inputStream42);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.String str17 = timeSeries15.getRangeDescription();
//        int int18 = fixedMillisecond9.compareTo((java.lang.Object) str17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond9.getMiddleMillisecond(calendar19);
//        boolean boolean22 = fixedMillisecond9.equals((java.lang.Object) 1560439986416L);
//        int int23 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.lang.Object obj24 = timeSeries3.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = fixedMillisecond25.compareTo((java.lang.Object) fixedMillisecond26);
//        boolean boolean29 = fixedMillisecond25.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
//        java.lang.String str33 = timeSeries31.getRangeDescription();
//        int int34 = fixedMillisecond25.compareTo((java.lang.Object) str33);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
//        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25, class38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (short) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean47 = spreadsheetDate44.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        int int48 = spreadsheetDate44.getDayOfWeek();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean51 = timeSeries50.getNotify();
//        java.lang.Comparable comparable52 = timeSeries50.getKey();
//        java.util.Collection collection53 = timeSeries50.getTimePeriods();
//        java.lang.Object obj54 = timeSeries50.clone();
//        boolean boolean55 = spreadsheetDate44.equals(obj54);
//        boolean boolean56 = timeSeriesDataItem42.equals((java.lang.Object) spreadsheetDate44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = timeSeriesDataItem42.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries3.addOrUpdate(regularTimePeriod57, (java.lang.Number) 1560440040995L);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440071857L + "'", long20 == 1560440071857L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 3 + "'", int48 == 3);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 100 + "'", comparable52.equals(100));
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test359");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        timeSeries1.clear();
//        java.util.List list6 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond7.getTime();
//        java.util.Date date11 = fixedMillisecond7.getTime();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date11);
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        java.util.Date date15 = fixedMillisecond13.getStart();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        java.lang.Number number18 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        int int19 = day17.getYear();
//        int int20 = day17.getYear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440072210L + "'", long9 == 1560440072210L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.addChangeListener(seriesChangeListener14);
        timeSeries12.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int19 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        boolean boolean22 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries6.clear();
        java.lang.Object obj8 = timeSeries6.clone();
        boolean boolean9 = timeSeries1.equals((java.lang.Object) timeSeries6);
        timeSeries6.removeAgedItems(0L, false);
        java.util.Collection collection13 = timeSeries6.getTimePeriods();
        java.util.Collection collection14 = org.jfree.chart.util.ObjectUtilities.deepClone(collection13);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-2199), (int) (short) 10, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.previous();
//        boolean boolean35 = year29.equals((java.lang.Object) 1560440016160L);
//        java.util.Calendar calendar36 = null;
//        try {
//            long long37 = year29.getFirstMillisecond(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440072400L + "'", long19 == 1560440072400L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440072402L + "'", long26 == 1560440072402L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) false);
//        java.lang.Number number11 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        long long12 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16);
//        int int19 = day18.getMonth();
//        long long20 = day18.getFirstMillisecond();
//        java.lang.Number number21 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getDayOfMonth();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440072424L + "'", long15 == 1560440072424L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
        boolean boolean19 = spreadsheetDate13.equals((java.lang.Object) false);
        boolean boolean20 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        java.lang.String str21 = spreadsheetDate1.toString();
        int int22 = spreadsheetDate1.getDayOfMonth();
        int int23 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-January-1900" + "'", str21.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean5 = timeSeries4.getNotify();
        java.lang.Comparable comparable6 = timeSeries4.getKey();
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class2, (java.lang.Object) timeSeries4);
        java.lang.String str9 = timeSeries4.getDescription();
        timeSeries4.setMaximumItemAge(1560439986394L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
        boolean boolean16 = fixedMillisecond12.equals((java.lang.Object) false);
        java.util.Date date17 = fixedMillisecond12.getTime();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560440009304L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 100 + "'", comparable6.equals(100));
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean25 = spreadsheetDate1.isAfter(serialDate24);
        java.lang.String str26 = serialDate24.getDescription();
        java.lang.String str27 = serialDate24.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "9-September-1902" + "'", str27.equals("9-September-1902"));
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        int int5 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) fixedMillisecond9);
//        boolean boolean12 = fixedMillisecond8.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
//        java.lang.String str16 = timeSeries14.getRangeDescription();
//        int int17 = fixedMillisecond8.compareTo((java.lang.Object) str16);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        boolean boolean22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class21);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, class21);
//        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class21);
//        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond26.getTime();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date29, timeZone30);
//        try {
//            timeSeries3.update(regularTimePeriod31, (java.lang.Number) 1560440070792L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(uRL24);
//        org.junit.Assert.assertNull(uRL25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560440072592L + "'", long28 == 1560440072592L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test371");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        boolean boolean3 = timeSeries1.isEmpty();
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list7 = timeSeries6.getItems();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
//        java.lang.Object obj10 = timeSeries1.clone();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean13 = timeSeries12.getNotify();
//        java.lang.Class class14 = timeSeries12.getTimePeriodClass();
//        timeSeries12.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        int int18 = fixedMillisecond16.compareTo((java.lang.Object) fixedMillisecond17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond17.getFirstMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 9);
//        timeSeries12.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = fixedMillisecond25.compareTo((java.lang.Object) fixedMillisecond26);
//        int int29 = fixedMillisecond25.compareTo((java.lang.Object) 0L);
//        long long30 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getFirstMillisecond(calendar32);
//        java.util.Date date34 = fixedMillisecond31.getTime();
//        java.util.Date date35 = fixedMillisecond31.getTime();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        java.util.Collection collection37 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440072610L + "'", long20 == 1560440072610L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440072611L + "'", long30 == 1560440072611L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560440072612L + "'", long33 == 1560440072612L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(collection37);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2958465, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test374");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        int int45 = fixedMillisecond43.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond44.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond44.getTime();
//        int int49 = year4.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Date date50 = year4.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 1560440015498L);
//        long long53 = year4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440072863L + "'", long2 == 1560440072863L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440072872L + "'", long38 == 1560440072872L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440072872L + "'", long40 == 1560440072872L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440072872L + "'", long41 == 1560440072872L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560440072875L + "'", long47 == 1560440072875L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2019L + "'", long53 == 2019L);
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test375");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries1.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        java.lang.String str9 = day5.toString();
//        org.jfree.data.time.SerialDate serialDate10 = day5.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440073070L + "'", long2 == 1560440073070L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean8 = timeSeries7.getNotify();
        java.lang.Comparable comparable9 = timeSeries7.getKey();
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Object obj11 = timeSeries7.clone();
        boolean boolean12 = spreadsheetDate1.equals(obj11);
        java.util.Date date13 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        int int18 = spreadsheetDate16.getMonth();
        int int19 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        spreadsheetDate1.setDescription("August 0");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        boolean boolean5 = timeSeriesDataItem2.equals((java.lang.Object) 1560440051580L);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate3.equals((java.lang.Object) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.Class<?> wildcardClass21 = serialDate20.getClass();
        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("August 0", (java.lang.Class) wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(inputStream22);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean36 = spreadsheetDate33.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean42 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        int int43 = spreadsheetDate40.getDayOfMonth();
//        int int44 = spreadsheetDate40.toSerial();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean47 = spreadsheetDate40.isOn(serialDate46);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries49.addAndOrUpdate(timeSeries51);
//        boolean boolean53 = spreadsheetDate40.equals((java.lang.Object) timeSeries52);
//        java.lang.Object obj54 = timeSeries52.clone();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day55);
//        int int57 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
//        long long58 = day55.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440073212L + "'", long19 == 1560440073212L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440073213L + "'", long26 == 1560440073213L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 43629L + "'", long58 == 43629L);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        timeSeries3.clear();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean12 = timeSeries11.getNotify();
//        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        int int17 = fixedMillisecond15.compareTo((java.lang.Object) fixedMillisecond16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 9);
//        timeSeries11.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getFirstMillisecond(calendar25);
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        java.lang.Class<?> wildcardClass28 = date27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
//        int int30 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.previous();
//        java.lang.String str34 = year29.toString();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440073491L + "'", long19 == 1560440073491L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440073492L + "'", long26 == 1560440073492L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.toSerial();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        long long8 = day5.getLastMillisecond();
//        long long9 = day5.getFirstMillisecond();
//        long long10 = day5.getMiddleMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day5.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440073655L + "'", long2 == 1560440073655L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test385");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate8.getYYYY();
//        java.lang.String str33 = spreadsheetDate8.toString();
//        int int34 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean40 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean45 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        boolean boolean46 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str49 = spreadsheetDate48.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean52 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        boolean boolean53 = spreadsheetDate37.equals((java.lang.Object) spreadsheetDate48);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate48);
//        java.lang.Class<?> wildcardClass55 = serialDate54.getClass();
//        int int56 = spreadsheetDate8.compare(serialDate54);
//        int int57 = spreadsheetDate8.toSerial();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1-January-1900" + "'", str33.equals("1-January-1900"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNull(str49);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-2199) + "'", int56 == (-2199));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("August 0");
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean3 = timeSeries2.getNotify();
//        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
//        timeSeries2.clear();
//        timeSeries2.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond8);
//        int int11 = fixedMillisecond7.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond7.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) fixedMillisecond14);
//        int int17 = fixedMillisecond13.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        long long19 = timeSeries2.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 43629L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) 1560439979754L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean52 = spreadsheetDate49.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean57 = spreadsheetDate54.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        boolean boolean58 = spreadsheetDate49.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate49);
//        int int60 = spreadsheetDate49.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond61.getFirstMillisecond(calendar62);
//        java.util.Date date64 = fixedMillisecond61.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64);
//        int int67 = day66.getMonth();
//        org.jfree.data.time.SerialDate serialDate68 = day66.getSerialDate();
//        boolean boolean69 = spreadsheetDate49.isOnOrBefore(serialDate68);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean74 = spreadsheetDate71.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
//        int int75 = spreadsheetDate71.getDayOfWeek();
//        java.lang.String str76 = spreadsheetDate71.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str80 = spreadsheetDate79.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean83 = spreadsheetDate79.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate82);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate79);
//        boolean boolean85 = spreadsheetDate71.isAfter(serialDate84);
//        org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate49.getEndOfCurrentMonth(serialDate84);
//        int int87 = fixedMillisecond20.compareTo((java.lang.Object) serialDate86);
//        try {
//            org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9999, serialDate86);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440073902L + "'", long38 == 1560440073902L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440073902L + "'", long40 == 1560440073902L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440073902L + "'", long41 == 1560440073902L);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1900 + "'", int60 == 1900);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560440073907L + "'", long63 == 1560440073907L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 3 + "'", int75 == 3);
//        org.junit.Assert.assertNull(str76);
//        org.junit.Assert.assertNull(str80);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) (byte) 1, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean7 = timeSeries6.getNotify();
        java.lang.Comparable comparable8 = timeSeries6.getKey();
        java.util.Collection collection9 = timeSeries6.getTimePeriods();
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class4, (java.lang.Object) timeSeries6);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class4);
        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean23 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean28 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str32 = spreadsheetDate31.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean35 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate20.equals((java.lang.Object) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.Class<?> wildcardClass38 = serialDate37.getClass();
        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("June", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "ClassContext", "Thu Jun 13 08:33:34 PDT 2019", (java.lang.Class) wildcardClass38);
        java.lang.Object obj41 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June 2019", (java.lang.Class) wildcardClass38);
        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:33:00 PDT 2019", class4, (java.lang.Class) wildcardClass38);
        java.lang.ClassLoader classLoader43 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass38);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 100 + "'", comparable8.equals(100));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNotNull(classLoader12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNull(inputStream39);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(classLoader43);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        boolean boolean7 = year4.equals((java.lang.Object) 1560439992798L);
//        java.lang.String str8 = year4.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            year4.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440074181L + "'", long2 == 1560440074181L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
//        timeSeries1.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        java.lang.Class<?> wildcardClass8 = date7.getClass();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date18, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date7, timeZone21);
//        java.lang.Number number24 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440074193L + "'", long6 == 1560440074193L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440074195L + "'", long17 == 1560440074195L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(number24);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        timeSeries1.clear();
        java.util.List list6 = timeSeries1.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        timeSeries1.setDomainDescription("Nearest");
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str28 = spreadsheetDate27.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean31 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean33 = spreadsheetDate14.isOnOrBefore(serialDate32);
        boolean boolean34 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            timeSeries1.update(regularTimePeriod2, (java.lang.Number) 1560440035796L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test399");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        java.util.Date date18 = day15.getStart();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 1560440025829L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day15.previous();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440074586L + "'", long12 == 1560440074586L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test400");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        long long6 = month5.getFirstMillisecond();
//        int int7 = month5.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440074662L + "'", long2 == 1560440074662L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("9-January-1900");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', (-456));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test404");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
//        java.lang.Class<?> wildcardClass8 = fixedMillisecond1.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440074708L + "'", long4 == 1560440074708L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440074708L + "'", long6 == 1560440074708L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test405");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560439985071L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
//        java.lang.Object obj9 = null;
//        int int10 = timeSeriesDataItem6.compareTo(obj9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440074741L + "'", long2 == 1560440074741L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate7.getDayOfWeek();
        java.lang.String str12 = spreadsheetDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int26 = spreadsheetDate16.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
        boolean boolean33 = fixedMillisecond29.equals((java.lang.Object) false);
        boolean boolean34 = spreadsheetDate28.equals((java.lang.Object) false);
        boolean boolean35 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean37 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 10);
        int int38 = spreadsheetDate14.getYYYY();
        java.lang.String str39 = spreadsheetDate14.toString();
        boolean boolean40 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str44 = spreadsheetDate43.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean47 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean54 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int55 = spreadsheetDate51.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean60 = spreadsheetDate57.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean65 = spreadsheetDate62.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
        boolean boolean66 = spreadsheetDate57.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str69 = spreadsheetDate68.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean72 = spreadsheetDate68.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate71);
        boolean boolean73 = spreadsheetDate57.equals((java.lang.Object) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean78 = spreadsheetDate75.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate77);
        int int79 = spreadsheetDate75.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean82 = timeSeries81.getNotify();
        java.lang.Comparable comparable83 = timeSeries81.getKey();
        java.util.Collection collection84 = timeSeries81.getTimePeriods();
        java.lang.Object obj85 = timeSeries81.clone();
        boolean boolean86 = spreadsheetDate75.equals(obj85);
        boolean boolean87 = spreadsheetDate57.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate89 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int90 = spreadsheetDate89.getYYYY();
        int int91 = spreadsheetDate89.getMonth();
        int int92 = spreadsheetDate89.getDayOfWeek();
        boolean boolean94 = spreadsheetDate51.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate75, (org.jfree.data.time.SerialDate) spreadsheetDate89, (int) (short) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1-January-1900" + "'", str39.equals("1-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + comparable83 + "' != '" + 100 + "'", comparable83.equals(100));
        org.junit.Assert.assertNotNull(collection84);
        org.junit.Assert.assertNotNull(obj85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1900 + "'", int90 == 1900);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 3 + "'", int92 == 3);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test407");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) fixedMillisecond14);
//        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) false);
//        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.addAndOrUpdate(timeSeries22);
//        boolean boolean24 = spreadsheetDate12.equals((java.lang.Object) timeSeries20);
//        int int25 = day5.compareTo((java.lang.Object) timeSeries20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day5.next();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean29 = timeSeries28.getNotify();
//        java.lang.Class class30 = timeSeries28.getTimePeriodClass();
//        timeSeries28.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        int int34 = fixedMillisecond32.compareTo((java.lang.Object) fixedMillisecond33);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond33.getFirstMillisecond(calendar35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 9);
//        java.util.Date date39 = fixedMillisecond33.getTime();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.next();
//        int int43 = day5.compareTo((java.lang.Object) month41);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440075735L + "'", long2 == 1560440075735L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440075741L + "'", long36 == 1560440075741L);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate7.getDayOfWeek();
        java.lang.String str12 = spreadsheetDate7.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int26 = spreadsheetDate16.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
        boolean boolean33 = fixedMillisecond29.equals((java.lang.Object) false);
        boolean boolean34 = spreadsheetDate28.equals((java.lang.Object) false);
        boolean boolean35 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean37 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 10);
        int int38 = spreadsheetDate14.getYYYY();
        java.lang.String str39 = spreadsheetDate14.toString();
        boolean boolean40 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str44 = spreadsheetDate43.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean47 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean54 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int57 = spreadsheetDate56.getYYYY();
        int int58 = spreadsheetDate56.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str61 = spreadsheetDate60.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean64 = spreadsheetDate60.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str67 = spreadsheetDate66.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean70 = spreadsheetDate66.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate69);
        boolean boolean71 = spreadsheetDate63.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SerialDate serialDate72 = spreadsheetDate56.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean79 = spreadsheetDate51.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate69, (org.jfree.data.time.SerialDate) spreadsheetDate75, 2147483647);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1-January-1900" + "'", str39.equals("1-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1900 + "'", int57 == 1900);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }
}

