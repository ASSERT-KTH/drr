import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            java.lang.Number number3 = timeSeries1.getValue(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', (int) 'a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem(regularTimePeriod4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', (int) (short) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oct" + "'", str2.equals("Oct"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        try {
            java.lang.Number number3 = timeSeries1.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ThreadContext");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries1.add(timeSeriesDataItem3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Oct");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        try {
            java.lang.Number number5 = timeSeries1.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Comparable comparable3 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        long long6 = fixedMillisecond4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439979860L + "'", long6 == 1560439979860L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(3, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        try {
            timeSeries1.delete(2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        int int4 = fixedMillisecond2.compareTo((java.lang.Object) fixedMillisecond3);
        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) false);
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) false);
        org.jfree.data.time.SerialDate serialDate8 = null;
        try {
            boolean boolean9 = spreadsheetDate1.isOnOrBefore(serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439980532L + "'", long2 == 1560439980532L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            timeSeries1.add(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        int int4 = fixedMillisecond2.compareTo((java.lang.Object) fixedMillisecond3);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 5, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 100, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439980774L + "'", long5 == 1560439980774L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6, 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(timeSeries4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439981344L + "'", long2 == 1560439981344L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        java.lang.Comparable comparable10 = timeSeries1.getKey();
        boolean boolean11 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100 + "'", comparable10.equals(100));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        java.lang.String str7 = spreadsheetDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ERROR : Relative To String");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day5.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439983299L + "'", long2 == 1560439983299L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 1.0d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439983669L + "'", long2 == 1560439983669L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Value");
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3, (int) (byte) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond8);
        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        java.lang.String str15 = timeSeries13.getRangeDescription();
        int int16 = fixedMillisecond7.compareTo((java.lang.Object) str15);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (short) 1);
        try {
            timeSeries1.add(timeSeriesDataItem24);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int2 = timeSeries1.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
//        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond8);
//        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        java.lang.String str15 = timeSeries13.getRangeDescription();
//        int int16 = fixedMillisecond7.compareTo((java.lang.Object) str15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond7.getMiddleMillisecond(calendar17);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 3);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560439983845L + "'", long18 == 1560439983845L);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.clear();
        timeSeries1.setMaximumItemCount(8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Oct");
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439984118L + "'", long4 == 1560439984118L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439984118L + "'", long6 == 1560439984118L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560439984118L + "'", long9 == 1560439984118L);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        try {
            java.lang.Number number4 = timeSeries1.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        timeSeries1.setDescription("Oct");
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            day5.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439985159L + "'", long2 == 1560439985159L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 1, (int) (byte) 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("ThreadContext");
        java.util.List list12 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        int int15 = fixedMillisecond13.compareTo((java.lang.Object) fixedMillisecond14);
        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        java.lang.String str21 = timeSeries19.getRangeDescription();
        int int22 = fixedMillisecond13.compareTo((java.lang.Object) str21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond13, class26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 1);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            day5.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439985897L + "'", long2 == 1560439985897L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean3 = timeSeries2.getNotify();
        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: hi!", class4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(obj5);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        long long7 = day5.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day5.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439985979L + "'", long2 == 1560439985979L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439986000L + "'", long2 == 1560439986000L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Comparable comparable3 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560439986024L + "'", long8 == 1560439986024L);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        java.util.Calendar calendar6 = null;
//        try {
//            day5.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439986048L + "'", long2 == 1560439986048L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        timeSeries1.removeAgedItems(1L, true);
        boolean boolean9 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean5 = timeSeries4.getNotify();
        java.lang.Comparable comparable6 = timeSeries4.getKey();
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class2, (java.lang.Object) timeSeries4);
        try {
            timeSeries4.delete(7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 100 + "'", comparable6.equals(100));
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, (int) 'a', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond12.next();
        try {
            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560439979754L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate13);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate13.getNearestDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond10.getFirstMillisecond(calendar12);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) '#', false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560439988024L + "'", long13 == 1560439988024L);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Calendar calendar8 = null;
//        try {
//            day5.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439988104L + "'", long2 == 1560439988104L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 1, (java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list7 = timeSeries6.getItems();
//        timeSeries6.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        int int12 = fixedMillisecond10.compareTo((java.lang.Object) fixedMillisecond11);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        boolean boolean14 = timeSeries6.isEmpty();
//        int int15 = year4.compareTo((java.lang.Object) boolean14);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439988772L + "'", long2 == 1560439988772L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        try {
            java.lang.Number number6 = timeSeries1.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(13, 100, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        boolean boolean3 = timeSeries1.isEmpty();
//        boolean boolean4 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
//        long long9 = fixedMillisecond6.getSerialIndex();
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560439989990L + "'", long9 == 1560439989990L);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Monday" + "'", str1.equals("Monday"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        try {
            java.lang.Number number10 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        try {
            timeSeries1.delete((int) ' ', (-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 6);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list4 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond8);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        boolean boolean11 = timeSeries3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries15);
        boolean boolean17 = fixedMillisecond1.equals((java.lang.Object) timeSeries16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries16.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.lang.String str4 = timeSeries2.getRangeDescription();
        java.lang.Class class5 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("Oct", class5);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2147483647);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond2);
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getRangeDescription();
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) str9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class14);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(inputStream17);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day5.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439991186L + "'", long2 == 1560439991186L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        boolean boolean3 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 10);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439991554L + "'", long6 == 1560439991554L);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate8.getYYYY();
//        try {
//            java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) int32);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int21 = spreadsheetDate11.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) fixedMillisecond25);
        boolean boolean28 = fixedMillisecond24.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) false);
        boolean boolean30 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11, 10);
        int int33 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(8, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate9.getFollowingDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertNotNull(serialDate34);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439991971L + "'", long2 == 1560439991971L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439991971L + "'", long6 == 1560439991971L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oct" + "'", str0.equals("Oct"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge(1560439989758L);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(13, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.addAndOrUpdate(timeSeries12);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.addChangeListener(seriesChangeListener14);
//        timeSeries12.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int19 = timeSeries18.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries18);
//        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        java.util.Collection collection22 = org.jfree.chart.util.ObjectUtilities.deepClone(collection21);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertNotNull(collection22);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        long long7 = year4.getLastMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            year4.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439993145L + "'", long2 == 1560439993145L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1-January-1900");
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1560439982382L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setDomainDescription("ThreadContext");
//        java.util.List list12 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
//        int int17 = timeSeries1.getIndex(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560439994048L + "'", long15 == 1560439994048L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate8.getDayOfMonth();
        int int12 = spreadsheetDate8.toSerial();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate14.getFollowingDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean16 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate19.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean26 = timeSeries25.getNotify();
        java.lang.Comparable comparable27 = timeSeries25.getKey();
        java.util.Collection collection28 = timeSeries25.getTimePeriods();
        java.lang.Object obj29 = timeSeries25.clone();
        boolean boolean30 = spreadsheetDate19.equals(obj29);
        boolean boolean31 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.util.Date date32 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
        boolean boolean19 = spreadsheetDate13.equals((java.lang.Object) false);
        boolean boolean20 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        try {
            int int22 = spreadsheetDate13.compareTo((java.lang.Object) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June" + "'", str1.equals("June"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9999, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.String str17 = timeSeries15.getRangeDescription();
//        int int18 = fixedMillisecond9.compareTo((java.lang.Object) str17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond9.getMiddleMillisecond(calendar19);
//        boolean boolean22 = fixedMillisecond9.equals((java.lang.Object) 1560439986416L);
//        int int23 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 9223372036854775807L);
//        try {
//            timeSeries3.add(timeSeriesDataItem26, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439995464L + "'", long20 == 1560439995464L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getYearValue();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 1560439991051L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        long long34 = day33.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2L + "'", long34 == 2L);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560439985071L);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean9 = timeSeries8.getNotify();
//        java.lang.Class class10 = timeSeries8.getTimePeriodClass();
//        int int11 = timeSeriesDataItem6.compareTo((java.lang.Object) class10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439996283L + "'", long2 == 1560439996283L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int13 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        boolean boolean22 = spreadsheetDate2.isOnOrBefore(serialDate21);
//        java.lang.String str23 = serialDate21.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560439997135L + "'", long16 == 1560439997135L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNull(str23);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = year4.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439997220L + "'", long2 == 1560439997220L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Comparable comparable3 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        java.lang.String str14 = timeSeries12.getRangeDescription();
//        int int15 = fixedMillisecond6.compareTo((java.lang.Object) str14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond6.getMiddleMillisecond(calendar16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        long long19 = fixedMillisecond6.getMiddleMillisecond();
//        int int21 = fixedMillisecond6.compareTo((java.lang.Object) 1560439980698L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560439997290L + "'", long17 == 1560439997290L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560439997290L + "'", long19 == 1560439997290L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        try {
//            timeSeries1.update((int) ' ', (java.lang.Number) (-435));
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560439997346L + "'", long9 == 1560439997346L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560439997373L + "'", long16 == 1560439997373L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1) + "'", obj2.equals((-1)));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate4.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean34 = timeSeries33.getNotify();
//        java.lang.Class class35 = timeSeries33.getTimePeriodClass();
//        timeSeries33.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        int int39 = fixedMillisecond37.compareTo((java.lang.Object) fixedMillisecond38);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond38.getFirstMillisecond(calendar40);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 9);
//        timeSeries33.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list48 = timeSeries47.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries47.removePropertyChangeListener(propertyChangeListener49);
//        java.util.Collection collection51 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries47);
//        java.lang.Class class52 = timeSeries47.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, class52);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560439997427L + "'", long41 == 1560439997427L);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNotNull(list48);
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(class52);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries1.add(regularTimePeriod10, (java.lang.Number) 1559372400000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list16 = timeSeries15.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries15.getTimePeriod(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560439997801L + "'", long9 == 1560439997801L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(collection19);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        int int11 = fixedMillisecond0.compareTo((java.lang.Object) ' ');
//        long long12 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560439998055L + "'", long12 == 1560439998055L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Thu Jun 13 08:33:00 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        boolean boolean3 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439998297L + "'", long6 == 1560439998297L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int21 = spreadsheetDate18.getDayOfMonth();
//        int int22 = spreadsheetDate18.toSerial();
//        boolean boolean23 = day5.equals((java.lang.Object) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str26 = spreadsheetDate25.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean29 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        int int35 = spreadsheetDate31.getDayOfWeek();
//        java.lang.String str36 = spreadsheetDate31.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean43 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean48 = spreadsheetDate45.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        boolean boolean49 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        int int50 = spreadsheetDate40.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        int int55 = fixedMillisecond53.compareTo((java.lang.Object) fixedMillisecond54);
//        boolean boolean57 = fixedMillisecond53.equals((java.lang.Object) false);
//        boolean boolean58 = spreadsheetDate52.equals((java.lang.Object) false);
//        boolean boolean59 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
//        boolean boolean61 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate40, 10);
//        int int62 = spreadsheetDate38.getYYYY();
//        java.lang.String str63 = spreadsheetDate38.toString();
//        boolean boolean64 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean65 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate18.getPreviousDayOfWeek((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560439998727L + "'", long2 == 1560439998727L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1900 + "'", int62 == 1900);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1-January-1900" + "'", str63.equals("1-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertNotNull(serialDate67);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        timeSeries1.fireSeriesChanged();
        java.lang.String str8 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries(comparable0, "Oct", "9-January-1900", class5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("October");
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        long long3 = month0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries13);
        try {
            java.lang.Number number16 = timeSeries1.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class3);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(uRL4);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timeSeries1.equals(obj4);
//        timeSeries1.removeAgedItems(1L, true);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 9223372036854775807L);
//        int int12 = month9.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month9.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate(regularTimePeriod13, (java.lang.Number) 1560439985071L);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 1560439997818L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439999793L + "'", long20 == 1560439999793L);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
        org.junit.Assert.assertNull(timeSeriesDataItem5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        try {
            java.lang.Number number7 = timeSeries1.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
        org.junit.Assert.assertNull(timeSeriesDataItem5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        timeSeries1.setMaximumItemAge(43629L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = year13.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560439999935L + "'", long9 == 1560439999935L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.List list4 = timeSeries1.getItems();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(list4);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getLastMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440000291L + "'", long6 == 1560440000291L);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setDomainDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        java.lang.Class<?> wildcardClass16 = date15.getClass();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year17);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = year17.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440000338L + "'", long14 == 1560440000338L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader3);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertNotNull(classLoader3);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        boolean boolean3 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        long long11 = day9.getMiddleMillisecond();
//        long long12 = day9.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440000601L + "'", long6 == 1560440000601L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setDomainDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        java.lang.Class<?> wildcardClass16 = date15.getClass();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year17);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.addAndOrUpdate(timeSeries23);
//        int int25 = timeSeries23.getItemCount();
//        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries23.getTimePeriod(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440000646L + "'", long14 == 1560440000646L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(collection26);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str9 = timePeriodFormatException8.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str11 = timePeriodFormatException8.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        boolean boolean3 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day9);
//        long long11 = day9.getMiddleMillisecond();
//        long long12 = day9.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440001223L + "'", long6 == 1560440001223L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560452399999L + "'", long11 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
        int int10 = fixedMillisecond6.compareTo((java.lang.Object) 0L);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list8 = timeSeries7.getItems();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        int int13 = fixedMillisecond11.compareTo((java.lang.Object) fixedMillisecond12);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560439995667L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj10 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int10 = timeSeries9.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries9);
        int int12 = timeSeries9.getMaximumItemCount();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        int int5 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.next();
//        int int11 = day5.getYear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440001938L + "'", long2 == 1560440001938L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) false);
//        java.lang.Number number11 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        long long12 = fixedMillisecond6.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440001981L + "'", long12 == 1560440001981L);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        boolean boolean3 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        int int6 = fixedMillisecond4.compareTo((java.lang.Object) fixedMillisecond5);
//        int int8 = fixedMillisecond4.compareTo((java.lang.Object) 0L);
//        long long9 = fixedMillisecond4.getMiddleMillisecond();
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond4.peg(calendar10);
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560439983263L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440002029L + "'", long9 == 1560440002029L);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year4.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440002044L + "'", long2 == 1560440002044L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.TimeZone timeZone5 = null;
//        try {
//            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440002109L + "'", long2 == 1560440002109L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Comparable comparable3 = timeSeries1.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        java.lang.String str14 = timeSeries12.getRangeDescription();
//        int int15 = fixedMillisecond6.compareTo((java.lang.Object) str14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond6.getMiddleMillisecond(calendar16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        long long19 = fixedMillisecond6.getMiddleMillisecond();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond6.getFirstMillisecond(calendar20);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440002136L + "'", long17 == 1560440002136L);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440002136L + "'", long19 == 1560440002136L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440002136L + "'", long21 == 1560440002136L);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        timeSeries1.removeAgedItems(1L, true);
        boolean boolean9 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 9223372036854775807L);
        try {
            timeSeries3.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        try {
            org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate8.getFollowingDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
        boolean boolean16 = fixedMillisecond12.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        java.lang.String str20 = timeSeries18.getRangeDescription();
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) str20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        boolean boolean26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond12, class25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        int int32 = fixedMillisecond30.compareTo((java.lang.Object) fixedMillisecond31);
        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
        java.lang.String str38 = timeSeries36.getRangeDescription();
        int int39 = fixedMillisecond30.compareTo((java.lang.Object) str38);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class43);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond30, class43);
        int int46 = timeSeriesDataItem29.compareTo((java.lang.Object) timeSeries45);
        try {
            timeSeries1.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        timeSeries1.clear();
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        java.lang.Comparable comparable10 = timeSeries1.getKey();
        java.util.List list11 = timeSeries1.getItems();
        try {
            java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) list11);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100 + "'", comparable10.equals(100));
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year4.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440003342L + "'", long2 == 1560440003342L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
//        long long12 = month11.getFirstMillisecond();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560439992509L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440003405L + "'", long8 == 1560440003405L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1559372400000L + "'", long12 == 1559372400000L);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440003546L + "'", long2 == 1560440003546L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.String str9 = timeSeries8.getDomainDescription();
        timeSeries8.setRangeDescription("October");
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Wednesday" + "'", str1.equals("Wednesday"));
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setRangeDescription("Thu Jun 13 08:33:00 PDT 2019");
//        timeSeries1.setRangeDescription("9-January-1900");
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        boolean boolean6 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1560439999379L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month2);
        try {
            timeSeries1.update((int) (byte) 100, (java.lang.Number) 1560440002058L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list18 = timeSeries17.getItems();
        timeSeries17.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) fixedMillisecond22);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        boolean boolean25 = timeSeries17.isEmpty();
        timeSeries17.setDomainDescription("ThreadContext");
        java.util.List list28 = timeSeries17.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.addAndOrUpdate(timeSeries17);
        timeSeries15.removeAgedItems((long) 2, false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries15.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.lang.String str6 = timeSeries1.getRangeDescription();
        try {
            java.lang.Number number8 = timeSeries1.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.addChangeListener(seriesChangeListener14);
        timeSeries12.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int19 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.lang.String str22 = timeSeries18.getDescription();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        int int6 = spreadsheetDate2.getDayOfWeek();
//        java.lang.String str7 = spreadsheetDate2.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int21 = spreadsheetDate11.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        int int26 = fixedMillisecond24.compareTo((java.lang.Object) fixedMillisecond25);
//        boolean boolean28 = fixedMillisecond24.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) false);
//        boolean boolean30 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11, 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond33.getTime();
//        java.lang.Class<?> wildcardClass37 = date36.getClass();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date36);
//        boolean boolean39 = spreadsheetDate9.isOnOrBefore(serialDate38);
//        try {
//            org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', serialDate38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440006318L + "'", long35 == 1560440006318L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean5 = timeSeries4.getNotify();
        java.lang.Comparable comparable6 = timeSeries4.getKey();
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class2, (java.lang.Object) timeSeries4);
        java.lang.ClassLoader classLoader9 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader9);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 100 + "'", comparable6.equals(100));
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(classLoader9);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.clear();
        java.lang.String str3 = timeSeries1.getDescription();
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 10 + "'", comparable4.equals((short) 10));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1900, (int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) fixedMillisecond8);
//        boolean boolean11 = fixedMillisecond7.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        java.lang.String str15 = timeSeries13.getRangeDescription();
//        int int16 = fixedMillisecond7.compareTo((java.lang.Object) str15);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
//        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class20);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, class20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = fixedMillisecond25.compareTo((java.lang.Object) fixedMillisecond26);
//        boolean boolean29 = fixedMillisecond25.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
//        java.lang.String str33 = timeSeries31.getRangeDescription();
//        int int34 = fixedMillisecond25.compareTo((java.lang.Object) str33);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
//        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25, class38);
//        int int41 = timeSeriesDataItem24.compareTo((java.lang.Object) timeSeries40);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
//        java.lang.Object obj44 = seriesChangeEvent43.getSource();
//        boolean boolean45 = timeSeriesDataItem24.equals(obj44);
//        int int46 = day5.compareTo((java.lang.Object) boolean45);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440006783L + "'", long2 == 1560440006783L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + obj44 + "' != '" + (-1) + "'", obj44.equals((-1)));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate13);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate13.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        long long6 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.next();
//        java.util.Calendar calendar11 = null;
//        try {
//            day5.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440007274L + "'", long2 == 1560440007274L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener7);
        timeSeries3.setDomainDescription("ClassContext");
        org.junit.Assert.assertNotNull(timeSeries4);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        long long7 = day5.getSerialIndex();
//        java.lang.String str8 = day5.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440007611L + "'", long2 == 1560440007611L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "9-January-1900");
        boolean boolean3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries1, (java.lang.Object) "9-January-1900");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener10);
//        timeSeries1.setMaximumItemAge(43629L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560439985071L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem20.getPeriod();
//        try {
//            timeSeries1.add(timeSeriesDataItem20, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440007656L + "'", long16 == 1560440007656L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440007671L + "'", long2 == 1560440007671L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        boolean boolean3 = timeSeries1.isEmpty();
//        boolean boolean4 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int16 = spreadsheetDate12.getDayOfWeek();
//        java.lang.String str17 = spreadsheetDate12.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean24 = spreadsheetDate21.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean29 = spreadsheetDate26.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        boolean boolean30 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        int int31 = spreadsheetDate21.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        int int36 = fixedMillisecond34.compareTo((java.lang.Object) fixedMillisecond35);
//        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) false);
//        boolean boolean39 = spreadsheetDate33.equals((java.lang.Object) false);
//        boolean boolean40 = spreadsheetDate21.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        boolean boolean42 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21, 10);
//        boolean boolean44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) spreadsheetDate19, (java.lang.Object) 1560439995821L);
//        timeSeries1.setKey((java.lang.Comparable) boolean44);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        int int18 = fixedMillisecond14.compareTo((java.lang.Object) 0L);
//        long long19 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getTime();
//        java.util.Date date24 = fixedMillisecond20.getTime();
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        try {
//            timeSeries1.delete(6, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440008495L + "'", long9 == 1560440008495L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440008496L + "'", long19 == 1560440008496L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440008498L + "'", long22 == 1560440008498L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeSeries25);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        long long11 = timeSeries3.getMaximumItemAge();
        java.util.List list12 = timeSeries3.getItems();
        try {
            java.util.Collection collection13 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list12);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list12);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.String str17 = timeSeries15.getRangeDescription();
//        int int18 = fixedMillisecond9.compareTo((java.lang.Object) str17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond9.getMiddleMillisecond(calendar19);
//        boolean boolean22 = fixedMillisecond9.equals((java.lang.Object) 1560439986416L);
//        int int23 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        long long24 = fixedMillisecond9.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440008710L + "'", long20 == 1560440008710L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440008710L + "'", long24 == 1560440008710L);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        java.util.Calendar calendar43 = null;
//        try {
//            long long44 = year4.getFirstMillisecond(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440008951L + "'", long2 == 1560440008951L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440008954L + "'", long38 == 1560440008954L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440008954L + "'", long40 == 1560440008954L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440008954L + "'", long41 == 1560440008954L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June");
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str9 = timePeriodFormatException8.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str11 = timePeriodFormatException4.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries1.removeAgedItems(1560440001981L, false);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener24);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440009140L + "'", long9 == 1560440009140L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440009141L + "'", long16 == 1560440009141L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean10 = timeSeries9.getNotify();
//        java.lang.Class class11 = timeSeries9.getTimePeriodClass();
//        timeSeries9.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) fixedMillisecond14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond14.getFirstMillisecond(calendar16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 9);
//        java.util.Date date20 = fixedMillisecond14.getTime();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20, timeZone21);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month22, (double) 1560440007309L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440009250L + "'", long17 == 1560440009250L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int23 = spreadsheetDate13.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        int int28 = fixedMillisecond26.compareTo((java.lang.Object) fixedMillisecond27);
        boolean boolean30 = fixedMillisecond26.equals((java.lang.Object) false);
        boolean boolean31 = spreadsheetDate25.equals((java.lang.Object) false);
        boolean boolean32 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean33 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int34 = spreadsheetDate13.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate13.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        java.lang.Class<?> wildcardClass5 = date4.getClass();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9, serialDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440009352L + "'", long3 == 1560440009352L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        try {
            java.lang.Number number5 = timeSeries1.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        long long11 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        timeSeries13.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9);
//        java.util.Date date24 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
//        int int27 = month26.getYearValue();
//        java.lang.Number number28 = null;
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month26, number28);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440009994L + "'", long21 == 1560440009994L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        boolean boolean14 = timeSeries1.isEmpty();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440010016L + "'", long9 == 1560440010016L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June");
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SerialDate.weekInMonthToString(): invalid code.", class4);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(inputStream5);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getMiddleMillisecond(calendar8);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getLastMillisecond(calendar10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440010121L + "'", long2 == 1560440010121L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440010121L + "'", long9 == 1560440010121L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440010121L + "'", long11 == 1560440010121L);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 8, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Oct");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries1.clear();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1560439985071L);
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1560452399999L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertNotNull(timeSeries8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440010580L + "'", long11 == 1560440010580L);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean13 = timeSeries12.getNotify();
        java.lang.Class class14 = timeSeries12.getTimePeriodClass();
        timeSeries12.clear();
        timeSeries12.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
        int int21 = fixedMillisecond17.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond17.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        int int27 = fixedMillisecond23.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day5.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440010740L + "'", long2 == 1560440010740L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ERROR : Relative To String");
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Date date8 = fixedMillisecond6.getStart();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day9.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440010790L + "'", long2 == 1560440010790L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
        boolean boolean19 = spreadsheetDate13.equals((java.lang.Object) false);
        boolean boolean20 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        try {
            org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate1.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        java.util.Calendar calendar21 = null;
//        try {
//            year19.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440010840L + "'", long9 == 1560440010840L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440010841L + "'", long16 == 1560440010841L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) fixedMillisecond14);
//        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) false);
//        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.addAndOrUpdate(timeSeries22);
//        boolean boolean24 = spreadsheetDate12.equals((java.lang.Object) timeSeries20);
//        int int25 = day5.compareTo((java.lang.Object) timeSeries20);
//        org.jfree.data.time.SerialDate serialDate26 = day5.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440011168L + "'", long2 == 1560440011168L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(serialDate26);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.String str4 = timePeriodFormatException3.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond10.getTime();
//        java.lang.Class<?> wildcardClass14 = date13.getClass();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod16, (double) 9999);
//        int int19 = fixedMillisecond6.compareTo((java.lang.Object) timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440011402L + "'", long2 == 1560440011402L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440011402L + "'", long9 == 1560440011402L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440011406L + "'", long12 == 1560440011406L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int34 = day33.getYear();
        java.util.Date date35 = day33.getStart();
        java.lang.String str36 = day33.toString();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = day33.getLastMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1-January-1900" + "'", str36.equals("1-January-1900"));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int11 = spreadsheetDate8.getDayOfMonth();
//        int int12 = spreadsheetDate8.toSerial();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.addAndOrUpdate(timeSeries19);
//        boolean boolean21 = spreadsheetDate8.equals((java.lang.Object) timeSeries20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.addOrUpdate(regularTimePeriod25, (double) 5);
//        long long28 = regularTimePeriod25.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560440011572L + "'", long24 == 1560440011572L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560440011573L + "'", long28 == 1560440011573L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2019, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy(2019, 8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440011692L + "'", long9 == 1560440011692L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Oct", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean8 = timeSeries7.getNotify();
        java.lang.Comparable comparable9 = timeSeries7.getKey();
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Object obj11 = timeSeries7.clone();
        boolean boolean12 = spreadsheetDate1.equals(obj11);
        java.util.Date date13 = spreadsheetDate1.toDate();
        java.util.Date date14 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 100 + "'", comparable9.equals(100));
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month2);
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean17 = timeSeries16.getNotify();
//        java.lang.Comparable comparable18 = timeSeries16.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        long long21 = fixedMillisecond19.getFirstMillisecond();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 1560439986109L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440012568L + "'", long9 == 1560440012568L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 100 + "'", comparable18.equals(100));
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440012570L + "'", long21 == 1560440012570L);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int17 = spreadsheetDate7.getMonth();
        boolean boolean18 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str21 = spreadsheetDate20.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean24 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean27 = spreadsheetDate20.isOnOrBefore(serialDate26);
        int int28 = spreadsheetDate20.getDayOfWeek();
        boolean boolean29 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 9223372036854775807L);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month5, (double) 1560439986109L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        boolean boolean9 = timeSeries1.equals((java.lang.Object) 1560439995821L);
        java.lang.String str10 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 1.0f + "'", comparable7.equals(1.0f));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
//        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.lang.String str26 = timeSeries24.getRangeDescription();
//        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
//        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeriesDataItem17.getPeriod();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Date date11 = fixedMillisecond9.getStart();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        timeSeries13.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9);
//        java.util.Date date24 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
//        java.util.Calendar calendar28 = null;
//        try {
//            year27.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440013469L + "'", long21 == 1560440013469L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = year19.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440013538L + "'", long9 == 1560440013538L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440013541L + "'", long16 == 1560440013541L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timeSeries1.equals(obj4);
//        timeSeries1.removeAgedItems(1L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1560439985071L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem15.getPeriod();
//        try {
//            timeSeries1.add(timeSeriesDataItem15, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440013576L + "'", long11 == 1560440013576L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440013626L + "'", long2 == 1560440013626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        java.util.Date date5 = fixedMillisecond0.getTime();
        java.util.Date date6 = fixedMillisecond0.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        timeSeries1.setMaximumItemAge(43629L);
        java.lang.Object obj14 = timeSeries1.clone();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        java.lang.Object obj2 = timeSeries1.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        long long8 = year7.getFirstMillisecond();
//        long long9 = year7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440013710L + "'", long5 == 1560440013710L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str9 = timePeriodFormatException8.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        java.lang.Comparable comparable10 = timeSeries1.getKey();
        java.util.List list11 = timeSeries1.getItems();
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        int int14 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 100 + "'", comparable10.equals(100));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean5 = timeSeries4.getNotify();
//        java.lang.Comparable comparable6 = timeSeries4.getKey();
//        java.util.Collection collection7 = timeSeries4.getTimePeriods();
//        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) class2, (java.lang.Object) timeSeries4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        int int11 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond10);
//        int int13 = fixedMillisecond9.compareTo((java.lang.Object) 0L);
//        long long14 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-460));
//        timeSeries4.removeAgedItems(1560440001223L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        int int24 = fixedMillisecond20.compareTo((java.lang.Object) 0L);
//        java.util.Date date25 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 100 + "'", comparable6.equals(100));
//        org.junit.Assert.assertNotNull(collection7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440014114L + "'", long14 == 1560440014114L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int3 = spreadsheetDate2.getYYYY();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str7 = spreadsheetDate6.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str13 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean16 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate9.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.lang.String str3 = fixedMillisecond0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440014221L + "'", long2 == 1560440014221L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:33:34 PDT 2019" + "'", str3.equals("Thu Jun 13 08:33:34 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
//        int int3 = month0.getMonth();
//        java.util.Date date4 = month0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        boolean boolean9 = fixedMillisecond5.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        java.lang.String str13 = timeSeries11.getRangeDescription();
//        int int14 = fixedMillisecond5.compareTo((java.lang.Object) str13);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, class18);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list23 = timeSeries22.getItems();
//        timeSeries22.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        int int28 = fixedMillisecond26.compareTo((java.lang.Object) fixedMillisecond27);
//        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        boolean boolean30 = timeSeries22.isEmpty();
//        timeSeries22.setDomainDescription("ThreadContext");
//        java.util.List list33 = timeSeries22.getItems();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries20.addAndOrUpdate(timeSeries22);
//        int int35 = month0.compareTo((java.lang.Object) timeSeries22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) fixedMillisecond37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        java.lang.String str44 = timeSeries42.getRangeDescription();
//        int int45 = fixedMillisecond36.compareTo((java.lang.Object) str44);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
//        boolean boolean50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class49);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond36, class49);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (short) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean58 = spreadsheetDate55.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        int int59 = spreadsheetDate55.getDayOfWeek();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean62 = timeSeries61.getNotify();
//        java.lang.Comparable comparable63 = timeSeries61.getKey();
//        java.util.Collection collection64 = timeSeries61.getTimePeriods();
//        java.lang.Object obj65 = timeSeries61.clone();
//        boolean boolean66 = spreadsheetDate55.equals(obj65);
//        boolean boolean67 = timeSeriesDataItem53.equals((java.lang.Object) spreadsheetDate55);
//        try {
//            timeSeries22.add(timeSeriesDataItem53, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(list33);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Value" + "'", str44.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + comparable63 + "' != '" + 100 + "'", comparable63.equals(100));
//        org.junit.Assert.assertNotNull(collection64);
//        org.junit.Assert.assertNotNull(obj65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        int int45 = fixedMillisecond43.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond44.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond44.getTime();
//        int int49 = year4.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Date date50 = year4.getEnd();
//        long long51 = year4.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440014507L + "'", long2 == 1560440014507L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440014509L + "'", long38 == 1560440014509L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440014509L + "'", long40 == 1560440014509L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440014509L + "'", long41 == 1560440014509L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560440014520L + "'", long47 == 1560440014520L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1562097599999L + "'", long51 == 1562097599999L);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        int int4 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Monday");
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        int int2 = timeSeries1.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
//        timeSeries1.removeAgedItems(0L, false);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getStart();
//        java.lang.String str10 = month8.toString();
//        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
//        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16);
//        int int19 = day18.getMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day18.getSerialDate();
//        long long21 = day18.getFirstMillisecond();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 1560439979421L, true);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440014895L + "'", long15 == 1560440014895L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        int int4 = fixedMillisecond2.compareTo((java.lang.Object) fixedMillisecond3);
//        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) false);
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.addAndOrUpdate(timeSeries11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries11.addChangeListener(seriesChangeListener13);
//        timeSeries11.fireSeriesChanged();
//        long long16 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        java.util.Date date19 = fixedMillisecond17.getStart();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean22 = timeSeries21.getNotify();
//        java.lang.Class class23 = timeSeries21.getTimePeriodClass();
//        timeSeries21.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = fixedMillisecond25.compareTo((java.lang.Object) fixedMillisecond26);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond26.getFirstMillisecond(calendar28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 9);
//        java.util.Date date32 = fixedMillisecond26.getTime();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date19, timeZone33);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) spreadsheetDate1, (java.lang.Object) date19);
//        try {
//            org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate1.getFollowingDayOfWeek((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560440015300L + "'", long29 == 1560440015300L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        java.lang.String str4 = month0.toString();
        int int6 = month0.compareTo((java.lang.Object) 1560439997427L);
        java.util.Calendar calendar7 = null;
        try {
            month0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        long long6 = day5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
//        int int8 = day5.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440015388L + "'", long2 == 1560440015388L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17);
//        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
//        timeSeries1.removeAgedItems(1560440001981L, false);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy(8, 9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440015412L + "'", long9 == 1560440015412L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560440015422L + "'", long16 == 1560440015422L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 5, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Thu Jun 13 08:33:34 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440015498L + "'", long2 == 1560440015498L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440015498L + "'", long5 == 1560440015498L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440015498L + "'", long7 == 1560440015498L);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        timeSeries1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean8 = spreadsheetDate1.isOnOrBefore(serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getFollowingDayOfWeek(7);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        long long7 = day5.getSerialIndex();
//        int int9 = day5.compareTo((java.lang.Object) 1560439990355L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440015773L + "'", long2 == 1560440015773L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        boolean boolean3 = timeSeries1.isEmpty();
        boolean boolean4 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        boolean boolean8 = timeSeries1.equals((java.lang.Object) fixedMillisecond6);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        java.lang.Class<?> wildcardClass10 = timeSeries1.getClass();
        try {
            java.lang.Number number12 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440015844L + "'", long7 == 1560440015844L);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        java.util.Date date3 = month2.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
//        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean8 = timeSeries7.getNotify();
//        java.lang.Class class9 = timeSeries7.getTimePeriodClass();
//        timeSeries7.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        int int13 = fixedMillisecond11.compareTo((java.lang.Object) fixedMillisecond12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 9);
//        java.util.Date date18 = fixedMillisecond12.getTime();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNull(number5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560440015887L + "'", long15 == 1560440015887L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            int int10 = timeSeries1.getIndex(regularTimePeriod9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
//        boolean boolean7 = year4.equals((java.lang.Object) 1560439992798L);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year4.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440016146L + "'", long2 == 1560440016146L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
//        boolean boolean16 = fixedMillisecond12.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
//        java.lang.String str20 = timeSeries18.getRangeDescription();
//        int int21 = fixedMillisecond12.compareTo((java.lang.Object) str20);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond12.getMiddleMillisecond(calendar22);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440016159L + "'", long9 == 1560440016159L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440016160L + "'", long23 == 1560440016160L);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        long long7 = day5.getFirstMillisecond();
//        java.lang.String str8 = day5.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440016201L + "'", long2 == 1560440016201L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        int int10 = fixedMillisecond6.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
//        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.util.Date date18 = fixedMillisecond12.getTime();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        java.lang.String str32 = spreadsheetDate1.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate1.getPreviousDayOfWeek(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "9-January-1900" + "'", str32.equals("9-January-1900"));
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        java.util.Calendar calendar15 = null;
//        try {
//            month14.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440016549L + "'", long9 == 1560440016549L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str7 = spreadsheetDate6.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        timeSeries1.clear();
//        java.util.List list6 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond7.getTime();
//        java.util.Date date11 = fixedMillisecond7.getTime();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date11);
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        java.util.Date date15 = fixedMillisecond13.getStart();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        java.lang.Number number18 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        java.lang.String str19 = timeSeries1.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener20);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(list6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440016590L + "'", long9 == 1560440016590L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries3.delete(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        java.util.Date date8 = day5.getStart();
//        long long9 = day5.getLastMillisecond();
//        long long10 = day5.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
//        int int17 = day16.getMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day16.getSerialDate();
//        long long19 = day16.getFirstMillisecond();
//        boolean boolean20 = day5.equals((java.lang.Object) long19);
//        int int21 = day5.getMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440016759L + "'", long2 == 1560440016759L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440016761L + "'", long13 == 1560440016761L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond0.getMiddleMillisecond(calendar16);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440016858L + "'", long17 == 1560440016858L);
//    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = spreadsheetDate14.getDayOfWeek();
//        java.lang.String str19 = spreadsheetDate14.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        boolean boolean32 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        int int33 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) fixedMillisecond37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) false);
//        boolean boolean41 = spreadsheetDate35.equals((java.lang.Object) false);
//        boolean boolean42 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        boolean boolean44 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23, 10);
//        java.lang.String str45 = spreadsheetDate14.toString();
//        boolean boolean46 = fixedMillisecond6.equals((java.lang.Object) spreadsheetDate14);
//        org.jfree.data.time.SerialDate serialDate47 = null;
//        try {
//            boolean boolean48 = spreadsheetDate14.isAfter(serialDate47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440016944L + "'", long9 == 1560440016944L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-January-1900" + "'", str45.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfWeek();
        java.lang.String str7 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean19 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int21 = spreadsheetDate11.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        int int26 = fixedMillisecond24.compareTo((java.lang.Object) fixedMillisecond25);
        boolean boolean28 = fixedMillisecond24.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate23.equals((java.lang.Object) false);
        boolean boolean30 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11, 10);
        int int33 = spreadsheetDate9.getYYYY();
        java.lang.String str34 = spreadsheetDate9.toString();
        try {
            org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1-January-1900" + "'", str34.equals("1-January-1900"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        int int20 = fixedMillisecond18.compareTo((java.lang.Object) fixedMillisecond19);
//        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
//        java.lang.String str26 = timeSeries24.getRangeDescription();
//        int int27 = fixedMillisecond18.compareTo((java.lang.Object) str26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
//        boolean boolean32 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class31);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class31);
//        int int34 = timeSeriesDataItem17.compareTo((java.lang.Object) timeSeries33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 9223372036854775807L);
//        int int38 = month35.getMonth();
//        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) month35);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
//        timeSeries41.clear();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries44.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries41.addAndOrUpdate(timeSeries47);
//        java.lang.Class class49 = timeSeries41.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries33.addAndOrUpdate(timeSeries41);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize(class2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date7, timeZone10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date7);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = month12.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(class2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440017437L + "'", long6 == 1560440017437L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = timeSeries1.equals(obj4);
//        timeSeries1.removeAgedItems(1L, true);
//        java.lang.Object obj9 = timeSeries1.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        java.util.Date date18 = day15.getStart();
//        long long19 = day15.getLastMillisecond();
//        long long20 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        java.util.Date date24 = fixedMillisecond21.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
//        int int27 = day26.getMonth();
//        org.jfree.data.time.SerialDate serialDate28 = day26.getSerialDate();
//        long long29 = day26.getFirstMillisecond();
//        boolean boolean30 = day15.equals((java.lang.Object) long29);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440017621L + "'", long12 == 1560440017621L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560440017624L + "'", long23 == 1560440017624L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries1.add(regularTimePeriod5, (java.lang.Number) 1560440010594L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month2);
        try {
            timeSeries1.delete(5, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str15 = spreadsheetDate14.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate3.equals((java.lang.Object) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.Class<?> wildcardClass21 = serialDate20.getClass();
        try {
            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((-435), serialDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        long long8 = day5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440018260L + "'", long2 == 1560440018260L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        java.lang.String str8 = timeSeries6.getRangeDescription();
//        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int23 = spreadsheetDate19.getDayOfWeek();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean26 = timeSeries25.getNotify();
//        java.lang.Comparable comparable27 = timeSeries25.getKey();
//        java.util.Collection collection28 = timeSeries25.getTimePeriods();
//        java.lang.Object obj29 = timeSeries25.clone();
//        boolean boolean30 = spreadsheetDate19.equals(obj29);
//        boolean boolean31 = timeSeriesDataItem17.equals((java.lang.Object) spreadsheetDate19);
//        java.lang.Number number32 = timeSeriesDataItem17.getValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + (short) 1 + "'", number32.equals((short) 1));
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int34 = day33.getYear();
        java.util.Date date35 = day33.getStart();
        java.lang.String str36 = day33.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 6);
        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) (byte) -1);
        int int41 = day33.compareTo((java.lang.Object) fixedMillisecond38);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1-January-1900" + "'", str36.equals("1-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean3 = timeSeries2.getNotify();
        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNull(uRL5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.lang.String str4 = timeSeries2.getRangeDescription();
        java.lang.Class class5 = timeSeries2.getTimePeriodClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", class5);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNull(obj6);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Date date11 = fixedMillisecond9.getStart();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        timeSeries13.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9);
//        java.util.Date date24 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = year27.getFirstMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440019367L + "'", long21 == 1560440019367L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-460));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy((int) (byte) 0, 13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.String str6 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        java.util.Date date6 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9-January-1900" + "'", str5.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.lang.String str2 = month0.toString();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        try {
//            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek((-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440020985L + "'", long2 == 1560440020985L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.lang.String str2 = month0.toString();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = timeSeries1.getTimePeriodClass();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        boolean boolean5 = timeSeries1.equals((java.lang.Object) 1560439979754L);
        timeSeries1.setMaximumItemAge(1560439997205L);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean25 = spreadsheetDate1.isAfter(serialDate24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        boolean boolean29 = timeSeries27.isEmpty();
        boolean boolean30 = timeSeries27.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        int int33 = fixedMillisecond31.compareTo((java.lang.Object) fixedMillisecond32);
        boolean boolean34 = timeSeries27.equals((java.lang.Object) fixedMillisecond32);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean41 = spreadsheetDate38.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean46 = spreadsheetDate43.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean47 = spreadsheetDate38.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
        int int48 = spreadsheetDate45.toSerial();
        boolean boolean49 = timeSeries27.equals((java.lang.Object) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Comparable comparable3 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        boolean boolean6 = timeSeries1.isEmpty();
        int int7 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "February" + "'", str2.equals("February"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        timeSeries3.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        boolean boolean12 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setDomainDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        java.lang.Class<?> wildcardClass16 = date15.getClass();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year17);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.addAndOrUpdate(timeSeries23);
//        int int25 = timeSeries23.getItemCount();
//        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener27);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440021703L + "'", long14 == 1560440021703L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(collection26);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list16 = timeSeries15.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        java.lang.Class class20 = timeSeries15.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean23 = timeSeries22.getNotify();
//        java.lang.Class class24 = timeSeries22.getTimePeriodClass();
//        timeSeries22.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        int int28 = fixedMillisecond26.compareTo((java.lang.Object) fixedMillisecond27);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond27.getFirstMillisecond(calendar29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9);
//        timeSeries22.setRangeDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        int int37 = fixedMillisecond35.compareTo((java.lang.Object) fixedMillisecond36);
//        int int39 = fixedMillisecond35.compareTo((java.lang.Object) 0L);
//        long long40 = fixedMillisecond35.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getFirstMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        java.util.Date date45 = fixedMillisecond41.getTime();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        java.lang.Number number47 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, number47);
//        try {
//            timeSeries15.delete(3, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440021815L + "'", long9 == 1560440021815L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560440021818L + "'", long30 == 1560440021818L);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440021819L + "'", long40 == 1560440021819L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560440021820L + "'", long43 == 1560440021820L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        long long6 = year4.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean16 = spreadsheetDate13.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        boolean boolean17 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        int int18 = spreadsheetDate15.toSerial();
//        boolean boolean19 = year4.equals((java.lang.Object) int18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        int int22 = fixedMillisecond20.compareTo((java.lang.Object) fixedMillisecond21);
//        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        java.lang.String str28 = timeSeries26.getRangeDescription();
//        int int29 = fixedMillisecond20.compareTo((java.lang.Object) str28);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, class33);
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond20.peg(calendar36);
//        long long38 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond20.getFirstMillisecond(calendar39);
//        long long41 = fixedMillisecond20.getSerialIndex();
//        int int42 = year4.compareTo((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        int int45 = fixedMillisecond43.compareTo((java.lang.Object) fixedMillisecond44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond44.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond44.getTime();
//        int int49 = year4.compareTo((java.lang.Object) fixedMillisecond44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond44.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440021897L + "'", long2 == 1560440021897L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560440021899L + "'", long38 == 1560440021899L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440021899L + "'", long40 == 1560440021899L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440021899L + "'", long41 == 1560440021899L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560440021913L + "'", long47 == 1560440021913L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        int int15 = fixedMillisecond13.compareTo((java.lang.Object) fixedMillisecond14);
//        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) false);
//        boolean boolean18 = spreadsheetDate12.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.addAndOrUpdate(timeSeries22);
//        boolean boolean24 = spreadsheetDate12.equals((java.lang.Object) timeSeries20);
//        int int25 = day5.compareTo((java.lang.Object) timeSeries20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener26);
//        int int28 = timeSeries20.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440022121L + "'", long2 == 1560440022121L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440022209L + "'", long2 == 1560440022209L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        timeSeries1.setRangeDescription("Thu Jun 13 08:33:00 PDT 2019");
//        try {
//            timeSeries1.update((-460), (java.lang.Number) 1560440003478L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        java.util.Calendar calendar6 = null;
//        long long7 = regularTimePeriod5.getMiddleMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440022236L + "'", long7 == 1560440022236L);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.removeAgedItems(1560440016858L, true);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 5, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries3.addChangeListener(seriesChangeListener5);
//        timeSeries3.fireSeriesChanged();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Date date11 = fixedMillisecond9.getStart();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean14 = timeSeries13.getNotify();
//        java.lang.Class class15 = timeSeries13.getTimePeriodClass();
//        timeSeries13.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) fixedMillisecond18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 9);
//        java.util.Date date24 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date11);
//        long long29 = year28.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440022448L + "'", long21 == 1560440022448L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
//        java.lang.String str8 = month6.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = month6.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440022602L + "'", long4 == 1560440022602L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-456) + "'", int1 == (-456));
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getFirstMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getTime();
//        java.lang.Class<?> wildcardClass36 = date35.getClass();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
//        boolean boolean38 = spreadsheetDate8.isOnOrBefore(serialDate37);
//        java.lang.String str39 = spreadsheetDate8.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440022697L + "'", long34 == 1560440022697L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNull(str39);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date21, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date12, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440022802L + "'", long9 == 1560440022802L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440022817L + "'", long20 == 1560440022817L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
//        int int8 = day5.getYear();
//        int int9 = day5.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.next();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day5.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440023055L + "'", long2 == 1560440023055L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.util.List list4 = timeSeries1.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(list4);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = month5.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440023134L + "'", long2 == 1560440023134L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Collection collection12 = timeSeries1.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries1.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (double) (byte) 1);
//        java.lang.Object obj24 = timeSeries1.clone();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440023149L + "'", long9 == 1560440023149L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440023161L + "'", long17 == 1560440023161L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(obj24);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        int int5 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year10, (double) '#', true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440023261L + "'", long8 == 1560440023261L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        boolean boolean5 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            java.lang.Number number9 = timeSeries1.getValue(regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Date date8 = fixedMillisecond6.getStart();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day10.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440023515L + "'", long2 == 1560440023515L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        int int8 = day5.getMonth();
//        java.lang.String str9 = day5.toString();
//        java.util.Date date10 = day5.getEnd();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440023530L + "'", long2 == 1560440023530L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        java.lang.Object obj7 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond2);
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getRangeDescription();
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) str9);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class14);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class22);
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", class14, class22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(obj24);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        java.lang.Class<?> wildcardClass5 = date4.getClass();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.addAndOrUpdate(timeSeries9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries9.addChangeListener(seriesChangeListener11);
//        timeSeries9.fireSeriesChanged();
//        long long14 = timeSeries9.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        java.util.Date date17 = fixedMillisecond15.getStart();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean20 = timeSeries19.getNotify();
//        java.lang.Class class21 = timeSeries19.getTimePeriodClass();
//        timeSeries19.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) 9);
//        java.util.Date date30 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30, timeZone31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date17, timeZone31);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean36 = timeSeries35.getNotify();
//        java.lang.Class class37 = timeSeries35.getTimePeriodClass();
//        timeSeries35.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        int int41 = fixedMillisecond39.compareTo((java.lang.Object) fixedMillisecond40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 9);
//        java.util.Date date46 = fixedMillisecond40.getTime();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize(class50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond52.getFirstMillisecond(calendar53);
//        java.util.Date date55 = fixedMillisecond52.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(date55);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date55, timeZone58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date46, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date17, timeZone58);
//        java.io.InputStream inputStream62 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Monday", (java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440023768L + "'", long3 == 1560440023768L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440023789L + "'", long27 == 1560440023789L);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560440023795L + "'", long43 == 1560440023795L);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560440023798L + "'", long54 == 1560440023798L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNull(inputStream62);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        java.util.Date date19 = fixedMillisecond15.getTime();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date19);
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        timeSeries14.setKey((java.lang.Comparable) timeSeriesDataItem23);
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timeSeries14.removePropertyChangeListener(propertyChangeListener25);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440024429L + "'", long17 == 1560440024429L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate20);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) timeSeries1);
        try {
            timeSeries1.update(0, (java.lang.Number) 1560439989990L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (short) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate19.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int23 = spreadsheetDate19.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean26 = timeSeries25.getNotify();
        java.lang.Comparable comparable27 = timeSeries25.getKey();
        java.util.Collection collection28 = timeSeries25.getTimePeriods();
        java.lang.Object obj29 = timeSeries25.clone();
        boolean boolean30 = spreadsheetDate19.equals(obj29);
        boolean boolean31 = timeSeriesDataItem17.equals((java.lang.Object) spreadsheetDate19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem17.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem17.getPeriod();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 100 + "'", comparable27.equals(100));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        int int5 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            timeSeries1.add(timeSeriesDataItem6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        int int10 = fixedMillisecond6.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
//        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond12.getLastMillisecond(calendar18);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560440025488L + "'", long19 == 1560440025488L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.setDescription("9-January-1900");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.addChangeListener(seriesChangeListener7);
        timeSeries5.fireSeriesChanged();
        long long10 = timeSeries5.getMaximumItemAge();
        java.lang.Object obj11 = timeSeries5.clone();
        try {
            int int12 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        int int10 = fixedMillisecond6.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        int int14 = fixedMillisecond12.compareTo((java.lang.Object) fixedMillisecond13);
//        int int16 = fixedMillisecond12.compareTo((java.lang.Object) 0L);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list20 = timeSeries19.getItems();
//        timeSeries19.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        boolean boolean27 = timeSeries19.isEmpty();
//        timeSeries19.setDomainDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
//        java.util.Date date33 = fixedMillisecond30.getTime();
//        java.lang.Class<?> wildcardClass34 = date33.getClass();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.previous();
//        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) year35);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries39.addAndOrUpdate(timeSeries41);
//        int int43 = timeSeries41.getItemCount();
//        java.util.Collection collection44 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries41);
//        boolean boolean45 = timeSeries17.equals((java.lang.Object) collection44);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560440025919L + "'", long32 == 1560440025919L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        int int6 = day5.getMonth();
//        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
//        long long8 = day5.getFirstMillisecond();
//        long long9 = day5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day5.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440026596L + "'", long2 == 1560440026596L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.addAndOrUpdate(timeSeries8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries8.addChangeListener(seriesChangeListener10);
//        timeSeries8.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond15);
//        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        int int23 = fixedMillisecond14.compareTo((java.lang.Object) str22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond14.getMiddleMillisecond(calendar24);
//        boolean boolean27 = fixedMillisecond14.equals((java.lang.Object) 1560439986416L);
//        int int28 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries4.addAndOrUpdate(timeSeries8);
//        int int30 = timeSeries8.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        boolean boolean34 = timeSeries32.isEmpty();
//        boolean boolean35 = timeSeries32.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) fixedMillisecond37);
//        boolean boolean39 = timeSeries32.equals((java.lang.Object) fixedMillisecond37);
//        long long40 = fixedMillisecond37.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 10);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Value" + "'", str22.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440026674L + "'", long25 == 1560440026674L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440026678L + "'", long40 == 1560440026678L);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-435));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("ThreadContext");
        java.util.List list12 = timeSeries1.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries1.add(regularTimePeriod13, (java.lang.Number) 1560440026678L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list12);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = spreadsheetDate14.getDayOfWeek();
//        java.lang.String str19 = spreadsheetDate14.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        boolean boolean32 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        int int33 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) fixedMillisecond37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) false);
//        boolean boolean41 = spreadsheetDate35.equals((java.lang.Object) false);
//        boolean boolean42 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        boolean boolean44 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23, 10);
//        java.lang.String str45 = spreadsheetDate14.toString();
//        boolean boolean46 = fixedMillisecond6.equals((java.lang.Object) spreadsheetDate14);
//        long long47 = fixedMillisecond6.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440027403L + "'", long9 == 1560440027403L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-January-1900" + "'", str45.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560440027403L + "'", long47 == 1560440027403L);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Following");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        java.util.Date date8 = fixedMillisecond6.getStart();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440028027L + "'", long2 == 1560440028027L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(0L, false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getStart();
        java.lang.String str10 = month8.toString();
        java.lang.Number number11 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month8);
        timeSeries1.setDomainDescription("Time");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            timeSeries1.add(regularTimePeriod14, (double) 1560439979860L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str22 = spreadsheetDate21.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean25 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate10.equals((java.lang.Object) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean28 = spreadsheetDate1.isOnOrAfter(serialDate27);
        java.lang.String str29 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-January-1900" + "'", str29.equals("9-January-1900"));
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
//        int int23 = timeSeries13.getIndex(regularTimePeriod22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod22, (double) 1560440020836L);
//        timeSeriesDataItem25.setValue((java.lang.Number) 1560439999379L);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440028151L + "'", long17 == 1560440028151L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate1.getDayOfWeek();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
        int int32 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int34 = day33.getYear();
        java.util.Date date35 = day33.getStart();
        long long36 = day33.getFirstMillisecond();
        long long37 = day33.getLastMillisecond();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = day33.getLastMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2208960000000L) + "'", long36 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208873600001L) + "'", long37 == (-2208873600001L));
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean17 = spreadsheetDate14.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = spreadsheetDate14.getDayOfWeek();
//        java.lang.String str19 = spreadsheetDate14.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean31 = spreadsheetDate28.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        boolean boolean32 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        int int33 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        int int38 = fixedMillisecond36.compareTo((java.lang.Object) fixedMillisecond37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) false);
//        boolean boolean41 = spreadsheetDate35.equals((java.lang.Object) false);
//        boolean boolean42 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        boolean boolean44 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23, 10);
//        java.lang.String str45 = spreadsheetDate14.toString();
//        boolean boolean46 = fixedMillisecond6.equals((java.lang.Object) spreadsheetDate14);
//        try {
//            int int48 = spreadsheetDate14.compareTo((java.lang.Object) 1560440009393L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440028287L + "'", long9 == 1560440028287L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9-January-1900" + "'", str45.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        java.util.Date date12 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12, timeZone13);
//        java.lang.String str15 = month14.toString();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = month14.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440028315L + "'", long9 == 1560440028315L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        long long11 = timeSeries3.getMaximumItemAge();
        java.lang.Class class12 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((-435), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        int int8 = fixedMillisecond6.compareTo((java.lang.Object) fixedMillisecond7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) false);
//        java.lang.Number number11 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond6.getMiddleMillisecond(calendar12);
//        org.junit.Assert.assertNotNull(timeSeries4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440028510L + "'", long13 == 1560440028510L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month2);
        int int6 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        boolean boolean9 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("ThreadContext");
        java.lang.String str12 = timeSeries1.getDescription();
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries12.addChangeListener(seriesChangeListener14);
        timeSeries12.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int19 = timeSeries18.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries18);
        java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.lang.Class class22 = timeSeries18.getTimePeriodClass();
        int int23 = timeSeries18.getItemCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 6);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean6 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int14 = spreadsheetDate3.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
//        int int21 = day20.getMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        boolean boolean23 = spreadsheetDate3.isOnOrBefore(serialDate22);
//        try {
//            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((-456), (org.jfree.data.time.SerialDate) spreadsheetDate3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440029260L + "'", long17 == 1560440029260L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries1.equals(obj4);
        timeSeries1.removeAgedItems(1L, true);
        java.lang.Object obj9 = timeSeries1.clone();
        boolean boolean10 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440029587L + "'", long2 == 1560440029587L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean21 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean26 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate18.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int28 = spreadsheetDate25.getDayOfMonth();
        int int29 = spreadsheetDate25.toSerial();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean32 = spreadsheetDate25.isOn(serialDate31);
        boolean boolean34 = spreadsheetDate2.isInRange(serialDate16, serialDate31, 0);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean2 = timeSeries1.getNotify();
//        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
//        timeSeries1.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 9);
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list16 = timeSeries15.getItems();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener17);
//        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.addAndOrUpdate(timeSeries23);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries23.addChangeListener(seriesChangeListener25);
//        timeSeries23.setDescription("9-January-1900");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        int int31 = fixedMillisecond29.compareTo((java.lang.Object) fixedMillisecond30);
//        boolean boolean33 = fixedMillisecond29.equals((java.lang.Object) false);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
//        java.lang.String str37 = timeSeries35.getRangeDescription();
//        int int38 = fixedMillisecond29.compareTo((java.lang.Object) str37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond29.getMiddleMillisecond(calendar39);
//        boolean boolean42 = fixedMillisecond29.equals((java.lang.Object) 1560439986416L);
//        int int43 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean49 = spreadsheetDate46.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        int int50 = spreadsheetDate46.getDayOfWeek();
//        java.lang.String str51 = spreadsheetDate46.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean58 = spreadsheetDate55.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean63 = spreadsheetDate60.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
//        boolean boolean64 = spreadsheetDate55.isOn((org.jfree.data.time.SerialDate) spreadsheetDate62);
//        int int65 = spreadsheetDate55.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        int int70 = fixedMillisecond68.compareTo((java.lang.Object) fixedMillisecond69);
//        boolean boolean72 = fixedMillisecond68.equals((java.lang.Object) false);
//        boolean boolean73 = spreadsheetDate67.equals((java.lang.Object) false);
//        boolean boolean74 = spreadsheetDate55.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
//        boolean boolean76 = spreadsheetDate46.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate53, (org.jfree.data.time.SerialDate) spreadsheetDate55, 10);
//        int int77 = spreadsheetDate53.getYYYY();
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addDays(8, (org.jfree.data.time.SerialDate) spreadsheetDate53);
//        int int79 = fixedMillisecond29.compareTo((java.lang.Object) 8);
//        int int80 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440031534L + "'", long9 == 1560440031534L);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440031536L + "'", long40 == 1560440031536L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
//        org.junit.Assert.assertNull(str51);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1900 + "'", int77 == 1900);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1) + "'", int80 == (-1));
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate1.getDayOfWeek();
//        java.lang.String str6 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 10);
//        int int32 = spreadsheetDate8.getYYYY();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int34 = day33.getYear();
//        java.util.Date date35 = day33.getStart();
//        long long36 = day33.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getFirstMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond37.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40);
//        int int43 = day42.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
//        java.util.Date date45 = day42.getStart();
//        long long46 = day42.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean51 = spreadsheetDate48.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean56 = spreadsheetDate53.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        boolean boolean57 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        int int58 = spreadsheetDate55.getDayOfMonth();
//        int int59 = spreadsheetDate55.toSerial();
//        boolean boolean60 = day42.equals((java.lang.Object) spreadsheetDate55);
//        java.lang.String str61 = spreadsheetDate55.toString();
//        boolean boolean62 = day33.equals((java.lang.Object) str61);
//        java.util.Calendar calendar63 = null;
//        try {
//            long long64 = day33.getFirstMillisecond(calendar63);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2208960000000L) + "'", long36 == (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440032105L + "'", long39 == 1560440032105L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 13 + "'", int43 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560495599999L + "'", long46 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 9 + "'", int58 == 9);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "9-January-1900" + "'", str61.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        java.lang.String str4 = month0.toString();
        int int6 = month0.compareTo((java.lang.Object) 1560439997427L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(8, (int) (short) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        int int9 = fixedMillisecond0.compareTo((java.lang.Object) str8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10, (java.lang.Object) class13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class13);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list18 = timeSeries17.getItems();
        timeSeries17.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        int int23 = fixedMillisecond21.compareTo((java.lang.Object) fixedMillisecond22);
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        boolean boolean25 = timeSeries17.isEmpty();
        timeSeries17.setDomainDescription("ThreadContext");
        java.util.List list28 = timeSeries17.getItems();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list32 = timeSeries31.getItems();
        timeSeries31.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        int int37 = fixedMillisecond35.compareTo((java.lang.Object) fixedMillisecond36);
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) 1560439980698L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries17.removeChangeListener(seriesChangeListener41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        timeSeries1.setRangeDescription("Monday");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Comparable comparable5 = timeSeries1.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 100 + "'", comparable5.equals(100));
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        java.lang.ClassLoader classLoader12 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class11);
//        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond5, (java.lang.Object) classLoader12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
//        java.lang.String str17 = timeSeries15.getRangeDescription();
//        boolean boolean19 = timeSeries15.equals((java.lang.Object) 1560439979754L);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        boolean boolean22 = timeSeries21.getNotify();
//        java.lang.Class class23 = timeSeries21.getTimePeriodClass();
//        timeSeries21.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        int int27 = fixedMillisecond25.compareTo((java.lang.Object) fixedMillisecond26);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond26.getFirstMillisecond(calendar28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 9);
//        java.util.Date date32 = fixedMillisecond26.getTime();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
//        java.lang.Number number35 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) month34);
//        boolean boolean36 = fixedMillisecond5.equals((java.lang.Object) number35);
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(classLoader12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560440032732L + "'", long29 == 1560440032732L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.addChangeListener(seriesChangeListener5);
        timeSeries3.fireSeriesChanged();
        long long8 = timeSeries3.getMaximumItemAge();
        java.lang.Object obj9 = timeSeries3.clone();
        int int10 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean14 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int16 = spreadsheetDate13.getDayOfMonth();
        int int17 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean20 = spreadsheetDate13.isOn(serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean25 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate22.getDayOfWeek();
        java.lang.String str27 = spreadsheetDate22.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean39 = spreadsheetDate36.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean40 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int41 = spreadsheetDate31.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        int int46 = fixedMillisecond44.compareTo((java.lang.Object) fixedMillisecond45);
        boolean boolean48 = fixedMillisecond44.equals((java.lang.Object) false);
        boolean boolean49 = spreadsheetDate43.equals((java.lang.Object) false);
        boolean boolean50 = spreadsheetDate31.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean52 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31, 10);
        boolean boolean53 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.util.Date date54 = spreadsheetDate13.toDate();
        boolean boolean55 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        java.lang.String str56 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "9-January-1900" + "'", str56.equals("9-January-1900"));
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        java.lang.Class<?> wildcardClass5 = date4.getClass();
//        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass5);
//        java.lang.ClassLoader classLoader7 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440033168L + "'", long3 == 1560440033168L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(obj6);
//        org.junit.Assert.assertNotNull(classLoader7);
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        int int2 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
//        long long7 = fixedMillisecond1.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440033528L + "'", long4 == 1560440033528L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440033528L + "'", long6 == 1560440033528L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440033528L + "'", long7 == 1560440033528L);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
//        java.util.List list2 = timeSeries1.getItems();
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = fixedMillisecond5.compareTo((java.lang.Object) fixedMillisecond6);
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        boolean boolean9 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries13);
//        java.lang.String str15 = timeSeries1.getDescription();
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(str15);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        java.lang.String str2 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(4);
//        boolean boolean8 = spreadsheetDate1.isOnOrBefore(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate10.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
//        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
//        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
//        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        java.util.Date date31 = spreadsheetDate10.toDate();
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(date31);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean8 = spreadsheetDate1.isOnOrBefore(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean13 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean18 = spreadsheetDate15.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        int int25 = fixedMillisecond23.compareTo((java.lang.Object) fixedMillisecond24);
        boolean boolean27 = fixedMillisecond23.equals((java.lang.Object) false);
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) false);
        boolean boolean29 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate30 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int31 = spreadsheetDate10.getYYYY();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Oct");
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int3, class7);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean8 = spreadsheetDate1.isOnOrBefore(serialDate7);
        int int9 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean15 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(4, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean28 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int29 = spreadsheetDate25.getDayOfWeek();
        java.lang.String str30 = spreadsheetDate25.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean37 = spreadsheetDate34.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean42 = spreadsheetDate39.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean43 = spreadsheetDate34.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int44 = spreadsheetDate34.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        int int49 = fixedMillisecond47.compareTo((java.lang.Object) fixedMillisecond48);
        boolean boolean51 = fixedMillisecond47.equals((java.lang.Object) false);
        boolean boolean52 = spreadsheetDate46.equals((java.lang.Object) false);
        boolean boolean53 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean55 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate34, 10);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays(3, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean58 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, serialDate56, 10);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean61 = timeSeries60.getNotify();
        java.lang.Class class62 = timeSeries60.getTimePeriodClass();
        java.util.List list63 = timeSeries60.getItems();
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timeSeries60.addPropertyChangeListener(propertyChangeListener64);
        try {
            int int66 = spreadsheetDate12.compareTo((java.lang.Object) timeSeries60);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(class62);
        org.junit.Assert.assertNotNull(list63);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        int int2 = timeSeries1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.addAndOrUpdate(timeSeries3);
        int int5 = timeSeries3.getMaximumItemCount();
        boolean boolean6 = timeSeries3.isEmpty();
        timeSeries3.clear();
        timeSeries3.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertNotNull(timeSeries4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.lang.Class<?> wildcardClass4 = date3.getClass();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 9999);
//        java.lang.Class<?> wildcardClass9 = regularTimePeriod6.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440035323L + "'", long2 == 1560440035323L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean4 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean9 = spreadsheetDate6.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        int int11 = spreadsheetDate8.getDayOfMonth();
//        int int12 = spreadsheetDate8.toSerial();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean15 = spreadsheetDate8.isOn(serialDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean20 = spreadsheetDate17.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        int int21 = spreadsheetDate17.getDayOfWeek();
//        java.lang.String str22 = spreadsheetDate17.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean29 = spreadsheetDate26.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean34 = spreadsheetDate31.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        boolean boolean35 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        int int36 = spreadsheetDate26.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        int int41 = fixedMillisecond39.compareTo((java.lang.Object) fixedMillisecond40);
//        boolean boolean43 = fixedMillisecond39.equals((java.lang.Object) false);
//        boolean boolean44 = spreadsheetDate38.equals((java.lang.Object) false);
//        boolean boolean45 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        boolean boolean47 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate26, 10);
//        boolean boolean48 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        java.util.Date date49 = spreadsheetDate8.toDate();
//        int int50 = spreadsheetDate8.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 9223372036854775807L);
        int int3 = month0.getMonth();
        java.lang.String str4 = month0.toString();
        long long5 = month0.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean5 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean10 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int13 = spreadsheetDate2.getDayOfMonth();
        java.lang.String str14 = spreadsheetDate2.getDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.addAndOrUpdate(timeSeries6);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries1.addAndOrUpdate(timeSeries7);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        java.lang.String str11 = seriesChangeEvent10.toString();
        java.lang.String str12 = seriesChangeEvent10.toString();
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        timeSeries1.clear();
        java.lang.Object obj3 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection6);
    }
}

