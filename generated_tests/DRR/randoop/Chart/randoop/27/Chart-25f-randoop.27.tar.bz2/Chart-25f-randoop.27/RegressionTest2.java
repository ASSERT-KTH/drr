import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = statisticalBarRenderer4.getSeriesToolTipGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = statisticalBarRenderer4.getBaseItemLabelGenerator();
        java.awt.Shape shape15 = statisticalBarRenderer4.getItemShape((-1), 500);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, (double) 0, 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textBlockAnchor20);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor19, textBlockAnchor20);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor19, (double) 1.0f, 1.0E-8d);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis27.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo33.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge37);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition39 = categoryLabelPositions36.getLabelPosition(rectangleEdge37);
        boolean boolean40 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge37);
        double double41 = categoryAxis27.getCategoryStart(8, 15, rectangle2D35, rectangleEdge37);
        java.awt.Font font45 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color46 = java.awt.Color.DARK_GRAY;
        int int47 = color46.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("", font45, (java.awt.Paint) color46);
        java.awt.Paint paint49 = labelBlock48.getPaint();
        java.lang.String str50 = labelBlock48.getID();
        java.lang.String str51 = labelBlock48.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D52 = labelBlock48.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis27.getCategoryEnd((-1), 64, rectangle2D52, rectangleEdge53);
        java.awt.Stroke stroke55 = categoryAxis27.getAxisLineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer59 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean61 = statisticalBarRenderer59.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer59.removeAnnotations();
        statisticalBarRenderer59.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer59.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer67 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator68 = statisticalBarRenderer67.getLegendItemLabelGenerator();
        statisticalBarRenderer59.setLegendItemLabelGenerator(categorySeriesLabelGenerator68);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, valueAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer59);
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.data.Range range72 = categoryPlot70.getDataRange(valueAxis71);
        categoryPlot70.setOutlineVisible(false);
        java.awt.Paint paint75 = categoryPlot70.getOutlinePaint();
        org.jfree.chart.LegendItem legendItem76 = new org.jfree.chart.LegendItem("RectangleEdge.TOP", "", "NOID", "AxisLocation.BOTTOM_OR_LEFT", shape25, stroke55, paint75);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(categoryLabelPosition39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 64 + "'", int47 == 64);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator68);
        org.junit.Assert.assertNull(range72);
        org.junit.Assert.assertNotNull(paint75);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(1.0E-8d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = org.jfree.data.RangeType.NEGATIVE;
        numberAxis0.setRangeType(rangeType1);
        float float3 = numberAxis0.getTickMarkInsideLength();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getLowerBound();
        java.lang.String str6 = range4.toString();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range7, (double) (byte) 100, false);
        boolean boolean12 = range7.equals((java.lang.Object) (-1.0d));
        boolean boolean15 = range7.intersects((double) 0L, (double) (-1L));
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range7, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range4, range7);
        numberAxis0.setRangeWithMargins(range4);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Range[0.0,1.0]" + "'", str6.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        double double7 = statisticalBarRenderer0.getLowerClip();
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesPaint((int) '#');
        java.awt.Paint paint10 = statisticalBarRenderer0.getBaseFillPaint();
        boolean boolean11 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("GradientPaintTransformType.VERTICAL", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getLowerBound();
        java.lang.String str2 = range0.toString();
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, (double) (byte) 100, false);
        boolean boolean8 = range3.equals((java.lang.Object) (-1.0d));
        boolean boolean11 = range3.intersects((double) 0L, (double) (-1L));
        org.jfree.data.Range range13 = org.jfree.data.Range.shift(range3, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range0, range3);
        org.jfree.data.Range range15 = rectangleConstraint14.getWidthRange();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Range[0.0,1.0]" + "'", str2.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis0);
        java.lang.String str2 = axisChangeEvent1.toString();
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, (double) '#', (double) (short) 1, (double) '4');
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.general.DatasetGroup datasetGroup6 = new org.jfree.data.general.DatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean12 = statisticalBarRenderer10.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer10.removeAnnotations();
        statisticalBarRenderer10.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer10.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator19 = statisticalBarRenderer18.getLegendItemLabelGenerator();
        statisticalBarRenderer10.setLegendItemLabelGenerator(categorySeriesLabelGenerator19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot21.getDataRange(valueAxis22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot21.getInsets();
        boolean boolean25 = datasetGroup6.equals((java.lang.Object) categoryPlot21);
        statisticalBarRenderer0.setPlot(categoryPlot21);
        boolean boolean27 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot21.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator19);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 100L);
        java.util.List list2 = axisState1.getTicks();
        double double3 = axisState1.getMax();
        java.util.List list4 = axisState1.getTicks();
        axisState1.cursorRight(3.0d);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        java.lang.String str4 = legendItemBlockContainer3.getURLText();
        legendItemBlockContainer3.clear();
        java.lang.Object obj6 = legendItemBlockContainer3.clone();
        legendItemBlockContainer3.setToolTipText("poly");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot14.getDomainAxis();
        java.awt.Paint paint19 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot14.getInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot14.getRenderer();
        categoryPlot14.mapDatasetToDomainAxis(500, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(categoryItemRenderer22);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets3.getBottom();
        double double6 = rectangleInsets3.calculateBottomOutset((double) 10);
        categoryAxis1.setLabelInsets(rectangleInsets3);
        categoryAxis1.setLowerMargin((double) (short) 10);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot15.getDataRange(valueAxis16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        boolean boolean19 = datasetGroup0.equals((java.lang.Object) categoryPlot15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = categoryPlot15.getDrawingSupplier();
        try {
            categoryPlot15.zoom((double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(drawingSupplier20);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = axisSpace19.shrink(rectangle2D23, rectangle2D24);
        double double26 = axisSpace19.getTop();
        categoryPlot14.setFixedRangeAxisSpace(axisSpace19);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot14.getRowRenderingOrder();
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color32 = java.awt.Color.DARK_GRAY;
        int int33 = color32.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("", font31, (java.awt.Paint) color32);
        java.awt.Paint paint35 = labelBlock34.getPaint();
        java.lang.String str36 = labelBlock34.getID();
        java.lang.String str37 = labelBlock34.getToolTipText();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean40 = statisticalBarRenderer38.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer38.removeAnnotations();
        statisticalBarRenderer38.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = statisticalBarRenderer38.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer38.setBaseOutlineStroke(stroke46, false);
        boolean boolean49 = labelBlock34.equals((java.lang.Object) statisticalBarRenderer38);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer38);
        java.awt.Stroke stroke51 = statisticalBarRenderer38.getBaseStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 64 + "'", int33 == 64);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        categoryPlot14.setOutlineVisible(false);
        java.awt.Paint paint19 = categoryPlot14.getOutlinePaint();
        boolean boolean20 = categoryPlot14.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot14.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot14.getDomainAxis((int) (byte) 100);
        categoryPlot14.setForegroundAlpha((float) 100);
        try {
            categoryPlot14.zoom((double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.Range range3 = new org.jfree.data.Range((double) (-1L), (double) 2);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range5, (double) (byte) 100, false);
        boolean boolean10 = range5.equals((java.lang.Object) (-1.0d));
        double double11 = range5.getLength();
        double double12 = range5.getLowerBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range15, (double) (byte) 100, false);
        boolean boolean20 = range15.equals((java.lang.Object) (-1.0d));
        boolean boolean23 = range15.intersects((double) 0L, (double) (-1L));
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range15, (double) (short) 100);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType26 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str27 = lengthConstraintType26.toString();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean31 = statisticalBarRenderer29.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer29.removeAnnotations();
        statisticalBarRenderer29.setAutoPopulateSeriesStroke(false);
        java.awt.Color color36 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer29.setSeriesItemLabelPaint(64, (java.awt.Paint) color36);
        java.awt.Color color38 = java.awt.Color.getColor("hi!", color36);
        java.awt.Color color39 = java.awt.Color.GREEN;
        float[] floatArray40 = null;
        float[] floatArray41 = color39.getColorComponents(floatArray40);
        float[] floatArray42 = color36.getRGBComponents(floatArray40);
        boolean boolean43 = lengthConstraintType26.equals((java.lang.Object) floatArray40);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, range5, lengthConstraintType13, 0.0d, range15, lengthConstraintType26);
        org.jfree.data.Range range46 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double47 = range46.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint(range46, (double) 0L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType50 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str51 = lengthConstraintType50.toString();
        java.lang.String str52 = lengthConstraintType50.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range3, lengthConstraintType26, (double) '4', range46, lengthConstraintType50);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(lengthConstraintType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "LengthConstraintType.NONE" + "'", str27.equals("LengthConstraintType.NONE"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "LengthConstraintType.NONE" + "'", str51.equals("LengthConstraintType.NONE"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "LengthConstraintType.NONE" + "'", str52.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj25 = jFreeChart24.getTextAntiAlias();
        java.awt.Image image26 = jFreeChart24.getBackgroundImage();
        java.lang.Object obj27 = jFreeChart24.getTextAntiAlias();
        boolean boolean28 = jFreeChart24.getAntiAlias();
        jFreeChart24.setTextAntiAlias(true);
        java.awt.Stroke stroke31 = jFreeChart24.getBorderStroke();
        java.awt.Image image32 = jFreeChart24.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(image32);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        statisticalBarRenderer0.setItemMargin((double) 1.0f);
        java.awt.Paint paint12 = statisticalBarRenderer0.getItemLabelPaint((int) (byte) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) -1);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot14.setDomainAxis((int) (short) 100, categoryAxis25);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean31 = statisticalBarRenderer29.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer29.setBaseItemLabelsVisible(true);
        statisticalBarRenderer29.setAutoPopulateSeriesPaint(true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean41 = statisticalBarRenderer39.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer39.removeAnnotations();
        statisticalBarRenderer39.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer39.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer47 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator48 = statisticalBarRenderer47.getLegendItemLabelGenerator();
        statisticalBarRenderer39.setLegendItemLabelGenerator(categorySeriesLabelGenerator48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.data.Range range52 = categoryPlot50.getDataRange(valueAxis51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryPlot50.getInsets();
        java.util.List list54 = categoryPlot50.getCategories();
        boolean boolean55 = categoryPlot50.isSubplot();
        categoryPlot50.setForegroundAlpha((float) (byte) 100);
        categoryPlot50.clearAnnotations();
        categoryPlot50.setRangeCrosshairValue((double) (short) -1);
        statisticalBarRenderer29.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot50);
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str63 = layer62.toString();
        java.util.Collection collection64 = categoryPlot50.getDomainMarkers(layer62);
        try {
            categoryPlot14.addRangeMarker(4, marker28, layer62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator48);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNull(list54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Layer.FOREGROUND" + "'", str63.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection64);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("UnitType.ABSOLUTE", "TextAnchor.CENTER");
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot14.getDataset(64);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot14.getRangeAxis(2);
        java.awt.Color color24 = java.awt.Color.pink;
        categoryPlot14.setOutlinePaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean28 = statisticalBarRenderer26.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer26.removeAnnotations();
        statisticalBarRenderer26.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = statisticalBarRenderer26.getSeriesToolTipGenerator(100);
        double double34 = statisticalBarRenderer26.getMaximumBarWidth();
        boolean boolean35 = statisticalBarRenderer26.getBaseCreateEntities();
        java.awt.Stroke stroke36 = statisticalBarRenderer26.getBaseStroke();
        categoryPlot14.setDomainGridlineStroke(stroke36);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("LengthConstraintType.NONE");
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        int int6 = color5.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font4, (java.awt.Paint) color5);
        java.lang.String str8 = labelBlock7.getToolTipText();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer11.setSeriesItemLabelPaint(64, (java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.getColor("hi!", color18);
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = color18.getRGBComponents(floatArray22);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font9);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("Layer.FOREGROUND", font9, (java.awt.Paint) color27);
        java.awt.Font font29 = textFragment28.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = statisticalBarRenderer30.getLegendItemLabelGenerator();
        statisticalBarRenderer30.setBaseItemLabelsVisible(true, false);
        statisticalBarRenderer30.setAutoPopulateSeriesOutlineStroke(true);
        double double37 = statisticalBarRenderer30.getLowerClip();
        java.awt.Paint paint39 = statisticalBarRenderer30.lookupSeriesPaint((int) '#');
        java.awt.Paint paint40 = statisticalBarRenderer30.getBaseFillPaint();
        java.awt.Color color45 = java.awt.Color.getHSBColor((float) 100L, (float) (-1), (float) '#');
        statisticalBarRenderer30.setSeriesItemLabelPaint((int) (short) 10, (java.awt.Paint) color45);
        boolean boolean47 = textFragment28.equals((java.lang.Object) color45);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        int int12 = color11.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color11);
        statisticalBarRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color11, false);
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) '4', (java.lang.Boolean) true);
        double double19 = statisticalBarRenderer0.getMinimumBarLength();
        statisticalBarRenderer0.setSeriesCreateEntities(4, (java.lang.Boolean) false);
        statisticalBarRenderer0.setBase(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 64 + "'", int12 == 64);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 2.0f, (double) 100);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        java.awt.Color color7 = java.awt.Color.red;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape9 = legendGraphic8.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer10.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalBarRenderer10.getNegativeItemLabelPositionFallback();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        boolean boolean17 = statisticalBarRenderer10.removeAnnotation(categoryAnnotation16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        boolean boolean19 = statisticalBarRenderer10.equals((java.lang.Object) rectangleInsets18);
        legendGraphic8.setMargin(rectangleInsets18);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType22 = standardGradientPaintTransformer21.getType();
        legendGraphic8.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer21);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType22);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot14.setDomainAxis((int) (short) 100, categoryAxis25);
        java.awt.Paint paint27 = categoryPlot14.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.Size2D size2D25 = textLine23.calculateDimensions(graphics2D24);
        double double26 = size2D25.getHeight();
        size2D25.height = 100;
        double double29 = size2D25.getHeight();
        boolean boolean30 = verticalAlignment22.equals((java.lang.Object) size2D25);
        org.jfree.chart.block.ColumnArrangement columnArrangement33 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment21, verticalAlignment22, (double) (byte) 1, 0.0d);
        org.jfree.chart.block.BlockContainer blockContainer34 = null;
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.data.Range range37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((double) 3, range37);
        try {
            org.jfree.chart.util.Size2D size2D39 = columnArrangement33.arrange(blockContainer34, graphics2D35, rectangleConstraint38);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.0d + "'", double29 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot14.setDataset(categoryDataset15);
        boolean boolean17 = categoryPlot14.isRangeZoomable();
        java.awt.Paint paint18 = categoryPlot14.getDomainGridlinePaint();
        boolean boolean19 = categoryPlot14.isOutlineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation20.getOpposite();
        categoryPlot14.setDomainAxisLocation(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        java.lang.String str5 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = statisticalBarRenderer0.getSeriesToolTipGenerator((int) ' ');
        org.jfree.data.general.DatasetGroup datasetGroup10 = new org.jfree.data.general.DatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean16 = statisticalBarRenderer14.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer14.removeAnnotations();
        statisticalBarRenderer14.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer14.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = statisticalBarRenderer22.getLegendItemLabelGenerator();
        statisticalBarRenderer14.setLegendItemLabelGenerator(categorySeriesLabelGenerator23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.data.Range range27 = categoryPlot25.getDataRange(valueAxis26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot25.getInsets();
        java.util.List list29 = categoryPlot25.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace30 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo32.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo32.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = axisSpace30.shrink(rectangle2D34, rectangle2D35);
        double double37 = axisSpace30.getTop();
        categoryPlot25.setFixedRangeAxisSpace(axisSpace30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean41 = statisticalBarRenderer39.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer39.removeAnnotations();
        statisticalBarRenderer39.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator46 = statisticalBarRenderer39.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer39.setBaseOutlineStroke(stroke47, false);
        categoryPlot25.setRangeGridlineStroke(stroke47);
        boolean boolean51 = datasetGroup10.equals((java.lang.Object) stroke47);
        statisticalBarRenderer0.setBaseStroke(stroke47, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(list29);
        org.junit.Assert.assertNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        java.awt.Color color7 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer0.setSeriesItemLabelPaint(64, (java.awt.Paint) color7);
        statisticalBarRenderer0.setBaseSeriesVisible(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color11, false);
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        int int17 = color16.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("", font15, (java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double21 = rectangleInsets19.calculateTopOutset((double) (byte) 1);
        labelBlock18.setPadding(rectangleInsets19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo24.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo24.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets19.createOutsetRectangle(rectangle2D26);
        statisticalBarRenderer0.setBaseShape((java.awt.Shape) rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 64 + "'", int17 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.lang.String str5 = labelBlock4.getToolTipText();
        java.awt.Font font6 = labelBlock4.getFont();
        labelBlock4.setToolTipText("hi!");
        java.lang.Object obj9 = labelBlock4.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("hi!", "CategoryLabelWidthType.RANGE");
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) "poly");
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        boolean boolean15 = statisticalBarRenderer9.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font16 = statisticalBarRenderer9.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 100, font16, false);
        java.awt.Paint paint20 = null;
        statisticalBarRenderer0.setSeriesPaint((int) '4', paint20, true);
        statisticalBarRenderer0.setItemMargin((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        statisticalBarRenderer0.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator26, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj25 = jFreeChart24.getTextAntiAlias();
        java.awt.Image image26 = jFreeChart24.getBackgroundImage();
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart24.removeProgressListener(chartProgressListener27);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        boolean boolean31 = textTitle29.equals((java.lang.Object) 0.2d);
        textTitle29.setToolTipText("hi!");
        java.lang.String str34 = textTitle29.getURLText();
        jFreeChart24.removeSubtitle((org.jfree.chart.title.Title) textTitle29);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean38 = statisticalBarRenderer36.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer36.setBaseItemLabelsVisible(true);
        java.awt.Shape shape41 = statisticalBarRenderer36.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape41, rectangleAnchor42, (double) 100L, (double) 10);
        boolean boolean46 = textTitle29.equals((java.lang.Object) 100L);
        java.lang.Object obj47 = textTitle29.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 2.0f, (double) 100);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        java.awt.Color color7 = java.awt.Color.red;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        legendGraphic8.setShapeVisible(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer11.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = statisticalBarRenderer19.getLegendItemLabelGenerator();
        statisticalBarRenderer11.setLegendItemLabelGenerator(categorySeriesLabelGenerator20);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer22.setBaseItemLabelsVisible(true);
        java.awt.Shape shape27 = statisticalBarRenderer22.getBaseShape();
        statisticalBarRenderer11.setBaseShape(shape27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle29.setLegendItemGraphicAnchor(rectangleAnchor30);
        legendGraphic8.setShapeAnchor(rectangleAnchor30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean35 = statisticalBarRenderer33.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer33.removeAnnotations();
        statisticalBarRenderer33.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator40 = statisticalBarRenderer33.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer33.setBaseOutlineStroke(stroke41, false);
        legendGraphic8.setOutlineStroke(stroke41);
        legendGraphic8.setShapeOutlineVisible(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.TickType tickType13 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18);
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType13, 0.0d, "ItemLabelAnchor.OUTSIDE12", textAnchor16, textAnchor18, (double) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12, textAnchor18, 1.0d);
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(64, itemLabelPosition23, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer26);
        double double28 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (byte) 100, false);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range0, 1.0d);
        double double6 = range0.getLength();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        int int6 = color5.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font4, (java.awt.Paint) color5);
        java.lang.String str8 = labelBlock7.getToolTipText();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer11.setSeriesItemLabelPaint(64, (java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.getColor("hi!", color18);
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = color18.getRGBComponents(floatArray22);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color18);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("LengthConstraintType.NONE", font9);
        java.awt.Color color27 = java.awt.Color.yellow;
        int int28 = color27.getAlpha();
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font9, (java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj25 = jFreeChart24.getTextAntiAlias();
        int int26 = jFreeChart24.getSubtitleCount();
        java.awt.Stroke stroke27 = jFreeChart24.getBorderStroke();
        java.awt.RenderingHints renderingHints28 = jFreeChart24.getRenderingHints();
        jFreeChart24.setTitle("EXPAND");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(renderingHints28);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit1, false, false);
        double double5 = numberAxis0.getLowerMargin();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        statisticalBarRenderer9.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer9.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = statisticalBarRenderer17.getLegendItemLabelGenerator();
        statisticalBarRenderer9.setLegendItemLabelGenerator(categorySeriesLabelGenerator18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.Range range22 = categoryPlot20.getDataRange(valueAxis21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot20.getInsets();
        java.util.List list24 = categoryPlot20.getCategories();
        boolean boolean25 = categoryPlot20.isSubplot();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str28 = layer27.toString();
        java.util.Collection collection29 = categoryPlot20.getRangeMarkers((int) (short) 10, layer27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot20);
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color33 = java.awt.Color.DARK_GRAY;
        int int34 = color33.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("", font32, (java.awt.Paint) color33);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double38 = rectangleInsets36.calculateTopOutset((double) (byte) 1);
        labelBlock35.setPadding(rectangleInsets36);
        jFreeChart30.setPadding(rectangleInsets36);
        jFreeChart30.setBackgroundImageAlignment((int) ' ');
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) double5, jFreeChart30, (int) (short) -1, 500);
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Layer.FOREGROUND" + "'", str28.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 64 + "'", int34 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerBound();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis0.getStandardTickUnits();
        java.text.NumberFormat numberFormat3 = numberAxis0.getNumberFormatOverride();
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        java.awt.Font font5 = numberAxis0.getLabelFont();
        numberAxis0.zoomRange(0.0d, 5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator19);
        java.awt.Paint paint22 = statisticalBarRenderer0.getSeriesFillPaint((int) (byte) -1);
        int int23 = statisticalBarRenderer0.getPassCount();
        java.awt.Paint paint24 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.DARK_GRAY;
        int int4 = color3.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font2, (java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double8 = rectangleInsets6.calculateTopOutset((double) (byte) 1);
        labelBlock5.setPadding(rectangleInsets6);
        java.awt.Font font10 = labelBlock5.getFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font10);
        java.lang.String str12 = textTitle11.getID();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat14 = numberAxis13.getNumberFormatOverride();
        java.awt.Font font15 = numberAxis13.getTickLabelFont();
        textTitle11.setFont(font15);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNotNull(font15);
    }
}

