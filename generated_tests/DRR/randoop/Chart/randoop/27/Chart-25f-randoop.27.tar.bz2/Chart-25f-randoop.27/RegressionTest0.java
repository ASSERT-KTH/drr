import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 100, (double) 10L, (int) ' ', (java.lang.Comparable) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, 0.0f, (float) 'a', 0.0d, (float) (-1), (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) '4', (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 100.0f, (java.lang.Object) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        java.awt.Paint paint9 = null;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Paint paint14 = null;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "", "", "hi!", false, shape5, true, paint7, false, paint9, stroke10, true, shape12, stroke13, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.TickLabelEntity tickLabelEntity3 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1L), (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE12" + "'", str1.equals("ItemLabelAnchor.OUTSIDE12"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint2 = null;
        try {
            statisticalBarRenderer0.setBaseFillPaint(paint2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        java.awt.Stroke stroke4 = null;
        try {
            statisticalBarRenderer0.setBaseOutlineStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 100.0f, numberFormat1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        boolean boolean15 = statisticalBarRenderer9.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font16 = statisticalBarRenderer9.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 100, font16, false);
        org.jfree.chart.block.Arrangement arrangement19 = null;
        org.jfree.chart.block.Arrangement arrangement20 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0, arrangement19, arrangement20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        textLine2.draw(graphics2D3, (float) (byte) 0, 1.0f, textAnchor6, 0.0f, (float) (short) 100, (-1.0d));
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType12 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor6, (double) 0L, categoryLabelWidthType12, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            statisticalBarRenderer0.addChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color1 = color0.darker();
        float[] floatArray4 = new float[] { 1.0f, 10.0f };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) 1.0f);
        boolean boolean4 = textBlockAnchor0.equals((java.lang.Object) 2.0f);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.lang.String str5 = labelBlock4.getToolTipText();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = labelBlock4.arrange(graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Shape shape5 = statisticalBarRenderer0.getBaseShape();
        statisticalBarRenderer0.setMaximumBarWidth((double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getNegativeItemLabelPosition(15, 1);
        double double4 = itemLabelPosition3.getAngle();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Shape shape5 = statisticalBarRenderer0.getBaseShape();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity11 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "hi!", "", categoryDataset8, (java.lang.Comparable) (short) 10, (java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
//        org.junit.Assert.assertNull(uRL2);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        statisticalBarRenderer0.setSeriesVisible(64, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        try {
            keyedObjects2D0.removeColumn(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1L, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 1, (double) (byte) 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer7.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, true);
        boolean boolean12 = statisticalBarRenderer0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ItemLabelAnchor.OUTSIDE12", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            statisticalBarRenderer0.drawOutline(graphics2D1, categoryPlot2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) (byte) 0, (float) (short) 1, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, true);
        statisticalBarRenderer0.setBaseSeriesVisible(false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color7 = java.awt.Color.DARK_GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        java.awt.Paint paint10 = labelBlock9.getPaint();
        java.lang.String str11 = labelBlock9.getID();
        java.lang.String str12 = labelBlock9.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D13 = labelBlock9.getBounds();
        java.lang.Object obj14 = null;
        try {
            java.lang.Object obj15 = legendItemBlockContainer3.draw(graphics2D4, rectangle2D13, obj14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 64 + "'", int8 == 64);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) (short) 10, 2, (java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        int int12 = color11.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color11);
        statisticalBarRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color11, false);
        java.awt.Paint paint17 = null;
        try {
            statisticalBarRenderer0.setSeriesPaint((-1), paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 64 + "'", int12 == 64);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) 0, (float) (short) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("GradientPaintTransformType.VERTICAL", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ItemLabelAnchor.OUTSIDE12", graphics2D1, 0.0f, 10.0f, textAnchor4, (double) (short) 0, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) (byte) 1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean6 = flowArrangement4.equals((java.lang.Object) itemLabelAnchor5);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.lang.String str5 = labelBlock4.getToolTipText();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color8 = java.awt.Color.DARK_GRAY;
        int int9 = color8.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font7, (java.awt.Paint) color8);
        boolean boolean11 = labelBlock4.equals((java.lang.Object) labelBlock10);
        labelBlock4.setWidth((double) 1.0f);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 64 + "'", int9 == 64);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str1.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.lang.String str5 = labelBlock4.getToolTipText();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color8 = java.awt.Color.DARK_GRAY;
        int int9 = color8.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font7, (java.awt.Paint) color8);
        boolean boolean11 = labelBlock4.equals((java.lang.Object) labelBlock10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = labelBlock4.arrange(graphics2D12, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 64 + "'", int9 == 64);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = plotRenderingInfo1.getPlotArea();
        java.lang.Object obj3 = plotRenderingInfo1.clone();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = plotRenderingInfo1.getSubplotInfo(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects0.getIndex(comparable1);
        int int4 = keyedObjects0.getIndex((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.calculateTopInset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE6" + "'", str1.equals("ItemLabelAnchor.INSIDE6"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "ItemLabelAnchor.OUTSIDE12", textAnchor3, textAnchor5, (double) 10);
        java.lang.String str9 = numberTick8.toString();
        org.jfree.chart.axis.TickType tickType10 = numberTick8.getTickType();
        java.lang.String str11 = numberTick8.getText();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ItemLabelAnchor.OUTSIDE12" + "'", str9.equals("ItemLabelAnchor.OUTSIDE12"));
        org.junit.Assert.assertNull(tickType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ItemLabelAnchor.OUTSIDE12" + "'", str11.equals("ItemLabelAnchor.OUTSIDE12"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        boolean boolean15 = statisticalBarRenderer9.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font16 = statisticalBarRenderer9.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 100, font16, false);
        statisticalBarRenderer0.removeAnnotations();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT", (double) 15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            categoryPlot14.addDomainMarker(categoryMarker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNotNull(layer20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.2d, numberFormat1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot14.setDataset(categoryDataset15);
        boolean boolean17 = categoryPlot14.isRangeZoomable();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.addFragment(textFragment1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        java.lang.String str7 = labelBlock6.getToolTipText();
        java.awt.Font font8 = labelBlock6.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean12 = statisticalBarRenderer10.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer10.removeAnnotations();
        statisticalBarRenderer10.setAutoPopulateSeriesStroke(false);
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer10.setSeriesItemLabelPaint(64, (java.awt.Paint) color17);
        java.awt.Color color19 = java.awt.Color.getColor("hi!", color17);
        java.awt.Color color20 = java.awt.Color.GREEN;
        float[] floatArray21 = null;
        float[] floatArray22 = color20.getColorComponents(floatArray21);
        float[] floatArray23 = color17.getRGBComponents(floatArray21);
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font8, (java.awt.Paint) color17);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("", font8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = null;
        try {
            textTitle25.setVerticalAlignment(verticalAlignment26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 64 + "'", int5 == 64);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(0, categoryURLGenerator7, false);
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("TextBlockAnchor.CENTER_LEFT", (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) (byte) 1);
        try {
            java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) flowArrangement4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=64,g=64,b=255]", graphics2D1, (float) (short) 0, (float) 10L, 0.0d, (float) 100L, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) "");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions();
        boolean boolean5 = legendItemBlockContainer3.equals((java.lang.Object) categoryLabelPositions4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        int int18 = color17.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font16, (java.awt.Paint) color17);
        java.awt.Paint paint20 = labelBlock19.getPaint();
        java.lang.String str21 = labelBlock19.getID();
        java.lang.String str22 = labelBlock19.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D23 = labelBlock19.getBounds();
        boolean boolean24 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D14, rectangle2D23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double28 = statisticalBarRenderer27.getItemMargin();
        statisticalBarRenderer27.setSeriesItemLabelsVisible(64, (java.lang.Boolean) false);
        java.awt.Paint paint34 = statisticalBarRenderer27.getItemLabelPaint((int) (short) 100, 15);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=64,g=64,b=255]", "TextAnchor.CENTER", "TextAnchor.BOTTOM_LEFT", (java.awt.Shape) rectangle2D23, (java.awt.Paint) color25, stroke26, paint34);
        try {
            legendItemBlockContainer3.draw(graphics2D6, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("ItemLabelAnchor.OUTSIDE12");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ItemLabelAnchor.OUTSIDE12");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextAnchor.BOTTOM_LEFT", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot14.getRendererForDataset(categoryDataset19);
        categoryPlot14.setRangeCrosshairLockedOnData(false);
        java.awt.Font font23 = null;
        try {
            categoryPlot14.setNoDataMessageFont(font23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(categoryItemRenderer20);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        statisticalBarRenderer0.setMinimumBarLength(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryLabelWidthType.RANGE", graphics2D1, (float) 1L, (float) (short) 1, textAnchor4, (double) ' ', (float) (byte) 0, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", "CategoryLabelWidthType.RANGE");
        java.lang.Object obj5 = null;
        boolean boolean6 = library4.equals(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer1.removeAnnotations();
        boolean boolean7 = statisticalBarRenderer1.isItemLabelVisible((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer1.getBaseItemLabelGenerator();
        statisticalBarRenderer1.setItemMargin((double) 1.0f);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        statisticalBarRenderer1.setSeriesURLGenerator(1, categoryURLGenerator12);
        boolean boolean14 = textAnchor0.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.awt.Paint paint5 = labelBlock4.getPaint();
        java.lang.String str6 = labelBlock4.getID();
        java.lang.String str7 = labelBlock4.getToolTipText();
        double double8 = labelBlock4.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) (byte) 1);
        java.lang.Object obj5 = new java.lang.Object();
        boolean boolean6 = flowArrangement4.equals(obj5);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, (double) 2.0f, (double) 100);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        boolean boolean14 = flowArrangement4.equals((java.lang.Object) shape12);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        shapeList0.clear();
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        boolean boolean7 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation6);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener8 = null;
        try {
            statisticalBarRenderer0.addChangeListener(rendererChangeListener8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        java.lang.Object obj2 = shapeList0.clone();
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone(obj2);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("TextBlockAnchor.CENTER_LEFT", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("CategoryLabelWidthType.RANGE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key CategoryLabelWidthType.RANGE");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects0.getIndex(comparable1);
        java.util.List list3 = keyedObjects0.getKeys();
        try {
            keyedObjects0.removeValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        try {
            statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(15);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = null;
        try {
            categoryPlot14.setOrientation(plotOrientation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(10, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo2.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = axisSpace0.shrink(rectangle2D4, rectangle2D5);
        try {
            java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D5, 0.2d, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            boolean boolean19 = categoryPlot14.removeAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = null;
        try {
            numberAxis0.setDefaultAutoRange(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        java.awt.Paint paint7 = labelBlock6.getPaint();
        java.lang.String str8 = labelBlock6.getID();
        java.lang.String str9 = labelBlock6.getToolTipText();
        boolean boolean10 = standardGradientPaintTransformer0.equals((java.lang.Object) str9);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 64 + "'", int5 == 64);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        categoryPlot14.setOutlineVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot14.setRenderer(categoryItemRenderer19, false);
        categoryPlot14.setRangeCrosshairValue((double) 64);
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        try {
            categoryPlot14.setRangeAxisLocation(axisLocation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        int int11 = color10.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color10);
        java.awt.Paint paint13 = labelBlock12.getPaint();
        java.lang.String str14 = labelBlock12.getID();
        java.lang.String str15 = labelBlock12.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock12.getBounds();
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D7, rectangle2D16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double21 = statisticalBarRenderer20.getItemMargin();
        statisticalBarRenderer20.setSeriesItemLabelsVisible(64, (java.lang.Boolean) false);
        java.awt.Paint paint27 = statisticalBarRenderer20.getItemLabelPaint((int) (short) 100, 15);
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=64,g=64,b=255]", "TextAnchor.CENTER", "TextAnchor.BOTTOM_LEFT", (java.awt.Shape) rectangle2D16, (java.awt.Paint) color18, stroke19, paint27);
        boolean boolean29 = legendItem28.isLineVisible();
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 64 + "'", int11 == 64);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot14.setDataset(categoryDataset15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot14.getDomainGridlinePosition();
        double double18 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot14.getDomainAxisEdge((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot14.getColumnRenderingOrder();
        java.lang.String str22 = sortOrder21.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "SortOrder.ASCENDING" + "'", str22.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("ItemLabelAnchor.INSIDE6");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ItemLabelAnchor.INSIDE6");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer0.getNegativeItemLabelPosition(1, (int) (byte) 0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType12 = standardGradientPaintTransformer11.getType();
        statisticalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean16 = statisticalBarRenderer14.isSeriesItemLabelsVisible(0);
        boolean boolean17 = standardGradientPaintTransformer11.equals((java.lang.Object) boolean16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(gradientPaintTransformType12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (byte) 100, (-1.0d), 1, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        java.lang.String str4 = legendItemBlockContainer3.getURLText();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            legendItemBlockContainer3.setMargin(rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font7 = statisticalBarRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        boolean boolean11 = statisticalBarRenderer0.getItemVisible((int) (short) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.DARK_GRAY;
        int int4 = color3.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font2, (java.awt.Paint) color3);
        java.lang.String str6 = labelBlock5.getToolTipText();
        java.awt.Font font7 = labelBlock5.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        statisticalBarRenderer9.setAutoPopulateSeriesStroke(false);
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer9.setSeriesItemLabelPaint(64, (java.awt.Paint) color16);
        java.awt.Color color18 = java.awt.Color.getColor("hi!", color16);
        java.awt.Color color19 = java.awt.Color.GREEN;
        float[] floatArray20 = null;
        float[] floatArray21 = color19.getColorComponents(floatArray20);
        float[] floatArray22 = color16.getRGBComponents(floatArray20);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font7, (java.awt.Paint) color16);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            textLine23.draw(graphics2D24, (float) 0, (float) (short) 1, textAnchor27, (float) (byte) -1, 2.0f, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.chart.event.ChartChangeListener chartChangeListener25 = null;
        try {
            jFreeChart24.removeChangeListener(chartChangeListener25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        textLine2.draw(graphics2D3, (float) (byte) 0, 1.0f, textAnchor6, 0.0f, (float) (short) 100, (-1.0d));
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType12 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor6, 0.05d, categoryLabelWidthType12, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("CategoryLabelWidthType.RANGE", (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        boolean boolean15 = statisticalBarRenderer9.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font16 = statisticalBarRenderer9.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 100, font16, false);
        java.awt.Paint paint20 = null;
        statisticalBarRenderer0.setSeriesPaint((int) '4', paint20, true);
        java.awt.Paint paint25 = statisticalBarRenderer0.getItemLabelPaint((int) '#', (int) '4');
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer30.removeAnnotations();
        statisticalBarRenderer30.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer30.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = statisticalBarRenderer38.getLegendItemLabelGenerator();
        statisticalBarRenderer30.setLegendItemLabelGenerator(categorySeriesLabelGenerator39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.data.Range range43 = categoryPlot41.getDataRange(valueAxis42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryPlot41.getInsets();
        java.util.List list45 = categoryPlot41.getCategories();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        categoryPlot41.setDataset(categoryDataset46);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = null;
        org.jfree.chart.axis.AxisSpace axisSpace50 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo51);
        java.awt.geom.Rectangle2D rectangle2D53 = plotRenderingInfo52.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D54 = plotRenderingInfo52.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = axisSpace50.shrink(rectangle2D54, rectangle2D55);
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D26, categoryPlot41, categoryAxis48, categoryMarker49, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(list45);
        org.junit.Assert.assertNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer19.removeAnnotations();
        statisticalBarRenderer19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = statisticalBarRenderer19.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer19.setBaseOutlineStroke(stroke27, false);
        categoryPlot14.setDomainGridlineStroke(stroke27);
        double double31 = categoryPlot14.getAnchorValue();
        int int32 = categoryPlot14.getRangeAxisCount();
        java.awt.Font font33 = null;
        try {
            categoryPlot14.setNoDataMessageFont(font33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot15.setDataset(categoryDataset16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        boolean boolean20 = numberAxis0.hasListener((java.util.EventListener) categoryPlot15);
        numberAxis0.setAutoRangeMinimumSize((double) 100, true);
        org.jfree.data.Range range24 = null;
        try {
            numberAxis0.setRangeWithMargins(range24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        boolean boolean7 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = statisticalBarRenderer0.getBaseURLGenerator();
        org.jfree.data.general.Dataset dataset7 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) statisticalBarRenderer0, dataset7);
        org.jfree.data.general.Dataset dataset9 = datasetChangeEvent8.getDataset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
        org.junit.Assert.assertNull(dataset9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "SortOrder.ASCENDING", (java.lang.Object) "java.awt.Color[r=64,g=64,b=255]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("GradientPaintTransformType.VERTICAL", (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer19.removeAnnotations();
        statisticalBarRenderer19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = statisticalBarRenderer19.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer19.setBaseOutlineStroke(stroke27, false);
        categoryPlot14.setDomainGridlineStroke(stroke27);
        double double31 = categoryPlot14.getAnchorValue();
        int int32 = categoryPlot14.getRangeAxisCount();
        boolean boolean33 = categoryPlot14.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        java.awt.Stroke stroke8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!", "SortOrder.ASCENDING", "Layer.FOREGROUND", "ItemLabelAnchor.INSIDE6", (java.awt.Shape) rectangle2D7, stroke8, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("{0}", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer1.setBaseItemLabelsVisible(true);
        java.awt.Shape shape6 = statisticalBarRenderer1.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean19 = statisticalBarRenderer17.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer17.removeAnnotations();
        statisticalBarRenderer17.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer17.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer25.getLegendItemLabelGenerator();
        statisticalBarRenderer17.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot28.getDataRange(valueAxis29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        java.util.List list32 = categoryPlot28.getCategories();
        boolean boolean33 = categoryPlot28.isSubplot();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        java.util.Collection collection37 = categoryPlot28.getRangeMarkers((int) (short) 10, layer35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        jFreeChart38.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryLabelPositions0, jFreeChart38, (int) (byte) 10, 10);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        try {
            jFreeChart38.draw(graphics2D44, rectangle2D45, chartRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection37);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        double double2 = numberAxis0.getUpperMargin();
        numberAxis0.setAxisLineVisible(true);
        org.jfree.data.Range range5 = null;
        try {
            numberAxis0.setRange(range5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        java.util.List list9 = keyedObjects2D0.getRowKeys();
        try {
            keyedObjects2D0.removeRow(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        java.lang.String str4 = legendItemBlockContainer3.getToolTipText();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (short) 1);
        org.jfree.chart.ui.Licences licences2 = new org.jfree.chart.ui.Licences();
        boolean boolean3 = categoryLabelPositions1.equals((java.lang.Object) licences2);
        java.lang.String str4 = licences2.getLGPL();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer1.setBaseItemLabelsVisible(true);
        java.awt.Shape shape6 = statisticalBarRenderer1.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean19 = statisticalBarRenderer17.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer17.removeAnnotations();
        statisticalBarRenderer17.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer17.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer25.getLegendItemLabelGenerator();
        statisticalBarRenderer17.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot28.getDataRange(valueAxis29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        java.util.List list32 = categoryPlot28.getCategories();
        boolean boolean33 = categoryPlot28.isSubplot();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        java.util.Collection collection37 = categoryPlot28.getRangeMarkers((int) (short) 10, layer35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        jFreeChart38.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryLabelPositions0, jFreeChart38, (int) (byte) 10, 10);
        jFreeChart38.fireChartChanged();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean47 = statisticalBarRenderer45.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer45.removeAnnotations();
        statisticalBarRenderer45.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator52 = statisticalBarRenderer45.getSeriesToolTipGenerator(100);
        double double53 = statisticalBarRenderer45.getMaximumBarWidth();
        boolean boolean54 = statisticalBarRenderer45.getBaseCreateEntities();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor55 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor55, textAnchor56);
        double double58 = itemLabelPosition57.getAngle();
        statisticalBarRenderer45.setBasePositiveItemLabelPosition(itemLabelPosition57);
        java.awt.Shape shape60 = statisticalBarRenderer45.getBaseShape();
        try {
            jFreeChart38.setTextAntiAlias((java.lang.Object) shape60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor55);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(shape60);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) "");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions();
        boolean boolean5 = legendItemBlockContainer3.equals((java.lang.Object) categoryLabelPositions4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = categoryLabelPositions4.getLabelPosition(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(categoryLabelPosition7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        double double8 = statisticalBarRenderer0.getMaximumBarWidth();
        boolean boolean9 = statisticalBarRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor11);
        double double13 = itemLabelPosition12.getAngle();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition12);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        statisticalBarRenderer0.setBaseStroke(stroke15, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        statisticalBarRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects0.getIndex(comparable1);
        java.util.List list3 = keyedObjects0.getKeys();
        java.lang.Object obj5 = keyedObjects0.getObject((int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(itemLabelPosition8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo2.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = axisSpace0.shrink(rectangle2D4, rectangle2D5);
        double double7 = axisSpace0.getRight();
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "Layer.FOREGROUND", "", "java.awt.Color[r=64,g=64,b=255]");
        java.lang.String str5 = library4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        int int6 = color5.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font4, (java.awt.Paint) color5);
        java.lang.String str8 = labelBlock7.getToolTipText();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer11.setSeriesItemLabelPaint(64, (java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.getColor("hi!", color18);
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = color18.getRGBComponents(floatArray22);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font9);
        numberAxis0.setTickLabelFont(font9);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets22.getBottom();
        legendTitle18.setItemLabelPadding(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape7, "ItemLabelAnchor.OUTSIDE12", "ItemLabelAnchor.OUTSIDE12");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean17 = statisticalBarRenderer15.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer15.removeAnnotations();
        statisticalBarRenderer15.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer15.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = statisticalBarRenderer23.getLegendItemLabelGenerator();
        statisticalBarRenderer15.setLegendItemLabelGenerator(categorySeriesLabelGenerator24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = categoryPlot26.getDataRange(valueAxis27);
        categoryPlot26.setOutlineVisible(false);
        java.awt.Paint paint31 = categoryPlot26.getOutlinePaint();
        java.awt.Color color33 = java.awt.Color.orange;
        int int34 = color33.getBlue();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape36 = defaultDrawingSupplier35.getNextShape();
        java.awt.Stroke stroke37 = defaultDrawingSupplier35.getNextOutlineStroke();
        java.awt.Font font42 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        int int44 = color43.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("", font42, (java.awt.Paint) color43);
        java.lang.String str46 = labelBlock45.getToolTipText();
        java.awt.Font font47 = labelBlock45.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer49 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean51 = statisticalBarRenderer49.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer49.removeAnnotations();
        statisticalBarRenderer49.setAutoPopulateSeriesStroke(false);
        java.awt.Color color56 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer49.setSeriesItemLabelPaint(64, (java.awt.Paint) color56);
        java.awt.Color color58 = java.awt.Color.getColor("hi!", color56);
        java.awt.Color color59 = java.awt.Color.GREEN;
        float[] floatArray60 = null;
        float[] floatArray61 = color59.getColorComponents(floatArray60);
        float[] floatArray62 = color56.getRGBComponents(floatArray60);
        org.jfree.chart.text.TextLine textLine63 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font47, (java.awt.Paint) color56);
        org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("", font47);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent67 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis66);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo69);
        java.awt.geom.Rectangle2D rectangle2D71 = plotRenderingInfo70.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D72 = plotRenderingInfo70.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType73 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = null;
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets68.createAdjustedRectangle(rectangle2D72, lengthAdjustmentType73, lengthAdjustmentType74);
        numberAxis66.setLeftArrow((java.awt.Shape) rectangle2D72);
        textTitle64.draw(graphics2D65, rectangle2D72);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer78 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean80 = statisticalBarRenderer78.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer78.removeAnnotations();
        statisticalBarRenderer78.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator85 = statisticalBarRenderer78.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke86 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer78.setBaseOutlineStroke(stroke86, false);
        java.awt.Paint paint89 = null;
        try {
            org.jfree.chart.LegendItem legendItem90 = new org.jfree.chart.LegendItem(attributedString0, "SortOrder.ASCENDING", "TextAnchor.CENTER", "Layer.FOREGROUND", true, shape7, true, paint31, true, (java.awt.Paint) color33, stroke37, false, (java.awt.Shape) rectangle2D72, stroke86, paint89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator24);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 64 + "'", int44 == 64);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNull(rectangle2D71);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator85);
        org.junit.Assert.assertNotNull(stroke86);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart1, (int) 'a', (int) (short) 10);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartProgressEvent4.setChart(jFreeChart5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.getHeight();
        size2D2.setWidth((double) 0);
        size2D2.setHeight((double) (-1.0f));
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color0 = java.awt.Color.lightGray;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getBottom();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color8 = java.awt.Color.DARK_GRAY;
        int int9 = color8.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font7, (java.awt.Paint) color8);
        java.awt.Paint paint11 = labelBlock10.getPaint();
        java.lang.String str12 = labelBlock10.getID();
        java.lang.String str13 = labelBlock10.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock10.getBounds();
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D5, rectangle2D14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets0.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType16, lengthAdjustmentType17);
        double double20 = rectangleInsets0.extendHeight(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 64 + "'", int9 == 64);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.0d + "'", double20 == 3.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        categoryPlot14.setOutlineVisible(false);
        java.awt.Paint paint19 = categoryPlot14.getOutlinePaint();
        boolean boolean20 = categoryPlot14.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot14.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot14.getDomainAxis((int) (byte) 100);
        categoryPlot14.setForegroundAlpha((float) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot14.getRangeAxisEdge((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        boolean boolean11 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        try {
            keyedObjects2D0.removeRow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font7 = statisticalBarRenderer0.getBaseItemLabelFont();
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getItemOutlineStroke((int) (short) -1, (-1));
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean19 = statisticalBarRenderer17.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer17.removeAnnotations();
        statisticalBarRenderer17.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer17.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer25.getLegendItemLabelGenerator();
        statisticalBarRenderer17.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot28.getDataRange(valueAxis29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        java.util.List list32 = categoryPlot28.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace33 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = plotRenderingInfo35.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D37 = plotRenderingInfo35.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = axisSpace33.shrink(rectangle2D37, rectangle2D38);
        double double40 = axisSpace33.getTop();
        categoryPlot28.setFixedRangeAxisSpace(axisSpace33);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean44 = statisticalBarRenderer42.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer42.removeAnnotations();
        statisticalBarRenderer42.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = statisticalBarRenderer42.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer42.setBaseOutlineStroke(stroke50, false);
        categoryPlot28.setRangeGridlineStroke(stroke50);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        try {
            statisticalBarRenderer0.drawRangeGridline(graphics2D13, categoryPlot28, valueAxis54, rectangle2D55, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator49);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Shape shape5 = statisticalBarRenderer0.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = categoryLabelPositions13.getLabelPosition(rectangleEdge14);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge18);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = categoryLabelPositions17.getLabelPosition(rectangleEdge18);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition11, categoryLabelPosition12, categoryLabelPosition16, categoryLabelPosition20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean25 = statisticalBarRenderer23.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer23.setBaseItemLabelsVisible(true);
        java.awt.Shape shape28 = statisticalBarRenderer23.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition34 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor29, textBlockAnchor33);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions22, categoryLabelPosition34);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer37.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer37.setBaseItemLabelsVisible(true);
        java.awt.Shape shape42 = statisticalBarRenderer37.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape42, rectangleAnchor43, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor47 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition48 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor43, textBlockAnchor47);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions49 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions36, categoryLabelPosition48);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition50 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions51 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition12, categoryLabelPosition34, categoryLabelPosition48, categoryLabelPosition50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(categoryLabelPosition16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(categoryLabelPosition20);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(textBlockAnchor47);
        org.junit.Assert.assertNotNull(categoryLabelPositions49);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        jFreeChart24.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        try {
            java.awt.image.BufferedImage bufferedImage31 = jFreeChart24.createBufferedImage(1, (int) (short) 10, (-1), chartRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        double double2 = numberAxis0.getUpperMargin();
        java.awt.Stroke stroke3 = numberAxis0.getTickMarkStroke();
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean4 = statisticalBarRenderer2.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer2.removeAnnotations();
        statisticalBarRenderer2.setAutoPopulateSeriesStroke(false);
        java.awt.Color color9 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer2.setSeriesItemLabelPaint(64, (java.awt.Paint) color9);
        java.awt.Color color11 = java.awt.Color.getColor("hi!", color9);
        float[] floatArray19 = new float[] { (byte) -1, (-1), 100.0f, 2 };
        float[] floatArray20 = java.awt.Color.RGBtoHSB((-1), 0, (int) (short) 0, floatArray19);
        float[] floatArray21 = color11.getComponents(floatArray19);
        java.awt.Color color22 = java.awt.Color.orange;
        java.awt.Paint paint23 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color11, color22, paint23 };
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        java.awt.Shape[] shapeArray30 = new java.awt.Shape[] { shape29 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray24, strokeArray25, strokeArray26, shapeArray30);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shapeArray30);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = java.awt.Color.GREEN;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getColorComponents(floatArray2);
        try {
            float[] floatArray4 = color0.getComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = plotRenderingInfo1.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getDataArea();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = plotRenderingInfo1.getSubplotInfo((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setLicenceName("SortOrder.ASCENDING");
        org.jfree.chart.ui.Library library7 = new org.jfree.chart.ui.Library("", "TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", "CategoryLabelWidthType.RANGE");
        java.lang.String str8 = library7.getInfo();
        basicProjectInfo0.addLibrary(library7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str8.equals("CategoryLabelWidthType.RANGE"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) true);
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) ' ', (java.lang.Boolean) true, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("TextAnchor.CENTER", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 100, (double) 0.95f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color1 = java.awt.Color.getColor("{0}");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis0);
        numberAxis0.setLabelURL("hi!");
        java.text.NumberFormat numberFormat4 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerBound();
        numberAxis0.setPositiveArrowVisible(true);
        numberAxis0.resizeRange((double) 1.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) -1, (float) 10, (double) (byte) 0, (float) (short) 10, (float) (-1L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot15.setDataset(categoryDataset16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        boolean boolean20 = numberAxis0.hasListener((java.util.EventListener) categoryPlot15);
        numberAxis0.setAutoRangeMinimumSize((double) 100, true);
        double double24 = numberAxis0.getLowerMargin();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis0.setDownArrow(shape25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer1.setBaseItemLabelsVisible(true);
        java.awt.Shape shape6 = statisticalBarRenderer1.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean19 = statisticalBarRenderer17.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer17.removeAnnotations();
        statisticalBarRenderer17.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer17.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer25.getLegendItemLabelGenerator();
        statisticalBarRenderer17.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot28.getDataRange(valueAxis29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        java.util.List list32 = categoryPlot28.getCategories();
        boolean boolean33 = categoryPlot28.isSubplot();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        java.util.Collection collection37 = categoryPlot28.getRangeMarkers((int) (short) 10, layer35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        jFreeChart38.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryLabelPositions0, jFreeChart38, (int) (byte) 10, 10);
        try {
            org.jfree.chart.title.Title title45 = jFreeChart38.getSubtitle(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection37);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer1.setBaseItemLabelsVisible(true);
        java.awt.Shape shape6 = statisticalBarRenderer1.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean19 = statisticalBarRenderer17.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer17.removeAnnotations();
        statisticalBarRenderer17.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer17.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer25.getLegendItemLabelGenerator();
        statisticalBarRenderer17.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot28.getDataRange(valueAxis29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        java.util.List list32 = categoryPlot28.getCategories();
        boolean boolean33 = categoryPlot28.isSubplot();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        java.util.Collection collection37 = categoryPlot28.getRangeMarkers((int) (short) 10, layer35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        jFreeChart38.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryLabelPositions0, jFreeChart38, (int) (byte) 10, 10);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.data.KeyedObjects2D keyedObjects2D45 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D45.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D45.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable53 = keyedObjects2D45.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        java.awt.geom.Rectangle2D rectangle2D60 = plotRenderingInfo59.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D61 = plotRenderingInfo59.getDataArea();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D61, (java.awt.Paint) color62);
        keyedObjects2D45.addObject((java.lang.Object) rectangle2D61, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        java.awt.geom.Point2D point2D67 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = null;
        try {
            jFreeChart38.draw(graphics2D44, rectangle2D61, point2D67, chartRenderingInfo68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + '#' + "'", comparable53.equals('#'));
        org.junit.Assert.assertNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D16, (java.awt.Paint) color17);
        keyedObjects2D0.addObject((java.lang.Object) rectangle2D16, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int23 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (-1));
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer24 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType25 = standardGradientPaintTransformer24.getType();
        java.lang.String str26 = gradientPaintTransformType25.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.addObject((java.lang.Object) gradientPaintTransformType25, (java.lang.Comparable) numberTickUnit27, (java.lang.Comparable) "SortOrder.ASCENDING");
        try {
            java.lang.Comparable comparable31 = keyedObjects2D0.getRowKey(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str26.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertNotNull(numberTickUnit27);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 1L);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D4.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D4.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable12 = keyedObjects2D4.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo18.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D20, (java.awt.Paint) color21);
        keyedObjects2D4.addObject((java.lang.Object) rectangle2D20, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer30.removeAnnotations();
        statisticalBarRenderer30.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer30.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = statisticalBarRenderer38.getLegendItemLabelGenerator();
        statisticalBarRenderer30.setLegendItemLabelGenerator(categorySeriesLabelGenerator39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.data.Range range43 = categoryPlot41.getDataRange(valueAxis42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryPlot41.getInsets();
        java.util.List list45 = categoryPlot41.getAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean48 = statisticalBarRenderer46.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer46.removeAnnotations();
        statisticalBarRenderer46.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = statisticalBarRenderer46.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer46.setBaseOutlineStroke(stroke54, false);
        categoryPlot41.setDomainGridlineStroke(stroke54);
        double double58 = categoryPlot41.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot41.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo61);
        java.awt.geom.Rectangle2D rectangle2D63 = plotRenderingInfo62.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D64 = plotRenderingInfo62.getDataArea();
        try {
            org.jfree.chart.axis.AxisState axisState65 = categoryAxis1.draw(graphics2D2, (-1.0d), rectangle2D20, rectangle2D26, rectangleEdge60, plotRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + '#' + "'", comparable12.equals('#'));
        org.junit.Assert.assertNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '4');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        java.awt.Paint paint19 = legendTitle18.getBackgroundPaint();
        double double20 = legendTitle18.getContentYOffset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Color color1 = java.awt.Color.getColor("GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        java.awt.Shape shape19 = null;
        statisticalBarRenderer0.setSeriesShape(0, shape19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        double double7 = statisticalBarRenderer0.getLowerClip();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        int int11 = color10.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color10);
        java.lang.String str13 = labelBlock12.getToolTipText();
        java.awt.Font font14 = labelBlock12.getFont();
        boolean boolean15 = statisticalBarRenderer0.equals((java.lang.Object) labelBlock12);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 64 + "'", int11 == 64);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (short) 1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean4 = statisticalBarRenderer2.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer2.setBaseItemLabelsVisible(true);
        java.awt.Shape shape7 = statisticalBarRenderer2.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition13);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot15.setDataset(categoryDataset16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        boolean boolean20 = numberAxis0.hasListener((java.util.EventListener) categoryPlot15);
        numberAxis0.setAutoRangeMinimumSize((double) 100, true);
        double double24 = numberAxis0.getLowerMargin();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo28.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo28.getDataArea();
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color33 = java.awt.Color.DARK_GRAY;
        int int34 = color33.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("", font32, (java.awt.Paint) color33);
        java.awt.Paint paint36 = labelBlock35.getPaint();
        java.lang.String str37 = labelBlock35.getID();
        java.lang.String str38 = labelBlock35.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock35.getBounds();
        boolean boolean40 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D30, rectangle2D39);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo45.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo45.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets43.createAdjustedRectangle(rectangle2D47, lengthAdjustmentType48, lengthAdjustmentType49);
        numberAxis41.setLeftArrow((java.awt.Shape) rectangle2D47);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo54);
        try {
            org.jfree.chart.axis.AxisState axisState56 = numberAxis0.draw(graphics2D25, (double) (-1.0f), rectangle2D30, rectangle2D47, rectangleEdge52, plotRenderingInfo55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 64 + "'", int34 == 64);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = categoryLabelPosition1.getWidthType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryLabelWidthType2);
        boolean boolean4 = itemLabelAnchor0.equals((java.lang.Object) chartChangeEvent3);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        basicProjectInfo0.addOptionalLibrary("ItemLabelAnchor.INSIDE6");
        basicProjectInfo0.setInfo("");
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Range[0.0,1.0]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        java.lang.String str4 = legendItemBlockContainer3.getURLText();
        legendItemBlockContainer3.clear();
        java.lang.Object obj6 = legendItemBlockContainer3.clone();
        org.jfree.chart.block.CenterArrangement centerArrangement7 = new org.jfree.chart.block.CenterArrangement();
        legendItemBlockContainer3.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisSpace axisSpace10 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = axisSpace10.shrink(rectangle2D14, rectangle2D15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Color color18 = java.awt.Color.gray;
        boolean boolean19 = horizontalAlignment17.equals((java.lang.Object) color18);
        try {
            java.lang.Object obj20 = legendItemBlockContainer3.draw(graphics2D9, rectangle2D15, (java.lang.Object) boolean19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str0.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.BOTTOM_LEFT", graphics2D1, (float) 255, (float) 1, textAnchor5, (double) ' ', textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        categoryAxis1.setLabelURL("");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setLabelURL("GradientPaintTransformType.VERTICAL");
        org.jfree.data.KeyedObjects2D keyedObjects2D9 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D9.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D9.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable17 = keyedObjects2D9.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo23.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo23.getDataArea();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D25, (java.awt.Paint) color26);
        keyedObjects2D9.addObject((java.lang.Object) rectangle2D25, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int32 = keyedObjects2D9.getColumnIndex((java.lang.Comparable) (-1));
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType34 = standardGradientPaintTransformer33.getType();
        java.lang.String str35 = gradientPaintTransformType34.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D9.addObject((java.lang.Object) gradientPaintTransformType34, (java.lang.Comparable) numberTickUnit36, (java.lang.Comparable) "SortOrder.ASCENDING");
        numberAxis6.setTickUnit(numberTickUnit36, true, true);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit36, "java.awt.Color[r=64,g=64,b=255]");
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + '#' + "'", comparable17.equals('#'));
        org.junit.Assert.assertNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str35.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertNotNull(numberTickUnit36);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        int int6 = color5.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font4, (java.awt.Paint) color5);
        java.lang.String str8 = labelBlock7.getToolTipText();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer11.setSeriesItemLabelPaint(64, (java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.getColor("hi!", color18);
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = color18.getRGBComponents(floatArray22);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font9);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("Range[0.0,1.0]", font9);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true, false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        double double7 = statisticalBarRenderer0.getLowerClip();
        java.awt.Paint paint9 = statisticalBarRenderer0.lookupSeriesPaint((int) '#');
        java.awt.Paint paint10 = statisticalBarRenderer0.getBaseFillPaint();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat12 = numberAxis11.getNumberFormatOverride();
        double double13 = numberAxis11.getUpperMargin();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        java.awt.Stroke stroke16 = defaultDrawingSupplier14.getNextOutlineStroke();
        numberAxis11.setTickMarkStroke(stroke16);
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke16);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        try {
            keyedObjects2D0.removeColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int3 = java.awt.Color.HSBtoRGB(1.0f, 0.95f, (float) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2244674) + "'", int3 == (-2244674));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot15.getDataRange(valueAxis16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        boolean boolean19 = datasetGroup0.equals((java.lang.Object) categoryPlot15);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.Font font22 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color23 = java.awt.Color.DARK_GRAY;
        int int24 = color23.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font22, (java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double28 = rectangleInsets26.calculateTopOutset((double) (byte) 1);
        labelBlock25.setPadding(rectangleInsets26);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo31.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo31.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets26.createOutsetRectangle(rectangle2D33);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo37.getPlotArea();
        boolean boolean39 = categoryPlot15.render(graphics2D20, rectangle2D34, 0, plotRenderingInfo37);
        java.awt.geom.Point2D point2D40 = null;
        try {
            int int41 = plotRenderingInfo37.getSubplotIndex(point2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 64 + "'", int24 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font7 = statisticalBarRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.DARK_GRAY;
        int int14 = color13.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font12, (java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double18 = rectangleInsets16.calculateTopOutset((double) (byte) 1);
        labelBlock15.setPadding(rectangleInsets16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets16.createOutsetRectangle(rectangle2D23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean30 = statisticalBarRenderer28.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer28.removeAnnotations();
        statisticalBarRenderer28.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer28.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = statisticalBarRenderer36.getLegendItemLabelGenerator();
        statisticalBarRenderer28.setLegendItemLabelGenerator(categorySeriesLabelGenerator37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer28);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.data.Range range41 = categoryPlot39.getDataRange(valueAxis40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryPlot39.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis44.setUpperMargin((double) 1.0f);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat48 = numberAxis47.getNumberFormatOverride();
        double double49 = numberAxis47.getUpperMargin();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape51 = defaultDrawingSupplier50.getNextShape();
        java.awt.Stroke stroke52 = defaultDrawingSupplier50.getNextOutlineStroke();
        numberAxis47.setTickMarkStroke(stroke52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        try {
            statisticalBarRenderer0.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D24, categoryPlot39, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis47, categoryDataset54, 0, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 64 + "'", int14 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNull(numberFormat48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Color color1 = java.awt.Color.getColor("rect");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer3.setWidth((double) (-1L));
        java.awt.Color color6 = java.awt.Color.CYAN;
        boolean boolean7 = legendItemBlockContainer3.equals((java.lang.Object) color6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape9 = defaultDrawingSupplier8.getNextShape();
        java.awt.Stroke stroke10 = defaultDrawingSupplier8.getNextOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color6, stroke10, rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 2.0f, (double) 100);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) 2.0f, 100.0f, (float) (byte) 100);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean19 = statisticalBarRenderer17.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer17.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = statisticalBarRenderer17.getBaseItemLabelGenerator();
        java.awt.Color color23 = java.awt.Color.magenta;
        statisticalBarRenderer17.setBaseOutlinePaint((java.awt.Paint) color23);
        java.awt.Paint paint26 = null;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean32 = statisticalBarRenderer30.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer30.removeAnnotations();
        statisticalBarRenderer30.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer30.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = statisticalBarRenderer38.getLegendItemLabelGenerator();
        statisticalBarRenderer30.setLegendItemLabelGenerator(categorySeriesLabelGenerator39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer30);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.data.Range range43 = categoryPlot41.getDataRange(valueAxis42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryPlot41.getInsets();
        java.util.List list45 = categoryPlot41.getAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean48 = statisticalBarRenderer46.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer46.removeAnnotations();
        statisticalBarRenderer46.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator53 = statisticalBarRenderer46.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer46.setBaseOutlineStroke(stroke54, false);
        categoryPlot41.setDomainGridlineStroke(stroke54);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent60 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis59);
        numberAxis59.setLabelURL("hi!");
        java.awt.Shape shape63 = numberAxis59.getUpArrow();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer64 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean66 = statisticalBarRenderer64.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer64.removeAnnotations();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = statisticalBarRenderer64.getSeriesPositiveItemLabelPosition((int) (short) 100);
        java.awt.Stroke stroke70 = statisticalBarRenderer64.getBaseStroke();
        java.awt.Color color71 = java.awt.Color.DARK_GRAY;
        int int72 = color71.getBlue();
        try {
            org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("java.awt.Color[r=64,g=64,b=255]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "CategoryLabelWidthType.RANGE", false, shape15, true, (java.awt.Paint) color23, false, paint26, stroke54, true, shape63, stroke70, (java.awt.Paint) color71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 64 + "'", int72 == 64);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot15.setDataset(categoryDataset16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        boolean boolean20 = numberAxis0.hasListener((java.util.EventListener) categoryPlot15);
        try {
            numberAxis0.setAutoRangeMinimumSize((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) "");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions();
        boolean boolean5 = legendItemBlockContainer3.equals((java.lang.Object) categoryLabelPositions4);
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color8 = java.awt.Color.DARK_GRAY;
        int int9 = color8.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font7, (java.awt.Paint) color8);
        java.awt.Paint paint11 = labelBlock10.getPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        legendItemBlockContainer3.add((org.jfree.chart.block.Block) labelBlock10, (java.lang.Object) itemLabelAnchor12);
        java.lang.String str14 = legendItemBlockContainer3.getToolTipText();
        legendItemBlockContainer3.setID("Range[0.0,1.0]");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 64 + "'", int9 == 64);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerBound();
        numberAxis0.setPositiveArrowVisible(true);
        numberAxis0.setUpperBound(1.0E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo20.getPlotArea();
        java.lang.Object obj22 = plotRenderingInfo20.clone();
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot14.zoomRangeAxes((double) (byte) -1, plotRenderingInfo20, point2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        try {
            categoryPlot14.setRangeAxisLocation(0, axisLocation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(rectangle2D21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) 1.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        double double3 = statisticalBarRenderer0.getLowerClip();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) '#', categoryURLGenerator5);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str9 = layer8.toString();
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Layer.FOREGROUND" + "'", str9.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getNegativeItemLabelPosition(15, 1);
        java.awt.Paint paint5 = null;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, paint5, true);
        java.lang.Object obj8 = statisticalBarRenderer0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = statisticalBarRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle18.getSources();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj25 = jFreeChart24.getTextAntiAlias();
        org.jfree.chart.event.ChartProgressListener chartProgressListener26 = null;
        jFreeChart24.removeProgressListener(chartProgressListener26);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        boolean boolean2 = categoryLabelWidthType0.equals((java.lang.Object) itemLabelAnchor1);
        java.lang.String str3 = categoryLabelWidthType0.toString();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = statisticalBarRenderer4.getSeriesToolTipGenerator(100);
        double double12 = statisticalBarRenderer4.getMaximumBarWidth();
        boolean boolean13 = statisticalBarRenderer4.getBaseCreateEntities();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor15);
        double double17 = itemLabelPosition16.getAngle();
        statisticalBarRenderer4.setBasePositiveItemLabelPosition(itemLabelPosition16);
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) str3, (java.lang.Object) statisticalBarRenderer4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalBarRenderer4.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str3.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.getHeight();
        size2D2.height = 100;
        java.lang.String str6 = size2D2.toString();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Size2D[width=0.0, height=100.0]" + "'", str6.equals("Size2D[width=0.0, height=100.0]"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 10.0d, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", textAnchor2, textAnchor3, (double) '4');
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 100.0f, (double) (byte) 1);
        textTitle0.setTextAlignment(horizontalAlignment1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        try {
            textTitle0.setVerticalAlignment(verticalAlignment7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 0L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot14.setDataset(categoryDataset15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot14.getDomainGridlinePosition();
        double double18 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot14.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(categoryAxis19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = null;
        textLine0.removeFragment(textFragment1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.TickType tickType8 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor13);
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick(tickType8, 0.0d, "ItemLabelAnchor.OUTSIDE12", textAnchor11, textAnchor13, (double) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor7, textAnchor13, 1.0d);
        textLine0.draw(graphics2D3, (float) 10, (float) 100L, textAnchor7, (float) (byte) 0, (float) 2, 100.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (byte) 10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        categoryPlot14.setOutlineVisible(false);
        java.awt.Paint paint19 = categoryPlot14.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot14.setDataset((int) '#', categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis24.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo30.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions33 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge34);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = categoryLabelPositions33.getLabelPosition(rectangleEdge34);
        boolean boolean37 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge34);
        double double38 = categoryAxis24.getCategoryStart(8, 15, rectangle2D32, rectangleEdge34);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean44 = statisticalBarRenderer42.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer42.removeAnnotations();
        statisticalBarRenderer42.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer42.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator51 = statisticalBarRenderer50.getLegendItemLabelGenerator();
        statisticalBarRenderer42.setLegendItemLabelGenerator(categorySeriesLabelGenerator51);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer42);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        categoryPlot53.setDataset(categoryDataset54);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor56 = categoryPlot53.getDomainGridlinePosition();
        double double57 = categoryPlot53.getRangeCrosshairValue();
        try {
            java.lang.Object obj58 = legendTitle18.draw(graphics2D22, rectangle2D32, (java.lang.Object) double57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(categoryLabelPosition36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator51);
        org.junit.Assert.assertNotNull(categoryAnchor56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        int int11 = color10.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color10);
        java.awt.Paint paint13 = labelBlock12.getPaint();
        java.lang.String str14 = labelBlock12.getID();
        java.lang.String str15 = labelBlock12.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D16 = labelBlock12.getBounds();
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D7, rectangle2D16);
        java.awt.Stroke stroke18 = null;
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) 100L, (float) (-1), (float) '#');
        try {
            org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("Layer.FOREGROUND", "hi!", "", "TextAnchor.BOTTOM_LEFT", (java.awt.Shape) rectangle2D16, stroke18, (java.awt.Paint) color22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 64 + "'", int11 == 64);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean21 = statisticalBarRenderer19.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer19.removeAnnotations();
        statisticalBarRenderer19.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = statisticalBarRenderer19.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer19.setBaseOutlineStroke(stroke27, false);
        categoryPlot14.setDomainGridlineStroke(stroke27);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = null;
        categoryPlot14.notifyListeners(plotChangeEvent31);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerBound();
        java.awt.Shape shape2 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity5 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape2, "TextBlockAnchor.CENTER_LEFT", "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color27 = java.awt.Color.DARK_GRAY;
        int int28 = color27.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("", font26, (java.awt.Paint) color27);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double32 = rectangleInsets30.calculateTopOutset((double) (byte) 1);
        labelBlock29.setPadding(rectangleInsets30);
        jFreeChart24.setPadding(rectangleInsets30);
        java.awt.Paint paint35 = jFreeChart24.getBorderPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 64 + "'", int28 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        statisticalBarRenderer0.setBase(1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        categoryPlot14.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textBlockAnchor0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        boolean boolean4 = chartChangeEventType2.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer1.setBaseItemLabelsVisible(true);
        java.awt.Shape shape6 = statisticalBarRenderer1.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean19 = statisticalBarRenderer17.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer17.removeAnnotations();
        statisticalBarRenderer17.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer17.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer25.getLegendItemLabelGenerator();
        statisticalBarRenderer17.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot28.getDataRange(valueAxis29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        java.util.List list32 = categoryPlot28.getCategories();
        boolean boolean33 = categoryPlot28.isSubplot();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        java.util.Collection collection37 = categoryPlot28.getRangeMarkers((int) (short) 10, layer35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        jFreeChart38.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryLabelPositions0, jFreeChart38, (int) (byte) 10, 10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        java.awt.image.BufferedImage bufferedImage49 = jFreeChart38.createBufferedImage((int) ' ', 10, (double) 1.0f, (double) (short) 10, chartRenderingInfo48);
        org.jfree.data.KeyedObjects keyedObjects50 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable51 = null;
        int int52 = keyedObjects50.getIndex(comparable51);
        java.util.List list53 = keyedObjects50.getKeys();
        jFreeChart38.setSubtitles(list53);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(list32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertNotNull(bufferedImage49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(list53);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        int int6 = color5.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font4, (java.awt.Paint) color5);
        java.lang.String str8 = labelBlock7.getToolTipText();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer11.setSeriesItemLabelPaint(64, (java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.getColor("hi!", color18);
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = color18.getRGBComponents(floatArray22);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font9);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("Layer.FOREGROUND", font9, (java.awt.Paint) color27);
        float float29 = textFragment28.getBaselineOffset();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.CENTER;
        textLine35.draw(graphics2D36, (float) (byte) 0, 1.0f, textAnchor39, 0.0f, (float) (short) 100, (-1.0d));
        java.lang.String str44 = textAnchor39.toString();
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick47 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-1), "SortOrder.ASCENDING", textAnchor39, textAnchor45, 0.0d);
        try {
            textFragment28.draw(graphics2D30, (float) (-1L), (float) 100, textAnchor45, (float) 1L, (float) (byte) 1, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "TextAnchor.CENTER" + "'", str44.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor45);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        int int12 = color11.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color11);
        statisticalBarRenderer0.setSeriesPaint((int) (short) 100, (java.awt.Paint) color11, false);
        java.awt.Shape shape17 = statisticalBarRenderer0.getSeriesShape((int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 64 + "'", int12 == 64);
        org.junit.Assert.assertNull(shape17);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textBlockAnchor0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean8 = statisticalBarRenderer6.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer6.removeAnnotations();
        statisticalBarRenderer6.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer6.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = statisticalBarRenderer14.getLegendItemLabelGenerator();
        statisticalBarRenderer6.setLegendItemLabelGenerator(categorySeriesLabelGenerator15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = categoryPlot17.getDataRange(valueAxis18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot17.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.Range range22 = categoryPlot17.getDataRange(valueAxis21);
        boolean boolean23 = chartChangeEventType2.equals((java.lang.Object) valueAxis21);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        int int6 = color5.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font4, (java.awt.Paint) color5);
        java.lang.String str8 = labelBlock7.getToolTipText();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer11.setSeriesItemLabelPaint(64, (java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.getColor("hi!", color18);
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = color18.getRGBComponents(floatArray22);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font9);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo32.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo32.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets30.createAdjustedRectangle(rectangle2D34, lengthAdjustmentType35, lengthAdjustmentType36);
        numberAxis28.setLeftArrow((java.awt.Shape) rectangle2D34);
        textTitle26.draw(graphics2D27, rectangle2D34);
        java.lang.Object obj40 = null;
        boolean boolean41 = textTitle26.equals(obj40);
        boolean boolean42 = numberTickUnit0.equals((java.lang.Object) boolean41);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets5.calculateTopOutset((double) (byte) 1);
        labelBlock4.setPadding(rectangleInsets5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D12);
        java.lang.String str15 = legendItemEntity14.toString();
        java.lang.Object obj16 = legendItemEntity14.clone();
        org.jfree.data.general.Dataset dataset17 = null;
        legendItemEntity14.setDataset(dataset17);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str15.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer0.getNegativeItemLabelPosition(1, (int) (byte) 0);
        boolean boolean11 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean7 = statisticalBarRenderer5.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer5.removeAnnotations();
        statisticalBarRenderer5.setAutoPopulateSeriesStroke(false);
        java.awt.Color color12 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer5.setSeriesItemLabelPaint(64, (java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.getColor("hi!", color12);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 1L, 0.0d, 10.0d, (double) (byte) -1, (java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis17.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        categoryAxis17.setLabelURL("");
        boolean boolean22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1L, (java.lang.Object) categoryAxis17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets5.calculateTopOutset((double) (byte) 1);
        labelBlock4.setPadding(rectangleInsets5);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createOutsetRectangle(rectangle2D12);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D12);
        java.lang.String str15 = legendItemEntity14.toString();
        java.lang.String str16 = legendItemEntity14.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str15.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str16.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.TickType tickType13 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18);
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType13, 0.0d, "ItemLabelAnchor.OUTSIDE12", textAnchor16, textAnchor18, (double) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12, textAnchor18, 1.0d);
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(64, itemLabelPosition23, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer26);
        double double28 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean31 = statisticalBarRenderer29.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer29.removeAnnotations();
        statisticalBarRenderer29.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = statisticalBarRenderer29.getSeriesToolTipGenerator(100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = statisticalBarRenderer29.getBaseItemLabelGenerator();
        java.awt.Shape shape40 = statisticalBarRenderer29.getItemShape((-1), 500);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape40, (double) 0, 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textBlockAnchor45);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition47 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor44, textBlockAnchor45);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape40, rectangleAnchor44, (double) 1.0f, 1.0E-8d);
        statisticalBarRenderer0.setBaseShape(shape50);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertNull(categoryItemLabelGenerator37);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot14.getDomainAxis();
        java.awt.Paint paint19 = categoryPlot14.getRangeCrosshairPaint();
        int int20 = categoryPlot14.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (double) (short) -1, (float) (-1), (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean9 = statisticalBarRenderer7.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer7.removeAnnotations();
        boolean boolean13 = statisticalBarRenderer7.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font14 = statisticalBarRenderer7.getBaseItemLabelFont();
        statisticalBarRenderer0.setBaseItemLabelFont(font14, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) '#', categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.extendHeight((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj25 = jFreeChart24.getTextAntiAlias();
        java.awt.Image image26 = jFreeChart24.getBackgroundImage();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        jFreeChart24.setBorderStroke(stroke27);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D7, (java.awt.Paint) color8);
        java.lang.Comparable comparable10 = legendItem9.getSeriesKey();
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Layer.FOREGROUND");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Layer.FOREGROUND\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot14.getDomainAxis();
        java.awt.Paint paint19 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot14.setDomainAxisLocation(axisLocation21);
        java.lang.String str23 = axisLocation21.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str23.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        categoryAxis1.setLabelURL("");
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis1.setTickLabelFont(font6);
        double double8 = categoryAxis1.getLowerMargin();
        int int9 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D16, (java.awt.Paint) color17);
        keyedObjects2D0.addObject((java.lang.Object) rectangle2D16, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int23 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 0);
        try {
            java.lang.Comparable comparable25 = keyedObjects2D0.getRowKey((-2244674));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double3 = rectangleInsets0.calculateLeftOutset((-2.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer4.getNegativeItemLabelPosition(1, (int) (byte) 0);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = statisticalBarRenderer0.getBaseURLGenerator();
        org.jfree.data.general.Dataset dataset7 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) statisticalBarRenderer0, dataset7);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryURLGenerator6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        statisticalBarRenderer0.setIncludeBaseInRange(true);
        org.jfree.chart.block.CenterArrangement centerArrangement10 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement10, dataset11, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer13.setWidth((double) (-1L));
        java.awt.Color color16 = java.awt.Color.CYAN;
        boolean boolean17 = legendItemBlockContainer13.equals((java.lang.Object) color16);
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean3 = statisticalBarRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean7 = statisticalBarRenderer5.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer5.removeAnnotations();
        boolean boolean11 = statisticalBarRenderer5.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font12 = statisticalBarRenderer5.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont(0, font12);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis2.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        categoryAxis2.setLabelURL("");
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis2.setTickLabelFont(font7);
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("{0}", font7);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        double double2 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        textLine2.draw(graphics2D3, (float) (byte) 0, 1.0f, textAnchor6, 0.0f, (float) (short) 100, (-1.0d));
        java.lang.String str11 = textAnchor6.toString();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick14 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-1), "SortOrder.ASCENDING", textAnchor6, textAnchor12, 0.0d);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        int int18 = color17.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font16, (java.awt.Paint) color17);
        java.lang.String str20 = labelBlock19.getToolTipText();
        java.awt.Font font21 = labelBlock19.getFont();
        labelBlock19.setToolTipText("hi!");
        boolean boolean24 = numberTick14.equals((java.lang.Object) labelBlock19);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.CENTER" + "'", str11.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 64 + "'", int18 == 64);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot15.getDataRange(valueAxis16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        boolean boolean19 = datasetGroup0.equals((java.lang.Object) categoryPlot15);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo20 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean21 = datasetGroup0.equals((java.lang.Object) basicProjectInfo20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = categoryPlot14.getRangeAxisIndex(valueAxis17);
        java.awt.Paint paint19 = categoryPlot14.getRangeCrosshairPaint();
        int int20 = categoryPlot14.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.DARK_GRAY;
        int int4 = color3.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font2, (java.awt.Paint) color3);
        java.lang.String str6 = labelBlock5.getToolTipText();
        java.awt.Font font7 = labelBlock5.getFont();
        textTitle0.setFont(font7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D16, (java.awt.Paint) color17);
        textTitle0.setPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Shape shape5 = statisticalBarRenderer0.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) 100L, (double) 10);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        java.lang.String str12 = chartEntity11.toString();
        java.lang.String str13 = chartEntity11.getURLText();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartEntity: tooltip = " + "'", str12.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 4);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("LegendItemEntity: seriesKey=null, dataset=null", graphics2D1, (float) 100L, (float) 255, textAnchor4, 0.0d, (float) '4', (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        int int2 = keyedObjects0.getIndex(comparable1);
        java.lang.Comparable comparable3 = null;
        try {
            keyedObjects0.removeValue(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("GradientPaintTransformType.VERTICAL", "ItemLabelAnchor.OUTSIDE12", "TextBlockAnchor.CENTER_LEFT", image3, "GradientPaintTransformType.VERTICAL", "", "Layer.FOREGROUND");
        java.util.List list8 = projectInfo7.getContributors();
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean7 = statisticalBarRenderer5.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer5.removeAnnotations();
        statisticalBarRenderer5.setAutoPopulateSeriesStroke(false);
        java.awt.Color color12 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer5.setSeriesItemLabelPaint(64, (java.awt.Paint) color12);
        java.awt.Color color14 = java.awt.Color.getColor("hi!", color12);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 8, 100.0d, (double) (byte) 1, (-1.0d), (java.awt.Paint) color12);
        int int16 = color12.getRGB();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-12566464) + "'", int16 == (-12566464));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("GradientPaintTransformType.VERTICAL");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextStroke();
        numberAxis0.setAxisLineStroke(stroke4);
        double double6 = numberAxis0.getAutoRangeMinimumSize();
        boolean boolean7 = numberAxis0.isInverted();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean14 = statisticalBarRenderer12.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer12.removeAnnotations();
        statisticalBarRenderer12.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer12.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = statisticalBarRenderer20.getLegendItemLabelGenerator();
        statisticalBarRenderer12.setLegendItemLabelGenerator(categorySeriesLabelGenerator21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.Range range25 = categoryPlot23.getDataRange(valueAxis24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryPlot23.getInsets();
        java.util.List list27 = categoryPlot23.getCategories();
        boolean boolean28 = categoryPlot23.isSubplot();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double30 = rectangleInsets29.getBottom();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo32.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo32.getDataArea();
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color37 = java.awt.Color.DARK_GRAY;
        int int38 = color37.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("", font36, (java.awt.Paint) color37);
        java.awt.Paint paint40 = labelBlock39.getPaint();
        java.lang.String str41 = labelBlock39.getID();
        java.lang.String str42 = labelBlock39.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D43 = labelBlock39.getBounds();
        boolean boolean44 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D34, rectangle2D43);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType45 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets29.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType45, lengthAdjustmentType46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean53 = statisticalBarRenderer51.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer51.removeAnnotations();
        statisticalBarRenderer51.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer51.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer59 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator60 = statisticalBarRenderer59.getLegendItemLabelGenerator();
        statisticalBarRenderer51.setLegendItemLabelGenerator(categorySeriesLabelGenerator60);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer51);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.data.Range range64 = categoryPlot62.getDataRange(valueAxis63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = categoryPlot62.getInsets();
        java.util.List list66 = categoryPlot62.getAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer67 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean69 = statisticalBarRenderer67.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer67.removeAnnotations();
        statisticalBarRenderer67.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator74 = statisticalBarRenderer67.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke75 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer67.setBaseOutlineStroke(stroke75, false);
        categoryPlot62.setDomainGridlineStroke(stroke75);
        double double79 = categoryPlot62.getAnchorValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot62.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.axis.AxisSpace axisSpace82 = new org.jfree.chart.axis.AxisSpace();
        axisSpace82.setLeft((double) 100);
        java.lang.Object obj85 = axisSpace82.clone();
        axisSpace82.setRight((double) ' ');
        try {
            org.jfree.chart.axis.AxisSpace axisSpace88 = numberAxis0.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) categoryPlot23, rectangle2D43, rectangleEdge81, axisSpace82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNull(list27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 64 + "'", int38 == 64);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType45);
        org.junit.Assert.assertNotNull(lengthAdjustmentType46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator60);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(list66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertNotNull(obj85);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.awt.Paint paint5 = labelBlock4.getPaint();
        java.lang.String str6 = labelBlock4.getID();
        java.lang.String str7 = labelBlock4.getToolTipText();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean10 = statisticalBarRenderer8.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer8.removeAnnotations();
        statisticalBarRenderer8.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = statisticalBarRenderer8.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer8.setBaseOutlineStroke(stroke16, false);
        boolean boolean19 = labelBlock4.equals((java.lang.Object) statisticalBarRenderer8);
        java.awt.Paint paint21 = statisticalBarRenderer8.getSeriesItemLabelPaint(3);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer1.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer1.setBaseItemLabelsVisible(true);
        java.awt.Shape shape6 = statisticalBarRenderer1.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = categoryLabelPositions14.getLabelPosition(rectangleEdge15);
        boolean boolean18 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = categoryLabelPositions13.getLabelPosition(rectangleEdge15);
        org.jfree.chart.text.TextAnchor textAnchor20 = categoryLabelPosition19.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(categoryLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition19);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot14.setDataset(categoryDataset15);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(categoryAnchor17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        textLine0.draw(graphics2D1, (float) (byte) 0, 1.0f, textAnchor4, 0.0f, (float) (short) 100, (-1.0d));
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.CENTER;
        textLine14.draw(graphics2D15, (float) (byte) 0, 1.0f, textAnchor18, 0.0f, (float) (short) 100, (-1.0d));
        java.lang.String str23 = textAnchor18.toString();
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick26 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-1), "SortOrder.ASCENDING", textAnchor18, textAnchor24, 0.0d);
        textLine0.draw(graphics2D9, 0.0f, (float) (byte) 1, textAnchor24, (float) 4, (float) (byte) 10, 1.0E-8d);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TextAnchor.CENTER" + "'", str23.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj25 = jFreeChart24.getTextAntiAlias();
        java.awt.Image image26 = jFreeChart24.getBackgroundImage();
        java.lang.Object obj27 = jFreeChart24.getTextAntiAlias();
        try {
            org.jfree.chart.plot.XYPlot xYPlot28 = jFreeChart24.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertNull(obj27);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) "");
        org.jfree.chart.block.BlockContainer blockContainer4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0);
        java.lang.Object obj5 = blockContainer4.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        categoryPlot14.setForegroundAlpha((float) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset23 = categoryPlot14.getDataset(0);
        java.awt.Stroke stroke24 = categoryPlot14.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryDataset23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 3.0d, (java.lang.Number) 4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D16, (java.awt.Paint) color17);
        keyedObjects2D0.addObject((java.lang.Object) rectangle2D16, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int23 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 0);
        keyedObjects2D0.removeObject((java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null", (java.lang.Comparable) 64);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean10 = statisticalBarRenderer8.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer8.removeAnnotations();
        statisticalBarRenderer8.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer8.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalBarRenderer8.getNegativeItemLabelPosition(1, (int) (byte) 0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer19 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType20 = standardGradientPaintTransformer19.getType();
        statisticalBarRenderer8.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer19);
        boolean boolean22 = statisticalBarRenderer0.equals((java.lang.Object) statisticalBarRenderer8);
        boolean boolean23 = statisticalBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(gradientPaintTransformType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        boolean boolean15 = statisticalBarRenderer9.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font16 = statisticalBarRenderer9.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 100, font16, false);
        java.awt.Paint paint20 = null;
        statisticalBarRenderer0.setSeriesPaint((int) '4', paint20, true);
        java.awt.Paint paint25 = statisticalBarRenderer0.getItemLabelPaint((int) '#', (int) '4');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator26 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator26, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot14.setDataset(categoryDataset15);
        boolean boolean17 = categoryPlot14.isRangeZoomable();
        java.awt.Paint paint18 = categoryPlot14.getDomainGridlinePaint();
        boolean boolean19 = categoryPlot14.isOutlineVisible();
        categoryPlot14.setWeight(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getNegativeItemLabelPosition(15, 1);
        statisticalBarRenderer0.setDrawBarOutline(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean8 = statisticalBarRenderer6.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer6.removeAnnotations();
        statisticalBarRenderer6.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer6.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = statisticalBarRenderer14.getLegendItemLabelGenerator();
        statisticalBarRenderer6.setLegendItemLabelGenerator(categorySeriesLabelGenerator15);
        statisticalBarRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator15);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D16, (java.awt.Paint) color17);
        keyedObjects2D0.addObject((java.lang.Object) rectangle2D16, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int23 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (-1));
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer24 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType25 = standardGradientPaintTransformer24.getType();
        java.lang.String str26 = gradientPaintTransformType25.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.addObject((java.lang.Object) gradientPaintTransformType25, (java.lang.Comparable) numberTickUnit27, (java.lang.Comparable) "SortOrder.ASCENDING");
        int int30 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str26.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { "LengthConstraintType.NONE", 3.0d };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { "Size2D[width=0.0, height=100.0]", 10, false, 3 };
        double[] doubleArray9 = new double[] { (short) 0 };
        double[] doubleArray11 = new double[] { (short) 0 };
        double[] doubleArray13 = new double[] { (short) 0 };
        double[] doubleArray15 = new double[] { (short) 0 };
        double[][] doubleArray16 = new double[][] { doubleArray9, doubleArray11, doubleArray13, doubleArray15 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray2, comparableArray7, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.lang.String str5 = labelBlock4.getToolTipText();
        java.awt.Font font6 = labelBlock4.getFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double9 = rectangleInsets7.trimWidth((double) 0);
        labelBlock4.setPadding(rectangleInsets7);
        java.lang.String str11 = labelBlock4.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.0d) + "'", double9 == (-2.0d));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean10 = statisticalBarRenderer8.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer8.removeAnnotations();
        statisticalBarRenderer8.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer8.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = statisticalBarRenderer16.getLegendItemLabelGenerator();
        statisticalBarRenderer8.setLegendItemLabelGenerator(categorySeriesLabelGenerator17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot19.getDataRange(valueAxis20);
        categoryPlot19.setOutlineVisible(false);
        java.awt.Paint paint24 = categoryPlot19.getOutlinePaint();
        java.awt.Stroke stroke25 = categoryPlot19.getOutlineStroke();
        try {
            statisticalBarRenderer0.setSeriesStroke((-12566464), stroke25, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator17);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean9 = statisticalBarRenderer7.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer7.removeAnnotations();
        boolean boolean13 = statisticalBarRenderer7.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font14 = statisticalBarRenderer7.getBaseItemLabelFont();
        statisticalBarRenderer0.setBaseItemLabelFont(font14, false);
        java.lang.Object obj17 = statisticalBarRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        java.awt.Paint paint19 = legendTitle18.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = legendTitle18.getHorizontalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle18.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle18.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle18.getBounds();
        org.jfree.chart.block.BlockFrame blockFrame23 = legendTitle18.getFrame();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color27 = java.awt.Color.DARK_GRAY;
        int int28 = color27.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("", font26, (java.awt.Paint) color27);
        java.awt.Paint paint30 = labelBlock29.getPaint();
        java.lang.String str31 = labelBlock29.getID();
        java.lang.String str32 = labelBlock29.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D33 = labelBlock29.getBounds();
        try {
            legendTitle18.draw(graphics2D24, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(blockFrame23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 64 + "'", int28 == 64);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.removeAnnotations();
        boolean boolean15 = statisticalBarRenderer9.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font16 = statisticalBarRenderer9.getBaseItemLabelFont();
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 100, font16, false);
        java.lang.Class<?> wildcardClass19 = statisticalBarRenderer0.getClass();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        boolean boolean21 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation20);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean24 = statisticalBarRenderer22.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer22.removeAnnotations();
        statisticalBarRenderer22.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer22.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer30 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = statisticalBarRenderer30.getLegendItemLabelGenerator();
        statisticalBarRenderer22.setLegendItemLabelGenerator(categorySeriesLabelGenerator31);
        statisticalBarRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator31);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean40 = statisticalBarRenderer38.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer38.removeAnnotations();
        statisticalBarRenderer38.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer38.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator47 = statisticalBarRenderer46.getLegendItemLabelGenerator();
        statisticalBarRenderer38.setLegendItemLabelGenerator(categorySeriesLabelGenerator47);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer38);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.data.Range range51 = categoryPlot49.getDataRange(valueAxis50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryPlot49.getInsets();
        java.util.List list53 = categoryPlot49.getCategories();
        boolean boolean54 = categoryPlot49.isSubplot();
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str57 = layer56.toString();
        java.util.Collection collection58 = categoryPlot49.getRangeMarkers((int) (short) 10, layer56);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        categoryPlot49.setDomainAxis((int) (short) 100, categoryAxis60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        try {
            statisticalBarRenderer0.drawBackground(graphics2D34, categoryPlot49, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator47);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNull(list53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Layer.FOREGROUND" + "'", str57.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection58);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        boolean boolean2 = numberAxis0.isAutoRange();
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo7.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D9 = plotRenderingInfo7.getDataArea();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge11);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = categoryLabelPositions10.getLabelPosition(rectangleEdge11);
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge11);
        double double15 = categoryAxis1.getCategoryStart(8, 15, rectangle2D9, rectangleEdge11);
        java.awt.Font font19 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color20 = java.awt.Color.DARK_GRAY;
        int int21 = color20.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("", font19, (java.awt.Paint) color20);
        java.awt.Paint paint23 = labelBlock22.getPaint();
        java.lang.String str24 = labelBlock22.getID();
        java.lang.String str25 = labelBlock22.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock22.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis1.getCategoryEnd((-1), 64, rectangle2D26, rectangleEdge27);
        int int29 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLabelAngle((double) 0);
        org.junit.Assert.assertNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(categoryLabelPosition13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 64 + "'", int21 == 64);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        java.lang.String str7 = labelBlock6.getToolTipText();
        java.awt.Font font8 = labelBlock6.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean12 = statisticalBarRenderer10.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer10.removeAnnotations();
        statisticalBarRenderer10.setAutoPopulateSeriesStroke(false);
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer10.setSeriesItemLabelPaint(64, (java.awt.Paint) color17);
        java.awt.Color color19 = java.awt.Color.getColor("hi!", color17);
        java.awt.Color color20 = java.awt.Color.GREEN;
        float[] floatArray21 = null;
        float[] floatArray22 = color20.getColorComponents(floatArray21);
        float[] floatArray23 = color17.getRGBComponents(floatArray21);
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font8, (java.awt.Paint) color17);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("", font8);
        java.lang.Object obj26 = textTitle25.clone();
        java.awt.Color color27 = java.awt.Color.gray;
        textTitle25.setBackgroundPaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 64 + "'", int5 == 64);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) "");
        centerArrangement0.clear();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset5, (java.lang.Comparable) 0.95f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle18.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle18.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        try {
            legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot14.setDataset(categoryDataset25);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot14.getRowRenderingOrder();
        categoryPlot14.setForegroundAlpha((float) (-1L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(sortOrder27);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.setSeriesItemLabelsVisible(64, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) (byte) 1);
        org.jfree.chart.block.CenterArrangement centerArrangement5 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement5, dataset6, (java.lang.Comparable) "");
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement5);
        blockContainer9.clear();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getLowerBound();
        java.lang.String str14 = range12.toString();
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range15, (double) (byte) 100, false);
        boolean boolean20 = range15.equals((java.lang.Object) (-1.0d));
        boolean boolean23 = range15.intersects((double) 0L, (double) (-1L));
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range15, (double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range12, range15);
        org.jfree.chart.util.Size2D size2D27 = flowArrangement4.arrange(blockContainer9, graphics2D11, rectangleConstraint26);
        java.lang.String str28 = blockContainer9.getID();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Range[0.0,1.0]" + "'", str14.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot14.setDomainAxis((int) (short) 100, categoryAxis25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo30.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        categoryPlot14.handleClick((int) ' ', 0, plotRenderingInfo30);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor34 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor34, textAnchor35);
        double double37 = itemLabelPosition36.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor38 = itemLabelPosition36.getTextAnchor();
        boolean boolean39 = plotRenderingInfo30.equals((java.lang.Object) textAnchor38);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(itemLabelAnchor34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        java.awt.Paint paint5 = labelBlock4.getPaint();
        java.lang.String str6 = labelBlock4.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = axisSpace19.shrink(rectangle2D23, rectangle2D24);
        double double26 = axisSpace19.getTop();
        categoryPlot14.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot14.getRendererForDataset(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(categoryItemRenderer29);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        double double3 = statisticalBarRenderer0.getLowerClip();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) '#', categoryURLGenerator5);
        statisticalBarRenderer0.setBaseCreateEntities(false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        categoryPlot14.setForegroundAlpha((float) (byte) 100);
        categoryPlot14.configureRangeAxes();
        categoryPlot14.setForegroundAlpha((float) 10L);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = null;
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Font font30 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color31 = java.awt.Color.DARK_GRAY;
        int int32 = color31.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("", font30, (java.awt.Paint) color31);
        java.lang.String str34 = labelBlock33.getToolTipText();
        java.awt.Font font35 = labelBlock33.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean39 = statisticalBarRenderer37.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer37.removeAnnotations();
        statisticalBarRenderer37.setAutoPopulateSeriesStroke(false);
        java.awt.Color color44 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer37.setSeriesItemLabelPaint(64, (java.awt.Paint) color44);
        java.awt.Color color46 = java.awt.Color.getColor("hi!", color44);
        java.awt.Color color47 = java.awt.Color.GREEN;
        float[] floatArray48 = null;
        float[] floatArray49 = color47.getColorComponents(floatArray48);
        float[] floatArray50 = color44.getRGBComponents(floatArray48);
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font35, (java.awt.Paint) color44);
        boolean boolean52 = layer27.equals((java.lang.Object) font35);
        try {
            categoryPlot14.addDomainMarker((-1), categoryMarker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 64 + "'", int32 == 64);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getName();
        org.jfree.chart.ui.Library library6 = new org.jfree.chart.ui.Library("", "TextAnchor.BOTTOM_LEFT", "TextAnchor.BOTTOM_LEFT", "CategoryLabelWidthType.RANGE");
        java.lang.String str7 = library6.getInfo();
        basicProjectInfo0.addOptionalLibrary(library6);
        java.lang.String str9 = library6.getLicenceName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str7.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str9.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot15.getDataRange(valueAxis16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        boolean boolean19 = datasetGroup0.equals((java.lang.Object) categoryPlot15);
        categoryPlot15.setOutlineVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        try {
            categoryPlot15.setRangeAxisLocation(axisLocation22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot14.setDomainAxis((int) (short) 100, categoryAxis25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo30.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        categoryPlot14.handleClick((int) ' ', 0, plotRenderingInfo30);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot14.getDomainAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = categoryPlot14.getOrientation();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = null;
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot14.addDomainMarker(categoryMarker36, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(layer37);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.DARK_GRAY;
        int int6 = color5.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font4, (java.awt.Paint) color5);
        java.lang.String str8 = labelBlock7.getToolTipText();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.removeAnnotations();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer11.setSeriesItemLabelPaint(64, (java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.getColor("hi!", color18);
        java.awt.Color color21 = java.awt.Color.GREEN;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getColorComponents(floatArray22);
        float[] floatArray24 = color18.getRGBComponents(floatArray22);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color18);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("", font9);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("Layer.FOREGROUND", font9, (java.awt.Paint) color27);
        float float29 = textFragment28.getBaselineOffset();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            textFragment28.draw(graphics2D30, (float) (short) 0, (float) (byte) 100, textAnchor33, 10.0f, (float) 10L, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor33);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot14.getRendererForDataset(categoryDataset19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot14.getParent();
        try {
            java.awt.Paint paint22 = plot21.getOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(categoryItemRenderer20);
        org.junit.Assert.assertNull(plot21);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getLowerBound();
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis0.getStandardTickUnits();
        numberAxis0.setRangeWithMargins((double) 100L, (double) 255);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("TextBlockAnchor.CENTER_LEFT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        jFreeChart24.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart24.getLegend((int) (byte) -1);
        try {
            jFreeChart24.setTextAntiAlias((java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message:  incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(legendTitle28);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1), jFreeChart1, (int) 'a', (int) (short) 10);
        chartProgressEvent4.setPercent(100);
        chartProgressEvent4.setPercent((int) (byte) -1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "ItemLabelAnchor.OUTSIDE12", textAnchor3, textAnchor5, (double) 10);
        org.jfree.chart.text.TextAnchor textAnchor9 = numberTick8.getTextAnchor();
        double double10 = numberTick8.getValue();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean4 = statisticalBarRenderer2.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer2.setBaseItemLabelsVisible(true);
        java.awt.Shape shape7 = statisticalBarRenderer2.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor8, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor12);
        java.lang.String str14 = textBlockAnchor12.toString();
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick17 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 255, textBlock1, textBlockAnchor12, textAnchor15, (-1.0d));
        org.jfree.chart.text.TextBlock textBlock18 = categoryTick17.getLabel();
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryTick17.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str14.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNull(textBlock18);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("GradientPaintTransformType.VERTICAL");
        org.jfree.data.KeyedObjects2D keyedObjects2D3 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D3.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D3.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable11 = keyedObjects2D3.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo17.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D19, (java.awt.Paint) color20);
        keyedObjects2D3.addObject((java.lang.Object) rectangle2D19, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int26 = keyedObjects2D3.getColumnIndex((java.lang.Comparable) (-1));
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer27 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType28 = standardGradientPaintTransformer27.getType();
        java.lang.String str29 = gradientPaintTransformType28.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D3.addObject((java.lang.Object) gradientPaintTransformType28, (java.lang.Comparable) numberTickUnit30, (java.lang.Comparable) "SortOrder.ASCENDING");
        numberAxis0.setTickUnit(numberTickUnit30, true, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis0);
        java.lang.Object obj37 = axisChangeEvent36.getSource();
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + '#' + "'", comparable11.equals('#'));
        org.junit.Assert.assertNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str29.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot15.setDataset(categoryDataset16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        boolean boolean20 = numberAxis0.hasListener((java.util.EventListener) categoryPlot15);
        java.awt.Stroke stroke21 = numberAxis0.getAxisLineStroke();
        double double22 = numberAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textLine0.calculateDimensions(graphics2D1);
        double double3 = size2D2.getHeight();
        size2D2.height = 100;
        double double6 = size2D2.getHeight();
        java.lang.Object obj7 = size2D2.clone();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets5.calculateTopOutset((double) (byte) 1);
        labelBlock4.setPadding(rectangleInsets5);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        labelBlock4.setPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=64,g=64,b=255]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets5.calculateTopOutset((double) (byte) 1);
        labelBlock4.setPadding(rectangleInsets5);
        double double9 = rectangleInsets5.getBottom();
        double double11 = rectangleInsets5.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-2.0d) + "'", double11 == (-2.0d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextBlockAnchor.CENTER_LEFT");
        categoryAxis2.removeCategoryLabelToolTip((java.lang.Comparable) 8);
        categoryAxis2.setLabelURL("");
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        categoryAxis2.setTickLabelFont(font7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean14 = statisticalBarRenderer12.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer12.removeAnnotations();
        statisticalBarRenderer12.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer12.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = statisticalBarRenderer20.getLegendItemLabelGenerator();
        statisticalBarRenderer12.setLegendItemLabelGenerator(categorySeriesLabelGenerator21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.Range range25 = categoryPlot23.getDataRange(valueAxis24);
        categoryPlot23.setOutlineVisible(false);
        java.awt.Paint paint28 = categoryPlot23.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("TextAnchor.BOTTOM_LEFT", font7, paint28, (float) 8);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator21);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) 2.0f, (double) 100);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        java.awt.Color color7 = java.awt.Color.red;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        legendGraphic8.setShapeVisible(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer11.setBaseItemLabelsVisible(true, false);
        statisticalBarRenderer11.setAutoPopulateSeriesOutlineStroke(true);
        double double18 = statisticalBarRenderer11.getLowerClip();
        java.awt.Stroke stroke20 = statisticalBarRenderer11.lookupSeriesOutlineStroke((int) (short) 10);
        legendGraphic8.setOutlineStroke(stroke20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendGraphic8.getShapeLocation();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) -1, (double) '#', (double) 15, (double) (-2244674));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        int int8 = statisticalBarRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer8.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator9);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean13 = statisticalBarRenderer11.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer11.setBaseItemLabelsVisible(true);
        java.awt.Shape shape16 = statisticalBarRenderer11.getBaseShape();
        statisticalBarRenderer0.setBaseShape(shape16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = legendTitle18.getHorizontalAlignment();
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle18.getBounds();
        org.jfree.chart.event.TitleChangeListener titleChangeListener23 = null;
        legendTitle18.addChangeListener(titleChangeListener23);
        java.awt.Paint paint25 = legendTitle18.getItemPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat4 = numberAxis3.getNumberFormatOverride();
        double double5 = numberAxis3.getUpperMargin();
        numberAxis3.setAxisLineVisible(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo9.getDataArea();
        numberAxis3.setLeftArrow((java.awt.Shape) rectangle2D11);
        try {
            shapeList0.setShape((-2244674), (java.awt.Shape) rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition4);
        int int6 = statisticalBarRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Object obj0 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState((double) 100L);
        java.util.List list3 = axisState2.getTicks();
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState((double) 100L);
        java.util.List list6 = axisState5.getTicks();
        axisState2.setTicks(list6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean11 = statisticalBarRenderer9.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer9.setBaseItemLabelsVisible(true);
        java.awt.Shape shape14 = statisticalBarRenderer9.getBaseShape();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, rectangleAnchor15, (double) 100L, (double) 10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor15, textBlockAnchor19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions8, categoryLabelPosition20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean27 = statisticalBarRenderer25.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer25.removeAnnotations();
        statisticalBarRenderer25.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer25.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator34 = statisticalBarRenderer33.getLegendItemLabelGenerator();
        statisticalBarRenderer25.setLegendItemLabelGenerator(categorySeriesLabelGenerator34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer25);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.data.Range range38 = categoryPlot36.getDataRange(valueAxis37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryPlot36.getInsets();
        java.util.List list40 = categoryPlot36.getCategories();
        boolean boolean41 = categoryPlot36.isSubplot();
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str44 = layer43.toString();
        java.util.Collection collection45 = categoryPlot36.getRangeMarkers((int) (short) 10, layer43);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot36);
        jFreeChart46.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent51 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryLabelPositions8, jFreeChart46, (int) (byte) 10, 10);
        jFreeChart46.fireChartChanged();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent55 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) axisState2, jFreeChart46, (-2244674), (int) (short) 10);
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent58 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart46, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator34);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNull(list40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.FOREGROUND" + "'", str44.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection45);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        java.lang.Object obj3 = keyedObjects2D0.clone();
        java.util.List list4 = keyedObjects2D0.getRowKeys();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis0);
        numberAxis0.setLabelURL("hi!");
        java.awt.Shape shape4 = numberAxis0.getUpArrow();
        try {
            numberAxis0.setRange((double) 100L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        categoryPlot14.setOutlineVisible(false);
        java.awt.Paint paint19 = categoryPlot14.getOutlinePaint();
        boolean boolean20 = categoryPlot14.isRangeZoomable();
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot14.getRowRenderingOrder();
        java.lang.String str22 = sortOrder21.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "SortOrder.ASCENDING" + "'", str22.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalBarRenderer0.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer0.setBaseOutlineStroke(stroke8, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator11);
        java.awt.Paint paint14 = statisticalBarRenderer0.lookupSeriesOutlinePaint(64);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) "");
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.DARK_GRAY;
        int int7 = color6.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font5, (java.awt.Paint) color6);
        java.awt.Paint paint9 = labelBlock8.getPaint();
        java.lang.String str10 = labelBlock8.getID();
        legendItemBlockContainer3.add((org.jfree.chart.block.Block) labelBlock8);
        java.lang.String str12 = legendItemBlockContainer3.getURLText();
        java.lang.Object obj13 = legendItemBlockContainer3.clone();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 64 + "'", int7 == 64);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft((double) 100);
        java.lang.Object obj3 = axisSpace0.clone();
        axisSpace0.setRight((double) ' ');
        double double6 = axisSpace0.getRight();
        org.jfree.chart.axis.AxisSpace axisSpace7 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo9.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = axisSpace7.shrink(rectangle2D11, rectangle2D12);
        axisSpace0.ensureAtLeast(axisSpace7);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 0.5f, (double) 100.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getCategories();
        boolean boolean19 = categoryPlot14.isSubplot();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str22 = layer21.toString();
        java.util.Collection collection23 = categoryPlot14.getRangeMarkers((int) (short) 10, layer21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.Object obj25 = jFreeChart24.getTextAntiAlias();
        java.awt.Image image26 = jFreeChart24.getBackgroundImage();
        try {
            org.jfree.chart.plot.XYPlot xYPlot27 = jFreeChart24.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(image26);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D16, (java.awt.Paint) color17);
        keyedObjects2D0.addObject((java.lang.Object) rectangle2D16, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int23 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 0);
        try {
            java.lang.Comparable comparable25 = keyedObjects2D0.getRowKey(64);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 64, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets5.calculateTopOutset((double) (byte) 1);
        labelBlock4.setPadding(rectangleInsets5);
        double double10 = rectangleInsets5.trimHeight((double) 0.0f);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2.0d) + "'", double10 == (-2.0d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot14.getInsets();
        java.util.List list18 = categoryPlot14.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot14.getLegendItems();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        boolean boolean21 = categoryPlot14.equals((java.lang.Object) textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer3.setWidth((double) (-1L));
        java.awt.Color color6 = java.awt.Color.CYAN;
        boolean boolean7 = legendItemBlockContainer3.equals((java.lang.Object) color6);
        java.lang.String str8 = legendItemBlockContainer3.getURLText();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double11 = rectangleInsets10.getBottom();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        int int19 = color18.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font17, (java.awt.Paint) color18);
        java.awt.Paint paint21 = labelBlock20.getPaint();
        java.lang.String str22 = labelBlock20.getID();
        java.lang.String str23 = labelBlock20.getToolTipText();
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock20.getBounds();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D15, rectangle2D24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets10.createAdjustedRectangle(rectangle2D24, lengthAdjustmentType26, lengthAdjustmentType27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 15, (-1.0f));
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape31, (double) 2.0f, (double) 100);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.clone(shape34);
        java.awt.Color color36 = java.awt.Color.red;
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape35, (java.awt.Paint) color36);
        legendGraphic37.setShapeVisible(true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean42 = statisticalBarRenderer40.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer40.removeAnnotations();
        statisticalBarRenderer40.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer40.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer48 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator49 = statisticalBarRenderer48.getLegendItemLabelGenerator();
        statisticalBarRenderer40.setLegendItemLabelGenerator(categorySeriesLabelGenerator49);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer51 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean53 = statisticalBarRenderer51.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer51.setBaseItemLabelsVisible(true);
        java.awt.Shape shape56 = statisticalBarRenderer51.getBaseShape();
        statisticalBarRenderer40.setBaseShape(shape56);
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer40);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle58.setLegendItemGraphicAnchor(rectangleAnchor59);
        legendGraphic37.setShapeAnchor(rectangleAnchor59);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer62 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean64 = statisticalBarRenderer62.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer62.removeAnnotations();
        statisticalBarRenderer62.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator69 = statisticalBarRenderer62.getSeriesToolTipGenerator(100);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer62.setBaseOutlineStroke(stroke70, false);
        legendGraphic37.setOutlineStroke(stroke70);
        java.lang.Object obj74 = legendGraphic37.clone();
        try {
            java.lang.Object obj75 = legendItemBlockContainer3.draw(graphics2D9, rectangle2D28, obj74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 64 + "'", int19 == 64);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(obj74);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setDrawBarOutline(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer0.getNegativeItemLabelPosition(1, (int) (byte) 0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType12 = standardGradientPaintTransformer11.getType();
        statisticalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer11);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(gradientPaintTransformType12);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, dataset1, (java.lang.Comparable) 1.0f);
        java.lang.String str4 = legendItemBlockContainer3.getURLText();
        legendItemBlockContainer3.clear();
        java.lang.Object obj6 = legendItemBlockContainer3.clone();
        legendItemBlockContainer3.setHeight(0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("GradientPaintTransformType.VERTICAL", "ItemLabelAnchor.OUTSIDE12", "TextBlockAnchor.CENTER_LEFT", image3, "GradientPaintTransformType.VERTICAL", "", "Layer.FOREGROUND");
        projectInfo7.setLicenceText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        statisticalBarRenderer3.setSeriesItemLabelPaint(64, (java.awt.Paint) color10);
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator13, false);
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) 100L, (float) (-1), (float) '#');
        boolean boolean20 = statisticalBarRenderer0.equals((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean6 = statisticalBarRenderer4.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer4.removeAnnotations();
        statisticalBarRenderer4.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer4.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer12.getLegendItemLabelGenerator();
        statisticalBarRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot15.setDataset(categoryDataset16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        java.awt.Paint paint19 = categoryPlot15.getDomainGridlinePaint();
        boolean boolean20 = numberAxis0.hasListener((java.util.EventListener) categoryPlot15);
        numberAxis0.setAutoRangeMinimumSize((double) 100, true);
        numberAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("ItemLabelAnchor.OUTSIDE12");
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.axis.TickType tickType1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick(tickType1, 0.0d, "ItemLabelAnchor.OUTSIDE12", textAnchor4, textAnchor6, (double) 10);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getTextAnchor();
        java.lang.String str11 = textAnchor10.toString();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor10, textAnchor12, (double) 0.0f);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str11.equals("TextAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (byte) 100, false);
        boolean boolean5 = range0.equals((java.lang.Object) (-1.0d));
        boolean boolean8 = range0.intersects((double) 0L, (double) (-1L));
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range9, (double) (byte) 100, false);
        boolean boolean14 = range9.equals((java.lang.Object) (-1.0d));
        boolean boolean17 = range9.intersects((double) 0L, (double) (-1L));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range0, range9);
        double double19 = range9.getLength();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D7, (java.awt.Paint) color8);
        org.jfree.data.general.Dataset dataset10 = legendItem9.getDataset();
        legendItem9.setSeriesIndex(3);
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(dataset10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer0.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer0.removeAnnotations();
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible((int) (byte) 0, (int) '4');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean9 = statisticalBarRenderer7.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer7.removeAnnotations();
        boolean boolean13 = statisticalBarRenderer7.isItemLabelVisible((int) (byte) 0, (int) '4');
        java.awt.Font font14 = statisticalBarRenderer7.getBaseItemLabelFont();
        statisticalBarRenderer0.setBaseItemLabelFont(font14, false);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = statisticalBarRenderer0.getToolTipGenerator((int) (short) 100, 0);
        int int23 = statisticalBarRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setLabelURL("GradientPaintTransformType.VERTICAL");
        org.jfree.data.KeyedObjects2D keyedObjects2D3 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D3.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D3.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable11 = keyedObjects2D3.getColumnKey(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo17.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "GradientPaintTransformType.VERTICAL", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", (java.awt.Shape) rectangle2D19, (java.awt.Paint) color20);
        keyedObjects2D3.addObject((java.lang.Object) rectangle2D19, (java.lang.Comparable) "hi!", (java.lang.Comparable) (byte) 1);
        int int26 = keyedObjects2D3.getColumnIndex((java.lang.Comparable) (-1));
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer27 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType28 = standardGradientPaintTransformer27.getType();
        java.lang.String str29 = gradientPaintTransformType28.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D3.addObject((java.lang.Object) gradientPaintTransformType28, (java.lang.Comparable) numberTickUnit30, (java.lang.Comparable) "SortOrder.ASCENDING");
        numberAxis0.setTickUnit(numberTickUnit30, true, true);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean41 = statisticalBarRenderer39.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer39.removeAnnotations();
        statisticalBarRenderer39.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer39.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer47 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator48 = statisticalBarRenderer47.getLegendItemLabelGenerator();
        statisticalBarRenderer39.setLegendItemLabelGenerator(categorySeriesLabelGenerator48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.data.Range range52 = categoryPlot50.getDataRange(valueAxis51);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryPlot50.getInsets();
        java.util.List list54 = categoryPlot50.getCategories();
        boolean boolean55 = categoryPlot50.isSubplot();
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str58 = layer57.toString();
        java.util.Collection collection59 = categoryPlot50.getRangeMarkers((int) (short) 10, layer57);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        double double61 = numberAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + '#' + "'", comparable11.equals('#'));
        org.junit.Assert.assertNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str29.equals("GradientPaintTransformType.VERTICAL"));
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator48);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNull(list54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Layer.FOREGROUND" + "'", str58.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0E-8d + "'", double61 == 1.0E-8d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("TextAnchor.CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key TextAnchor.CENTER");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) 1L);
        keyedObjects2D0.addObject((java.lang.Object) (short) -1, (java.lang.Comparable) (-1), (java.lang.Comparable) '#');
        java.lang.Comparable comparable8 = keyedObjects2D0.getColumnKey(0);
        int int10 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 0.95f);
        java.lang.Comparable comparable11 = null;
        java.lang.Object obj13 = keyedObjects2D0.getObject(comparable11, (java.lang.Comparable) "CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '#' + "'", comparable8.equals('#'));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Paint paint4 = statisticalBarRenderer0.lookupSeriesFillPaint((int) (byte) 100);
        statisticalBarRenderer0.setMinimumBarLength((double) 64);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean5 = statisticalBarRenderer3.isSeriesItemLabelsVisible(0);
        statisticalBarRenderer3.removeAnnotations();
        statisticalBarRenderer3.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemLabelGenerator();
        statisticalBarRenderer3.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot14.getDataRange(valueAxis15);
        categoryPlot14.setOutlineVisible(false);
        java.awt.Paint paint19 = categoryPlot14.getOutlinePaint();
        java.awt.Paint paint20 = categoryPlot14.getRangeGridlinePaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot14.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }
}

