import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean17 = timeSeries6.equals((java.lang.Object) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond19.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond19.previous();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        java.lang.String str27 = month25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month25.next();
        int int29 = month25.getYearValue();
        long long30 = month25.getMiddleMillisecond();
        org.jfree.data.time.Year year31 = month25.getYear();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) year31);
        try {
            java.lang.Number number35 = timeSeries33.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560668399999L + "'", long30 == 1560668399999L);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year2.compareTo((java.lang.Object) date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        java.util.Date date11 = fixedMillisecond10.getTime();
        java.util.Date date12 = fixedMillisecond10.getTime();
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        java.lang.Class<?> wildcardClass15 = date13.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date13);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21);
        long long23 = timeSeries22.getMaximumItemAge();
        java.util.List list24 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31);
        long long33 = timeSeries32.getMaximumItemAge();
        timeSeries32.setDomainDescription("2019");
        timeSeries32.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
        java.util.Date date41 = fixedMillisecond38.getTime();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42);
        java.util.Collection collection44 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        boolean boolean45 = timeSeries15.equals((java.lang.Object) timeSeries32);
        timeSeries15.setMaximumItemCount(1);
        timeSeries15.setKey((java.lang.Comparable) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        timeSeries6.clear();
        timeSeries6.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.Year year28 = month26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, number30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((int) (short) 0, 0);
        timeSeries25.clear();
        java.util.Collection collection36 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection37 = timeSeries25.getTimePeriods();
        timeSeries25.setDescription("31-December-1969");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries25, seriesChangeInfo40);
        java.lang.Object obj42 = timeSeries25.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getLastMillisecond(calendar45);
        boolean boolean48 = fixedMillisecond44.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 1969);
        boolean boolean51 = timeSeriesDataItem50.isSelected();
        java.lang.Number number52 = timeSeriesDataItem50.getValue();
        java.lang.Object obj53 = timeSeriesDataItem50.clone();
        timeSeries25.add(timeSeriesDataItem50, false);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass57 = month56.getClass();
        java.lang.String str58 = month56.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month56.next();
        int int60 = month56.getYearValue();
        long long61 = month56.getMiddleMillisecond();
        long long62 = month56.getSerialIndex();
        int int63 = timeSeriesDataItem50.compareTo((java.lang.Object) month56);
        java.lang.Class class64 = null;
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass66 = month65.getClass();
        org.jfree.data.time.Year year67 = month65.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar70 = null;
        long long71 = fixedMillisecond69.getMiddleMillisecond(calendar70);
        java.util.Date date72 = fixedMillisecond69.getTime();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
        int int74 = year67.compareTo((java.lang.Object) date72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond(date72);
        java.util.Date date76 = fixedMillisecond75.getTime();
        java.util.Date date77 = fixedMillisecond75.getTime();
        java.util.TimeZone timeZone78 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date77, timeZone78);
        boolean boolean80 = timeSeriesDataItem50.equals((java.lang.Object) date77);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 1969 + "'", number52.equals(1969));
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560668399999L + "'", long61 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 24234L + "'", long62 == 24234L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(year67);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 100L + "'", long71 == 100L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) Double.NaN, "", "June 2019");
        timeSeries3.setRangeDescription("Time");
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year13);
        long long15 = timeSeries14.getMaximumItemAge();
        timeSeries14.setDomainDescription("2019");
        timeSeries14.clear();
        java.lang.String str19 = timeSeries14.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getLastMillisecond(calendar22);
        boolean boolean25 = fixedMillisecond21.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1969);
        boolean boolean28 = timeSeriesDataItem27.isSelected();
        java.lang.Number number29 = timeSeriesDataItem27.getValue();
        boolean boolean30 = timeSeriesDataItem27.isSelected();
        timeSeries14.add(timeSeriesDataItem27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond33.getTime();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        java.lang.String str39 = day38.toString();
        java.lang.String str40 = day38.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day38.next();
        int int42 = timeSeriesDataItem27.compareTo((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries6.addOrUpdate(timeSeriesDataItem27);
        java.lang.String str44 = timeSeries6.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1969 + "'", number29.equals(1969));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31-December-1969" + "'", str39.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31-December-1969" + "'", str40.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Value" + "'", str44.equals("Value"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21);
        long long23 = timeSeries22.getMaximumItemAge();
        java.util.List list24 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries22);
        int int26 = timeSeries25.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31);
        java.lang.String str34 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 9999);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 1561964399999L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond40.getTime();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year44);
        long long46 = timeSeries45.getMaximumItemAge();
        timeSeries45.setDomainDescription("2019");
        timeSeries45.clear();
        timeSeries45.fireSeriesChanged();
        timeSeries45.setNotify(false);
        int int53 = month33.compareTo((java.lang.Object) false);
        java.lang.String str54 = month33.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "December 1969" + "'", str34.equals("December 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "December 1969" + "'", str54.equals("December 1969"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        java.lang.String str11 = timeSeries6.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1969);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        java.lang.Number number21 = timeSeriesDataItem19.getValue();
        boolean boolean22 = timeSeriesDataItem19.isSelected();
        timeSeries6.add(timeSeriesDataItem19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28);
        java.lang.String str31 = day30.toString();
        java.lang.String str32 = day30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        int int34 = timeSeriesDataItem19.compareTo((java.lang.Object) regularTimePeriod33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeriesDataItem19.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1969 + "'", number21.equals(1969));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-1969" + "'", str32.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year2.compareTo((java.lang.Object) date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond11.next();
        boolean boolean16 = year2.equals((java.lang.Object) regularTimePeriod15);
        long long17 = year2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17);
        long long19 = timeSeries18.getMaximumItemAge();
        timeSeries18.clear();
        java.util.Collection collection21 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(comparable22);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.lang.String str7 = month6.toString();
        int int8 = month6.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        long long16 = timeSeries15.getMaximumItemAge();
        timeSeries15.setDomainDescription("2019");
        timeSeries15.clear();
        timeSeries15.fireSeriesChanged();
        int int21 = month6.compareTo((java.lang.Object) timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 7);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year27 = month26.getYear();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(100);
        long long30 = year29.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) year29);
        java.util.Calendar calendar32 = null;
        try {
            month26.peg(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 1969" + "'", str7.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-59011603200000L) + "'", long30 == (-59011603200000L));
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) (short) 100);
        boolean boolean7 = month0.equals((java.lang.Object) fixedMillisecond2);
        org.jfree.data.time.Year year8 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year12);
        long long14 = timeSeries13.getMaximumItemAge();
        timeSeries13.setDomainDescription("2019");
        timeSeries13.clear();
        timeSeries13.fireSeriesChanged();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        java.lang.String str21 = year19.toString();
        java.lang.Number number22 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) year19);
        java.util.Date date23 = year19.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.previous();
        int int25 = year6.compareTo((java.lang.Object) year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year6.next();
        try {
            org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(2019, year6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-50) + "'", int25 == (-50));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.lang.String str7 = month6.toString();
        int int8 = month6.getMonth();
        long long9 = month6.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15);
        long long17 = timeSeries16.getMaximumItemAge();
        java.util.List list18 = timeSeries16.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        java.lang.String str26 = day25.toString();
        int int27 = day25.getYear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass29 = month28.getClass();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        int int37 = year30.compareTo((java.lang.Object) date35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date35);
        java.util.Date date39 = fixedMillisecond38.getTime();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) day25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.lang.String str41 = timeSeries40.getDomainDescription();
        int int42 = month6.compareTo((java.lang.Object) str41);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 1969" + "'", str7.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2649600000L) + "'", long9 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-1969" + "'", str26.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass8 = month7.getClass();
//        org.jfree.data.time.Year year9 = month7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass14 = month13.getClass();
//        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
//        boolean boolean17 = timeSeries6.equals((java.lang.Object) 10);
//        boolean boolean18 = timeSeries6.getNotify();
//        timeSeries6.removeAgedItems(false);
//        java.lang.String str21 = timeSeries6.getDescription();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries6.getDataItem(regularTimePeriod24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond27.getTime();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass34 = month33.getClass();
//        org.jfree.data.time.Year year35 = month33.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
//        java.lang.Number number37 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, number37);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
//        java.util.Date date46 = fixedMillisecond43.getTime();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year47);
//        long long49 = timeSeries48.getMaximumItemAge();
//        java.util.List list50 = timeSeries48.getItems();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries41.addAndOrUpdate(timeSeries48);
//        int int52 = timeSeries51.getItemCount();
//        boolean boolean53 = timeSeriesDataItem25.equals((java.lang.Object) timeSeries51);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries51.getDataItem(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list50);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        java.lang.String str11 = timeSeries6.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1969);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        java.lang.Number number21 = timeSeriesDataItem19.getValue();
        boolean boolean22 = timeSeriesDataItem19.isSelected();
        timeSeries6.add(timeSeriesDataItem19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28);
        java.lang.String str31 = day30.toString();
        java.lang.String str32 = day30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day30.next();
        int int34 = timeSeriesDataItem19.compareTo((java.lang.Object) regularTimePeriod33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond36.getTime();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year40);
        long long42 = timeSeries41.getMaximumItemAge();
        timeSeries41.setDomainDescription("2019");
        timeSeries41.clear();
        boolean boolean46 = timeSeries41.isEmpty();
        java.util.Collection collection47 = timeSeries41.getTimePeriods();
        timeSeries41.setRangeDescription("Value");
        int int50 = timeSeriesDataItem19.compareTo((java.lang.Object) timeSeries41);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1969 + "'", number21.equals(1969));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-1969" + "'", str32.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        int int8 = day6.getMonth();
        java.lang.String str9 = day6.toString();
        long long10 = day6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28799999L + "'", long10 == 28799999L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.lang.String str14 = year12.toString();
        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = year12.getYear();
        int int17 = year12.getYear();
        java.util.Date date18 = year12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.Year year28 = month26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, number30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond36.getTime();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year40);
        long long42 = timeSeries41.getMaximumItemAge();
        timeSeries41.setDomainDescription("2019");
        timeSeries41.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year51);
        java.util.Collection collection53 = timeSeries41.getTimePeriodsUniqueToOtherSeries(timeSeries52);
        java.util.Collection collection54 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries41);
        java.lang.Object obj55 = timeSeries34.clone();
        int int56 = year12.compareTo(obj55);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date8 = fixedMillisecond1.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass2 = month1.getClass();
        org.jfree.data.time.Year year3 = month1.getYear();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(8, year3);
        long long5 = month4.getFirstMillisecond();
        long long6 = month4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1564642800000L + "'", long5 == 1564642800000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1564642800000L + "'", long6 == 1564642800000L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: 100");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 100" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 100"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "org.jfree.data.event.SeriesChangeEvent[source=2019]", "org.jfree.data.event.SeriesChangeEvent[source=2019]");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15);
        long long17 = timeSeries16.getMaximumItemAge();
        timeSeries16.setDomainDescription("2019");
        timeSeries16.clear();
        boolean boolean21 = timeSeries16.isEmpty();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year23 = month22.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        long long26 = month22.getLastMillisecond();
        int int27 = month22.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.Object obj4 = null;
        int int5 = month0.compareTo(obj4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        java.lang.String str8 = year7.toString();
        java.util.Date date9 = year7.getStart();
        boolean boolean10 = month0.equals((java.lang.Object) year7);
        int int11 = month0.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
        long long2 = year1.getFirstMillisecond();
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        java.util.Date date5 = year1.getEnd();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-59011603200000L) + "'", long2 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.Calendar calendar7 = null;
        fixedMillisecond6.peg(calendar7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        boolean boolean21 = fixedMillisecond17.equals((java.lang.Object) (short) 100);
        java.lang.Number number22 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.lang.Class class23 = timeSeries6.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) class23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        org.jfree.data.time.Year year27 = month25.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        java.util.Date date32 = fixedMillisecond29.getTime();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        int int34 = year27.compareTo((java.lang.Object) date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date32);
        java.util.Date date36 = fixedMillisecond35.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date36, timeZone38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date36);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getFirstMillisecond(calendar41);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond40.getLastMillisecond(calendar43);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21);
        long long23 = timeSeries22.getMaximumItemAge();
        java.util.List list24 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries22);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        boolean boolean21 = fixedMillisecond17.equals((java.lang.Object) (short) 100);
        java.lang.Number number22 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries6.setRangeDescription("31-December-1969");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener25);
        long long27 = timeSeries6.getMaximumItemAge();
        try {
            timeSeries6.delete(1969, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(number22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        long long8 = day6.getSerialIndex();
        java.util.Date date9 = day6.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        long long16 = timeSeries15.getMaximumItemAge();
        timeSeries15.setDomainDescription("2019");
        timeSeries15.clear();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1969);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeries15.setKey((java.lang.Comparable) timeSeriesDataItem28);
        java.util.Collection collection31 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        int int32 = timeSeries15.getItemCount();
        timeSeries15.clear();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.lang.Number number35 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) month34);
        timeSeries15.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(number35);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        boolean boolean11 = timeSeries6.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass20 = month19.getClass();
        org.jfree.data.time.Year year21 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.next();
        java.lang.Number number23 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, number23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        int int27 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
        long long28 = month25.getSerialIndex();
        long long29 = month25.getLastMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass31 = month30.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        int int34 = month30.compareTo((java.lang.Object) fixedMillisecond33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month30);
        java.lang.String str36 = month30.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month30.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.lang.String str3 = year2.toString();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = month0.compareTo((java.lang.Object) fixedMillisecond3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        int int11 = month6.compareTo((java.lang.Object) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.next();
        int int13 = month6.getMonth();
        boolean boolean14 = fixedMillisecond3.equals((java.lang.Object) month6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 10L);
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int5 = month0.compareTo((java.lang.Object) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        long long9 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.lang.String str7 = month6.toString();
        int int8 = month6.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        long long16 = timeSeries15.getMaximumItemAge();
        timeSeries15.setDomainDescription("2019");
        timeSeries15.clear();
        timeSeries15.fireSeriesChanged();
        int int21 = month6.compareTo((java.lang.Object) timeSeries15);
        java.lang.Object obj22 = null;
        int int23 = month6.compareTo(obj22);
        long long24 = month6.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29);
        long long32 = day31.getSerialIndex();
        long long33 = day31.getFirstMillisecond();
        boolean boolean34 = month6.equals((java.lang.Object) day31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 1969" + "'", str7.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1310400001L) + "'", long24 == (-1310400001L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 25568L + "'", long32 == 25568L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-57600000L) + "'", long33 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.lang.String str14 = year12.toString();
        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        boolean boolean21 = fixedMillisecond17.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 1969);
        timeSeriesDataItem23.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries6.addOrUpdate(timeSeriesDataItem23);
        java.lang.Comparable comparable27 = timeSeries6.getKey();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(comparable27);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass25 = month24.getClass();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, number28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) (short) 100);
        java.lang.Number number39 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond46.getFirstMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        boolean boolean52 = timeSeries51.getNotify();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries51);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo54 = seriesChangeEvent53.getSummary();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(seriesChangeInfo54);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) '#');
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 35.0d + "'", number4.equals(35.0d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year2.compareTo((java.lang.Object) date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        java.util.Date date11 = fixedMillisecond10.getTime();
        java.util.Date date12 = fixedMillisecond10.getTime();
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19);
        long long21 = timeSeries20.getMaximumItemAge();
        java.util.List list22 = timeSeries20.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year28);
        long long30 = timeSeries29.getMaximumItemAge();
        timeSeries29.setDomainDescription("2019");
        timeSeries29.clear();
        timeSeries29.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getLastMillisecond(calendar37);
        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 1969);
        boolean boolean43 = timeSeriesDataItem42.isSelected();
        timeSeries29.setKey((java.lang.Comparable) timeSeriesDataItem42);
        java.util.Collection collection45 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        double double46 = timeSeries20.getMaxY();
        java.lang.Object obj47 = timeSeries20.clone();
        int int48 = fixedMillisecond10.compareTo((java.lang.Object) timeSeries20);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        java.lang.String str8 = day6.toString();
        java.lang.String str9 = day6.toString();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getSerialIndex();
        int int12 = day6.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21);
        long long23 = timeSeries22.getMaximumItemAge();
        timeSeries22.setDomainDescription("2019");
        timeSeries22.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year32);
        java.util.Collection collection34 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.util.Collection collection35 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41);
        long long43 = timeSeries42.getMaximumItemAge();
        java.util.List list44 = timeSeries42.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond46.getTime();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49);
        java.lang.String str52 = day51.toString();
        int int53 = day51.getYear();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass55 = month54.getClass();
        org.jfree.data.time.Year year56 = month54.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond58.getMiddleMillisecond(calendar59);
        java.util.Date date61 = fixedMillisecond58.getTime();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date61);
        int int63 = year56.compareTo((java.lang.Object) date61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date61);
        java.util.Date date65 = fixedMillisecond64.getTime();
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
        java.lang.String str67 = day51.toString();
        long long68 = day51.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = day51.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) (byte) 100);
        java.lang.Number number72 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day51);
        try {
            org.jfree.data.time.TimeSeries timeSeries75 = timeSeries15.createCopy(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-1969" + "'", str52.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1969 + "'", int53 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(year56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeSeries66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "31-December-1969" + "'", str67.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-57600000L) + "'", long68 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNull(number72);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) 25568L);
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        long long16 = timeSeries15.getMaximumItemAge();
        timeSeries15.setDomainDescription("2019");
        timeSeries15.clear();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1969);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeries15.setKey((java.lang.Comparable) timeSeriesDataItem28);
        java.util.Collection collection31 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        int int32 = timeSeries15.getItemCount();
        timeSeries15.clear();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.lang.Number number35 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) month34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41);
        long long43 = timeSeries42.getMaximumItemAge();
        java.util.List list44 = timeSeries42.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond46.getTime();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year50);
        long long52 = timeSeries51.getMaximumItemAge();
        timeSeries51.setDomainDescription("2019");
        timeSeries51.clear();
        timeSeries51.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond58.getLastMillisecond(calendar59);
        boolean boolean62 = fixedMillisecond58.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (java.lang.Number) 1969);
        boolean boolean65 = timeSeriesDataItem64.isSelected();
        timeSeries51.setKey((java.lang.Comparable) timeSeriesDataItem64);
        java.util.Collection collection67 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries51.createCopy((int) (byte) 100, (int) (short) 100);
        java.util.Collection collection71 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        org.jfree.data.time.TimeSeries timeSeries72 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries73 = timeSeries51.addAndOrUpdate(timeSeries72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertNotNull(timeSeries70);
        org.junit.Assert.assertNotNull(collection71);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        int int7 = month2.compareTo((java.lang.Object) (-1.0f));
        int int8 = month0.compareTo((java.lang.Object) int7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent10.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent10.setSummary(seriesChangeInfo12);
        java.lang.Object obj14 = seriesChangeEvent10.getSource();
        int int15 = month0.compareTo((java.lang.Object) seriesChangeEvent10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        seriesChangeEvent10.setSummary(seriesChangeInfo16);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(seriesChangeInfo11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year2.compareTo((java.lang.Object) date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        java.util.Date date11 = fixedMillisecond10.getTime();
        java.util.Date date12 = fixedMillisecond10.getTime();
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        java.lang.String str16 = month14.toString();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "December 1969" + "'", str16.equals("December 1969"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
        java.util.Calendar calendar17 = null;
        fixedMillisecond15.peg(calendar17);
        java.lang.Object obj19 = null;
        boolean boolean20 = fixedMillisecond15.equals(obj19);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond15.getMiddleMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        long long31 = year30.getSerialIndex();
        int int32 = year30.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond34.getTime();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37);
        java.lang.String str40 = day39.toString();
        java.lang.String str41 = day39.toString();
        java.lang.String str42 = day39.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond44.getTime();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year48);
        long long50 = timeSeries49.getMaximumItemAge();
        boolean boolean51 = day39.equals((java.lang.Object) long50);
        java.lang.String str52 = day39.toString();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year30, (org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar56 = null;
        long long57 = fixedMillisecond55.getMiddleMillisecond(calendar56);
        java.util.Date date58 = fixedMillisecond55.getTime();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year59);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass62 = month61.getClass();
        org.jfree.data.time.Year year63 = month61.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month61.next();
        java.lang.Number number65 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month61, number65);
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass68 = month67.getClass();
        int int69 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) month67);
        boolean boolean71 = timeSeries60.equals((java.lang.Object) 10);
        java.lang.Object obj72 = timeSeries60.clone();
        timeSeries60.setMaximumItemAge((long) 9999);
        boolean boolean75 = year30.equals((java.lang.Object) 9999);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1969L + "'", long31 == 1969L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31-December-1969" + "'", str40.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31-December-1969" + "'", str41.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "31-December-1969" + "'", str42.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 9223372036854775807L + "'", long50 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-1969" + "'", str52.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 100L + "'", long57 == 100L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(year63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean17 = timeSeries6.equals((java.lang.Object) 10);
        java.lang.Object obj18 = timeSeries6.clone();
        timeSeries6.clear();
        timeSeries6.setDescription("June 2019");
        timeSeries6.setDescription("org.jfree.data.time.TimePeriodFormatException: 100");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries6.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.Object obj16 = timeSeries6.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass29 = month28.getClass();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
        java.lang.Number number32 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, number32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.createCopy((int) (short) 0, 0);
        timeSeries27.clear();
        timeSeries27.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond41.getTime();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass48 = month47.getClass();
        org.jfree.data.time.Year year49 = month47.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month47.next();
        java.lang.Number number51 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, number51);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries46.createCopy((int) (short) 0, 0);
        timeSeries46.clear();
        java.util.Collection collection57 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        java.util.Collection collection58 = timeSeries46.getTimePeriods();
        double double59 = timeSeries46.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries46.removeChangeListener(seriesChangeListener60);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries6.addAndOrUpdate(timeSeries46);
        timeSeries46.clear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries62);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-1), (-50));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.Object obj16 = timeSeries6.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
        java.util.Date date21 = fixedMillisecond18.getTime();
        java.util.Date date22 = fixedMillisecond18.getEnd();
        java.util.Calendar calendar23 = null;
        fixedMillisecond18.peg(calendar23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int5 = month0.compareTo((java.lang.Object) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        int int7 = month6.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass16 = month15.getClass();
        org.jfree.data.time.Year year17 = month15.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.next();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, number19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass22 = month21.getClass();
        int int23 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) month21);
        java.lang.Object obj24 = timeSeries14.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries14.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 1);
        java.lang.Object obj29 = timeSeries14.clone();
        java.util.List list30 = timeSeries14.getItems();
        java.lang.String str31 = timeSeries14.getDomainDescription();
        double double32 = timeSeries14.getMinY();
        int int33 = month6.compareTo((java.lang.Object) timeSeries14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = month0.compareTo((java.lang.Object) fixedMillisecond3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond3.peg(calendar5);
        java.util.Calendar calendar7 = null;
        fixedMillisecond3.peg(calendar7);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, year1);
        long long3 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year2.compareTo((java.lang.Object) date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
        java.util.Calendar calendar12 = null;
        long long13 = regularTimePeriod11.getMiddleMillisecond(calendar12);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 101L + "'", long13 == 101L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.Object obj16 = timeSeries6.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
        java.lang.Object obj21 = timeSeries6.clone();
        java.util.List list22 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond24.getTime();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass31 = month30.getClass();
        org.jfree.data.time.Year year32 = month30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.next();
        java.lang.Number number34 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, number34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass37 = month36.getClass();
        int int38 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) month36);
        java.lang.Object obj39 = timeSeries29.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries29.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 1);
        java.lang.Object obj44 = timeSeries29.clone();
        java.util.Collection collection45 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year51);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass54 = month53.getClass();
        org.jfree.data.time.Year year55 = month53.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month53.next();
        java.lang.Number number57 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries52.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month53, number57);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries52.createCopy((int) (short) 0, 0);
        timeSeries52.clear();
        timeSeries52.removeAgedItems((long) '#', true);
        boolean boolean66 = timeSeries29.equals((java.lang.Object) timeSeries52);
        timeSeries29.setRangeDescription("org.jfree.data.general.SeriesException: ");
        timeSeries29.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass8 = month7.getClass();
//        org.jfree.data.time.Year year9 = month7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass14 = month13.getClass();
//        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
//        java.lang.Object obj16 = timeSeries6.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
//        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
//        java.lang.Object obj21 = timeSeries6.clone();
//        java.util.List list22 = timeSeries6.getItems();
//        java.util.List list23 = timeSeries6.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getTime();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass32 = month31.getClass();
//        org.jfree.data.time.Year year33 = month31.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month31.next();
//        java.lang.Number number35 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, number35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass38 = month37.getClass();
//        int int39 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month37);
//        boolean boolean41 = timeSeries30.equals((java.lang.Object) 10);
//        boolean boolean42 = timeSeries30.getNotify();
//        timeSeries30.removeAgedItems(false);
//        java.lang.String str45 = timeSeries30.getDescription();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        int int47 = day46.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day46.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries30.getDataItem(regularTimePeriod48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond51.getMiddleMillisecond(calendar52);
//        java.util.Date date54 = fixedMillisecond51.getTime();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year55);
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass58 = month57.getClass();
//        org.jfree.data.time.Year year59 = month57.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = month57.next();
//        java.lang.Number number61 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, number61);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries56.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar68 = null;
//        long long69 = fixedMillisecond67.getMiddleMillisecond(calendar68);
//        java.util.Date date70 = fixedMillisecond67.getTime();
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date70);
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year71);
//        long long73 = timeSeries72.getMaximumItemAge();
//        java.util.List list74 = timeSeries72.getItems();
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries65.addAndOrUpdate(timeSeries72);
//        int int76 = timeSeries75.getItemCount();
//        boolean boolean77 = timeSeriesDataItem49.equals((java.lang.Object) timeSeries75);
//        try {
//            timeSeries6.add(timeSeriesDataItem49, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period June 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(list22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 100L + "'", long53 == 100L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 100L + "'", long69 == 100L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 9223372036854775807L + "'", long73 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list74);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        org.jfree.data.time.Year year13 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month11.next();
        int int16 = month11.compareTo((java.lang.Object) (-1.0f));
        int int17 = month9.compareTo((java.lang.Object) int16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year18);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = seriesChangeEvent19.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        seriesChangeEvent19.setSummary(seriesChangeInfo21);
        java.lang.Object obj23 = seriesChangeEvent19.getSource();
        int int24 = month9.compareTo((java.lang.Object) seriesChangeEvent19);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31);
        long long33 = timeSeries32.getMaximumItemAge();
        timeSeries32.setDomainDescription("2019");
        timeSeries32.clear();
        timeSeries32.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
        boolean boolean43 = fixedMillisecond39.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 1969);
        boolean boolean46 = timeSeriesDataItem45.isSelected();
        timeSeries32.setKey((java.lang.Comparable) timeSeriesDataItem45);
        timeSeries6.add(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(seriesChangeInfo20);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.Object obj16 = timeSeries6.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass29 = month28.getClass();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
        java.lang.Number number32 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, number32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.createCopy((int) (short) 0, 0);
        timeSeries27.clear();
        timeSeries27.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond41.getTime();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass48 = month47.getClass();
        org.jfree.data.time.Year year49 = month47.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month47.next();
        java.lang.Number number51 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, number51);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries46.createCopy((int) (short) 0, 0);
        timeSeries46.clear();
        java.util.Collection collection57 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        java.util.Collection collection58 = timeSeries46.getTimePeriods();
        double double59 = timeSeries46.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries46.removeChangeListener(seriesChangeListener60);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries6.addAndOrUpdate(timeSeries46);
        timeSeries46.removeAgedItems((long) 2, true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries62);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.lang.String str16 = day15.toString();
        int int17 = day15.getYear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        int int27 = year20.compareTo((java.lang.Object) date25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date25);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date35);
        java.util.Date date39 = fixedMillisecond38.getTime();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        boolean boolean41 = day15.equals((java.lang.Object) month40);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-1969" + "'", str16.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        timeSeries17.setDescription("");
        int int21 = timeSeries17.getItemCount();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass23 = month22.getClass();
        org.jfree.data.time.Year year24 = month22.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        int int31 = year24.compareTo((java.lang.Object) date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond33.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond33.next();
        boolean boolean38 = year24.equals((java.lang.Object) regularTimePeriod37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.String str40 = timeSeries17.getDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        long long16 = timeSeries15.getMaximumItemAge();
        timeSeries15.setDomainDescription("2019");
        timeSeries15.clear();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1969);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeries15.setKey((java.lang.Comparable) timeSeriesDataItem28);
        java.util.Collection collection31 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        int int32 = timeSeries15.getItemCount();
        timeSeries15.clear();
        java.lang.String str34 = timeSeries15.getRangeDescription();
        java.lang.String str35 = timeSeries15.getDomainDescription();
        java.util.Collection collection36 = timeSeries15.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Value" + "'", str34.equals("Value"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(collection36);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass25 = month24.getClass();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, number28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) (short) 100);
        java.lang.Number number39 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.addAndOrUpdate(timeSeries23);
        timeSeries42.clear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(timeSeries42);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = month0.compareTo((java.lang.Object) fixedMillisecond3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond3.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond3.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = month0.compareTo((java.lang.Object) fixedMillisecond3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond3.peg(calendar5);
        java.util.Date date7 = fixedMillisecond3.getTime();
        long long8 = fixedMillisecond3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass25 = month24.getClass();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, number28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) (short) 100);
        java.lang.Number number39 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.addAndOrUpdate(timeSeries23);
        java.util.Collection collection43 = timeSeries23.getTimePeriods();
        timeSeries23.clear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(collection43);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        boolean boolean11 = timeSeries6.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass20 = month19.getClass();
        org.jfree.data.time.Year year21 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.next();
        java.lang.Number number23 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, number23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        int int27 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
        long long28 = month25.getSerialIndex();
        long long29 = month25.getLastMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass31 = month30.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        int int34 = month30.compareTo((java.lang.Object) fixedMillisecond33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month30);
        java.util.Calendar calendar36 = null;
        try {
            month30.peg(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(timeSeries35);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getSerialIndex();
        int int8 = day6.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, "", "org.jfree.data.event.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        boolean boolean12 = timeSeries6.isEmpty();
        timeSeries6.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '4');
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) (short) 0);
        try {
            java.lang.Number number19 = timeSeries6.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries6.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.lang.String str2 = year1.toString();
        java.util.Date date3 = year1.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) (short) 0);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        long long2 = month0.getSerialIndex();
        int int3 = month0.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        timeSeries17.setDescription("");
        int int21 = timeSeries17.getItemCount();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass23 = month22.getClass();
        org.jfree.data.time.Year year24 = month22.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
        int int31 = year24.compareTo((java.lang.Object) date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond33.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond33.next();
        boolean boolean38 = year24.equals((java.lang.Object) regularTimePeriod37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.String str40 = year24.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 100L + "'", long35 == 100L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getLastMillisecond();
        long long8 = day6.getSerialIndex();
        int int9 = day6.getDayOfMonth();
        long long10 = day6.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-57600000L) + "'", long10 == (-57600000L));
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.lang.Class<?> wildcardClass27 = day26.getClass();
        java.lang.Number number28 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        java.util.List list29 = timeSeries6.getItems();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21);
        long long23 = timeSeries22.getMaximumItemAge();
        java.util.List list24 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries22);
        int int26 = timeSeries25.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31);
        java.lang.String str34 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) 9999);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 1561964399999L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond40.getTime();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass47 = month46.getClass();
        org.jfree.data.time.Year year48 = month46.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month46.next();
        java.lang.Number number50 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month46, number50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass53 = month52.getClass();
        int int54 = timeSeries45.getIndex((org.jfree.data.time.RegularTimePeriod) month52);
        boolean boolean56 = timeSeries45.equals((java.lang.Object) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond58.getMiddleMillisecond(calendar59);
        java.util.Date date61 = fixedMillisecond58.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond58.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = fixedMillisecond58.previous();
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass65 = month64.getClass();
        java.lang.String str66 = month64.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month64.next();
        int int68 = month64.getYearValue();
        long long69 = month64.getMiddleMillisecond();
        org.jfree.data.time.Year year70 = month64.getYear();
        long long71 = year70.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (org.jfree.data.time.RegularTimePeriod) year70);
        boolean boolean73 = month33.equals((java.lang.Object) timeSeries72);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "December 1969" + "'", str34.equals("December 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "June 2019" + "'", str66.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2019 + "'", int68 == 2019);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560668399999L + "'", long69 == 1560668399999L);
        org.junit.Assert.assertNotNull(year70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.lang.String str7 = month6.toString();
        int int8 = month6.getMonth();
        java.util.Date date9 = month6.getEnd();
        java.lang.String str10 = month6.toString();
        org.jfree.data.time.Year year11 = month6.getYear();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 1969" + "'", str7.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 1969" + "'", str10.equals("December 1969"));
        org.junit.Assert.assertNotNull(year11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.lang.String str14 = year12.toString();
        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Date date16 = year12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date16, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, "7", "7");
        int int11 = timeSeries10.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        timeSeries6.clear();
        timeSeries6.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.Year year28 = month26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, number30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((int) (short) 0, 0);
        timeSeries25.clear();
        java.util.Collection collection36 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection37 = timeSeries25.getTimePeriods();
        timeSeries25.setDescription("31-December-1969");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries25, seriesChangeInfo40);
        java.lang.Object obj42 = timeSeries25.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getLastMillisecond(calendar45);
        boolean boolean48 = fixedMillisecond44.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 1969);
        boolean boolean51 = timeSeriesDataItem50.isSelected();
        java.lang.Number number52 = timeSeriesDataItem50.getValue();
        java.lang.Object obj53 = timeSeriesDataItem50.clone();
        timeSeries25.add(timeSeriesDataItem50, false);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass57 = month56.getClass();
        java.lang.String str58 = month56.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month56.next();
        int int60 = month56.getYearValue();
        long long61 = month56.getMiddleMillisecond();
        long long62 = month56.getSerialIndex();
        int int63 = timeSeriesDataItem50.compareTo((java.lang.Object) month56);
        java.util.Calendar calendar64 = null;
        try {
            month56.peg(calendar64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 1969 + "'", number52.equals(1969));
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "June 2019" + "'", str58.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560668399999L + "'", long61 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 24234L + "'", long62 == 24234L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1969);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        timeSeries6.setKey((java.lang.Comparable) timeSeriesDataItem19);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener22);
        try {
            java.lang.Number number25 = timeSeries6.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        timeSeries17.setDescription("");
        int int21 = timeSeries17.getItemCount();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass23 = month22.getClass();
        org.jfree.data.time.Year year24 = month22.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.next();
        java.lang.Object obj26 = null;
        int int27 = month22.compareTo(obj26);
        timeSeries17.setKey((java.lang.Comparable) month22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        java.util.Date date33 = fixedMillisecond30.getTime();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
        java.lang.String str36 = month35.toString();
        int int37 = month35.getMonth();
        int int39 = month35.compareTo((java.lang.Object) "December 1969");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        java.util.Calendar calendar41 = null;
        try {
            long long42 = month35.getLastMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "December 1969" + "'", str36.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.lang.Class<?> wildcardClass5 = fixedMillisecond1.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass25 = month24.getClass();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, number28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) (short) 100);
        java.lang.Number number39 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries6.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year2.compareTo((java.lang.Object) date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7);
        int int12 = day11.getYear();
        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        int int9 = year2.compareTo((java.lang.Object) date7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year2.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean17 = timeSeries6.equals((java.lang.Object) 10);
        boolean boolean18 = timeSeries6.getNotify();
        timeSeries6.removeAgedItems(false);
        timeSeries6.setNotify(false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1969);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        timeSeries6.setKey((java.lang.Comparable) timeSeriesDataItem19);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem19, seriesChangeInfo22);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo24 = seriesChangeEvent23.getSummary();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(seriesChangeInfo24);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        timeSeries17.setDescription("");
        int int21 = timeSeries17.getItemCount();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass23 = month22.getClass();
        org.jfree.data.time.Year year24 = month22.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.next();
        java.lang.Object obj26 = null;
        int int27 = month22.compareTo(obj26);
        timeSeries17.setKey((java.lang.Comparable) month22);
        java.lang.Class<?> wildcardClass29 = timeSeries17.getClass();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.lang.String str8 = timeSeries6.getRangeDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass10 = month9.getClass();
        org.jfree.data.time.Year year11 = month9.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17);
        long long19 = timeSeries18.getMaximumItemAge();
        java.lang.String str20 = timeSeries18.getRangeDescription();
        boolean boolean21 = year11.equals((java.lang.Object) str20);
        java.lang.Class<?> wildcardClass22 = year11.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year11.next();
        timeSeries6.add(regularTimePeriod23, (java.lang.Number) 2019L, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(99L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        java.util.Date date33 = fixedMillisecond30.getTime();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass37 = month36.getClass();
        org.jfree.data.time.Year year38 = month36.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month36.next();
        java.lang.Number number40 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, number40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass43 = month42.getClass();
        int int44 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        java.lang.Object obj45 = timeSeries35.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries35.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond47.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries51 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21);
        long long23 = timeSeries22.getMaximumItemAge();
        java.util.List list24 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31);
        long long33 = timeSeries32.getMaximumItemAge();
        timeSeries32.setDomainDescription("2019");
        timeSeries32.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
        java.util.Date date41 = fixedMillisecond38.getTime();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42);
        java.util.Collection collection44 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        boolean boolean45 = timeSeries15.equals((java.lang.Object) timeSeries32);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries32.createCopy(6, 9);
        boolean boolean49 = timeSeries32.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.Object obj16 = timeSeries6.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
        java.lang.Object obj21 = timeSeries6.clone();
        java.util.List list22 = timeSeries6.getItems();
        java.lang.String str23 = timeSeries6.getDomainDescription();
        double double24 = timeSeries6.getMinY();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        int int29 = month25.compareTo((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.previous();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        org.jfree.data.time.Year year33 = month31.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month31.next();
        int int36 = month31.compareTo((java.lang.Object) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month31.next();
        int int38 = month31.getMonth();
        boolean boolean39 = fixedMillisecond28.equals((java.lang.Object) month31);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond28.getFirstMillisecond(calendar40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
        java.util.Date date46 = fixedMillisecond43.getTime();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year47);
        long long49 = timeSeries48.getMaximumItemAge();
        timeSeries48.setDomainDescription("2019");
        timeSeries48.clear();
        timeSeries48.fireSeriesChanged();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getSerialIndex();
        java.lang.String str56 = year54.toString();
        java.lang.Number number57 = timeSeries48.getValue((org.jfree.data.time.RegularTimePeriod) year54);
        java.util.Date date58 = year54.getEnd();
        java.util.Date date59 = year54.getStart();
        long long60 = year54.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) year54);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
        org.junit.Assert.assertNull(number57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries61);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "1969");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.Date date8 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        java.lang.String str8 = day6.toString();
        java.lang.String str9 = day6.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15);
        long long17 = timeSeries16.getMaximumItemAge();
        boolean boolean18 = day6.equals((java.lang.Object) long17);
        java.lang.String str19 = day6.toString();
        java.lang.String str20 = day6.toString();
        org.jfree.data.time.SerialDate serialDate21 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-1969" + "'", str19.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-1969" + "'", str20.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        java.lang.String str16 = day15.toString();
        int int17 = day15.getYear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.Year year20 = month18.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        int int27 = year20.compareTo((java.lang.Object) date25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date25);
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        java.lang.String str31 = day15.toString();
        long long32 = day15.getFirstMillisecond();
        long long33 = day15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day15.previous();
        java.lang.String str35 = day15.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-1969" + "'", str16.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-57600000L) + "'", long32 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-57600000L) + "'", long33 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-1969" + "'", str35.equals("31-December-1969"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        java.lang.String str14 = year12.toString();
        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = year12.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
        boolean boolean22 = fixedMillisecond18.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1969);
        boolean boolean25 = timeSeriesDataItem24.isSelected();
        java.lang.Number number26 = timeSeriesDataItem24.getValue();
        java.lang.Object obj27 = timeSeriesDataItem24.clone();
        boolean boolean28 = year12.equals(obj27);
        int int30 = year12.compareTo((java.lang.Object) "1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year36);
        long long38 = timeSeries37.getMaximumItemAge();
        java.util.List list39 = timeSeries37.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond41.getTime();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
        java.lang.String str47 = day46.toString();
        int int48 = day46.getYear();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass50 = month49.getClass();
        org.jfree.data.time.Year year51 = month49.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond53.getMiddleMillisecond(calendar54);
        java.util.Date date56 = fixedMillisecond53.getTime();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
        int int58 = year51.compareTo((java.lang.Object) date56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond(date56);
        java.util.Date date60 = fixedMillisecond59.getTime();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        boolean boolean62 = year12.equals((java.lang.Object) timeSeries61);
        int int63 = timeSeries61.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1969 + "'", number26.equals(1969));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31-December-1969" + "'", str47.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1969 + "'", int48 == 1969);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(year51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2147483647 + "'", int63 == 2147483647);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getLastMillisecond();
        long long8 = day6.getSerialIndex();
        int int9 = day6.getDayOfMonth();
        int int10 = day6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        java.util.Calendar calendar9 = null;
        try {
            day8.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        java.lang.String str8 = day6.toString();
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getMonth();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.lang.Number number9 = null;
        try {
            timeSeries6.update((int) (byte) 100, number9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass25 = month24.getClass();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, number28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) (short) 100);
        java.lang.Number number39 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond46.getFirstMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        timeSeries23.removeAgedItems(0L, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getMiddleMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond56.getTime();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date59);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date59);
        java.lang.String str62 = month61.toString();
        int int63 = month61.getMonth();
        java.util.Date date64 = month61.getEnd();
        java.lang.String str65 = month61.toString();
        org.jfree.data.time.Year year66 = month61.getYear();
        java.lang.String str67 = year66.toString();
        try {
            timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year66, (double) 5, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "December 1969" + "'", str62.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 12 + "'", int63 == 12);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "December 1969" + "'", str65.equals("December 1969"));
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1969" + "'", str67.equals("1969"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timeSeries6.isEmpty();
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((-1), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        boolean boolean24 = fixedMillisecond20.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 1969);
        boolean boolean27 = timeSeriesDataItem26.isSelected();
        java.lang.Number number28 = timeSeriesDataItem26.getValue();
        java.lang.Object obj29 = timeSeriesDataItem26.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond31.getTime();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.Year year39 = month37.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month37.next();
        java.lang.Number number41 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, number41);
        int int43 = timeSeriesDataItem26.compareTo((java.lang.Object) month37);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month37);
        double double45 = timeSeries6.getMaxY();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1969 + "'", number28.equals(1969));
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        timeSeries6.fireSeriesChanged();
        boolean boolean12 = timeSeries6.isEmpty();
        java.lang.Object obj13 = timeSeries6.clone();
        timeSeries6.clear();
        java.lang.String str15 = timeSeries6.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
        boolean boolean6 = fixedMillisecond2.equals((java.lang.Object) (short) 100);
        boolean boolean7 = month0.equals((java.lang.Object) fixedMillisecond2);
        long long8 = fixedMillisecond2.getMiddleMillisecond();
        long long9 = fixedMillisecond2.getSerialIndex();
        java.util.Calendar calendar10 = null;
        fixedMillisecond2.peg(calendar10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        timeSeries6.clear();
        timeSeries6.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.Year year28 = month26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, number30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((int) (short) 0, 0);
        timeSeries25.clear();
        java.util.Collection collection36 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection37 = timeSeries25.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries25.addChangeListener(seriesChangeListener38);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean17 = timeSeries6.equals((java.lang.Object) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond19.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond19.previous();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        java.lang.String str27 = month25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month25.next();
        int int29 = month25.getYearValue();
        long long30 = month25.getMiddleMillisecond();
        org.jfree.data.time.Year year31 = month25.getYear();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) year31);
        long long34 = fixedMillisecond19.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560668399999L + "'", long30 == 1560668399999L);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        java.lang.String str7 = month6.toString();
        int int8 = month6.getMonth();
        java.util.Date date9 = month6.getEnd();
        java.lang.String str10 = month6.toString();
        int int11 = month6.getMonth();
        long long12 = month6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 1969" + "'", str7.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 1969" + "'", str10.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2649600000L) + "'", long12 == (-2649600000L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.Object obj16 = timeSeries6.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass29 = month28.getClass();
        org.jfree.data.time.Year year30 = month28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
        java.lang.Number number32 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, number32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries27.createCopy((int) (short) 0, 0);
        timeSeries27.clear();
        timeSeries27.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond41.getTime();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass48 = month47.getClass();
        org.jfree.data.time.Year year49 = month47.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month47.next();
        java.lang.Number number51 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, number51);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries46.createCopy((int) (short) 0, 0);
        timeSeries46.clear();
        java.util.Collection collection57 = timeSeries27.getTimePeriodsUniqueToOtherSeries(timeSeries46);
        java.util.Collection collection58 = timeSeries46.getTimePeriods();
        double double59 = timeSeries46.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries46.removeChangeListener(seriesChangeListener60);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries6.addAndOrUpdate(timeSeries46);
        timeSeries62.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeSeries62);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean17 = timeSeries6.equals((java.lang.Object) 10);
        boolean boolean18 = timeSeries6.getNotify();
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1969);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        java.lang.Number number30 = timeSeriesDataItem28.getValue();
        timeSeriesDataItem28.setValue((java.lang.Number) (byte) -1);
        timeSeriesDataItem28.setSelected(true);
        try {
            timeSeries6.add(timeSeriesDataItem28);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1969 + "'", number30.equals(1969));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int5 = month0.compareTo((java.lang.Object) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        int int7 = month0.getMonth();
        int int8 = month0.getYearValue();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month0.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            year2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("100");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 100" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 100"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        long long8 = day6.getSerialIndex();
        java.util.Date date9 = day6.getStart();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener10);
        boolean boolean12 = timeSeries6.isEmpty();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        java.util.Collection collection18 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        timeSeries17.setDescription("");
        int int21 = timeSeries17.getItemCount();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass23 = month22.getClass();
        org.jfree.data.time.Year year24 = month22.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.next();
        java.lang.Object obj26 = null;
        int int27 = month22.compareTo(obj26);
        timeSeries17.setKey((java.lang.Comparable) month22);
        java.lang.Class<?> wildcardClass29 = timeSeries17.getClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries17.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) (byte) 1);
        int int15 = month7.compareTo((java.lang.Object) (byte) 1);
        java.lang.String str16 = month7.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass12 = month11.getClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        org.jfree.data.time.Year year15 = month13.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        int int18 = month13.compareTo((java.lang.Object) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month13.next();
        int int20 = month13.getMonth();
        org.jfree.data.time.Year year21 = month13.getYear();
        long long22 = year21.getLastMillisecond();
        boolean boolean23 = month11.equals((java.lang.Object) year21);
        int int25 = year21.compareTo((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, 100.0d);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(100);
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 1969, true);
        java.lang.String str33 = timeSeries6.getDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(7);
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        long long16 = timeSeries15.getMaximumItemAge();
        timeSeries15.setDomainDescription("2019");
        timeSeries15.clear();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1969);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeries15.setKey((java.lang.Comparable) timeSeriesDataItem28);
        java.util.Collection collection31 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.setNotify(true);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass35 = month34.getClass();
        org.jfree.data.time.Year year36 = month34.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.next();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month34, 0.0d);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries15.addChangeListener(seriesChangeListener40);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        long long16 = timeSeries6.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass25 = month24.getClass();
        org.jfree.data.time.Year year26 = month24.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, number28);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries23.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
        boolean boolean38 = fixedMillisecond34.equals((java.lang.Object) (short) 100);
        java.lang.Number number39 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries6.addAndOrUpdate(timeSeries23);
        double double43 = timeSeries42.getMinY();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 100L + "'", long36 == 100L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(number39);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        java.lang.String str9 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass8 = month7.getClass();
//        org.jfree.data.time.Year year9 = month7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
//        timeSeries6.clear();
//        timeSeries6.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getTime();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass27 = month26.getClass();
//        org.jfree.data.time.Year year28 = month26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, number30);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((int) (short) 0, 0);
//        timeSeries25.clear();
//        java.util.Collection collection36 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond38.getTime();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass45 = month44.getClass();
//        org.jfree.data.time.Year year46 = month44.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month44.next();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, number48);
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass51 = month50.getClass();
//        int int52 = timeSeries43.getIndex((org.jfree.data.time.RegularTimePeriod) month50);
//        boolean boolean54 = timeSeries43.equals((java.lang.Object) 10);
//        boolean boolean55 = timeSeries43.getNotify();
//        timeSeries43.removeAgedItems(false);
//        java.lang.String str58 = timeSeries43.getDescription();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        int int60 = day59.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day59.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries43.getDataItem(regularTimePeriod61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar65 = null;
//        long long66 = fixedMillisecond64.getMiddleMillisecond(calendar65);
//        java.util.Date date67 = fixedMillisecond64.getTime();
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date67);
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year68);
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass71 = month70.getClass();
//        org.jfree.data.time.Year year72 = month70.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month70.next();
//        java.lang.Number number74 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month70, number74);
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries69.createCopy((int) (short) 0, 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
//        java.util.Calendar calendar81 = null;
//        long long82 = fixedMillisecond80.getMiddleMillisecond(calendar81);
//        java.util.Date date83 = fixedMillisecond80.getTime();
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date83);
//        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year84);
//        long long86 = timeSeries85.getMaximumItemAge();
//        java.util.List list87 = timeSeries85.getItems();
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries78.addAndOrUpdate(timeSeries85);
//        int int89 = timeSeries88.getItemCount();
//        boolean boolean90 = timeSeriesDataItem62.equals((java.lang.Object) timeSeries88);
//        timeSeries25.add(timeSeriesDataItem62);
//        int int92 = timeSeries25.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertNull(str58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertNotNull(year72);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//        org.junit.Assert.assertNotNull(timeSeries78);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 100L + "'", long82 == 100L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 9223372036854775807L + "'", long86 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list87);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2147483647 + "'", int92 == 2147483647);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int4 = month0.compareTo((java.lang.Object) fixedMillisecond3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond3.peg(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond3.previous();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        long long5 = year3.getSerialIndex();
        long long6 = year3.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        timeSeries6.setDomainDescription("2019");
        timeSeries6.clear();
        java.lang.String str11 = timeSeries6.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getLastMillisecond(calendar14);
        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1969);
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        java.lang.Number number21 = timeSeriesDataItem19.getValue();
        boolean boolean22 = timeSeriesDataItem19.isSelected();
        timeSeries6.add(timeSeriesDataItem19);
        java.lang.Number number24 = timeSeriesDataItem19.getValue();
        java.lang.Number number25 = timeSeriesDataItem19.getValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass34 = month33.getClass();
        org.jfree.data.time.Year year35 = month33.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, number37);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getLastMillisecond(calendar44);
        boolean boolean47 = fixedMillisecond43.equals((java.lang.Object) (short) 100);
        java.lang.Number number48 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.lang.Class class49 = timeSeries32.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeries32.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod50, "org.jfree.data.time.TimePeriodFormatException: ", "31-December-1969");
        int int54 = timeSeriesDataItem19.compareTo((java.lang.Object) timeSeries53);
        java.lang.String str55 = timeSeries53.getDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1969 + "'", number21.equals(1969));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1969 + "'", number24.equals(1969));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1969 + "'", number25.equals(1969));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNull(str55);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.util.List list8 = timeSeries6.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year14);
        long long16 = timeSeries15.getMaximumItemAge();
        timeSeries15.setDomainDescription("2019");
        timeSeries15.clear();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1969);
        boolean boolean29 = timeSeriesDataItem28.isSelected();
        timeSeries15.setKey((java.lang.Comparable) timeSeriesDataItem28);
        java.util.Collection collection31 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        int int32 = timeSeries15.getItemCount();
        timeSeries15.clear();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.lang.Number number35 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) month34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year41);
        long long43 = timeSeries42.getMaximumItemAge();
        java.util.List list44 = timeSeries42.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond46.getTime();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year50);
        long long52 = timeSeries51.getMaximumItemAge();
        timeSeries51.setDomainDescription("2019");
        timeSeries51.clear();
        timeSeries51.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond58.getLastMillisecond(calendar59);
        boolean boolean62 = fixedMillisecond58.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond58, (java.lang.Number) 1969);
        boolean boolean65 = timeSeriesDataItem64.isSelected();
        timeSeries51.setKey((java.lang.Comparable) timeSeriesDataItem64);
        java.util.Collection collection67 = timeSeries42.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries51.createCopy((int) (byte) 100, (int) (short) 100);
        java.util.Collection collection71 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        timeSeries15.setDomainDescription("June 2019");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(number35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(collection67);
        org.junit.Assert.assertNotNull(timeSeries70);
        org.junit.Assert.assertNotNull(collection71);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass14 = month13.getClass();
        int int15 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.Object obj16 = timeSeries6.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1);
        java.lang.Object obj21 = timeSeries6.clone();
        java.util.List list22 = timeSeries6.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries6.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) 1561964399999L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year21);
        long long23 = timeSeries22.getMaximumItemAge();
        java.util.List list24 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries15.addAndOrUpdate(timeSeries22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year31);
        long long33 = timeSeries32.getMaximumItemAge();
        timeSeries32.setDomainDescription("2019");
        timeSeries32.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getMiddleMillisecond(calendar39);
        java.util.Date date41 = fixedMillisecond38.getTime();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year42);
        java.util.Collection collection44 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        boolean boolean45 = timeSeries15.equals((java.lang.Object) timeSeries32);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond48.getLastMillisecond(calendar49);
        boolean boolean52 = fixedMillisecond48.equals((java.lang.Object) (short) 100);
        boolean boolean53 = month46.equals((java.lang.Object) fixedMillisecond48);
        long long54 = fixedMillisecond48.getMiddleMillisecond();
        long long55 = fixedMillisecond48.getSerialIndex();
        try {
            timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 0.0f, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 100L + "'", long54 == 100L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        int int5 = month0.compareTo((java.lang.Object) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.next();
        int int7 = month0.getMonth();
        org.jfree.data.time.Year year8 = month0.getYear();
        int int9 = month0.getMonth();
        int int10 = month0.getMonth();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month0);
        int int12 = month0.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        int int2 = month0.getMonth();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        int int8 = day6.getDayOfMonth();
        java.lang.String str9 = day6.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15);
        long long17 = timeSeries16.getMaximumItemAge();
        java.util.List list18 = timeSeries16.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24);
        long long26 = timeSeries25.getMaximumItemAge();
        timeSeries25.setDomainDescription("2019");
        timeSeries25.clear();
        timeSeries25.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        boolean boolean36 = fixedMillisecond32.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1969);
        boolean boolean39 = timeSeriesDataItem38.isSelected();
        timeSeries25.setKey((java.lang.Comparable) timeSeriesDataItem38);
        java.util.Collection collection41 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.List list42 = timeSeries16.getItems();
        boolean boolean43 = day6.equals((java.lang.Object) list42);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.next();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, number11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 0, 0);
        timeSeries6.clear();
        timeSeries6.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.Year year28 = month26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
        java.lang.Number number30 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, number30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries25.createCopy((int) (short) 0, 0);
        timeSeries25.clear();
        java.util.Collection collection36 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.util.Collection collection37 = timeSeries25.getTimePeriods();
        timeSeries25.setDescription("31-December-1969");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo40 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries25, seriesChangeInfo40);
        java.lang.Object obj42 = timeSeries25.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getLastMillisecond(calendar45);
        boolean boolean48 = fixedMillisecond44.equals((java.lang.Object) (short) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 1969);
        boolean boolean51 = timeSeriesDataItem50.isSelected();
        java.lang.Number number52 = timeSeriesDataItem50.getValue();
        java.lang.Object obj53 = timeSeriesDataItem50.clone();
        timeSeries25.add(timeSeriesDataItem50, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year61);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass64 = month63.getClass();
        org.jfree.data.time.Year year65 = month63.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month63.next();
        java.lang.Number number67 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries62.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month63, number67);
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries62.createCopy((int) (short) 0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond73.getLastMillisecond(calendar74);
        boolean boolean77 = fixedMillisecond73.equals((java.lang.Object) (short) 100);
        java.lang.Number number78 = timeSeries62.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
        java.lang.Class class79 = timeSeries62.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = timeSeries62.getNextTimePeriod();
        timeSeries25.setKey((java.lang.Comparable) regularTimePeriod80);
        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass83 = month82.getClass();
        java.lang.String str84 = month82.toString();
        org.jfree.data.time.Year year85 = month82.getYear();
        long long86 = month82.getLastMillisecond();
        java.lang.Number number87 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) month82);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 1969 + "'", number52.equals(1969));
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 100L + "'", long59 == 100L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(year65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 100L + "'", long75 == 100L);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(number78);
        org.junit.Assert.assertNotNull(class79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "June 2019" + "'", str84.equals("June 2019"));
        org.junit.Assert.assertNotNull(year85);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1561964399999L + "'", long86 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + number87 + "' != '" + 1969 + "'", number87.equals(1969));
    }
}

