import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) -1, jFreeChart1, chartChangeEventType2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Shape shape0 = null;
        org.jfree.chart.title.Title title1 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity4 = new org.jfree.chart.entity.TitleEntity(shape0, title1, "", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity3 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(xYDataset0, list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("VerticalAlignment.CENTER");
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        java.lang.String str1 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.DESCENDING" + "'", str1.equals("DomainOrder.DESCENDING"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Range[0.0,1.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 0, (double) 1.0f, 0.0d, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        int int4 = segmentedTimeline3.getSegmentsIncluded();
        java.util.Date date5 = null;
        java.util.Date date6 = null;
        try {
            boolean boolean7 = segmentedTimeline3.containsDomainRange(date5, date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name VerticalAlignment.CENTER, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Range[0.0,1.0]", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("DomainOrder.DESCENDING", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound(xYDataset0, (-1), (double) (byte) 10, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 10);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter3 = null;
        try {
            xYBarRenderer0.setBarPainter(xYBarPainter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 10L, (double) (short) 10, (double) 1L);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = null;
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            gradientBarPainter3.paintBarShadow(graphics2D4, barRenderer5, (int) (byte) 1, 175, true, rectangularShape9, rectangleEdge10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) 0L);
        java.util.Date date3 = null;
        try {
            java.lang.String str4 = dateTickUnit0.dateToString(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity6 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape3, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        try {
            java.util.Date date3 = dateTickUnit0.addToDate(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color13, stroke14);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            xYBarRenderer0.drawRangeMarker(graphics2D9, xYPlot10, valueAxis11, (org.jfree.chart.plot.Marker) valueMarker15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        xYBarRenderer0.setSeriesVisible((int) (byte) 10, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot1.getInsets();
        double double4 = rectangleInsets3.getRight();
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries1.remove((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 10L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getStartTime();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline3.getBaseTimeline();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNull(segmentedTimeline5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = null;
        try {
            legendItem1.setFillPaintTransformer(gradientPaintTransformer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 100.0d, 0.0d, (double) 8);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        axisState1.cursorRight((double) 3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("UnitType.ABSOLUTE");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot1.getInsets();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D6, rectangleAnchor7);
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            multiplePiePlot1.draw(graphics2D4, rectangle2D5, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(point2D8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = null;
        java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D4, rectangleAnchor5);
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            multiplePiePlot1.draw(graphics2D2, rectangle2D3, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYBarRenderer5.getSeriesURLGenerator(1);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer5.setBaseOutlineStroke(stroke8);
        xYBarRenderer5.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer5.setBaseShape(shape14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator21 = xYBarRenderer19.getSeriesURLGenerator(1);
        xYBarRenderer19.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color24 = java.awt.Color.PINK;
        xYBarRenderer19.setBasePaint((java.awt.Paint) color24, false);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator31 = xYBarRenderer29.getSeriesURLGenerator(1);
        java.awt.Stroke stroke32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer29.setBaseOutlineStroke(stroke32);
        xYBarRenderer29.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer29.setBaseShape(shape38);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color42, stroke43);
        try {
            org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem(attributedString0, "UnitType.ABSOLUTE", "", "Range[0.0,1.0]", true, shape14, true, (java.awt.Paint) color17, true, (java.awt.Paint) color24, stroke27, true, shape38, stroke40, (java.awt.Paint) color42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(xYURLGenerator21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(xYURLGenerator31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setGroupingUsed(true);
        try {
            java.lang.Object obj4 = numberFormat0.parseObject("VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = timeSeries1.createCopy(regularTimePeriod2, regularTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Paint paint0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = null;
        try {
            timeSeries1.add(timeSeriesDataItem2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            int int5 = timeSeries1.getIndex(regularTimePeriod4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener9 = null;
        try {
            xYBarRenderer0.addChangeListener(rendererChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer0.getURLGenerator((int) (byte) 1, 100, true);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator12);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(true, true);
        double double5 = piePlot3D1.getLabelGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot3D1.removeChangeListener(plotChangeListener6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = null;
        try {
            piePlot3D1.setLabelLinkStyle(pieLabelLinkStyle8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            org.jfree.chart.axis.AxisState axisState7 = categoryAxis3D0.draw(graphics2D1, 0.0d, rectangle2D3, rectangle2D4, rectangleEdge5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        java.awt.Shape shape12 = null;
        xYBarRenderer0.setLegendShape((int) (byte) 10, shape12);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        java.lang.Object obj6 = markerChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        boolean boolean14 = piePlot3D1.getDarkerSides();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("VerticalAlignment.CENTER");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(true, true);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = null;
        java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            piePlot3D1.draw(graphics2D5, rectangle2D6, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean2 = blockBorder0.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = null;
        try {
            xYPlot0.setDomainZeroBaselineStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYDataItem xYDataItem7 = null;
        try {
            xYSeries1.add(xYDataItem7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener7 = null;
        try {
            xYBarRenderer0.addChangeListener(rendererChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) 0L);
        int int4 = dateTickUnit0.compareTo((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        try {
            xYLineAndShapeRenderer0.setSeriesLinesVisible(2147483647, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, (double) 10.0f, (double) (-1.0f));
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        java.lang.String str3 = range0.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range0, (double) 10.0f, true);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range0.intersects(range7);
        boolean boolean10 = range7.contains(2.0d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("TextAnchor.TOP_LEFT", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        piePlot3D1.setStartAngle((double) 4);
        java.awt.Stroke stroke8 = null;
        try {
            piePlot3D1.setBaseSectionOutlineStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            periodAxis1.setLast(regularTimePeriod15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'last' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { "SeriesRenderingOrder.FORWARD", (short) 10, (short) 0 };
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { 90.0d, (byte) 10, "SeriesRenderingOrder.FORWARD", (-1L) };
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[][] doubleArray15 = new double[][] { doubleArray9, doubleArray10, doubleArray11, doubleArray12, doubleArray13, doubleArray14 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray8, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        xYBarRenderer0.setSeriesVisibleInLegend(8, (java.lang.Boolean) true);
        java.awt.Paint paint8 = xYBarRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        java.lang.String str2 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str2.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "hi!", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER");
        java.lang.String str5 = library4.getVersion();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (float) (byte) 100, (float) 35, (double) 1, (float) (byte) 0, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        float[] floatArray7 = new float[] { 'a', (byte) 100, (short) 100, (short) -1 };
        float[] floatArray8 = java.awt.Color.RGBtoHSB(0, 0, (int) 'a', floatArray7);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot16.getRangeAxis((int) '#');
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean21 = periodAxis20.isAxisLineVisible();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            xYBarRenderer0.fillRangeGridBand(graphics2D15, xYPlot16, (org.jfree.chart.axis.ValueAxis) periodAxis20, rectangle2D22, Double.NaN, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = categoryAxis3D0.draw(graphics2D3, (double) 1, rectangle2D5, rectangle2D6, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint12 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        xYBarRenderer0.setBase(0.0d);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYBarRenderer0.setSeriesItemLabelPaint(0, (java.awt.Paint) color16);
        double double18 = xYBarRenderer0.getBase();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        java.lang.Object obj2 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        int int2 = defaultXYDataset0.indexOf((java.lang.Comparable) 0.025d);
        java.lang.Object obj3 = defaultXYDataset0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 100.0d, 0.0d, (double) 8);
        double double6 = rectangleInsets5.getLeft();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        try {
            legendItem1.setFillPaintTransformer(gradientPaintTransformer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        xYBarRenderer0.setDrawBarOutline(false);
        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYBarRenderer0.setBaseItemLabelFont(font9);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        int int2 = defaultXYDataset0.indexOf((java.lang.Comparable) 0.025d);
        java.util.List list3 = null;
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range4, range8);
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toRangeHeight(range13);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(range13);
        try {
            org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, list3, (org.jfree.data.Range) dateRange15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("DomainOrder.DESCENDING");
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate(regularTimePeriod4, (java.lang.Number) 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.lang.Class class4 = null;
        try {
            periodAxis1.setAutoRangeTimePeriodClass(class4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key VerticalAlignment.CENTER");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        java.lang.Class class2 = null;
        try {
            periodAxis1.setMajorTickTimePeriodClass(class2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener2);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries1.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            jFreeChart2.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        try {
            org.jfree.chart.title.Title title13 = jFreeChart7.getSubtitle(35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            xYSeriesCollection0.setSelected((int) (byte) 10, (int) (short) 100, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1.0f));
        java.lang.String str5 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HorizontalAlignment.CENTER" + "'", str5.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        java.awt.Font font3 = xYLineAndShapeRenderer0.lookupLegendTextFont((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot3 = jFreeChart2.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) rectangleAnchor2);
        try {
            java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setMinimumFractionDigits((int) (byte) 0);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter();
        try {
            java.lang.String str4 = numberFormat0.format((java.lang.Object) gradientBarPainter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        double double2 = timeSeries1.getMinY();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        xYPlot20.setDomainCrosshairVisible(false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot20.getDomainAxisForDataset((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 97 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        try {
            java.awt.image.BufferedImage bufferedImage7 = jFreeChart2.createBufferedImage((int) (byte) 1, 0, 10, chartRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (0) must be > 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        java.lang.Comparable comparable19 = null;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        boolean boolean22 = piePlot3D21.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot3D21.getLegendLabelToolTipGenerator();
        double double24 = piePlot3D21.getStartAngle();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D21.setLabelBackgroundPaint((java.awt.Paint) color25);
        try {
            piePlot3D8.setSectionOutlinePaint(comparable19, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 90.0d + "'", double24 == 90.0d);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            xYPlot20.setDomainAxisLocation(axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.lang.Number number0 = null;
        try {
            org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(number0, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'x' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        int int22 = xYPlot20.getRendererCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        intervalMarker2.setStartValue((double) (short) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        try {
            intervalMarker2.setLabelOffsetType(lengthAdjustmentType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYBarRenderer0.setBaseItemLabelFont(font11);
        java.awt.Font font13 = xYBarRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = borderArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        boolean boolean4 = tickUnits0.equals((java.lang.Object) (-1));
        try {
            org.jfree.chart.axis.TickUnit tickUnit6 = tickUnits0.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        java.lang.Object obj2 = timeSeries1.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries2.createCopy((int) 'a', (int) (byte) -1);
        xYSeries2.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries10 = xYSeries2.createCopy(10, 1);
        xYSeries2.clear();
        boolean boolean12 = tickUnits0.equals((java.lang.Object) xYSeries2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        try {
            org.jfree.chart.axis.TickUnit tickUnit14 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertNotNull(xYSeries10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(numberTickUnit13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        double double2 = timeSeries1.getMinY();
        int int3 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            int int5 = timeSeries1.getIndex(regularTimePeriod4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 175, (double) (-1), (int) (byte) 1, (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        piePlot3D1.setBackgroundImageAlignment(6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        try {
            org.jfree.data.xy.XYSeries xYSeries22 = xYSeriesCollection0.getSeries((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "VerticalAlignment.CENTER", 0.08d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("[size=1]");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, 10, 4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("java.awt.Color[r=255,g=0,b=0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        try {
            org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset7, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        xYBarRenderer0.setBaseSeriesVisible(true, false);
        xYBarRenderer0.setItemLabelAnchorOffset(10.0d);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot21.panDomainAxes((double) (byte) 0, plotRenderingInfo25, point2D28);
        boolean boolean30 = xYPlot21.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D31 = xYPlot21.getQuadrantOrigin();
        org.jfree.chart.axis.PeriodAxis periodAxis33 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis33.setLowerBound((double) 10);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.Color color38 = java.awt.Color.RED;
        java.lang.String str39 = color38.toString();
        java.awt.Stroke stroke40 = null;
        try {
            xYBarRenderer0.drawDomainLine(graphics2D20, xYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis33, rectangle2D36, (double) 3492L, (java.awt.Paint) color38, stroke40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str39.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint12 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        xYBarRenderer0.setBaseFillPaint((java.awt.Paint) color13, true);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        org.jfree.chart.LegendItem legendItem7 = xYBarRenderer0.getLegendItem(100, 0);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries3.createCopy((int) 'a', (int) (byte) -1);
        xYSeries3.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries3.createCopy(10, 1);
        xYSeries3.clear();
        boolean boolean13 = tickUnits1.equals((java.lang.Object) xYSeries3);
        xYSeriesCollection0.removeSeries(xYSeries3);
        try {
            xYSeriesCollection0.setIntervalPositionFactor(8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        java.util.TimeZone timeZone5 = null;
        try {
            periodAxis1.setTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        org.jfree.data.xy.XYDataItem xYDataItem12 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        org.jfree.data.xy.XYDataItem xYDataItem13 = xYSeries9.addOrUpdate(xYDataItem12);
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertNull(xYDataItem13);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        try {
            double double5 = defaultXYDataset0.getXValue(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[size=1]", numberFormat1, numberFormat2);
        java.text.DateFormat dateFormat4 = standardXYToolTipGenerator3.getYDateFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.add(0.0d, (double) 10);
        boolean boolean8 = xYSeries1.getNotify();
        try {
            org.jfree.data.xy.XYSeries xYSeries11 = xYSeries1.createCopy((int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        piePlot3D1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        try {
            java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset3, (java.lang.Comparable) "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Shape shape9 = null;
        xYBarRenderer0.setBaseLegendShape(shape9);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        boolean boolean3 = piePlot3D2.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D2.getLegendLabelToolTipGenerator();
        double double5 = piePlot3D2.getStartAngle();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D2.setLabelBackgroundPaint((java.awt.Paint) color6);
        java.awt.Color color9 = java.awt.Color.black;
        piePlot3D2.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color9);
        boolean boolean11 = timePeriodAnchor0.equals((java.lang.Object) "[size=1]");
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 97L, 0.0d, (double) 10.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "April" + "'", str1.equals("April"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[size=1]", numberFormat1, numberFormat2);
        java.math.RoundingMode roundingMode4 = null;
        try {
            numberFormat1.setRoundingMode(roundingMode4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.insertValue(3, (java.lang.Comparable) 8.0d, (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) (byte) 1);
        java.lang.String str4 = range1.toString();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range1, (double) 10.0f, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, range7);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[0.0,1.0]" + "'", str4.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        boolean boolean3 = piePlot3D2.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D2.getLegendLabelToolTipGenerator();
        double double5 = piePlot3D2.getStartAngle();
        java.awt.Paint paint6 = piePlot3D2.getLabelPaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        boolean boolean11 = piePlot3D10.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot3D10.getLegendLabelToolTipGenerator();
        double double13 = piePlot3D10.getStartAngle();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D10.setLabelBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.PiePlotState piePlotState18 = piePlot3D2.initialise(graphics2D7, rectangle2D8, (org.jfree.chart.plot.PiePlot) piePlot3D10, (java.lang.Integer) 10, plotRenderingInfo17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color21 = java.awt.Color.getColor("hi!", color20);
        piePlot3D10.setLabelOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = xYBarRenderer24.getSeriesURLGenerator(1);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer24.setBaseOutlineStroke(stroke27);
        xYBarRenderer24.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint32 = xYBarRenderer24.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, paint32, stroke33);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        valueMarker34.setOutlineStroke(stroke35);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot40 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset39);
        org.jfree.chart.plot.Plot plot41 = multiplePiePlot40.getRootPlot();
        java.awt.Paint paint42 = plot41.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint42);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer44 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator46 = xYBarRenderer44.getSeriesURLGenerator(1);
        java.awt.Stroke stroke47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer44.setBaseOutlineStroke(stroke47);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 13, (java.awt.Paint) color21, stroke35, paint42, stroke47, (float) 175);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 90.0d + "'", double13 == 90.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(piePlotState18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(xYURLGenerator26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(xYURLGenerator46);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[size=1]", numberFormat1, numberFormat2);
        java.math.RoundingMode roundingMode4 = numberFormat1.getRoundingMode();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode4.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        double double14 = piePlot3D8.getDepthFactor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.12d + "'", double14 == 0.12d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        java.awt.Stroke stroke6 = xYPlot0.getDomainMinorGridlineStroke();
        boolean boolean7 = xYPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            plot2.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.add((double) (byte) -1, (double) (short) 1, true);
        boolean boolean9 = xYSeries1.getNotify();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString((double) 13);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13" + "'", str2.equals("13"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("VerticalAlignment.CENTER", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        java.lang.Object obj4 = valueMarker3.clone();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        valueMarker3.setLabelTextAnchor(textAnchor5);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape4, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot10.getRootPlot();
        java.awt.Shape shape12 = multiplePiePlot10.getLegendItemShape();
        chartEntity8.setArea(shape12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke17);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity21 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart16, "java.awt.Color[r=255,g=0,b=0]", "hi!");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator22 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator23 = null;
        try {
            java.lang.String str24 = jFreeChartEntity21.getImageMapAreaTag(toolTipTagFragmentGenerator22, uRLTagFragmentGenerator23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        xYBarRenderer0.setShadowYOffset((double) 2019);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.black;
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color8);
        piePlot3D1.setIgnoreZeroValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 100);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator1, xYURLGenerator2);
        boolean boolean4 = xYAreaRenderer3.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        boolean boolean5 = piePlot3D1.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        java.lang.String str3 = range0.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range0, (double) 10.0f, true);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range0.intersects(range7);
        boolean boolean11 = range7.intersects((double) 1, 0.0d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        piePlot3D8.setPieIndex((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ClassContext", graphics2D1, (float) 100, (float) 175, textAnchor4, (double) 2019L, 0.0f, (float) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.awt.Paint paint2 = paintMap0.getPaint((java.lang.Comparable) 2019);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries5 = xYSeries2.createCopy((int) 'a', (int) (byte) -1);
        xYSeries2.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries10 = xYSeries2.createCopy(10, 1);
        xYSeries2.clear();
        boolean boolean12 = tickUnits0.equals((java.lang.Object) xYSeries2);
        org.jfree.data.xy.XYDataItem xYDataItem15 = xYSeries2.addOrUpdate((double) (-1L), (double) 4);
        try {
            xYSeries2.updateByIndex(3, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries5);
        org.junit.Assert.assertNotNull(xYSeries10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(xYDataItem15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        java.awt.Paint paint6 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean14 = range12.contains((double) (byte) 1);
        double double15 = range12.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range8, range12);
        boolean boolean17 = seriesRenderingOrder7.equals((java.lang.Object) rectangleConstraint16);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        double double2 = timeSeries1.getMinY();
        int int3 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.update(1900, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range4);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toRangeHeight(range9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(range9);
        long long12 = dateRange11.getUpperMillis();
        java.lang.String str13 = dateRange11.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str13.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart2.setBorderPaint((java.awt.Paint) color3);
        java.awt.Stroke stroke5 = jFreeChart2.getBorderStroke();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray5, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("null", "[size=1]", numberArray8);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-1), (double) '#');
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.isShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = null;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        xYPlot13.panDomainAxes((double) (byte) 0, plotRenderingInfo17, point2D20);
        xYPlot0.zoomRangeAxes((double) 97L, (double) 100, plotRenderingInfo12, point2D20);
        boolean boolean23 = xYPlot0.isDomainPannable();
        xYPlot0.setDomainPannable(true);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        legendTitle11.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        legendTitle11.setPadding(0.0d, 0.05d, (double) 1L, 0.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        piePlot3D1.setDrawingSupplier(drawingSupplier5, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.removeAgedItems((long) (-1), false);
        try {
            timeSeries1.update(0, (java.lang.Number) 3492L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range4);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toRangeHeight(range9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(range9);
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        try {
            org.jfree.data.time.SerialDate serialDate15 = serialDate13.getNearestDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        boolean boolean13 = legendTitle11.equals((java.lang.Object) 175);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo16.getChartArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        try {
            legendTitle11.draw(graphics2D14, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double6 = range5.getLength();
        boolean boolean7 = logFormat4.equals((java.lang.Object) double6);
        org.jfree.chart.util.LogFormat logFormat13 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer15 = null;
        java.text.FieldPosition fieldPosition16 = null;
        java.lang.StringBuffer stringBuffer17 = logFormat13.format((long) '#', stringBuffer15, fieldPosition16);
        java.text.FieldPosition fieldPosition18 = null;
        java.lang.StringBuffer stringBuffer19 = logFormat4.format(0L, stringBuffer15, fieldPosition18);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        boolean boolean22 = piePlot3D21.getIgnoreZeroValues();
        double double24 = piePlot3D21.getExplodePercent((java.lang.Comparable) "");
        boolean boolean25 = logFormat4.equals((java.lang.Object) double24);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stringBuffer17);
        org.junit.Assert.assertNotNull(stringBuffer19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer2 = null;
        waferMapPlot1.setRenderer(waferMapRenderer2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = null;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        xYPlot13.panDomainAxes((double) (byte) 0, plotRenderingInfo17, point2D20);
        xYPlot0.zoomRangeAxes((double) 97L, (double) 100, plotRenderingInfo12, point2D20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape3 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) xYPlot4, "", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str19 = plotEntity18.toString();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotEntity: tooltip = " + "'", str19.equals("PlotEntity: tooltip = "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(175);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            timeSeries1.add(regularTimePeriod3, (java.lang.Number) 1L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        jFreeChart7.setBorderPaint(paint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = xYBarRenderer13.getSeriesURLGenerator(1);
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer13.setBaseOutlineStroke(stroke16);
        xYBarRenderer13.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer13.setBaseShape(shape22);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity24 = new org.jfree.chart.entity.LegendItemEntity(shape22);
        java.awt.Shape shape25 = legendItemEntity24.getArea();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D(pieDataset26);
        boolean boolean28 = legendItemEntity24.equals((java.lang.Object) piePlot3D27);
        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
        java.awt.geom.Rectangle2D rectangle2D31 = chartRenderingInfo30.getChartArea();
        legendItemEntity24.setArea((java.awt.Shape) rectangle2D31);
        org.jfree.chart.entity.EntityCollection entityCollection33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo(entityCollection33);
        java.awt.geom.Rectangle2D rectangle2D35 = chartRenderingInfo34.getChartArea();
        try {
            jFreeChart7.draw(graphics2D12, rectangle2D31, chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(xYURLGenerator15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        try {
            periodAxis2.setAutoRangeMinimumSize((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat1 = standardPieSectionLabelGenerator0.getPercentFormat();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel((int) (byte) 10);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        double double19 = piePlot3D8.getShadowXOffset();
        org.jfree.chart.util.Rotation rotation20 = piePlot3D8.getDirection();
        java.lang.String str21 = rotation20.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Rotation.CLOCKWISE" + "'", str21.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str6 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        categoryAxis3D0.setVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        org.jfree.chart.plot.Plot plot4 = multiplePiePlot3.getRootPlot();
        java.awt.Paint paint5 = plot4.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker6);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            double double3 = xYSeriesCollection0.getXValue(100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape3 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) xYPlot4, "", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator21 = xYBarRenderer19.getSeriesURLGenerator(1);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer19.setBaseOutlineStroke(stroke22);
        xYBarRenderer19.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint27 = xYBarRenderer19.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean29 = xYBarRenderer19.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint31 = xYBarRenderer19.getSeriesItemLabelPaint(100);
        boolean boolean32 = plotEntity18.equals((java.lang.Object) xYBarRenderer19);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(xYURLGenerator21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        boolean boolean2 = xYLineAndShapeRenderer0.getDrawSeriesLineAsPath();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        double double3 = piePlot3D1.getStartAngle();
        piePlot3D1.setBackgroundAlpha((float) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint12 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        xYBarRenderer0.setBase(0.0d);
        int int15 = xYBarRenderer0.getPassCount();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = periodAxis1.getStandardTickUnits();
        periodAxis1.pan(0.12d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(tickUnitSource3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        java.lang.String str6 = legendItem1.getDescription();
        boolean boolean7 = legendItem1.isShapeVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries3.createCopy((int) 'a', (int) (byte) -1);
        xYSeries3.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries3.createCopy(10, 1);
        xYSeries3.clear();
        boolean boolean13 = tickUnits1.equals((java.lang.Object) xYSeries3);
        xYSeriesCollection0.removeSeries(xYSeries3);
        try {
            xYSeriesCollection0.removeSeries(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((-1.0d), 97.0d, (double) (short) 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        piePlot3D1.setStartAngle((double) 4);
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 100L, 100.0d, 0.0d, (double) 8);
        piePlot3D1.setSimpleLabelOffset(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo17.getChartArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        xYPlot21.panDomainAxes((double) (byte) 0, plotRenderingInfo25, point2D28);
        boolean boolean30 = xYPlot21.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot34.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = null;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor40);
        xYPlot34.panDomainAxes((double) (byte) 0, plotRenderingInfo38, point2D41);
        xYPlot21.zoomRangeAxes((double) 97L, (double) 100, plotRenderingInfo33, point2D41);
        org.jfree.chart.plot.PlotState plotState44 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            piePlot3D1.draw(graphics2D15, rectangle2D18, point2D41, plotState44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(point2D41);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot1.getInsets();
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(rectangleInsets3, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate15 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        int int16 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        org.jfree.chart.axis.AxisSpace axisSpace17 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(axisSpace17);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawRangeTickBands(graphics2D3, rectangle2D4, list5);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot0.getRangeAxisForDataset(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 8 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, 0.08d, (double) '4', (double) 1.0f);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        piePlot3D1.setSectionOutlinesVisible(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Paint paint5 = piePlot3D1.getLabelPaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        boolean boolean10 = piePlot3D9.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D9.getLegendLabelToolTipGenerator();
        double double12 = piePlot3D9.getStartAngle();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D9.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot3D1.initialise(graphics2D6, rectangle2D7, (org.jfree.chart.plot.PiePlot) piePlot3D9, (java.lang.Integer) 10, plotRenderingInfo16);
        double double18 = piePlot3D9.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(piePlotState17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.14d + "'", double18 == 0.14d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("April", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        long long9 = segmentedTimeline3.getExceptionSegmentCount(97L, (long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline3.getSegment((long) '4');
        org.jfree.chart.axis.SegmentedTimeline.Segment segment14 = segment11.intersect((long) 1900, (long) (byte) 10);
        try {
            long long15 = segment14.getMillisecond();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertNull(segment14);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str5 = numberTickUnit4.toString();
        double[] doubleArray8 = new double[] { 1, 97L };
        double[] doubleArray11 = new double[] { 1, 97L };
        double[] doubleArray14 = new double[] { 1, 97L };
        double[] doubleArray17 = new double[] { 1, 97L };
        double[] doubleArray20 = new double[] { 1, 97L };
        double[] doubleArray23 = new double[] { 1, 97L };
        double[][] doubleArray24 = new double[][] { doubleArray8, doubleArray11, doubleArray14, doubleArray17, doubleArray20, doubleArray23 };
        try {
            defaultXYDataset0.addSeries((java.lang.Comparable) numberTickUnit4, doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'data' array must have length == 2.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[size=1]" + "'", str5.equals("[size=1]"));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        try {
            int[] intArray9 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) defaultXYDataset3, 1900, (double) 15, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getIntegerInstance();
        numberFormat4.setGroupingUsed(true);
        java.text.NumberFormat numberFormat7 = java.text.NumberFormat.getIntegerInstance();
        numberFormat7.setGroupingUsed(true);
        int int10 = numberFormat7.getMaximumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator11 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SeriesRenderingOrder.FORWARD", numberFormat4, numberFormat7);
        java.lang.String str12 = standardXYToolTipGenerator11.getNullYString();
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator(7, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator11, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYBarRenderer16.getSeriesURLGenerator(1);
        xYBarRenderer16.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color21 = java.awt.Color.PINK;
        xYBarRenderer16.setBasePaint((java.awt.Paint) color21, false);
        xYLineAndShapeRenderer0.setSeriesItemLabelPaint(13, (java.awt.Paint) color21, true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "null" + "'", str12.equals("null"));
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        boolean boolean4 = xYBarRenderer0.isSeriesVisible(9);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color5 = java.awt.Color.PINK;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color5, false);
        xYBarRenderer0.setShadowYOffset((double) 8);
        xYBarRenderer0.setItemLabelAnchorOffset((double) 3492L);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator13 = null;
        xYBarRenderer0.setSeriesItemLabelGenerator(15, xYItemLabelGenerator13, false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        xYBarRenderer0.removeAnnotations();
        xYBarRenderer0.setShadowYOffset((double) 2019L);
        org.junit.Assert.assertNull(xYURLGenerator2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getURLGenerator((int) (byte) 10, (int) (short) 0, true);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        java.lang.Object obj15 = null;
        boolean boolean16 = piePlot3D14.equals(obj15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) piePlot3D14, true);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart18, (int) (byte) 100, (int) (byte) 0);
        java.awt.RenderingHints renderingHints22 = null;
        try {
            jFreeChart18.setRenderingHints(renderingHints22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.LegendItem legendItem10 = xYBarRenderer0.getLegendItem((int) (short) 0, (int) ' ');
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(xYBarPainter7);
        org.junit.Assert.assertNull(legendItem10);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = markerChangeEvent5.getType();
        java.lang.String str7 = markerChangeEvent5.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = rectangleConstraint0.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight((double) 13);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        try {
            xYSeriesCollection0.setSelected(0, 3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) 100L, 100.0d, 0.0d, (double) 8);
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries24 = xYSeries21.createCopy((int) 'a', (int) (byte) -1);
        boolean boolean25 = rectangleInsets19.equals((java.lang.Object) 'a');
        piePlot3D8.setInsets(rectangleInsets19);
        boolean boolean27 = piePlot3D8.isNotify();
        float float28 = piePlot3D8.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(xYSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        double double15 = range8.getLowerBound();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) double3, seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = seriesChangeEvent5.getSummary();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(seriesChangeInfo6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMinorTickMarkOutsideLength(0.0f);
        boolean boolean5 = categoryAxis3D0.isVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) true);
        boolean boolean5 = xYLineAndShapeRenderer0.getDrawSeriesLineAsPath();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 2019, (-5.76E7d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getDescription();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries6.createCopy((int) 'a', (int) (byte) -1);
        xYSeries6.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries14 = xYSeries6.createCopy(10, 1);
        xYSeries6.clear();
        boolean boolean16 = tickUnits4.equals((java.lang.Object) xYSeries6);
        xYSeriesCollection3.removeSeries(xYSeries6);
        xYSeriesCollection3.setIntervalPositionFactor(Double.NaN);
        legendItem1.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection3);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertNotNull(xYSeries14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        long long9 = segmentedTimeline3.getExceptionSegmentCount(97L, (long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline3.getSegment((long) '4');
        org.jfree.chart.axis.SegmentedTimeline.Segment segment14 = segment11.intersect((long) 1900, (long) (byte) 10);
        try {
            segment14.moveIndexToEnd();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertNull(segment14);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = xYPlot20.getDatasetRenderingOrder();
        java.lang.String str22 = datasetRenderingOrder21.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str22.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        int int1 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        double double4 = xYSeriesCollection2.getDomainLowerBound(false);
        org.jfree.chart.entity.XYItemEntity xYItemEntity9 = new org.jfree.chart.entity.XYItemEntity(shape1, (org.jfree.data.xy.XYDataset) xYSeriesCollection2, 9, 0, "ClassContext", "TextAnchor.TOP_LEFT");
        try {
            double double12 = xYSeriesCollection2.getStartXValue(15, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator0.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        piePlot3D1.setSectionOutlinesVisible(false);
        boolean boolean7 = piePlot3D1.isCircular();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.axis.Axis axis3 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity4 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D2, axis3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        boolean boolean7 = xYBarRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = xYLineAndShapeRenderer4.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape7 = xYLineAndShapeRenderer4.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot8.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        xYPlot8.panDomainAxes((double) (byte) 0, plotRenderingInfo12, point2D15);
        boolean boolean17 = xYPlot8.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D18 = xYPlot8.getQuadrantOrigin();
        int int19 = xYPlot8.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) xYPlot8, "", "SerialDate.weekInMonthToString(): invalid code.");
        java.awt.Font font24 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D(pieDataset25);
        java.lang.Object obj27 = null;
        boolean boolean28 = piePlot3D26.equals(obj27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("", font24, (org.jfree.chart.plot.Plot) piePlot3D26, true);
        java.awt.Color color31 = java.awt.Color.PINK;
        jFreeChart30.setBorderPaint((java.awt.Paint) color31);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("[size=1]", "[size=1]", "HorizontalAlignment.CENTER", "DomainOrder.DESCENDING", shape7, (java.awt.Paint) color31);
        org.junit.Assert.assertNull(xYItemLabelGenerator6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        java.awt.Paint paint3 = plot2.getNoDataMessagePaint();
        int int4 = plot2.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        double double11 = xYBarRenderer0.getBarAlignmentFactor();
        xYBarRenderer0.setAutoPopulateSeriesPaint(true);
        java.awt.Paint paint15 = xYBarRenderer0.getSeriesFillPaint((int) (short) 100);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        java.awt.Paint paint11 = xYPlot0.getBackgroundPaint();
        xYPlot0.clearDomainMarkers();
        boolean boolean13 = xYPlot0.isRangePannable();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot0.getRangeAxis((-1));
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = piePlot3D4.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D4.getLegendLabelToolTipGenerator();
        double double7 = piePlot3D4.getStartAngle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D4.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D4);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D0.setTickLabelFont(font11);
        float float13 = categoryAxis3D0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        java.lang.String str3 = range0.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range0, (double) 10.0f, true);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range0.intersects(range7);
        double double9 = range7.getCentralValue();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5d + "'", double9 == 0.5d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean15 = range13.contains((double) (byte) 1);
        double double16 = range13.getLowerBound();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean19 = range17.contains((double) (byte) 1);
        double double20 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range17);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toRangeHeight(range22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean26 = range24.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint23.toRangeHeight(range24);
        org.jfree.chart.util.Size2D size2D28 = legendTitle11.arrange(graphics2D12, rectangleConstraint27);
        java.lang.Object obj29 = size2D28.clone();
        double double30 = size2D28.height;
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint2, (float) 2, textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(35, 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        combinedRangeXYPlot0.setOutlineVisible(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot10.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot10.panDomainAxes((double) (byte) 0, plotRenderingInfo14, point2D17);
        boolean boolean19 = xYPlot10.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D20 = xYPlot10.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState21 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            combinedRangeXYPlot0.draw(graphics2D4, rectangle2D7, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(point2D20);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        piePlot3D1.setStartAngle((double) 4);
        boolean boolean8 = piePlot3D1.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean2 = piePlot0.equals((java.lang.Object) categoryAxis3D1);
        double double3 = categoryAxis3D1.getLabelAngle();
        categoryAxis3D1.setLabelAngle((double) (-2208960000000L));
        categoryAxis3D1.setLowerMargin((double) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("PlotEntity: tooltip = ", graphics2D1, (float) 3, (float) 15, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            gradientBarPainter0.paintBar(graphics2D1, barRenderer2, 2019, 10, false, (java.awt.geom.RectangularShape) rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Paint paint5 = piePlot3D1.getLabelPaint();
        piePlot3D1.setDarkerSides(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer6 = null;
        java.text.FieldPosition fieldPosition7 = null;
        java.lang.StringBuffer stringBuffer8 = logFormat4.format((long) '#', stringBuffer6, fieldPosition7);
        logFormat4.setMinimumIntegerDigits(100);
        org.junit.Assert.assertNotNull(stringBuffer8);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        java.lang.String str3 = range0.toString();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range0, Double.NaN);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) 100L, 100.0d, 0.0d, (double) 8);
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries24 = xYSeries21.createCopy((int) 'a', (int) (byte) -1);
        boolean boolean25 = rectangleInsets19.equals((java.lang.Object) 'a');
        piePlot3D8.setInsets(rectangleInsets19);
        boolean boolean27 = piePlot3D8.getAutoPopulateSectionOutlineStroke();
        int int28 = piePlot3D8.getPieIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(xYSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("java.awt.Color[r=255,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        piePlot3D1.setStartAngle((double) 4);
        double double8 = piePlot3D1.getLabelGap();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        java.util.Date date2 = null;
        try {
            segmentedTimeline1.addBaseTimelineException(date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        java.lang.String str3 = range0.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range0, (double) 10.0f, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues3 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset4 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) defaultKeyedValues3);
        java.lang.Comparable comparable5 = null;
        try {
            java.lang.String str6 = standardPieSectionLabelGenerator0.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset4, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        try {
            org.jfree.data.xy.XYSeries xYSeries8 = xYSeriesCollection3.getSeries((java.lang.Comparable) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 2147483647");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        xYPlot20.setDomainCrosshairVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset24);
        org.jfree.chart.plot.Plot plot26 = multiplePiePlot25.getRootPlot();
        org.jfree.chart.util.TableOrder tableOrder27 = multiplePiePlot25.getDataExtractOrder();
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        multiplePiePlot25.setAggregatedItemsPaint(paint28);
        boolean boolean30 = xYPlot20.equals((java.lang.Object) paint28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(plot26);
        org.junit.Assert.assertNotNull(tableOrder27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 10L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        double double4 = xYSeriesCollection2.getDomainLowerBound(false);
        org.jfree.chart.entity.XYItemEntity xYItemEntity9 = new org.jfree.chart.entity.XYItemEntity(shape1, (org.jfree.data.xy.XYDataset) xYSeriesCollection2, 9, 0, "ClassContext", "TextAnchor.TOP_LEFT");
        try {
            int int11 = xYSeriesCollection2.getItemCount(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) dateTickUnit2, stroke3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean9 = periodAxis8.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = periodAxis8.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis12.setLowerBound((double) 10);
        java.util.TimeZone timeZone15 = periodAxis12.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYBarRenderer16.getSeriesURLGenerator(1);
        xYBarRenderer16.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        xYBarRenderer16.setSeriesNegativeItemLabelPosition(2, itemLabelPosition22, false);
        xYBarRenderer16.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection6, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis12, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer16);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot26.setRangeMinorGridlineStroke(stroke27);
        try {
            strokeMap0.put((java.lang.Comparable) "SeriesRenderingOrder.FORWARD", stroke27);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.DateTickUnit cannot be cast to java.lang.String");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        java.awt.Paint paint6 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean8 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        int int9 = xYSeriesCollection7.getSeriesCount();
        org.jfree.data.Range range10 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        try {
            java.lang.Number number13 = xYSeriesCollection7.getX(10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYBarRenderer0.setBaseItemLabelFont(font11);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYBarRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(xYURLGenerator13);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        piePlot3D1.setStartAngle((double) 4);
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 100L, 100.0d, 0.0d, (double) 8);
        piePlot3D1.setSimpleLabelOffset(rectangleInsets13);
        boolean boolean15 = piePlot3D1.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        java.awt.Stroke stroke3 = piePlot3D1.getLabelOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(range11);
        java.lang.String str13 = range11.toString();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[97.0,97.0]" + "'", str13.equals("Range[97.0,97.0]"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setDomainAxis((int) '4', valueAxis6, true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot0.setRangeTickBandPaint(paint10);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.setMaximumItemAge(0L);
        try {
            java.lang.Number number8 = timeSeries1.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        java.lang.String str6 = legendItem1.getDescription();
        legendItem1.setSeriesIndex(13);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("null");
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.setMaximumItemAge(0L);
        java.lang.Object obj7 = timeSeries1.clone();
        boolean boolean8 = timeSeries1.isEmpty();
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries11.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset12);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate14 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset12);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double7 = range6.getLength();
        boolean boolean8 = logFormat5.equals((java.lang.Object) double7);
        org.jfree.chart.util.LogFormat logFormat14 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer16 = null;
        java.text.FieldPosition fieldPosition17 = null;
        java.lang.StringBuffer stringBuffer18 = logFormat14.format((long) '#', stringBuffer16, fieldPosition17);
        java.text.FieldPosition fieldPosition19 = null;
        java.lang.StringBuffer stringBuffer20 = logFormat5.format(0L, stringBuffer16, fieldPosition19);
        java.lang.StringBuffer stringBuffer22 = null;
        java.text.FieldPosition fieldPosition23 = null;
        java.lang.StringBuffer stringBuffer24 = logFormat5.format((long) (byte) 100, stringBuffer22, fieldPosition23);
        java.text.NumberFormat numberFormat25 = java.text.NumberFormat.getIntegerInstance();
        numberFormat25.setMinimumFractionDigits((int) (byte) 0);
        int int28 = numberFormat25.getMaximumIntegerDigits();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator29 = new org.jfree.chart.labels.StandardPieToolTipGenerator("null", (java.text.NumberFormat) logFormat5, numberFormat25);
        java.text.NumberFormat numberFormat30 = standardPieToolTipGenerator29.getPercentFormat();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stringBuffer18);
        org.junit.Assert.assertNotNull(stringBuffer20);
        org.junit.Assert.assertNotNull(stringBuffer24);
        org.junit.Assert.assertNotNull(numberFormat25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat30);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYBarRenderer6.getSeriesURLGenerator(1);
        xYBarRenderer6.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color11 = java.awt.Color.PINK;
        xYBarRenderer6.setBasePaint((java.awt.Paint) color11, false);
        boolean boolean14 = intervalXYDelegate5.equals((java.lang.Object) color11);
        try {
            java.lang.Number number17 = intervalXYDelegate5.getStartX(1, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        intervalMarker14.setStartValue((double) (short) 10);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean19 = xYPlot0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) intervalMarker14, layer17, true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker14);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.LegendItem legendItem6 = xYAreaRenderer3.getLegendItem((-1), 6);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset2, (java.lang.Comparable) 100.0f);
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator0.getNumberFormat();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-2208960000000L), (float) (byte) 100);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            java.lang.Number number4 = defaultXYDataset0.getX(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double2 = periodAxis1.getUpperMargin();
        org.jfree.data.Range range3 = periodAxis1.getRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        boolean boolean4 = xYLineAndShapeRenderer0.getItemShapeVisible((int) ' ', 0);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) rectangleAnchor7);
        valueMarker3.setLabelAnchor(rectangleAnchor7);
        java.lang.String str10 = rectangleAnchor7.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str10.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D1.getLabelGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot3D1.getLegendItems();
        java.util.Iterator iterator8 = legendItemCollection7.iterator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(iterator8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment3, (double) (short) 100, (double) (-1.0f));
        org.jfree.chart.block.Block block7 = null;
        columnArrangement6.add(block7, (java.lang.Object) 1L);
        boolean boolean10 = gradientPaintTransformType1.equals((java.lang.Object) columnArrangement6);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset11 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset11);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6, (org.jfree.data.general.Dataset) defaultXYDataset11, (java.lang.Comparable) Double.NaN);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Font font17 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D(pieDataset18);
        java.lang.Object obj20 = null;
        boolean boolean21 = piePlot3D19.equals(obj20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", font17, (org.jfree.chart.plot.Plot) piePlot3D19, true);
        java.awt.Color color24 = java.awt.Color.PINK;
        jFreeChart23.setBorderPaint((java.awt.Paint) color24);
        org.jfree.chart.title.LegendTitle legendTitle27 = jFreeChart23.getLegend(0);
        legendTitle27.setHeight((double) (byte) 100);
        legendTitle27.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        java.awt.geom.Rectangle2D rectangle2D37 = chartRenderingInfo36.getChartArea();
        legendTitle27.setBounds(rectangle2D37);
        try {
            legendItemBlockContainer14.draw(graphics2D15, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(legendTitle27);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            java.lang.Number number6 = defaultXYDataset0.getY(13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        java.awt.Paint paint11 = xYPlot0.getBackgroundPaint();
        xYPlot0.clearDomainMarkers();
        boolean boolean13 = xYPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot17.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor23);
        xYPlot17.panDomainAxes((double) (byte) 0, plotRenderingInfo21, point2D24);
        boolean boolean26 = xYPlot17.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D27 = xYPlot17.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes(0.05d, (double) (-1.0f), plotRenderingInfo16, point2D27);
        java.io.ObjectOutputStream objectOutputStream29 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D27, objectOutputStream29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = null;
        xYLineAndShapeRenderer0.setSeriesItemLabelGenerator(2, xYItemLabelGenerator6);
        java.awt.Shape shape9 = xYLineAndShapeRenderer0.lookupSeriesShape(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("[size=1]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name [size=1], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        xYDataItem2.setSelected(true);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = xYDataItem2.compareTo((java.lang.Object) month5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        java.awt.Paint paint6 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        java.awt.Shape shape8 = xYBarRenderer0.lookupSeriesShape(4);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        xYBarRenderer0.setSeriesItemLabelsVisible((int) (short) 100, (java.lang.Boolean) true, false);
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem10.setLine(shape13);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape13, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.plot.Plot plot20 = multiplePiePlot19.getRootPlot();
        java.awt.Shape shape21 = multiplePiePlot19.getLegendItemShape();
        chartEntity17.setArea(shape21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot24.getPieChart();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart25.setBorderStroke(stroke26);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity30 = new org.jfree.chart.entity.JFreeChartEntity(shape21, jFreeChart25, "java.awt.Color[r=255,g=0,b=0]", "hi!");
        xYBarRenderer0.setLegendBar(shape21);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean15 = range13.contains((double) (byte) 1);
        double double16 = range13.getLowerBound();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean19 = range17.contains((double) (byte) 1);
        double double20 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range17);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toRangeHeight(range22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean26 = range24.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint23.toRangeHeight(range24);
        org.jfree.chart.util.Size2D size2D28 = legendTitle11.arrange(graphics2D12, rectangleConstraint27);
        double double29 = size2D28.height;
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) rectangleAnchor7);
        valueMarker3.setLabelAnchor(rectangleAnchor7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYBarRenderer10.setBaseFillPaint((java.awt.Paint) color13, false);
        valueMarker3.setPaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = valueMarker3.getLabelOffset();
        double double19 = rectangleInsets17.calculateRightInset(0.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getURLGenerator((int) (byte) 10, (int) (short) 0, true);
        xYBarRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        xYBarRenderer0.setSeriesPositiveItemLabelPosition(2, itemLabelPosition14);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(xYURLGenerator10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.setFixedDimension((double) 0);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = null;
        try {
            categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo12.getChartArea();
        try {
            java.awt.image.BufferedImage bufferedImage14 = jFreeChart7.createBufferedImage((int) (byte) 100, 8, (int) (short) 100, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        java.awt.Shape shape16 = null;
        xYBarRenderer0.setSeriesShape(0, shape16);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        int int1 = defaultXYDataset0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("SeriesRenderingOrder.FORWARD", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        xYSeriesCollection0.setAutoWidth(true);
        try {
            double double6 = xYSeriesCollection0.getStartXValue((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        java.lang.Class class8 = null;
        try {
            periodAxis1.setAutoRangeTimePeriodClass(class8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        intervalMarker2.setStartValue((double) (short) 10);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer5 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType6 = standardGradientPaintTransformer5.getType();
        intervalMarker2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot6.getRootPlot();
        boolean boolean8 = xYBarRenderer0.hasListener((java.util.EventListener) plot7);
        org.jfree.chart.LegendItem legendItem11 = xYBarRenderer0.getLegendItem((int) (byte) 1, 255);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(legendItem11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = valueMarker3.getLabelAnchor();
        java.awt.Paint paint6 = valueMarker3.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem4.setLine(shape7);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape7, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.chart.plot.Plot plot14 = multiplePiePlot13.getRootPlot();
        java.awt.Shape shape15 = multiplePiePlot13.getLegendItemShape();
        chartEntity11.setArea(shape15);
        xYStepAreaRenderer0.setLegendShape(2, shape15);
        xYStepAreaRenderer0.setPlotArea(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.Object obj3 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.JFreeChart jFreeChart7 = multiplePiePlot6.getPieChart();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        int int10 = color8.getBlue();
        java.awt.color.ColorSpace colorSpace11 = color8.getColorSpace();
        java.awt.Color color12 = java.awt.Color.GREEN;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray20 = new float[] { 97L, 'a', 60000L, 6, (short) 1, (byte) -1 };
        float[] floatArray21 = color13.getColorComponents(floatArray20);
        float[] floatArray22 = color12.getComponents(floatArray20);
        float[] floatArray23 = color4.getComponents(colorSpace11, floatArray22);
        valueMarker3.setLabelPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(jFreeChart7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        java.lang.Class class4 = timeSeries1.getTimePeriodClass();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getBaseShapesVisible();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYLineAndShapeRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator7);
        boolean boolean9 = timeSeries1.equals((java.lang.Object) xYLineAndShapeRenderer5);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        periodAxis1.zoomRange(0.0d, 0.0d);
        float float18 = periodAxis1.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        double double5 = periodAxis1.getUpperMargin();
        java.awt.Stroke stroke6 = periodAxis1.getMinorTickMarkStroke();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        boolean boolean13 = legendTitle11.equals((java.lang.Object) 175);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = legendTitle11.getItemLabelPadding();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D15, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        java.awt.Shape shape3 = multiplePiePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        boolean boolean6 = piePlot3D5.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D5.getLegendLabelToolTipGenerator();
        double double8 = piePlot3D5.getStartAngle();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D5.setLabelBackgroundPaint((java.awt.Paint) color9);
        java.awt.Color color12 = java.awt.Color.black;
        piePlot3D5.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color12);
        java.lang.String str14 = color12.toString();
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=0,g=0,b=0]" + "'", str14.equals("java.awt.Color[r=0,g=0,b=0]"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        jFreeChart7.setBorderPaint(paint10);
        jFreeChart7.setBackgroundImageAlignment(1900);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 100.0f, 90.0d, 1.0E-8d, (double) 1L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long6 = segmentedTimeline5.getSegmentsExcludedSize();
        boolean boolean9 = segmentedTimeline5.containsDomainRange(0L, (long) (short) 1);
        boolean boolean10 = gradientPaintTransformType1.equals((java.lang.Object) segmentedTimeline5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(3492L, 8, 2147483647);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7499012895324L + "'", long4 == 7499012895324L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        xYPlot20.setDomainCrosshairVisible(false);
        xYPlot20.mapDatasetToRangeAxis(175, 4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYBarRenderer4.getSeriesURLGenerator(1);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer4.setBaseOutlineStroke(stroke7);
        xYBarRenderer4.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer4.setBaseShape(shape13);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        java.awt.Shape shape16 = legendItemEntity15.getArea();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D(pieDataset17);
        boolean boolean19 = legendItemEntity15.equals((java.lang.Object) piePlot3D18);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator22 = xYBarRenderer20.getSeriesURLGenerator(1);
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer20.setBaseOutlineStroke(stroke23);
        xYBarRenderer20.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer20.setBaseShape(shape29);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity31 = new org.jfree.chart.entity.LegendItemEntity(shape29);
        java.awt.Shape shape32 = legendItemEntity31.getArea();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D(pieDataset33);
        boolean boolean35 = legendItemEntity31.equals((java.lang.Object) piePlot3D34);
        org.jfree.chart.entity.EntityCollection entityCollection36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = new org.jfree.chart.ChartRenderingInfo(entityCollection36);
        java.awt.geom.Rectangle2D rectangle2D38 = chartRenderingInfo37.getChartArea();
        legendItemEntity31.setArea((java.awt.Shape) rectangle2D38);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D38, (double) 0, 10.0f, (float) 2019L);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace46 = periodAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) piePlot3D18, rectangle2D38, rectangleEdge44, axisSpace45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(xYURLGenerator22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(shape43);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = xYBarRenderer5.getSeriesURLGenerator(1);
        xYBarRenderer5.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        xYBarRenderer5.setSeriesNegativeItemLabelPosition(2, itemLabelPosition11, false);
        xYBarRenderer5.removeAnnotations();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = xYBarRenderer5.getLegendItemLabelGenerator();
        xYBarRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator15);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator7);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator15);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray8, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset12, false);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset12, false);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange(range16);
        periodAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange17, false, false);
        java.awt.Shape shape21 = null;
        try {
            periodAxis1.setRightArrow(shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.LegendItem legendItem10 = xYBarRenderer0.getLegendItem((int) (short) 0, (int) ' ');
        java.awt.Paint paint12 = xYBarRenderer0.getSeriesOutlinePaint((-1));
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(xYBarPainter7);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        double double19 = piePlot3D8.getShadowXOffset();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot3D8.addChangeListener(plotChangeListener20);
        boolean boolean22 = piePlot3D8.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }
}

