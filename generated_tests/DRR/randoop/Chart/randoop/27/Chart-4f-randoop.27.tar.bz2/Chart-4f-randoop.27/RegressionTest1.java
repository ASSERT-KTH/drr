import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        java.awt.geom.Line2D line2D2 = null;
        xYItemRendererState1.workingLine = line2D2;
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getDescription();
        java.awt.Font font3 = legendItem1.getLabelFont();
        boolean boolean4 = legendItem1.isShapeOutlineVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator9, true);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        xYPlot13.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot13.getFixedLegendItems();
        java.awt.Stroke stroke19 = xYPlot13.getDomainMinorGridlineStroke();
        xYBarRenderer0.setSeriesStroke(13, stroke19, true);
        xYBarRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        xYBarRenderer0.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = verticalAlignment0.equals(obj1);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double2 = periodAxis1.getUpperMargin();
        java.awt.Color color3 = java.awt.Color.PINK;
        int int4 = color3.getGreen();
        periodAxis1.setLabelPaint((java.awt.Paint) color3);
        periodAxis1.resizeRange(8.0d);
        periodAxis1.setMinorTickMarkInsideLength((float) 2958465);
        double double10 = periodAxis1.getLowerBound();
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range11.contains((double) (byte) 1);
        java.lang.String str14 = range11.toString();
        periodAxis1.setRange(range11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-5.76E7d) + "'", double10 == (-5.76E7d));
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Range[0.0,1.0]" + "'", str14.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        java.lang.Object obj5 = markerChangeEvent4.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        markerChangeEvent4.setType(chartChangeEventType6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Rotation.CLOCKWISE", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getLegendShape(6);
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.ObjectList objectList5 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        categoryAxis3D6.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        double double13 = categoryAxis3D12.getLabelAngle();
        categoryAxis3D12.clearCategoryLabelToolTips();
        categoryAxis3D12.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str18 = categoryAxis3D12.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D12.drawTickMarks(graphics2D19, (double) (byte) -1, rectangle2D21, rectangleEdge23, axisState25);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = xYBarRenderer27.getSeriesURLGenerator(1);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer27.setBaseOutlineStroke(stroke30);
        xYBarRenderer27.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer27.setBaseShape(shape36);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity(shape36);
        java.awt.Shape shape39 = legendItemEntity38.getArea();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D(pieDataset40);
        boolean boolean42 = legendItemEntity38.equals((java.lang.Object) piePlot3D41);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.geom.Rectangle2D rectangle2D45 = chartRenderingInfo44.getChartArea();
        legendItemEntity38.setArea((java.awt.Shape) rectangle2D45);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D();
        double double48 = categoryAxis3D47.getLabelAngle();
        categoryAxis3D47.clearCategoryLabelToolTips();
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str53 = categoryAxis3D47.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge57);
        org.jfree.chart.axis.AxisState axisState60 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D47.drawTickMarks(graphics2D54, (double) (byte) -1, rectangle2D56, rectangleEdge58, axisState60);
        java.util.List list62 = categoryAxis3D6.refreshTicks(graphics2D11, axisState25, rectangle2D45, rectangleEdge58);
        boolean boolean63 = objectList5.equals((java.lang.Object) rectangle2D45);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer64 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator66 = xYBarRenderer64.getSeriesURLGenerator(1);
        xYBarRenderer64.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.general.PieDataset pieDataset69 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D70 = new org.jfree.chart.plot.PiePlot3D(pieDataset69);
        boolean boolean71 = piePlot3D70.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint72 = piePlot3D70.getBaseSectionPaint();
        xYBarRenderer64.setBasePaint(paint72);
        org.jfree.chart.axis.PeriodAxis periodAxis75 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double76 = periodAxis75.getUpperMargin();
        java.awt.Stroke stroke77 = periodAxis75.getMinorTickMarkStroke();
        java.awt.Paint paint78 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem79 = new org.jfree.chart.LegendItem(attributedString0, "XY Plot", "LengthConstraintType.NONE", "Range[0.0,1.0]", (java.awt.Shape) rectangle2D45, paint72, stroke77, paint78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(xYURLGenerator29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(xYURLGenerator66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(paint78);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        double double8 = piePlot3D3.getShadowYOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset7);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.setFixedDimension((double) 0);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        java.awt.Font font17 = categoryAxis3D0.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(true, true);
        double double5 = piePlot3D1.getLabelGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot3D1.removeChangeListener(plotChangeListener6);
        double double8 = piePlot3D1.getDepthFactor();
        piePlot3D1.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.12d + "'", double8 == 0.12d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesLinesVisible(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot6.getRootPlot();
        java.awt.Shape shape8 = multiplePiePlot6.getLegendItemShape();
        xYLineAndShapeRenderer0.setLegendLine(shape8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis11.setLowerBound((double) 10);
        java.util.TimeZone timeZone14 = periodAxis11.getTimeZone();
        periodAxis11.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = range18.contains((double) (byte) 1);
        double double21 = range18.getLowerBound();
        periodAxis11.setRange(range18, false, false);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        periodAxis11.setLast((org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) periodAxis11);
        java.lang.String str29 = axisEntity28.toString();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "AxisEntity: tooltip = null" + "'", str29.equals("AxisEntity: tooltip = null"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        double double2 = categoryAxis3D1.getLabelAngle();
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        double double8 = categoryAxis3D7.getLabelAngle();
        categoryAxis3D7.clearCategoryLabelToolTips();
        categoryAxis3D7.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str13 = categoryAxis3D7.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.axis.AxisState axisState20 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D7.drawTickMarks(graphics2D14, (double) (byte) -1, rectangle2D16, rectangleEdge18, axisState20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer22.getSeriesURLGenerator(1);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer22.setBaseOutlineStroke(stroke25);
        xYBarRenderer22.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer22.setBaseShape(shape31);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity(shape31);
        java.awt.Shape shape34 = legendItemEntity33.getArea();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D(pieDataset35);
        boolean boolean37 = legendItemEntity33.equals((java.lang.Object) piePlot3D36);
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        java.awt.geom.Rectangle2D rectangle2D40 = chartRenderingInfo39.getChartArea();
        legendItemEntity33.setArea((java.awt.Shape) rectangle2D40);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        double double43 = categoryAxis3D42.getLabelAngle();
        categoryAxis3D42.clearCategoryLabelToolTips();
        categoryAxis3D42.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str48 = categoryAxis3D42.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
        org.jfree.chart.axis.AxisState axisState55 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D42.drawTickMarks(graphics2D49, (double) (byte) -1, rectangle2D51, rectangleEdge53, axisState55);
        java.util.List list57 = categoryAxis3D1.refreshTicks(graphics2D6, axisState20, rectangle2D40, rectangleEdge53);
        boolean boolean58 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) lengthConstraintType0, (java.lang.Object) axisState20);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = piePlot3D4.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D4.getLegendLabelToolTipGenerator();
        double double7 = piePlot3D4.getStartAngle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D4.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D4);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D0.setTickLabelFont(font11);
        float float13 = categoryAxis3D0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("PlotEntity: tooltip = ", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "", true);
        boolean boolean3 = rendererChangeEvent2.getSeriesVisibilityChanged();
        java.lang.Object obj4 = rendererChangeEvent2.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + "" + "'", obj4.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setGroupingUsed(true);
        java.util.Currency currency3 = numberFormat0.getCurrency();
        numberFormat0.setMaximumIntegerDigits(1);
        boolean boolean6 = numberFormat0.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str7 = seriesRenderingOrder6.toString();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis10.setLowerBound((double) 10);
        java.util.TimeZone timeZone13 = periodAxis10.getTimeZone();
        periodAxis10.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean19 = range17.contains((double) (byte) 1);
        double double20 = range17.getLowerBound();
        periodAxis10.setRange(range17, false, false);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        periodAxis10.setLast((org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean29 = periodAxis28.isAxisLineVisible();
        periodAxis28.setAutoRangeMinimumSize((double) 2, true);
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis34.setLowerBound((double) 10);
        java.util.TimeZone timeZone37 = periodAxis34.getTimeZone();
        double double38 = periodAxis34.getUpperMargin();
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean45 = piePlot43.equals((java.lang.Object) categoryAxis3D44);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset48);
        org.jfree.chart.plot.Plot plot50 = multiplePiePlot49.getRootPlot();
        java.awt.Paint paint51 = plot50.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint51);
        categoryAxis3D44.setTickMarkPaint(paint51);
        org.jfree.chart.block.BlockBorder blockBorder54 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 3492L, (double) 3, 0.0d, paint51);
        periodAxis34.setLabelPaint(paint51);
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean58 = periodAxis57.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource59 = periodAxis57.getStandardTickUnits();
        java.awt.Color color60 = java.awt.Color.cyan;
        periodAxis57.setLabelPaint((java.awt.Paint) color60);
        org.jfree.chart.axis.PeriodAxis periodAxis63 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis63.setLowerBound((double) 10);
        java.util.TimeZone timeZone66 = periodAxis63.getTimeZone();
        boolean boolean67 = periodAxis63.isVerticalTickLabels();
        org.jfree.chart.axis.PeriodAxis periodAxis69 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis69.setLowerBound((double) 10);
        java.util.TimeZone timeZone72 = periodAxis69.getTimeZone();
        double double73 = periodAxis69.getUpperMargin();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray74 = new org.jfree.chart.axis.ValueAxis[] { periodAxis10, periodAxis28, periodAxis34, periodAxis57, periodAxis63, periodAxis69 };
        xYPlot0.setDomainAxes(valueAxisArray74);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation76 = null;
        try {
            boolean boolean77 = xYPlot0.removeAnnotation(xYAnnotation76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str7.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(plot50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(tickUnitSource59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(valueAxisArray74);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        java.awt.Paint paint6 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries3.createCopy((int) 'a', (int) (byte) -1);
        xYSeries3.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries3.createCopy(10, 1);
        xYSeries3.clear();
        boolean boolean13 = tickUnits1.equals((java.lang.Object) xYSeries3);
        xYSeriesCollection0.removeSeries(xYSeries3);
        xYSeriesCollection0.setIntervalPositionFactor(Double.NaN);
        try {
            double double19 = xYSeriesCollection0.getStartYValue(3, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long16 = segmentedTimeline15.getSegmentsGroupSize();
        segmentedTimeline15.setAdjustForDaylightSaving(false);
        long long21 = segmentedTimeline15.getExceptionSegmentCount(97L, (long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment23 = segmentedTimeline15.getSegment((long) '4');
        segment23.dec();
        long long26 = segment23.calculateSegmentNumber(10L);
        try {
            org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset7, (java.lang.Comparable) segment23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3492L + "'", long16 == 3492L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(segment23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        xYSeries1.setMaximumItemCount((int) (byte) 100);
        xYSeries1.setNotify(false);
        boolean boolean14 = xYSeries1.getNotify();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        java.awt.Font font21 = periodAxis6.getLabelFont();
        double double22 = periodAxis6.getLowerBound();
        try {
            periodAxis6.resizeRange((double) 7499012895324L, (double) 3L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-5.76E7d) + "'", double22 == (-5.76E7d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "hi!", "VerticalAlignment.CENTER", "VerticalAlignment.CENTER");
        java.lang.String str5 = library4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot2.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = null;
        java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        xYPlot2.panDomainAxes((double) (byte) 0, plotRenderingInfo6, point2D9);
        try {
            org.jfree.chart.plot.XYPlot xYPlot11 = combinedDomainXYPlot0.findSubplot(plotRenderingInfo1, point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(point2D9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        double double11 = xYBarRenderer0.getBarAlignmentFactor();
        xYBarRenderer0.setBarAlignmentFactor((double) 15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis16 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean17 = periodAxis16.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = periodAxis16.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis20.setLowerBound((double) 10);
        java.util.TimeZone timeZone23 = periodAxis20.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = xYBarRenderer24.getSeriesURLGenerator(1);
        xYBarRenderer24.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        xYBarRenderer24.setSeriesNegativeItemLabelPosition(2, itemLabelPosition30, false);
        xYBarRenderer24.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection14, (org.jfree.chart.axis.ValueAxis) periodAxis16, (org.jfree.chart.axis.ValueAxis) periodAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer24);
        java.awt.Font font35 = periodAxis20.getLabelFont();
        xYBarRenderer0.setBaseItemLabelFont(font35, true);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(xYURLGenerator26);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getMinorTickCount();
        int int2 = dateTickUnit0.getMultiple();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem11 = xYSeries1.remove((java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        xYBarRenderer0.setAutoPopulateSeriesStroke(false);
        double double17 = xYBarRenderer0.getMargin();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getToolTipText();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = piePlot3D4.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D4.getLegendLabelToolTipGenerator();
        double double7 = piePlot3D4.getStartAngle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D4.setLabelBackgroundPaint((java.awt.Paint) color8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        boolean boolean12 = piePlot3D11.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot3D11.getLegendLabelToolTipGenerator();
        double double14 = piePlot3D11.getStartAngle();
        java.awt.Paint paint15 = piePlot3D11.getLabelPaint();
        piePlot3D4.setParent((org.jfree.chart.plot.Plot) piePlot3D11);
        java.awt.Stroke stroke17 = piePlot3D11.getLabelLinkStroke();
        legendItem1.setOutlineStroke(stroke17);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 90.0d + "'", double14 == 90.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 255, 0, (int) (short) 0);
        try {
            boolean boolean5 = segmentedTimeline3.containsDomainValue((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries3.createCopy((int) 'a', (int) (byte) -1);
        xYSeries3.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries3.createCopy(10, 1);
        double double12 = xYSeries3.getMaxY();
        boolean boolean13 = segmentedTimeline0.equals((java.lang.Object) xYSeries3);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = periodAxis1.getStandardTickUnits();
        java.awt.Color color4 = java.awt.Color.cyan;
        periodAxis1.setLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = periodAxis1.getTickMarkPaint();
        periodAxis1.resizeRange((double) 15, 0.5d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        java.awt.Shape shape12 = legendItemEntity11.getArea();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = null;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        xYPlot13.panDomainAxes((double) (byte) 0, plotRenderingInfo17, point2D20);
        boolean boolean22 = xYPlot13.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D23 = xYPlot13.getQuadrantOrigin();
        int int24 = xYPlot13.getRangeAxisCount();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset25 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset25, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate28 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset25);
        int int29 = xYPlot13.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset25);
        legendItemEntity11.setDataset((org.jfree.data.general.Dataset) defaultXYDataset25);
        legendItemEntity11.setURLText("ClassContext");
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        xYBarRenderer0.removeAnnotations();
        java.awt.Paint paint11 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) 100);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 10, itemLabelPosition16);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYBarRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYURLGenerator18);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(4.0d, (-1.0d), (double) 12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("HorizontalAlignment.CENTER");
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.add(0.0d, (double) 10);
        boolean boolean8 = xYSeries1.getAutoSort();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = xYLineAndShapeRenderer4.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape7 = xYLineAndShapeRenderer4.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot8.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        xYPlot8.panDomainAxes((double) (byte) 0, plotRenderingInfo12, point2D15);
        boolean boolean17 = xYPlot8.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D18 = xYPlot8.getQuadrantOrigin();
        int int19 = xYPlot8.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) xYPlot8, "", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.util.StrokeMap strokeMap23 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj24 = strokeMap23.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        strokeMap23.put((java.lang.Comparable) dateTickUnit25, stroke26);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = xYBarRenderer28.getSeriesURLGenerator(1);
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer28.setBaseOutlineStroke(stroke31);
        xYBarRenderer28.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint36 = xYBarRenderer28.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean38 = xYBarRenderer28.isSeriesItemLabelsVisible(100);
        double double39 = xYBarRenderer28.getBarAlignmentFactor();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color40);
        xYBarRenderer28.setBasePaint((java.awt.Paint) color40, false);
        try {
            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem(attributedString0, "PlotEntity: tooltip = ", "", "AxisEntity: tooltip = null", shape7, stroke26, (java.awt.Paint) color40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(dateTickUnit25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(xYURLGenerator30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        boolean boolean7 = xYBarRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        java.lang.String str2 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str2.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) double3, seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo6);
        java.lang.String str8 = seriesChangeEvent5.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=0.0]"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        numberFormat1.setGroupingUsed(true);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getIntegerInstance();
        numberFormat4.setGroupingUsed(true);
        int int7 = numberFormat4.getMaximumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SeriesRenderingOrder.FORWARD", numberFormat1, numberFormat4);
        java.text.ParsePosition parsePosition10 = null;
        try {
            java.lang.Object obj11 = numberFormat1.parseObject("VerticalAlignment.CENTER", parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 1900, (float) 64, (float) 0L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        double double5 = xYBarRenderer0.getShadowYOffset();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = xYBarRenderer0.getToolTipGenerator(255, (int) (byte) -1, false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNull(xYToolTipGenerator11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean5 = xYLineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        xYLineAndShapeRenderer0.setSeriesLinesVisible(1, (java.lang.Boolean) false);
        int int9 = xYLineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.addCategoryLabelToolTip((java.lang.Comparable) (short) 1, "PlotEntity: tooltip = ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.Number number18 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, number18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year15.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        boolean boolean6 = xYLineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        boolean boolean10 = piePlot3D9.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D9.getLegendLabelToolTipGenerator();
        double double12 = piePlot3D9.getStartAngle();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D9.setLabelBackgroundPaint((java.awt.Paint) color13);
        java.awt.Color color16 = java.awt.Color.black;
        piePlot3D9.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color16);
        xYLineAndShapeRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color16, false);
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        int int23 = xYLineAndShapeRenderer0.getDefaultEntityRadius();
        java.lang.Boolean boolean25 = xYLineAndShapeRenderer0.getSeriesLinesVisible(10);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNull(boolean25);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean5 = xYLineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean11 = periodAxis10.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = periodAxis10.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = xYBarRenderer18.getSeriesURLGenerator(1);
        xYBarRenderer18.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        xYBarRenderer18.setSeriesNegativeItemLabelPosition(2, itemLabelPosition24, false);
        xYBarRenderer18.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection8, (org.jfree.chart.axis.ValueAxis) periodAxis10, (org.jfree.chart.axis.ValueAxis) periodAxis14, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer18);
        java.awt.Font font29 = periodAxis14.getLabelFont();
        double double30 = periodAxis14.getLowerBound();
        java.awt.Font font32 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D(pieDataset33);
        java.lang.Object obj35 = null;
        boolean boolean36 = piePlot3D34.equals(obj35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("", font32, (org.jfree.chart.plot.Plot) piePlot3D34, true);
        java.awt.Color color39 = java.awt.Color.PINK;
        jFreeChart38.setBorderPaint((java.awt.Paint) color39);
        org.jfree.chart.title.LegendTitle legendTitle42 = jFreeChart38.getLegend(0);
        legendTitle42.setHeight((double) (byte) 100);
        legendTitle42.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection50 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo(entityCollection50);
        java.awt.geom.Rectangle2D rectangle2D52 = chartRenderingInfo51.getChartArea();
        legendTitle42.setBounds(rectangle2D52);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D55 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D52, rectangleAnchor54);
        try {
            xYLineAndShapeRenderer0.fillRangeGridBand(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis14, rectangle2D52, (double) (short) 1, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(tickUnitSource12);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(xYURLGenerator20);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-5.76E7d) + "'", double30 == (-5.76E7d));
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(legendTitle42);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(point2D55);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint3 = piePlot3D1.getBaseSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getSectionOutlineStroke((java.lang.Comparable) 60000L);
        piePlot3D1.setIgnoreZeroValues(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(2958465);
        boolean boolean2 = xYAreaRenderer1.getPlotShapes();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(2958465);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = standardGradientPaintTransformer2.getType();
        xYAreaRenderer1.setGradientTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape4, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot10.getRootPlot();
        java.awt.Shape shape12 = multiplePiePlot10.getLegendItemShape();
        chartEntity8.setArea(shape12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) multiplePiePlot15);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            multiplePiePlot15.drawOutline(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(jFreeChart16);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        java.awt.Shape shape12 = legendItemEntity11.getArea();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        boolean boolean15 = legendItemEntity11.equals((java.lang.Object) piePlot3D14);
        java.lang.Object obj16 = legendItemEntity11.clone();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("DomainOrder.DESCENDING", graphics2D1, (float) 64, 0.0f, (double) 2019, (float) 2019, (float) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = periodAxis1.getStandardTickUnits();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset4);
        org.jfree.chart.plot.Plot plot6 = multiplePiePlot5.getRootPlot();
        java.awt.Paint paint7 = plot6.getNoDataMessagePaint();
        boolean boolean8 = periodAxis1.hasListener((java.util.EventListener) plot6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Shape shape5 = xYBarRenderer0.getLegendBar();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            java.lang.Number number4 = xYSeriesCollection0.getY(0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, 0.0f, (double) (short) 1, (float) 3L, (float) 255);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.Object obj1 = null;
        boolean boolean2 = logFormat0.equals(obj1);
        logFormat0.setMinimumFractionDigits((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        double double4 = xYSeriesCollection2.getDomainLowerBound(false);
        org.jfree.chart.entity.XYItemEntity xYItemEntity9 = new org.jfree.chart.entity.XYItemEntity(shape1, (org.jfree.data.xy.XYDataset) xYSeriesCollection2, 9, 0, "ClassContext", "TextAnchor.TOP_LEFT");
        int int10 = xYItemEntity9.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getRangeAxis((int) '#');
        xYPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot7.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str14 = seriesRenderingOrder13.toString();
        xYPlot7.setSeriesRenderingOrder(seriesRenderingOrder13);
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        java.awt.Font font19 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D(pieDataset20);
        java.lang.Object obj22 = null;
        boolean boolean23 = piePlot3D21.equals(obj22);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("", font19, (org.jfree.chart.plot.Plot) piePlot3D21, true);
        java.awt.Color color26 = java.awt.Color.PINK;
        jFreeChart25.setBorderPaint((java.awt.Paint) color26);
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart25.getLegend(0);
        legendTitle29.setHeight((double) (byte) 100);
        legendTitle29.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        java.awt.geom.Rectangle2D rectangle2D39 = chartRenderingInfo38.getChartArea();
        legendTitle29.setBounds(rectangle2D39);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D(pieDataset42);
        boolean boolean44 = piePlot3D43.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator45 = piePlot3D43.getLegendLabelToolTipGenerator();
        double double46 = piePlot3D43.getStartAngle();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D43.setLabelBackgroundPaint((java.awt.Paint) color47);
        java.awt.Color color50 = java.awt.Color.black;
        piePlot3D43.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color50);
        piePlot3D43.setIgnoreNullValues(true);
        java.awt.Paint paint54 = piePlot3D43.getLabelOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot56 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset55);
        org.jfree.chart.JFreeChart jFreeChart57 = multiplePiePlot56.getPieChart();
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart57.setBorderStroke(stroke58);
        xYAreaRenderer3.drawDomainLine(graphics2D6, xYPlot7, (org.jfree.chart.axis.ValueAxis) periodAxis17, rectangle2D39, (double) 10L, paint54, stroke58);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis64 = xYPlot62.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = null;
        java.awt.geom.Point2D point2D69 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D67, rectangleAnchor68);
        xYPlot62.panDomainAxes((double) (byte) 0, plotRenderingInfo66, point2D69);
        boolean boolean71 = xYPlot62.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke72 = xYPlot62.getDomainZeroBaselineStroke();
        try {
            xYAreaRenderer3.setSeriesOutlineStroke(2147483647, stroke72, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str14.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(legendTitle29);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 90.0d + "'", double46 == 90.0d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(jFreeChart57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNull(valueAxis64);
        org.junit.Assert.assertNotNull(point2D69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        java.awt.Stroke stroke6 = xYPlot0.getDomainMinorGridlineStroke();
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean15 = range13.contains((double) (byte) 1);
        double double16 = range13.getLowerBound();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean19 = range17.contains((double) (byte) 1);
        double double20 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range17);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toRangeHeight(range22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean26 = range24.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint23.toRangeHeight(range24);
        org.jfree.chart.util.Size2D size2D28 = legendTitle11.arrange(graphics2D12, rectangleConstraint27);
        java.lang.Object obj29 = size2D28.clone();
        size2D28.height = 10.0f;
        java.lang.Object obj32 = size2D28.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = periodAxis1.getStandardTickUnits();
        java.awt.Color color4 = java.awt.Color.cyan;
        periodAxis1.setLabelPaint((java.awt.Paint) color4);
        int int6 = color4.getRed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str6 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D0.drawTickMarks(graphics2D7, (double) (byte) -1, rectangle2D9, rectangleEdge11, axisState13);
        axisState13.setMax((double) 35);
        axisState13.cursorLeft(1.0E-5d);
        axisState13.cursorUp(0.08d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        tickUnits0.add((org.jfree.chart.axis.TickUnit) numberTickUnit1);
        java.lang.String str3 = numberTickUnit1.toString();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[size=1]" + "'", str3.equals("[size=1]"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D1.getLabelGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot3D1.getLegendItems();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = segmentedTimeline8.getBaseTimeline();
        boolean boolean10 = legendItemCollection7.equals((java.lang.Object) segmentedTimeline9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 175, dateTickUnitType2, 10, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) 100L, 100.0d, 0.0d, (double) 8);
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries24 = xYSeries21.createCopy((int) 'a', (int) (byte) -1);
        boolean boolean25 = rectangleInsets19.equals((java.lang.Object) 'a');
        piePlot3D8.setInsets(rectangleInsets19);
        boolean boolean27 = piePlot3D8.getAutoPopulateSectionOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.chart.JFreeChart jFreeChart30 = multiplePiePlot29.getPieChart();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart30.setBorderPaint((java.awt.Paint) color31);
        piePlot3D8.setLabelShadowPaint((java.awt.Paint) color31);
        org.jfree.data.xy.XYSeries xYSeries35 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries38 = xYSeries35.createCopy((int) 'a', (int) (byte) -1);
        xYSeries35.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries43 = xYSeries35.createCopy(10, 1);
        boolean boolean44 = color31.equals((java.lang.Object) xYSeries35);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(xYSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jFreeChart30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(xYSeries38);
        org.junit.Assert.assertNotNull(xYSeries43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        double double11 = xYBarRenderer0.getBarAlignmentFactor();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color12);
        xYBarRenderer0.setBasePaint((java.awt.Paint) color12, false);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot16.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = null;
        java.awt.geom.Point2D point2D23 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor22);
        xYPlot16.panDomainAxes((double) (byte) 0, plotRenderingInfo20, point2D23);
        boolean boolean25 = xYPlot16.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot29.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = null;
        java.awt.geom.Point2D point2D36 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D34, rectangleAnchor35);
        xYPlot29.panDomainAxes((double) (byte) 0, plotRenderingInfo33, point2D36);
        xYPlot16.zoomRangeAxes((double) 97L, (double) 100, plotRenderingInfo28, point2D36);
        xYBarRenderer0.setPlot(xYPlot16);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(point2D36);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) defaultKeyedValues0);
        java.lang.Number number3 = defaultPieDataset1.getValue(0);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset1);
        double double5 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset1);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range4);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toRangeHeight(range9);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getHeightConstraintType();
        java.lang.String str12 = lengthConstraintType11.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleConstraintType.RANGE" + "'", str12.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) defaultKeyedValues0);
        defaultPieDataset1.clear();
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        double double4 = xYSeriesCollection2.getDomainLowerBound(false);
        org.jfree.chart.entity.XYItemEntity xYItemEntity9 = new org.jfree.chart.entity.XYItemEntity(shape1, (org.jfree.data.xy.XYDataset) xYSeriesCollection2, 9, 0, "ClassContext", "TextAnchor.TOP_LEFT");
        double double11 = xYSeriesCollection2.getRangeUpperBound(true);
        try {
            double double14 = xYSeriesCollection2.getStartXValue(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double2 = periodAxis1.getUpperMargin();
        java.awt.Color color3 = java.awt.Color.PINK;
        int int4 = color3.getGreen();
        periodAxis1.setLabelPaint((java.awt.Paint) color3);
        periodAxis1.resizeRange(8.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = periodAxis1.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNull(tickUnitSource8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = null;
        ringPlot0.setLabelOutlineStroke(stroke1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape4, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot10.getRootPlot();
        java.awt.Shape shape12 = multiplePiePlot10.getLegendItemShape();
        chartEntity8.setArea(shape12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke17);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity21 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart16, "java.awt.Color[r=255,g=0,b=0]", "hi!");
        java.lang.String str22 = jFreeChartEntity21.getShapeCoords();
        java.lang.Object obj23 = jFreeChartEntity21.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str22.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        xYBarRenderer0.setBaseSeriesVisible(true, false);
        xYBarRenderer0.setItemLabelAnchorOffset(10.0d);
        java.awt.Font font21 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYBarRenderer0.setSeriesItemLabelFont((int) (byte) 10, font21, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D(pieDataset26);
        boolean boolean28 = piePlot3D27.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint29 = piePlot3D27.getBaseSectionPaint();
        xYBarRenderer0.setSeriesOutlinePaint(2958465, paint29, false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNull(itemLabelPosition24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range4);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toRangeHeight(range9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range9, (double) 1L);
        double double14 = range9.getUpperBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("DomainOrder.DESCENDING", "AxisEntity: tooltip = null", "", "LengthConstraintType.NONE", "TextAnchor.TOP_LEFT");
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D10, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        java.lang.String str3 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertNull(waferMapDataset2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.setMaximumItemAge(0L);
        java.lang.Object obj7 = timeSeries1.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis9.setLowerBound((double) 10);
        java.util.TimeZone timeZone12 = periodAxis9.getTimeZone();
        periodAxis9.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean18 = range16.contains((double) (byte) 1);
        double double19 = range16.getLowerBound();
        periodAxis9.setRange(range16, false, false);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        periodAxis9.setLast((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, number26);
        int int28 = year23.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 3492L);
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis32.setLowerBound((double) 10);
        java.util.TimeZone timeZone35 = periodAxis32.getTimeZone();
        periodAxis32.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean41 = range39.contains((double) (byte) 1);
        double double42 = range39.getLowerBound();
        periodAxis32.setRange(range39, false, false);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getSerialIndex();
        periodAxis32.setLast((org.jfree.data.time.RegularTimePeriod) year46);
        java.lang.Number number49 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year46, number49);
        try {
            timeSeries1.add(timeSeriesDataItem50);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator9, true);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        xYPlot13.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot13.getFixedLegendItems();
        java.awt.Stroke stroke19 = xYPlot13.getDomainMinorGridlineStroke();
        xYBarRenderer0.setSeriesStroke(13, stroke19, true);
        xYBarRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset24);
        org.jfree.chart.plot.Plot plot26 = multiplePiePlot25.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = multiplePiePlot25.getInsets();
        boolean boolean28 = xYBarRenderer0.equals((java.lang.Object) rectangleInsets27);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(plot26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.setUseFillPaint(false);
        java.lang.Object obj6 = xYAreaRenderer3.clone();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        java.lang.Object obj8 = null;
        boolean boolean9 = piePlot3D7.equals(obj8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) piePlot3D7, true);
        java.awt.Color color12 = java.awt.Color.PINK;
        jFreeChart11.setBorderPaint((java.awt.Paint) color12);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart11.getLegend(0);
        legendTitle15.setHeight((double) (byte) 100);
        legendTitle15.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        legendTitle15.setBounds(rectangle2D25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor27);
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean31 = piePlot29.equals((java.lang.Object) categoryAxis3D30);
        java.awt.Font font38 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D(pieDataset39);
        java.lang.Object obj41 = null;
        boolean boolean42 = piePlot3D40.equals(obj41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("", font38, (org.jfree.chart.plot.Plot) piePlot3D40, true);
        java.awt.Color color45 = java.awt.Color.PINK;
        jFreeChart44.setBorderPaint((java.awt.Paint) color45);
        org.jfree.chart.title.LegendTitle legendTitle48 = jFreeChart44.getLegend(0);
        legendTitle48.setHeight((double) (byte) 100);
        legendTitle48.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection56 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo(entityCollection56);
        java.awt.geom.Rectangle2D rectangle2D58 = chartRenderingInfo57.getChartArea();
        legendTitle48.setBounds(rectangle2D58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D61 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor60);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D();
        double double63 = categoryAxis3D62.getLabelAngle();
        categoryAxis3D62.clearCategoryLabelToolTips();
        categoryAxis3D62.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str68 = categoryAxis3D62.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D69 = null;
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge72);
        org.jfree.chart.axis.AxisState axisState75 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D62.drawTickMarks(graphics2D69, (double) (byte) -1, rectangle2D71, rectangleEdge73, axisState75);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge73);
        double double78 = categoryAxis3D30.getCategorySeriesMiddle((int) (byte) 0, (int) (short) 1, 1, 7, 0.12d, rectangle2D58, rectangleEdge73);
        boolean boolean79 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge73);
        try {
            java.util.List list80 = logAxis0.refreshTicks(graphics2D1, axisState3, rectangle2D25, rectangleEdge73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(legendTitle15);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(legendTitle48);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(point2D61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries4.setMaximumItemCount(2019);
        boolean boolean7 = xYSeries4.getAllowDuplicateXValues();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = xYPlot20.getDatasetRenderingOrder();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries23.removeAgedItems((long) (-1), false);
        timeSeries23.setMaximumItemAge(0L);
        java.lang.Object obj29 = timeSeries23.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis31.setLowerBound((double) 10);
        java.util.TimeZone timeZone34 = periodAxis31.getTimeZone();
        periodAxis31.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean40 = range38.contains((double) (byte) 1);
        double double41 = range38.getLowerBound();
        periodAxis31.setRange(range38, false, false);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getSerialIndex();
        periodAxis31.setLast((org.jfree.data.time.RegularTimePeriod) year45);
        java.lang.Number number48 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year45, number48);
        int int50 = year45.getYear();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) year45, (java.lang.Number) 3492L);
        boolean boolean53 = datasetRenderingOrder21.equals((java.lang.Object) 3492L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, 100.0d, 0.0d, (double) 8);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot0.getOrientation();
        java.lang.String str12 = plotOrientation11.toString();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PlotOrientation.VERTICAL" + "'", str12.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape4, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot10.getRootPlot();
        java.awt.Shape shape12 = multiplePiePlot10.getLegendItemShape();
        chartEntity8.setArea(shape12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) multiplePiePlot15);
        java.awt.Paint paint18 = multiplePiePlot15.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) (byte) 1);
        double double4 = range1.getLowerBound();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean7 = range5.contains((double) (byte) 1);
        double double8 = range5.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range1, range5);
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toRangeHeight(range10);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange(range10);
        java.util.Date date13 = dateRange12.getUpperDate();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate14.getNearestDayOfWeek(7);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        java.awt.Color color9 = java.awt.Color.PINK;
        jFreeChart8.setBorderPaint((java.awt.Paint) color9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart8.getLegend(0);
        legendTitle12.setHeight((double) (byte) 100);
        legendTitle12.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle12.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment20, (double) 1.0f, (double) 1L);
        java.lang.String str24 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "HorizontalAlignment.CENTER" + "'", str24.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        boolean boolean6 = xYLineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        boolean boolean10 = piePlot3D9.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D9.getLegendLabelToolTipGenerator();
        double double12 = piePlot3D9.getStartAngle();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D9.setLabelBackgroundPaint((java.awt.Paint) color13);
        java.awt.Color color16 = java.awt.Color.black;
        piePlot3D9.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color16);
        xYLineAndShapeRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color16, false);
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        int int23 = xYLineAndShapeRenderer0.getDefaultEntityRadius();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = xYLineAndShapeRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator24);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot20.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer23.getSeriesURLGenerator(1);
        xYBarRenderer23.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        xYBarRenderer23.setSeriesNegativeItemLabelPosition(2, itemLabelPosition29, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = xYBarRenderer23.getSeriesURLGenerator(35);
        java.awt.Stroke stroke37 = xYBarRenderer23.getItemStroke((int) ' ', 0, false);
        xYPlot20.setDomainCrosshairStroke(stroke37);
        xYPlot20.setDomainCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNull(xYURLGenerator33);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        double double4 = piePlot3D1.getExplodePercent((java.lang.Comparable) "");
        piePlot3D1.clearSectionOutlineStrokes(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.Object obj2 = null;
        boolean boolean3 = year0.equals(obj2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape3 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) xYPlot4, "", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.util.ObjectList objectList21 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color24, stroke25);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker26);
        objectList21.set(0, (java.lang.Object) valueMarker26);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean32 = xYPlot4.removeRangeMarker(13, (org.jfree.chart.plot.Marker) valueMarker26, layer30, false);
        org.jfree.chart.axis.AxisSpace axisSpace33 = xYPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(axisSpace33);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        java.lang.Object obj3 = null;
        boolean boolean4 = piePlot3D2.equals(obj3);
        boolean boolean5 = piePlot3D2.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke6 = piePlot3D2.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D2.getLabelGenerator();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = piePlot3D2.getLegendItems();
        boolean boolean9 = timeSeriesCollection0.equals((java.lang.Object) legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot0.getSeriesRenderingOrder();
        java.lang.String str13 = seriesRenderingOrder12.toString();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str13.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        int int4 = segmentedTimeline3.getSegmentsIncluded();
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(date5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long11 = segmentedTimeline10.getSegmentsGroupSize();
        segmentedTimeline10.setAdjustForDaylightSaving(false);
        long long16 = segmentedTimeline10.getExceptionSegmentCount(97L, (long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline10.getSegment((long) '4');
        segment18.dec();
        long long21 = segment18.calculateSegmentNumber(10L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline25 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long26 = segmentedTimeline25.getStartTime();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment28 = segmentedTimeline25.getSegment(date27);
        boolean boolean29 = segment18.after(segment28);
        boolean boolean30 = segment6.after(segment18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3492L + "'", long11 == 3492L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(segment28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getURLGenerator((int) (byte) 10, (int) (short) 0, true);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        java.lang.Object obj15 = null;
        boolean boolean16 = piePlot3D14.equals(obj15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) piePlot3D14, true);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart18, (int) (byte) 100, (int) (byte) 0);
        chartProgressEvent21.setPercent(3);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        defaultKeyedValues0.setValue((java.lang.Comparable) 97.0d, 0.0d);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean7 = range5.contains((double) (byte) 1);
        double double8 = range5.getLowerBound();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range9.contains((double) (byte) 1);
        double double12 = range9.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range5, range9);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toRangeHeight(range14);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange(range14);
        java.util.Date date17 = dateRange16.getUpperDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        try {
            defaultKeyedValues0.removeValue((java.lang.Comparable) date17);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (Wed Dec 31 16:00:00 PST 1969) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, true);
        try {
            java.lang.Number number11 = xYSeriesCollection3.getY(2019, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNull(categoryDataset3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "UnitType.ABSOLUTE", "Range[0.0,1.0]", image3, "{0}", "[size=1]", "Range[0.0,1.0]");
        org.jfree.chart.ui.Library library8 = null;
        try {
            projectInfo7.addOptionalLibrary(library8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.black;
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color8);
        piePlot3D1.setIgnoreNullValues(true);
        piePlot3D1.clearSectionPaints(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMinorTickMarkOutsideLength(0.0f);
        categoryAxis3D0.setAxisLineVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = piePlot3D4.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D4.getLegendLabelToolTipGenerator();
        double double7 = piePlot3D4.getStartAngle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D4.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D4);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D0.setTickLabelFont(font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis3D0.getTickLabelInsets();
        double double14 = rectangleInsets13.getBottom();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets13.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        java.lang.Object obj4 = piePlot3D1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot3D1.getLabelPadding();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = null;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        xYPlot13.panDomainAxes((double) (byte) 0, plotRenderingInfo17, point2D20);
        xYPlot0.zoomRangeAxes((double) 97L, (double) 100, plotRenderingInfo12, point2D20);
        boolean boolean23 = xYPlot0.isDomainPannable();
        java.lang.Object obj24 = null;
        boolean boolean25 = xYPlot0.equals(obj24);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D(pieDataset26);
        java.lang.Object obj28 = null;
        boolean boolean29 = piePlot3D27.equals(obj28);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) piePlot3D27);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor31 = null;
        try {
            piePlot3D27.setLabelDistributor(abstractPieLabelDistributor31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        int int4 = defaultXYDataset0.indexOf((java.lang.Comparable) date3);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean2 = piePlot0.equals((java.lang.Object) categoryAxis3D1);
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        java.lang.Object obj12 = null;
        boolean boolean13 = piePlot3D11.equals(obj12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) piePlot3D11, true);
        java.awt.Color color16 = java.awt.Color.PINK;
        jFreeChart15.setBorderPaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart15.getLegend(0);
        legendTitle19.setHeight((double) (byte) 100);
        legendTitle19.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        java.awt.geom.Rectangle2D rectangle2D29 = chartRenderingInfo28.getChartArea();
        legendTitle19.setBounds(rectangle2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D32 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor31);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        double double34 = categoryAxis3D33.getLabelAngle();
        categoryAxis3D33.clearCategoryLabelToolTips();
        categoryAxis3D33.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str39 = categoryAxis3D33.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge43);
        org.jfree.chart.axis.AxisState axisState46 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D33.drawTickMarks(graphics2D40, (double) (byte) -1, rectangle2D42, rectangleEdge44, axisState46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge44);
        double double49 = categoryAxis3D1.getCategorySeriesMiddle((int) (byte) 0, (int) (short) 1, 1, 7, 0.12d, rectangle2D29, rectangleEdge44);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        try {
            boolean boolean51 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D29, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        boolean boolean9 = segmentedTimeline3.containsDomainRange((long) (byte) 1, 3L);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        piePlot3D11.setCircular(true, true);
        double double15 = piePlot3D11.getLabelGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot3D11.removeChangeListener(plotChangeListener16);
        double double18 = piePlot3D11.getDepthFactor();
        boolean boolean19 = segmentedTimeline3.equals((java.lang.Object) piePlot3D11);
        long long21 = segmentedTimeline3.toMillisecond((long) '4');
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.025d + "'", double15 == 0.025d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.12d + "'", double18 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart2.setBorderStroke(stroke3);
        boolean boolean5 = jFreeChart2.isNotify();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart2.getLegend(7);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(legendTitle7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 10);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(true, true);
        double double5 = piePlot3D1.getLabelGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot3D1.removeChangeListener(plotChangeListener6);
        double double8 = piePlot3D1.getDepthFactor();
        java.awt.Paint paint9 = piePlot3D1.getBaseSectionPaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.12d + "'", double8 == 0.12d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3D6.setTickLabelFont((java.lang.Comparable) '4', font10);
        boolean boolean12 = piePlot3D1.equals((java.lang.Object) categoryAxis3D6);
        java.lang.Object obj13 = categoryAxis3D6.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis15.setLowerBound((double) 10);
        java.util.TimeZone timeZone18 = periodAxis15.getTimeZone();
        periodAxis15.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean24 = range22.contains((double) (byte) 1);
        double double25 = range22.getLowerBound();
        periodAxis15.setRange(range22, false, false);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getSerialIndex();
        periodAxis15.setLast((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.Number number32 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, number32);
        int int34 = year29.getYear();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D(pieDataset35);
        boolean boolean37 = piePlot3D36.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator38 = piePlot3D36.getLegendLabelToolTipGenerator();
        double double39 = piePlot3D36.getStartAngle();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D36.setLabelBackgroundPaint((java.awt.Paint) color40);
        categoryAxis3D6.setTickLabelPaint((java.lang.Comparable) year29, (java.awt.Paint) color40);
        float float43 = categoryAxis3D6.getMinorTickMarkInsideLength();
        categoryAxis3D6.removeCategoryLabelToolTip((java.lang.Comparable) 2.0d);
        java.awt.Font font47 = categoryAxis3D6.getTickLabelFont((java.lang.Comparable) 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) defaultKeyedValues0);
        java.lang.Number number3 = defaultPieDataset1.getValue(0);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset1);
        try {
            defaultPieDataset1.insertValue((int) (short) -1, (java.lang.Comparable) 7, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder4 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        legendTitle11.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle11.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray8 = new float[] { 97L, 'a', 60000L, 6, (short) 1, (byte) -1 };
        float[] floatArray9 = color1.getColorComponents(floatArray8);
        float[] floatArray10 = color0.getColorComponents(floatArray8);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        java.awt.Shape shape12 = legendItemEntity11.getArea();
        boolean boolean14 = legendItemEntity11.equals((java.lang.Object) 13);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset15 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate17 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset15, true);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset15);
        legendItemEntity11.setDataset((org.jfree.data.general.Dataset) defaultXYDataset15);
        legendItemEntity11.setURLText("April");
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        legendTitle11.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle11.getLegendItemGraphicPadding();
        double double20 = rectangleInsets19.getLeft();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        java.util.List list2 = combinedRangeXYPlot0.getAnnotations();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) rectangleAnchor10);
        valueMarker6.setLabelAnchor(rectangleAnchor10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker6, layer13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        categoryPlot34.configureRangeAxes();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        java.lang.String str3 = range0.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range0, (double) 10.0f, true);
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range0.intersects(range7);
        double double10 = range0.constrain((double) (byte) -1);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getStartTime();
        boolean boolean6 = segmentedTimeline3.containsDomainValue((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("LegendItemEntity: seriesKey=null, dataset=null");
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate15 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        int int16 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        int int18 = defaultXYDataset12.indexOf((java.lang.Comparable) '#');
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color5 = java.awt.Color.PINK;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color5, false);
        xYBarRenderer0.setShadowYOffset((double) 8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.data.Range range11 = xYBarRenderer0.findDomainBounds(xYDataset10);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint2 = textFragment1.getPaint();
        float float3 = textFragment1.getBaselineOffset();
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textFragment1.calculateDimensions(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape3 = xYBarRenderer1.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        int int6 = xYSeriesCollection4.getSeriesCount();
        org.jfree.data.Range range7 = xYBarRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        try {
            java.lang.String str12 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (int) (byte) 10, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYBarRenderer0.getBaseItemLabelGenerator();
        java.awt.Color color12 = java.awt.Color.getHSBColor(0.0f, (float) (short) -1, (float) 1);
        xYBarRenderer0.setSeriesFillPaint((int) (short) 10, (java.awt.Paint) color12, false);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMinorTickMarkOutsideLength(0.0f);
        double double5 = categoryAxis3D0.getLowerMargin();
        double double6 = categoryAxis3D0.getCategoryMargin();
        boolean boolean7 = categoryAxis3D0.isVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double6 = intervalXYDelegate5.getFixedIntervalWidth();
        try {
            java.lang.Number number9 = intervalXYDelegate5.getEndX((int) (byte) 1, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator0.getNumberFormat();
        java.lang.String str3 = standardPieSectionLabelGenerator0.getLabelFormat();
        java.text.AttributedString attributedString5 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel(6, attributedString5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        double double3 = categoryAxis3D2.getLabelAngle();
        int int4 = categoryAxis3D2.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        boolean boolean7 = piePlot3D6.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3D6.getLegendLabelToolTipGenerator();
        double double9 = piePlot3D6.getStartAngle();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D6.setLabelBackgroundPaint((java.awt.Paint) color10);
        categoryAxis3D2.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D6);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D2.setTickLabelFont(font13);
        categoryAxis3D2.setCategoryLabelPositionOffset(0);
        int int17 = objectList1.indexOf((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.0d + "'", double9 == 90.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        java.lang.String str4 = piePlot3D1.getNoDataMessage();
        java.awt.Paint paint5 = piePlot3D1.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        java.awt.Color color9 = java.awt.Color.PINK;
        jFreeChart8.setBorderPaint((java.awt.Paint) color9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart8.getLegend(0);
        legendTitle12.setHeight((double) (byte) 100);
        legendTitle12.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle12.getVerticalAlignment();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean22 = xYLineAndShapeRenderer21.getBaseShapesVisible();
        xYLineAndShapeRenderer21.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean26 = xYLineAndShapeRenderer21.getAutoPopulateSeriesStroke();
        boolean boolean27 = legendTitle12.equals((java.lang.Object) boolean26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator30 = xYLineAndShapeRenderer28.getSeriesItemLabelGenerator(2958465);
        columnArrangement0.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) xYItemLabelGenerator30);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator30);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        java.awt.Color color9 = java.awt.Color.PINK;
        jFreeChart8.setBorderPaint((java.awt.Paint) color9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart8.getLegend(0);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean16 = range14.contains((double) (byte) 1);
        double double17 = range14.getLowerBound();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = range18.contains((double) (byte) 1);
        double double21 = range18.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range14, range18);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toRangeHeight(range23);
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean27 = range25.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint24.toRangeHeight(range25);
        org.jfree.chart.util.Size2D size2D29 = legendTitle12.arrange(graphics2D13, rectangleConstraint28);
        boolean boolean30 = numberTickUnit0.equals((java.lang.Object) graphics2D13);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint28);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getDescription();
        java.awt.Font font3 = legendItem1.getLabelFont();
        java.lang.String str4 = legendItem1.getDescription();
        boolean boolean5 = legendItem1.isShapeFilled();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        legendItem1.setOutlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        java.lang.Object obj4 = piePlot3D1.clone();
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) 100L, 100.0d, 0.0d, (double) 8);
        piePlot3D1.setInsets(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        boolean boolean11 = xYPlot0.canSelectByPoint();
        try {
            java.awt.Paint paint13 = xYPlot0.getQuadrantPaint(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (13) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        java.lang.Object obj10 = null;
        boolean boolean11 = piePlot3D9.equals(obj10);
        boolean boolean12 = piePlot3D9.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke13 = piePlot3D9.getBaseSectionOutlineStroke();
        piePlot3D9.setStartAngle((double) 4);
        org.jfree.chart.util.UnitType unitType16 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) 100L, 100.0d, 0.0d, (double) 8);
        piePlot3D9.setSimpleLabelOffset(rectangleInsets21);
        jFreeChart7.setPadding(rectangleInsets21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(unitType16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis2.setLowerBound((double) 10);
        java.util.TimeZone timeZone5 = periodAxis2.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("", timeZone5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis8.getLabelInsets();
        java.util.TimeZone timeZone11 = dateAxis8.getTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("PlotEntity: tooltip = ", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        java.awt.Paint paint3 = piePlot3D1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[size=1]", numberFormat1, numberFormat2);
        java.lang.String str4 = standardXYToolTipGenerator3.getFormatString();
        java.lang.String str5 = standardXYToolTipGenerator3.getNullYString();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[size=1]" + "'", str4.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null" + "'", str5.equals("null"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot20.getLegendItems();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str25 = legendItem24.getDescription();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str28 = dateTickUnit26.valueToString((double) 0L);
        legendItem24.setSeriesKey((java.lang.Comparable) 0L);
        legendItemCollection22.add(legendItem24);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str33 = legendItem32.getDescription();
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str36 = dateTickUnit34.valueToString((double) 0L);
        legendItem32.setSeriesKey((java.lang.Comparable) 0L);
        legendItemCollection22.add(legendItem32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "12/31/69 4:00 PM" + "'", str28.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "12/31/69 4:00 PM" + "'", str36.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        defaultKeyedValues0.setValue((java.lang.Comparable) 97.0d, 0.0d);
        org.jfree.chart.util.SortOrder sortOrder5 = null;
        try {
            defaultKeyedValues0.sortByValues(sortOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        double double5 = periodAxis1.getUpperMargin();
        double double6 = periodAxis1.getAutoRangeMinimumSize();
        periodAxis1.setFixedAutoRange((double) 1.0f);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int3 = java.awt.Color.HSBtoRGB((float) 2958465, (float) 2019L, (float) 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-133) + "'", int3 == (-133));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat17 = standardPieSectionLabelGenerator16.getPercentFormat();
        piePlot3D8.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(numberFormat17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        intervalMarker2.setStartValue((double) (short) 10);
        java.lang.Object obj5 = intervalMarker2.clone();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Stroke stroke10 = xYPlot0.getRangeGridlineStroke();
        xYPlot0.setDomainCrosshairValue(100.0d, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean2 = xYStepAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem5.setLine(shape8);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape8, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.plot.Plot plot15 = multiplePiePlot14.getRootPlot();
        java.awt.Shape shape16 = multiplePiePlot14.getLegendItemShape();
        chartEntity12.setArea(shape16);
        xYStepAreaRenderer1.setLegendShape(2, shape16);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape16, (double) 7, (float) 8, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        java.util.List list5 = null;
        try {
            segmentedTimeline3.addExceptions(list5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        boolean boolean4 = jFreeChartResources0.containsKey("[6.0, NaN]");
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint12 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        xYBarRenderer0.setBase(0.0d);
        boolean boolean16 = xYBarRenderer0.isSeriesVisibleInLegend(35);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYBarRenderer0.getSeriesURLGenerator((int) (byte) 10);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(xYURLGenerator18);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(8.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", false);
        logFormat3.setMaximumFractionDigits((int) (short) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        jFreeChart7.clearSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("SeriesRenderingOrder.REVERSE", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("item");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name item, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        xYDataItem3.setSelected(true);
        java.lang.String str6 = xYDataItem3.toString();
        java.lang.Number number7 = null;
        defaultKeyedValues0.setValue((java.lang.Comparable) xYDataItem3, number7);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[6.0, NaN]" + "'", str6.equals("[6.0, NaN]"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        boolean boolean2 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer3.setBaseOutlineStroke(stroke6);
        xYBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        xYBarRenderer3.setDrawBarOutline(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = xYBarRenderer3.getLegendItemURLGenerator();
        java.awt.Shape shape13 = xYBarRenderer3.getLegendBar();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYBarRenderer14.getSeriesURLGenerator(1);
        xYBarRenderer14.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        xYBarRenderer14.setSeriesNegativeItemLabelPosition(2, itemLabelPosition20, false);
        xYBarRenderer14.removeAnnotations();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = xYBarRenderer14.getLegendItemLabelGenerator();
        xYBarRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator24);
        xYLineAndShapeRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator24);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        objectList1.set(0, (java.lang.Object) valueMarker6);
        objectList1.clear();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.Object obj0 = null;
        org.jfree.chart.util.PaintMap paintMap1 = new org.jfree.chart.util.PaintMap();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart4.setBorderStroke(stroke5);
        boolean boolean7 = paintMap1.equals((java.lang.Object) jFreeChart4);
        boolean boolean8 = jFreeChart4.isBorderVisible();
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        java.lang.Object obj13 = null;
        boolean boolean14 = piePlot3D12.equals(obj13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) piePlot3D12, true);
        java.awt.Color color17 = java.awt.Color.PINK;
        jFreeChart16.setBorderPaint((java.awt.Paint) color17);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart16.getLegend(0);
        legendTitle20.setHeight((double) (byte) 100);
        legendTitle20.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        jFreeChart4.removeSubtitle((org.jfree.chart.title.Title) legendTitle20);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection31 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis33 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean34 = periodAxis33.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = periodAxis33.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis37.setLowerBound((double) 10);
        java.util.TimeZone timeZone40 = periodAxis37.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer41 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator43 = xYBarRenderer41.getSeriesURLGenerator(1);
        xYBarRenderer41.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = null;
        xYBarRenderer41.setSeriesNegativeItemLabelPosition(2, itemLabelPosition47, false);
        xYBarRenderer41.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection31, (org.jfree.chart.axis.ValueAxis) periodAxis33, (org.jfree.chart.axis.ValueAxis) periodAxis37, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer41);
        boolean boolean52 = chartChangeEventType30.equals((java.lang.Object) xYBarRenderer41);
        boolean boolean53 = unitType29.equals((java.lang.Object) chartChangeEventType30);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent54 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart4, chartChangeEventType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(tickUnitSource35);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(xYURLGenerator43);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str7 = seriesRenderingOrder6.toString();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        try {
            java.awt.Paint paint10 = xYPlot0.getQuadrantPaint(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (2958465) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str7.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot34.getDomainAxisLocation(2147483647);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape6 = xYLineAndShapeRenderer5.getLegendLine();
        xYLineAndShapeRenderer0.setLegendLine(shape6);
        int int8 = xYLineAndShapeRenderer0.getPassCount();
        java.util.Collection collection9 = xYLineAndShapeRenderer0.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment3, (double) (short) 100, (double) (-1.0f));
        org.jfree.chart.block.Block block7 = null;
        columnArrangement6.add(block7, (java.lang.Object) 1L);
        boolean boolean10 = gradientPaintTransformType1.equals((java.lang.Object) columnArrangement6);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset11 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset11);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6, (org.jfree.data.general.Dataset) defaultXYDataset11, (java.lang.Comparable) Double.NaN);
        legendItemBlockContainer14.clear();
        java.lang.Comparable comparable16 = legendItemBlockContainer14.getSeriesKey();
        java.lang.String str17 = legendItemBlockContainer14.getID();
        java.lang.String str18 = legendItemBlockContainer14.getToolTipText();
        double double19 = legendItemBlockContainer14.getContentXOffset();
        boolean boolean20 = legendItemBlockContainer14.isEmpty();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertEquals((double) comparable16, Double.NaN, 0);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        xYBarRenderer3.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        xYBarRenderer3.setSeriesNegativeItemLabelPosition(2, itemLabelPosition9, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYBarRenderer3.getSeriesURLGenerator(35);
        java.awt.Stroke stroke17 = xYBarRenderer3.getItemStroke((int) ' ', 0, false);
        intervalMarker2.setOutlineStroke(stroke17);
        intervalMarker2.setLabel("UnitType.ABSOLUTE");
        double double21 = intervalMarker2.getStartValue();
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot36.getRangeAxis((int) '#');
        xYPlot36.setRangeCrosshairVisible(true);
        xYPlot36.clearRangeAxes();
        java.awt.Paint paint42 = xYPlot36.getDomainTickBandPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder43 = xYPlot36.getDatasetRenderingOrder();
        categoryPlot34.setDatasetRenderingOrder(datasetRenderingOrder43);
        java.awt.Paint paint45 = categoryPlot34.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNull(paint42);
        org.junit.Assert.assertNotNull(datasetRenderingOrder43);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        try {
            double double8 = intervalXYDelegate5.getEndXValue((int) (byte) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = periodAxis1.getStandardTickUnits();
        periodAxis1.setLowerBound((double) 97L);
        try {
            periodAxis1.setAutoRangeMinimumSize((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(tickUnitSource3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "DomainOrder.DESCENDING");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        try {
            java.lang.Comparable comparable4 = defaultXYDataset0.getSeriesKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem4.setLine(shape7);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape7, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.chart.plot.Plot plot14 = multiplePiePlot13.getRootPlot();
        java.awt.Shape shape15 = multiplePiePlot13.getLegendItemShape();
        chartEntity11.setArea(shape15);
        xYStepAreaRenderer0.setLegendShape(2, shape15);
        boolean boolean18 = xYStepAreaRenderer0.getShapesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYBarRenderer12.getSeriesURLGenerator(1);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer12.setBaseOutlineStroke(stroke15);
        xYBarRenderer12.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint20 = xYBarRenderer12.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, paint20, stroke21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer23);
        java.util.List list26 = null;
        try {
            xYPlot0.mapDatasetToDomainAxes((int) (short) 10, list26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setUseYInterval(false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        xYPlot20.setDomainCrosshairVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot25.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = null;
        java.awt.geom.Point2D point2D32 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor31);
        xYPlot25.panDomainAxes((double) (byte) 0, plotRenderingInfo29, point2D32);
        boolean boolean34 = xYPlot25.isRangeZeroBaselineVisible();
        int int35 = xYPlot25.getDatasetCount();
        java.awt.Paint paint36 = xYPlot25.getBackgroundPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean40 = periodAxis39.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource41 = periodAxis39.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis43 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis43.setLowerBound((double) 10);
        java.util.TimeZone timeZone46 = periodAxis43.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer47 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator49 = xYBarRenderer47.getSeriesURLGenerator(1);
        xYBarRenderer47.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = null;
        xYBarRenderer47.setSeriesNegativeItemLabelPosition(2, itemLabelPosition53, false);
        xYBarRenderer47.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection37, (org.jfree.chart.axis.ValueAxis) periodAxis39, (org.jfree.chart.axis.ValueAxis) periodAxis43, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer47);
        boolean boolean58 = xYPlot57.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection59 = xYPlot57.getLegendItems();
        xYPlot25.setFixedLegendItems(legendItemCollection59);
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color63, stroke64);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent66 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker65);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent67 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker65);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor68 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean70 = textBlockAnchor68.equals((java.lang.Object) rectangleAnchor69);
        valueMarker65.setLabelAnchor(rectangleAnchor69);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer72 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator74 = xYBarRenderer72.getSeriesURLGenerator(1);
        java.awt.Color color75 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYBarRenderer72.setBaseFillPaint((java.awt.Paint) color75, false);
        valueMarker65.setPaint((java.awt.Paint) color75);
        org.jfree.chart.util.Layer layer79 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean80 = xYPlot25.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker65, layer79);
        java.util.Collection collection81 = xYPlot20.getDomainMarkers(12, layer79);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(tickUnitSource41);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(xYURLGenerator49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(legendItemCollection59);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(textBlockAnchor68);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(xYURLGenerator74);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(layer79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(collection81);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2, textAnchor3, (double) 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE5" + "'", str1.equals("ItemLabelAnchor.OUTSIDE5"));
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.data.general.SeriesChangeEvent[source=0.0]", graphics2D1, 0.0f, (float) 0L, 0.025d, (float) 2958465, (float) 36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.Number number18 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, number18);
        int int20 = year15.getYear();
        java.util.Date date21 = year15.getStart();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setDomainAxis((int) '4', valueAxis6, true);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset9 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset9, true);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) defaultXYDataset9);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(xYItemRenderer13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesLinesVisible(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot6.getRootPlot();
        java.awt.Shape shape8 = multiplePiePlot6.getLegendItemShape();
        xYLineAndShapeRenderer0.setLegendLine(shape8);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer0.getSeriesItemLabelsVisible(6);
        java.lang.Boolean boolean13 = xYLineAndShapeRenderer0.getSeriesCreateEntities(0);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color36, stroke37);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker38);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = valueMarker38.getLabelOffset();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray43 = new java.awt.Paint[] { color41, color42 };
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray50 = new java.awt.Paint[] { paint44, paint45, color46, color47, color48, color49 };
        java.awt.Stroke stroke51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray55 = new java.awt.Stroke[] { stroke51, stroke52, stroke53, stroke54 };
        java.awt.Stroke[] strokeArray56 = new java.awt.Stroke[] {};
        java.awt.Shape shape57 = null;
        java.awt.Shape[] shapeArray58 = new java.awt.Shape[] { shape57 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier59 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray43, paintArray50, strokeArray55, strokeArray56, shapeArray58);
        boolean boolean60 = valueMarker38.equals((java.lang.Object) strokeArray56);
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot61.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        java.util.List list66 = null;
        xYPlot61.drawRangeTickBands(graphics2D64, rectangle2D65, list66);
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color69, stroke70);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent72 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker71);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = valueMarker71.getLabelAnchor();
        org.jfree.chart.util.Layer layer74 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean75 = xYPlot61.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker71, layer74);
        boolean boolean76 = categoryPlot34.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker38, layer74);
        java.awt.Font font77 = null;
        try {
            valueMarker38.setLabelFont(font77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paintArray50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(strokeArray55);
        org.junit.Assert.assertNotNull(strokeArray56);
        org.junit.Assert.assertNotNull(shapeArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(valueAxis63);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleAnchor73);
        org.junit.Assert.assertNotNull(layer74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str7 = seriesRenderingOrder6.toString();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        java.awt.Paint paint10 = null;
        try {
            xYPlot0.setQuadrantPaint(8, paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (8) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str7.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        xYSeries1.setMaximumItemCount((int) (byte) 100);
        xYSeries1.setNotify(true);
        boolean boolean14 = xYSeries1.getNotify();
        org.jfree.data.xy.XYDataItem xYDataItem17 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        xYDataItem17.setSelected(true);
        xYSeries1.add(xYDataItem17, false);
        boolean boolean22 = xYDataItem17.isSelected();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        periodAxis1.zoomRange(0.0d, 0.0d);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = range18.contains((double) (byte) 1);
        double double21 = range18.getLowerBound();
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean24 = range22.contains((double) (byte) 1);
        double double25 = range22.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range18, range22);
        org.jfree.data.Range range27 = rectangleConstraint26.getWidthRange();
        org.jfree.data.Range range29 = org.jfree.data.Range.expandToInclude(range27, (double) 10);
        periodAxis1.setRange(range27, true, false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range4, range8);
        periodAxis1.setRangeWithMargins(range8, true, false);
        boolean boolean16 = periodAxis1.isInverted();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        java.awt.Shape shape12 = legendItemEntity11.getArea();
        boolean boolean14 = legendItemEntity11.equals((java.lang.Object) 13);
        java.lang.String str15 = legendItemEntity11.toString();
        java.lang.String str16 = legendItemEntity11.toString();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str15.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str16.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("item", graphics2D1, (float) 2, (float) 5, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        boolean boolean6 = xYLineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        boolean boolean10 = piePlot3D9.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D9.getLegendLabelToolTipGenerator();
        double double12 = piePlot3D9.getStartAngle();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D9.setLabelBackgroundPaint((java.awt.Paint) color13);
        java.awt.Color color16 = java.awt.Color.black;
        piePlot3D9.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color16);
        xYLineAndShapeRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color16, false);
        xYLineAndShapeRenderer0.setDrawSeriesLineAsPath(true);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, 3.0d, (double) (short) 0);
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        java.lang.Object obj11 = null;
        boolean boolean12 = piePlot3D10.equals(obj11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) piePlot3D10, true);
        java.awt.Color color15 = java.awt.Color.PINK;
        jFreeChart14.setBorderPaint((java.awt.Paint) color15);
        java.awt.Paint paint17 = jFreeChart14.getBorderPaint();
        java.awt.Image image18 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart14, "{0}");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.lang.Object obj7 = null;
        boolean boolean8 = piePlot3D6.equals(obj7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) piePlot3D6, true);
        java.awt.Color color11 = java.awt.Color.PINK;
        jFreeChart10.setBorderPaint((java.awt.Paint) color11);
        multiplePiePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart10);
        java.lang.Comparable comparable14 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "Other" + "'", comparable14.equals("Other"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        intervalXYDelegate3.datasetChanged(datasetChangeEvent4);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1.0f));
        org.jfree.chart.block.Block block5 = null;
        columnArrangement4.add(block5, (java.lang.Object) 1L);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, dataset8, (java.lang.Comparable) 100.0d);
        legendItemBlockContainer10.setURLText("ClassContext");
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, 3.0d, (double) (short) 0);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color8, stroke9);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean15 = textBlockAnchor13.equals((java.lang.Object) rectangleAnchor14);
        valueMarker10.setLabelAnchor(rectangleAnchor14);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor14, (double) 0.0f, 0.08d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color5 = java.awt.Color.PINK;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color5, false);
        xYBarRenderer0.setShadowYOffset((double) 8);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYBarRenderer0.setSeriesStroke(7, stroke11, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        xYBarRenderer0.setBaseURLGenerator(xYURLGenerator14, false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean2 = periodAxis1.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = periodAxis1.getStandardTickUnits();
        periodAxis1.setLowerBound((double) 97L);
        java.lang.Class class6 = null;
        try {
            periodAxis1.setMajorTickTimePeriodClass(class6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(tickUnitSource3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawRangeTickBands(graphics2D3, rectangle2D4, list5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer8.getSeriesURLGenerator(1);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer8.setBaseOutlineStroke(stroke11);
        xYBarRenderer8.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint16 = xYBarRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean18 = xYBarRenderer8.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint20 = xYBarRenderer8.getSeriesItemLabelPaint(100);
        xYBarRenderer8.setBase(0.0d);
        boolean boolean24 = xYBarRenderer8.isSeriesVisibleInLegend(35);
        xYPlot0.setRenderer(2019, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYBarRenderer8.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor27 = itemLabelPosition26.getTextAnchor();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot2.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = null;
        java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        xYPlot2.panDomainAxes((double) (byte) 0, plotRenderingInfo6, point2D9);
        boolean boolean11 = xYPlot2.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot15.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        xYPlot15.panDomainAxes((double) (byte) 0, plotRenderingInfo19, point2D22);
        xYPlot2.zoomRangeAxes((double) 97L, (double) 100, plotRenderingInfo14, point2D22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot2.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot2.setFixedRangeAxisSpace(axisSpace26, false);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("ClassContext", font1, (org.jfree.chart.plot.Plot) xYPlot2, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot2.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot2.getRangeAxis();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(valueAxis32);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot14.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = null;
        java.awt.geom.Point2D point2D21 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D19, rectangleAnchor20);
        xYPlot14.panDomainAxes((double) (byte) 0, plotRenderingInfo18, point2D21);
        boolean boolean23 = xYPlot14.isDomainGridlinesVisible();
        java.awt.Stroke stroke24 = xYPlot14.getRangeGridlineStroke();
        piePlot3D8.setBaseSectionOutlineStroke(stroke24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        int int2 = xYLineAndShapeRenderer0.getPassCount();
        boolean boolean5 = xYLineAndShapeRenderer0.getItemShapeFilled((int) (byte) 10, 8);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries3.createCopy((int) 'a', (int) (byte) -1);
        xYSeries3.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries3.createCopy(10, 1);
        xYSeries3.clear();
        boolean boolean13 = tickUnits1.equals((java.lang.Object) xYSeries3);
        xYSeriesCollection0.removeSeries(xYSeries3);
        xYSeries3.add((double) 7, (double) 9223372036854775807L);
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) year15);
        java.lang.Number number18 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, number18);
        long long20 = year15.getFirstMillisecond();
        long long21 = year15.getSerialIndex();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        int int3 = xYSeriesCollection1.getSeriesCount();
        boolean boolean4 = standardPieSectionLabelGenerator0.equals((java.lang.Object) xYSeriesCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        boolean boolean13 = legendTitle11.equals((java.lang.Object) 175);
        double double14 = legendTitle11.getContentYOffset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D();
        double double16 = categoryAxis3D15.getLabelAngle();
        categoryAxis3D15.clearCategoryLabelToolTips();
        categoryAxis3D15.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str21 = categoryAxis3D15.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        org.jfree.chart.axis.AxisState axisState28 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D15.drawTickMarks(graphics2D22, (double) (byte) -1, rectangle2D24, rectangleEdge26, axisState28);
        legendTitle11.setLegendItemGraphicEdge(rectangleEdge26);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.util.ObjectList objectList33 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D();
        double double35 = categoryAxis3D34.getLabelAngle();
        categoryAxis3D34.clearCategoryLabelToolTips();
        categoryAxis3D34.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D();
        double double41 = categoryAxis3D40.getLabelAngle();
        categoryAxis3D40.clearCategoryLabelToolTips();
        categoryAxis3D40.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str46 = categoryAxis3D40.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge50);
        org.jfree.chart.axis.AxisState axisState53 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D40.drawTickMarks(graphics2D47, (double) (byte) -1, rectangle2D49, rectangleEdge51, axisState53);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer55 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator57 = xYBarRenderer55.getSeriesURLGenerator(1);
        java.awt.Stroke stroke58 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer55.setBaseOutlineStroke(stroke58);
        xYBarRenderer55.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer55.setBaseShape(shape64);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity66 = new org.jfree.chart.entity.LegendItemEntity(shape64);
        java.awt.Shape shape67 = legendItemEntity66.getArea();
        org.jfree.data.general.PieDataset pieDataset68 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D69 = new org.jfree.chart.plot.PiePlot3D(pieDataset68);
        boolean boolean70 = legendItemEntity66.equals((java.lang.Object) piePlot3D69);
        org.jfree.chart.entity.EntityCollection entityCollection71 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = new org.jfree.chart.ChartRenderingInfo(entityCollection71);
        java.awt.geom.Rectangle2D rectangle2D73 = chartRenderingInfo72.getChartArea();
        legendItemEntity66.setArea((java.awt.Shape) rectangle2D73);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D75 = new org.jfree.chart.axis.CategoryAxis3D();
        double double76 = categoryAxis3D75.getLabelAngle();
        categoryAxis3D75.clearCategoryLabelToolTips();
        categoryAxis3D75.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str81 = categoryAxis3D75.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D82 = null;
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge85);
        org.jfree.chart.axis.AxisState axisState88 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D75.drawTickMarks(graphics2D82, (double) (byte) -1, rectangle2D84, rectangleEdge86, axisState88);
        java.util.List list90 = categoryAxis3D34.refreshTicks(graphics2D39, axisState53, rectangle2D73, rectangleEdge86);
        boolean boolean91 = objectList33.equals((java.lang.Object) rectangle2D73);
        try {
            legendTitle11.draw(graphics2D31, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNull(xYURLGenerator57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertNotNull(list90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        periodAxis14.setAutoRange(false);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape3 = xYLineAndShapeRenderer0.getLegendLine();
        xYLineAndShapeRenderer0.setDrawSeriesLineAsPath(true);
        try {
            xYLineAndShapeRenderer0.setSeriesShapesFilled((-1), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-2208960000000L), 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.Object obj1 = null;
        boolean boolean2 = dateTickMarkPosition0.equals(obj1);
        java.lang.String str3 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str3.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle11.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1.0f));
        columnArrangement19.clear();
        blockContainer14.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement19);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.util.Size2D size2D23 = blockContainer14.arrange(graphics2D22);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(size2D23);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        xYSeries1.add((double) 35, (double) 'a', false);
        org.jfree.data.xy.XYDataItem xYDataItem8 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        xYDataItem8.setSelected(true);
        xYSeries1.add(xYDataItem8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries13.removeAgedItems((long) (-1), false);
        boolean boolean17 = xYDataItem8.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.setMaximumItemAge(0L);
        java.lang.Object obj7 = timeSeries1.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis9.setLowerBound((double) 10);
        java.util.TimeZone timeZone12 = periodAxis9.getTimeZone();
        periodAxis9.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean18 = range16.contains((double) (byte) 1);
        double double19 = range16.getLowerBound();
        periodAxis9.setRange(range16, false, false);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        periodAxis9.setLast((org.jfree.data.time.RegularTimePeriod) year23);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, number26);
        int int28 = year23.getYear();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 3492L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 1);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean2 = piePlot0.equals((java.lang.Object) categoryAxis3D1);
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        java.lang.Object obj12 = null;
        boolean boolean13 = piePlot3D11.equals(obj12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font9, (org.jfree.chart.plot.Plot) piePlot3D11, true);
        java.awt.Color color16 = java.awt.Color.PINK;
        jFreeChart15.setBorderPaint((java.awt.Paint) color16);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart15.getLegend(0);
        legendTitle19.setHeight((double) (byte) 100);
        legendTitle19.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        java.awt.geom.Rectangle2D rectangle2D29 = chartRenderingInfo28.getChartArea();
        legendTitle19.setBounds(rectangle2D29);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D32 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor31);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D();
        double double34 = categoryAxis3D33.getLabelAngle();
        categoryAxis3D33.clearCategoryLabelToolTips();
        categoryAxis3D33.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str39 = categoryAxis3D33.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge43);
        org.jfree.chart.axis.AxisState axisState46 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D33.drawTickMarks(graphics2D40, (double) (byte) -1, rectangle2D42, rectangleEdge44, axisState46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge44);
        double double49 = categoryAxis3D1.getCategorySeriesMiddle((int) (byte) 0, (int) (short) 1, 1, 7, 0.12d, rectangle2D29, rectangleEdge44);
        categoryAxis3D1.setCategoryMargin(0.4d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        piePlot3D8.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        java.awt.Shape shape8 = xYBarRenderer0.lookupLegendShape(10);
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        combinedRangeXYPlot0.setOutlineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = combinedRangeXYPlot0.getDomainAxis();
        java.util.List list5 = combinedRangeXYPlot0.getSubplots();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 1900, (double) 12);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean7 = range5.contains((double) (byte) 1);
        double double8 = range5.getLowerBound();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range9.contains((double) (byte) 1);
        double double12 = range9.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range5, range9);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toRangeHeight(range14);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean18 = range16.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint15.toRangeHeight(range16);
        java.lang.String str20 = range16.toString();
        boolean boolean22 = range16.contains((double) 100.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean24 = range16.equals((java.lang.Object) rectangleEdge23);
        boolean boolean25 = horizontalAlignment0.equals((java.lang.Object) rectangleEdge23);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Range[0.0,1.0]" + "'", str20.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        double double2 = timeSeries1.getMinY();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis4.setLowerBound((double) 10);
        java.util.TimeZone timeZone7 = periodAxis4.getTimeZone();
        periodAxis4.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range11.contains((double) (byte) 1);
        double double14 = range11.getLowerBound();
        periodAxis4.setRange(range11, false, false);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getSerialIndex();
        periodAxis4.setLast((org.jfree.data.time.RegularTimePeriod) year18);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, number21);
        java.lang.Number number23 = timeSeriesDataItem22.getValue();
        timeSeries1.add(timeSeriesDataItem22, true);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = xYBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        double double13 = categoryAxis3D12.getLabelAngle();
        categoryAxis3D12.clearCategoryLabelToolTips();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3D12.setTickLabelFont((java.lang.Comparable) '4', font16);
        xYBarRenderer0.setBaseItemLabelFont(font16);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator22 = xYLineAndShapeRenderer20.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape23 = xYLineAndShapeRenderer20.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot24.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = null;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor30);
        xYPlot24.panDomainAxes((double) (byte) 0, plotRenderingInfo28, point2D31);
        boolean boolean33 = xYPlot24.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D34 = xYPlot24.getQuadrantOrigin();
        int int35 = xYPlot24.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape23, (org.jfree.chart.plot.Plot) xYPlot24, "", "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot39.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = null;
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D44, rectangleAnchor45);
        xYPlot39.panDomainAxes((double) (byte) 0, plotRenderingInfo43, point2D46);
        boolean boolean48 = xYPlot39.isRangeZeroBaselineVisible();
        int int49 = xYPlot39.getDatasetCount();
        java.awt.Paint paint50 = xYPlot39.getBackgroundPaint();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean54 = periodAxis53.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource55 = periodAxis53.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis57.setLowerBound((double) 10);
        java.util.TimeZone timeZone60 = periodAxis57.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer61 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator63 = xYBarRenderer61.getSeriesURLGenerator(1);
        xYBarRenderer61.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition67 = null;
        xYBarRenderer61.setSeriesNegativeItemLabelPosition(2, itemLabelPosition67, false);
        xYBarRenderer61.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection51, (org.jfree.chart.axis.ValueAxis) periodAxis53, (org.jfree.chart.axis.ValueAxis) periodAxis57, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer61);
        boolean boolean72 = xYPlot71.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection73 = xYPlot71.getLegendItems();
        xYPlot39.setFixedLegendItems(legendItemCollection73);
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke78 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker79 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color77, stroke78);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent80 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker79);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent81 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker79);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor82 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor83 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean84 = textBlockAnchor82.equals((java.lang.Object) rectangleAnchor83);
        valueMarker79.setLabelAnchor(rectangleAnchor83);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer86 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator88 = xYBarRenderer86.getSeriesURLGenerator(1);
        java.awt.Color color89 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYBarRenderer86.setBaseFillPaint((java.awt.Paint) color89, false);
        valueMarker79.setPaint((java.awt.Paint) color89);
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean94 = xYPlot39.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker79, layer93);
        java.util.Collection collection95 = xYPlot24.getRangeMarkers(layer93);
        xYPlot24.setRangeCrosshairLockedOnData(true);
        java.awt.Stroke stroke98 = xYPlot24.getDomainGridlineStroke();
        xYBarRenderer0.setSeriesOutlineStroke(6, stroke98);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(xYItemLabelGenerator22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNull(tickUnitSource55);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(xYURLGenerator63);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(legendItemCollection73);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(textBlockAnchor82);
        org.junit.Assert.assertNotNull(rectangleAnchor83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(xYURLGenerator88);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNull(collection95);
        org.junit.Assert.assertNotNull(stroke98);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        legendTitle11.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        legendTitle11.setBounds(rectangle2D21);
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint24 = null;
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal(paint23, paint24);
        legendTitle11.setBackgroundPaint(paint24);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = null;
        xYLineAndShapeRenderer0.setSeriesItemLabelGenerator(100, xYItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesLinesVisible(2);
        org.jfree.chart.LegendItem legendItem7 = xYLineAndShapeRenderer0.getLegendItem((int) (byte) 1, 5);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) 0L);
        int int3 = dateTickUnit0.getMultiple();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline4.getBaseTimeline();
        java.util.Date date7 = segmentedTimeline5.getDate((long) 10);
        java.util.Date date8 = dateTickUnit0.rollDate(date7);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle11.getItemContainer();
        java.lang.Object obj15 = blockContainer14.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        xYBarRenderer10.setAutoPopulateSeriesShape(false);
        xYBarRenderer10.setMargin(90.0d);
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem27.setLine(shape30);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape30, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot36 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset35);
        org.jfree.chart.plot.Plot plot37 = multiplePiePlot36.getRootPlot();
        java.awt.Shape shape38 = multiplePiePlot36.getLegendItemShape();
        chartEntity34.setArea(shape38);
        xYBarRenderer10.setSeriesShape(6, shape38);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(plot37);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsExcludedSize();
        boolean boolean7 = segmentedTimeline3.containsDomainRange(0L, (long) (short) 1);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline3.getSegment((long) 'a');
        java.lang.Object obj10 = null;
        boolean boolean11 = segment9.equals(obj10);
        segment9.dec();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 97L + "'", long4 == 97L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(3492L, 8, 2147483647);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        int int6 = segmentedTimeline3.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getToolTipText();
        java.lang.Comparable comparable3 = legendItem1.getSeriesKey();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(comparable3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate15 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        int int16 = xYPlot0.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        try {
            int int19 = defaultXYDataset12.getItemCount(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis2.setLowerBound((double) 10);
        java.util.TimeZone timeZone5 = periodAxis2.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("", timeZone5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis8.getLabelInsets();
        double double12 = rectangleInsets10.calculateTopInset(0.5d);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        categoryPlot34.setDomainGridlinesVisible(false);
        boolean boolean38 = categoryPlot34.isRangeZoomable();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 10, itemLabelPosition16);
        java.awt.Shape shape18 = null;
        xYBarRenderer0.setBaseLegendShape(shape18);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        org.jfree.chart.util.SortOrder sortOrder2 = null;
        try {
            defaultKeyedValues0.sortByKeys(sortOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        numberFormat1.setGroupingUsed(true);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getIntegerInstance();
        numberFormat4.setGroupingUsed(true);
        int int7 = numberFormat4.getMaximumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SeriesRenderingOrder.FORWARD", numberFormat1, numberFormat4);
        java.text.DateFormat dateFormat9 = standardXYToolTipGenerator8.getYDateFormat();
        java.lang.String str10 = standardXYToolTipGenerator8.getFormatString();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNull(dateFormat9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str10.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot20.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer23.getSeriesURLGenerator(1);
        xYBarRenderer23.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        xYBarRenderer23.setSeriesNegativeItemLabelPosition(2, itemLabelPosition29, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = xYBarRenderer23.getSeriesURLGenerator(35);
        java.awt.Stroke stroke37 = xYBarRenderer23.getItemStroke((int) ' ', 0, false);
        xYPlot20.setDomainCrosshairStroke(stroke37);
        java.awt.Paint paint39 = xYPlot20.getBackgroundPaint();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection42 = xYPlot20.getDomainMarkers(2958465, layer41);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNull(xYURLGenerator33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, 3.0d, (double) (short) 0);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        java.lang.Object obj15 = null;
        boolean boolean16 = piePlot3D14.equals(obj15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) piePlot3D14, true);
        java.awt.Color color19 = java.awt.Color.PINK;
        jFreeChart18.setBorderPaint((java.awt.Paint) color19);
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart18.getLegend(0);
        legendTitle22.setHeight((double) (byte) 100);
        org.jfree.chart.entity.TitleEntity titleEntity26 = new org.jfree.chart.entity.TitleEntity(shape6, (org.jfree.chart.title.Title) legendTitle22, "13");
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color27, color28 };
        java.awt.Paint paint30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { paint30, paint31, color32, color33, color34, color35 };
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] { stroke37, stroke38, stroke39, stroke40 };
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = null;
        java.awt.Shape[] shapeArray44 = new java.awt.Shape[] { shape43 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray29, paintArray36, strokeArray41, strokeArray42, shapeArray44);
        java.awt.Paint paint46 = defaultDrawingSupplier45.getNextOutlinePaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator48 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator49 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer50 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator48, xYURLGenerator49);
        xYAreaRenderer50.setUseFillPaint(false);
        boolean boolean53 = xYAreaRenderer50.getUseFillPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis56 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double57 = periodAxis56.getUpperMargin();
        java.awt.Stroke stroke58 = periodAxis56.getMinorTickMarkStroke();
        xYAreaRenderer50.setSeriesOutlineStroke(100, stroke58);
        java.awt.Paint paint60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        java.awt.Paint paint61 = null;
        boolean boolean62 = org.jfree.chart.util.PaintUtilities.equal(paint60, paint61);
        try {
            org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem(attributedString0, "DatasetRenderingOrder.REVERSE", "Range[97.0,97.0]", "PlotEntity: tooltip = ", shape6, paint46, stroke58, paint60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shapeArray44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries3.createCopy((int) 'a', (int) (byte) -1);
        xYSeries3.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries3.createCopy(10, 1);
        xYSeries3.clear();
        boolean boolean13 = tickUnits1.equals((java.lang.Object) xYSeries3);
        xYSeriesCollection0.removeSeries(xYSeries3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean18 = periodAxis17.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = periodAxis17.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis21.setLowerBound((double) 10);
        java.util.TimeZone timeZone24 = periodAxis21.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer25.getSeriesURLGenerator(1);
        xYBarRenderer25.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        xYBarRenderer25.setSeriesNegativeItemLabelPosition(2, itemLabelPosition31, false);
        xYBarRenderer25.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection15, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.axis.ValueAxis) periodAxis21, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis37.setLowerBound((double) 10);
        java.util.TimeZone timeZone40 = periodAxis37.getTimeZone();
        periodAxis37.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range44 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean46 = range44.contains((double) (byte) 1);
        double double47 = range44.getLowerBound();
        periodAxis37.setRange(range44, false, false);
        periodAxis37.zoomRange(0.0d, 0.0d);
        double double54 = periodAxis37.getUpperMargin();
        periodAxis37.setVisible(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator58 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator59 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer60 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator58, xYURLGenerator59);
        xYAreaRenderer60.setUseFillPaint(false);
        xYAreaRenderer60.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.axis.ValueAxis) periodAxis37, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer60);
        periodAxis37.setUpperMargin(0.0d);
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        numberFormat1.setGroupingUsed(true);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getIntegerInstance();
        numberFormat4.setGroupingUsed(true);
        int int7 = numberFormat4.getMaximumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SeriesRenderingOrder.FORWARD", numberFormat1, numberFormat4);
        java.lang.String str9 = standardXYToolTipGenerator8.getNullYString();
        java.lang.String str10 = standardXYToolTipGenerator8.getFormatString();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment12, (double) (short) 100, (double) (-1.0f));
        boolean boolean16 = standardXYToolTipGenerator8.equals((java.lang.Object) columnArrangement15);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "null" + "'", str9.equals("null"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str10.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(verticalAlignment12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape5 = xYBarRenderer3.getSeriesShape((int) (byte) 1);
        xYBarRenderer3.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter10 = xYBarRenderer3.getBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter10);
        xYBarRenderer0.setBarPainter(xYBarPainter10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = xYBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(xYBarPainter10);
        org.junit.Assert.assertNull(xYToolTipGenerator13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = xYBarRenderer1.getSeriesURLGenerator(1);
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer1.setBaseOutlineStroke(stroke4);
        xYBarRenderer1.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint9 = xYBarRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, paint9, stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        valueMarker11.setOutlineStroke(stroke12);
        valueMarker11.setLabel("PieLabelLinkStyle.STANDARD");
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        boolean boolean18 = piePlot3D17.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot3D17.getLegendLabelToolTipGenerator();
        double double20 = piePlot3D17.getStartAngle();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D17.setLabelBackgroundPaint((java.awt.Paint) color21);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D(pieDataset23);
        boolean boolean25 = piePlot3D24.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = piePlot3D24.getLegendLabelToolTipGenerator();
        double double27 = piePlot3D24.getStartAngle();
        java.awt.Paint paint28 = piePlot3D24.getLabelPaint();
        piePlot3D17.setParent((org.jfree.chart.plot.Plot) piePlot3D24);
        org.jfree.chart.util.UnitType unitType30 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets(unitType30, (double) 100L, 100.0d, 0.0d, (double) 8);
        org.jfree.data.xy.XYSeries xYSeries37 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries40 = xYSeries37.createCopy((int) 'a', (int) (byte) -1);
        boolean boolean41 = rectangleInsets35.equals((java.lang.Object) 'a');
        piePlot3D24.setInsets(rectangleInsets35);
        boolean boolean43 = piePlot3D24.getAutoPopulateSectionOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot45 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset44);
        org.jfree.chart.JFreeChart jFreeChart46 = multiplePiePlot45.getPieChart();
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart46.setBorderPaint((java.awt.Paint) color47);
        piePlot3D24.setLabelShadowPaint((java.awt.Paint) color47);
        valueMarker11.setPaint((java.awt.Paint) color47);
        java.awt.Color color51 = java.awt.Color.WHITE;
        java.awt.Color color52 = java.awt.Color.cyan;
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray60 = new float[] { 97L, 'a', 60000L, 6, (short) 1, (byte) -1 };
        float[] floatArray61 = color53.getColorComponents(floatArray60);
        float[] floatArray62 = color52.getRGBColorComponents(floatArray61);
        float[] floatArray63 = color51.getComponents(floatArray61);
        float[] floatArray64 = color47.getColorComponents(floatArray61);
        org.junit.Assert.assertNull(xYURLGenerator3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 90.0d + "'", double20 == 90.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 90.0d + "'", double27 == 90.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(xYSeries40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jFreeChart46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        xYLineAndShapeRenderer0.setSeriesShapesFilled(0, true);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double2 = xYSeriesCollection0.getDomainLowerBound(false);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str2 = dateTickUnit0.valueToString((double) 0L);
        java.lang.String str4 = dateTickUnit0.valueToString((double) 10);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        java.lang.Object obj9 = null;
        boolean boolean10 = piePlot3D8.equals(obj9);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) piePlot3D8, true);
        java.awt.Color color13 = java.awt.Color.PINK;
        jFreeChart12.setBorderPaint((java.awt.Paint) color13);
        java.awt.Paint paint15 = jFreeChart12.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart12.getLegend(2958465);
        boolean boolean18 = dateTickUnit0.equals((java.lang.Object) jFreeChart12);
        java.lang.String str19 = dateTickUnit0.toString();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69 4:00 PM" + "'", str2.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "12/31/69 4:00 PM" + "'", str4.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str19.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "UnitType.ABSOLUTE", "Range[0.0,1.0]", image3, "{0}", "[size=1]", "Range[0.0,1.0]");
        projectInfo7.setLicenceName("");
        java.lang.String str10 = projectInfo7.getInfo();
        projectInfo7.setLicenceText("");
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Range[0.0,1.0]" + "'", str10.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis2.setLowerBound((double) 10);
        java.util.TimeZone timeZone5 = periodAxis2.getTimeZone();
        periodAxis2.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean11 = range9.contains((double) (byte) 1);
        double double12 = range9.getLowerBound();
        periodAxis2.setRange(range9, false, false);
        periodAxis2.zoomRange(0.0d, 0.0d);
        periodAxis2.setAxisLineVisible(true);
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend21 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) periodAxis2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        int int2 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-8355585) + "'", int2 == (-8355585));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot0.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot0.setDomainAxis(valueAxis12);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("WMAP_Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name WMAP_Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYBarRenderer39.getSeriesURLGenerator(1);
        xYBarRenderer39.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        xYBarRenderer39.setSeriesNegativeItemLabelPosition(2, itemLabelPosition45, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator49 = xYBarRenderer39.getSeriesURLGenerator(35);
        java.awt.Stroke stroke53 = xYBarRenderer39.getItemStroke((int) ' ', 0, false);
        intervalMarker38.setOutlineStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        java.awt.Color color56 = java.awt.Color.cyan;
        categoryPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color56);
        int int58 = categoryPlot34.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot34.setFixedDomainAxisSpace(axisSpace59, true);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertNull(xYURLGenerator49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.14d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("[size=1]");
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        org.jfree.data.DomainOrder domainOrder2 = defaultXYDataset0.getDomainOrder();
        java.lang.String str3 = domainOrder2.toString();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(domainOrder2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DomainOrder.NONE" + "'", str3.equals("DomainOrder.NONE"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = xYBarRenderer2.getSeriesURLGenerator(1);
        xYBarRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        xYBarRenderer2.setSeriesNegativeItemLabelPosition(2, itemLabelPosition8, false);
        boolean boolean11 = blockBorder1.equals((java.lang.Object) itemLabelPosition8);
        java.awt.Paint paint12 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(xYURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        java.lang.Object obj6 = intervalXYDelegate5.clone();
        try {
            double double9 = intervalXYDelegate5.getStartXValue(64, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 64, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.getSeriesItemLabelPaint((int) '#');
        java.lang.Boolean boolean5 = xYLineAndShapeRenderer0.getSeriesLinesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.updateCrosshairX(0.0d);
        crosshairState1.updateCrosshairY((double) (short) 0);
        int int6 = crosshairState1.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = null;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        xYPlot13.panDomainAxes((double) (byte) 0, plotRenderingInfo17, point2D20);
        xYPlot0.zoomRangeAxes((double) 97L, (double) 100, plotRenderingInfo12, point2D20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace24, false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot0.getDomainAxisForDataset(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 2147483647 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYLineAndShapeRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator2);
        java.text.NumberFormat numberFormat6 = java.text.NumberFormat.getIntegerInstance();
        numberFormat6.setGroupingUsed(true);
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getIntegerInstance();
        numberFormat9.setGroupingUsed(true);
        int int12 = numberFormat9.getMaximumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator13 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SeriesRenderingOrder.FORWARD", numberFormat6, numberFormat9);
        java.lang.String str14 = standardXYToolTipGenerator13.getNullYString();
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator13);
        java.lang.Object obj16 = standardXYToolTipGenerator13.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "null" + "'", str14.equals("null"));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(3492L, 8, 2147483647);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        java.lang.Class class6 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = segmentedTimeline7.getBaseTimeline();
        java.util.Date date10 = segmentedTimeline8.getDate((long) 10);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis12.setLowerBound((double) 10);
        java.util.TimeZone timeZone15 = periodAxis12.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone15;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone15;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone15);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment19 = segmentedTimeline3.getSegment(date10);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(segment19);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.updateCrosshairX(0.0d);
        int int4 = crosshairState1.getRangeAxisIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        timeSeries1.add(regularTimePeriod7, (java.lang.Number) 10L, true);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = regularTimePeriod7.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.setUseFillPaint(false);
        boolean boolean6 = xYAreaRenderer3.getPlotShapes();
        xYAreaRenderer3.setSeriesCreateEntities(2019, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = intervalMarker2.getLabelAnchor();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "", true);
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        java.lang.Object obj10 = null;
        boolean boolean11 = piePlot3D9.equals(obj10);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) piePlot3D9, true);
        java.awt.Color color14 = java.awt.Color.PINK;
        jFreeChart13.setBorderPaint((java.awt.Paint) color14);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart13.getLegend(0);
        rendererChangeEvent5.setChart(jFreeChart13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean23 = periodAxis22.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = periodAxis22.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis26.setLowerBound((double) 10);
        java.util.TimeZone timeZone29 = periodAxis26.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator32 = xYBarRenderer30.getSeriesURLGenerator(1);
        xYBarRenderer30.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        xYBarRenderer30.setSeriesNegativeItemLabelPosition(2, itemLabelPosition36, false);
        xYBarRenderer30.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection20, (org.jfree.chart.axis.ValueAxis) periodAxis22, (org.jfree.chart.axis.ValueAxis) periodAxis26, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer30);
        boolean boolean41 = chartChangeEventType19.equals((java.lang.Object) xYBarRenderer30);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) year1, jFreeChart13, chartChangeEventType19);
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis44.setLowerBound((double) 10);
        java.util.TimeZone timeZone47 = periodAxis44.getTimeZone();
        periodAxis44.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range51 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean53 = range51.contains((double) (byte) 1);
        double double54 = range51.getLowerBound();
        periodAxis44.setRange(range51, false, false);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        long long59 = year58.getSerialIndex();
        periodAxis44.setLast((org.jfree.data.time.RegularTimePeriod) year58);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries62.removeAgedItems((long) (-1), false);
        timeSeries62.setMaximumItemAge(0L);
        java.lang.Object obj68 = timeSeries62.clone();
        boolean boolean69 = timeSeries62.isEmpty();
        org.jfree.chart.axis.PeriodAxis periodAxis72 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis72.setLowerBound((double) 10);
        java.util.TimeZone timeZone75 = periodAxis72.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone75;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone75;
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("", timeZone75);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection79 = new org.jfree.data.time.TimeSeriesCollection(timeSeries62, timeZone75);
        java.util.Locale locale80 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis81 = new org.jfree.chart.axis.PeriodAxis("org.jfree.data.general.SeriesChangeEvent[source=0.0]", (org.jfree.data.time.RegularTimePeriod) year1, (org.jfree.data.time.RegularTimePeriod) year58, timeZone75, locale80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(legendTitle17);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(tickUnitSource24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(xYURLGenerator32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2019L + "'", long59 == 2019L);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(timeZone75);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot34.setRangeZeroBaselinePaint(paint36);
        categoryPlot34.setRangeCrosshairValue(0.08d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        double double42 = categoryAxis3D41.getLabelAngle();
        int int43 = categoryAxis3D41.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D(pieDataset44);
        boolean boolean46 = piePlot3D45.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot3D45.getLegendLabelToolTipGenerator();
        double double48 = piePlot3D45.getStartAngle();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D45.setLabelBackgroundPaint((java.awt.Paint) color49);
        categoryAxis3D41.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D45);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D41.setTickLabelFont(font52);
        categoryAxis3D41.setLabel("Range[0.0,1.0]");
        categoryPlot34.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, false);
        int int58 = categoryPlot34.getRangeAxisCount();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 90.0d + "'", double48 == 90.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("[6.0, NaN]", "", "Range[97.0,97.0]", "item", "SeriesRenderingOrder.FORWARD");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) defaultKeyedValues0);
        java.lang.Number number3 = defaultPieDataset1.getValue(0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long8 = segmentedTimeline7.getSegmentsExcludedSize();
        boolean boolean11 = segmentedTimeline7.containsDomainRange(0L, (long) (short) 1);
        long long13 = segmentedTimeline7.getTimeFromLong(60000L);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean16 = range14.contains((double) (byte) 1);
        double double17 = range14.getLowerBound();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = range18.contains((double) (byte) 1);
        double double21 = range18.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range14, range18);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toRangeHeight(range23);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(range23);
        java.util.Date date26 = dateRange25.getUpperDate();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        segmentedTimeline7.addException(date26);
        defaultPieDataset1.setValue((java.lang.Comparable) date26, (java.lang.Number) 1.0E-8d);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 60000L + "'", long13 == 60000L);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setDomainDescription("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        try {
            java.lang.Number number8 = timeSeriesCollection5.getStartX((-8355585), 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.LegendItem legendItem10 = xYBarRenderer0.getLegendItem((int) (short) 0, (int) ' ');
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        java.awt.Font font13 = xYBarRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint14 = xYBarRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(xYBarPainter7);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("item", graphics2D1, 0.0f, (float) (byte) 1, Double.NaN, (float) 2958465, (float) 52L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            double double6 = defaultXYDataset0.getYValue((int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        int int4 = defaultXYDataset0.indexOf((java.lang.Comparable) "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart2.setBorderPaint((java.awt.Paint) color3);
        org.jfree.chart.title.TextTitle textTitle5 = jFreeChart2.getTitle();
        java.awt.Paint paint6 = jFreeChart2.getBackgroundPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        try {
            jFreeChart2.plotChanged(plotChangeEvent7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textTitle5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double6 = range5.getLength();
        boolean boolean7 = logFormat4.equals((java.lang.Object) double6);
        org.jfree.chart.util.LogFormat logFormat13 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer15 = null;
        java.text.FieldPosition fieldPosition16 = null;
        java.lang.StringBuffer stringBuffer17 = logFormat13.format((long) '#', stringBuffer15, fieldPosition16);
        java.text.FieldPosition fieldPosition18 = null;
        java.lang.StringBuffer stringBuffer19 = logFormat4.format(0L, stringBuffer15, fieldPosition18);
        java.lang.StringBuffer stringBuffer21 = null;
        java.text.FieldPosition fieldPosition22 = null;
        java.lang.StringBuffer stringBuffer23 = logFormat4.format((long) (byte) 100, stringBuffer21, fieldPosition22);
        org.jfree.chart.util.LogFormat logFormat29 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double31 = range30.getLength();
        boolean boolean32 = logFormat29.equals((java.lang.Object) double31);
        org.jfree.chart.util.LogFormat logFormat38 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer40 = null;
        java.text.FieldPosition fieldPosition41 = null;
        java.lang.StringBuffer stringBuffer42 = logFormat38.format((long) '#', stringBuffer40, fieldPosition41);
        java.text.FieldPosition fieldPosition43 = null;
        java.lang.StringBuffer stringBuffer44 = logFormat29.format(0L, stringBuffer40, fieldPosition43);
        java.text.FieldPosition fieldPosition45 = null;
        java.lang.StringBuffer stringBuffer46 = logFormat4.format((long) 4, stringBuffer40, fieldPosition45);
        org.jfree.chart.util.LogFormat logFormat52 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer54 = null;
        java.text.FieldPosition fieldPosition55 = null;
        java.lang.StringBuffer stringBuffer56 = logFormat52.format((long) '#', stringBuffer54, fieldPosition55);
        java.text.FieldPosition fieldPosition57 = null;
        java.lang.StringBuffer stringBuffer58 = logFormat4.format((long) (-133), stringBuffer56, fieldPosition57);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stringBuffer17);
        org.junit.Assert.assertNotNull(stringBuffer19);
        org.junit.Assert.assertNotNull(stringBuffer23);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stringBuffer42);
        org.junit.Assert.assertNotNull(stringBuffer44);
        org.junit.Assert.assertNotNull(stringBuffer46);
        org.junit.Assert.assertNotNull(stringBuffer56);
        org.junit.Assert.assertNotNull(stringBuffer58);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.data.Range range35 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset7);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.RenderingSource renderingSource2 = null;
        chartRenderingInfo1.setRenderingSource(renderingSource2);
        chartRenderingInfo1.clear();
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues7 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj8 = defaultKeyedValues7.clone();
        defaultKeyedValues7.setValue((java.lang.Comparable) 97.0d, 0.0d);
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) day4, (org.jfree.data.KeyedValues) defaultKeyedValues7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(true, true);
        double double5 = piePlot3D1.getLabelGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot3D1.removeChangeListener(plotChangeListener6);
        double double8 = piePlot3D1.getDepthFactor();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator10, xYURLGenerator11);
        xYAreaRenderer12.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot16.getRangeAxis((int) '#');
        xYPlot16.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = xYPlot16.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder22 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str23 = seriesRenderingOrder22.toString();
        xYPlot16.setSeriesRenderingOrder(seriesRenderingOrder22);
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        java.awt.Font font28 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D(pieDataset29);
        java.lang.Object obj31 = null;
        boolean boolean32 = piePlot3D30.equals(obj31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("", font28, (org.jfree.chart.plot.Plot) piePlot3D30, true);
        java.awt.Color color35 = java.awt.Color.PINK;
        jFreeChart34.setBorderPaint((java.awt.Paint) color35);
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart34.getLegend(0);
        legendTitle38.setHeight((double) (byte) 100);
        legendTitle38.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo(entityCollection46);
        java.awt.geom.Rectangle2D rectangle2D48 = chartRenderingInfo47.getChartArea();
        legendTitle38.setBounds(rectangle2D48);
        org.jfree.data.general.PieDataset pieDataset51 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D(pieDataset51);
        boolean boolean53 = piePlot3D52.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator54 = piePlot3D52.getLegendLabelToolTipGenerator();
        double double55 = piePlot3D52.getStartAngle();
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D52.setLabelBackgroundPaint((java.awt.Paint) color56);
        java.awt.Color color59 = java.awt.Color.black;
        piePlot3D52.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color59);
        piePlot3D52.setIgnoreNullValues(true);
        java.awt.Paint paint63 = piePlot3D52.getLabelOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot65 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset64);
        org.jfree.chart.JFreeChart jFreeChart66 = multiplePiePlot65.getPieChart();
        java.awt.Stroke stroke67 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart66.setBorderStroke(stroke67);
        xYAreaRenderer12.drawDomainLine(graphics2D15, xYPlot16, (org.jfree.chart.axis.ValueAxis) periodAxis26, rectangle2D48, (double) 10L, paint63, stroke67);
        piePlot3D1.setBaseSectionOutlinePaint(paint63);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.12d + "'", double8 == 0.12d);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(seriesRenderingOrder22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str23.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(legendTitle38);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(jFreeChart66);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairValue(Double.NaN, false);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        combinedDomainXYPlot0.remove(xYPlot4);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot17.getRangeAxis((int) '#');
        xYPlot17.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        xYPlot17.setDomainAxis((int) '4', valueAxis23, true);
        org.jfree.chart.axis.AxisSpace axisSpace26 = xYPlot17.getFixedDomainAxisSpace();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D();
        double double29 = categoryAxis3D28.getLabelAngle();
        categoryAxis3D28.clearCategoryLabelToolTips();
        categoryAxis3D28.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D();
        double double35 = categoryAxis3D34.getLabelAngle();
        categoryAxis3D34.clearCategoryLabelToolTips();
        categoryAxis3D34.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str40 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge44);
        org.jfree.chart.axis.AxisState axisState47 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D34.drawTickMarks(graphics2D41, (double) (byte) -1, rectangle2D43, rectangleEdge45, axisState47);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator51 = xYBarRenderer49.getSeriesURLGenerator(1);
        java.awt.Stroke stroke52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer49.setBaseOutlineStroke(stroke52);
        xYBarRenderer49.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer49.setBaseShape(shape58);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity60 = new org.jfree.chart.entity.LegendItemEntity(shape58);
        java.awt.Shape shape61 = legendItemEntity60.getArea();
        org.jfree.data.general.PieDataset pieDataset62 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D63 = new org.jfree.chart.plot.PiePlot3D(pieDataset62);
        boolean boolean64 = legendItemEntity60.equals((java.lang.Object) piePlot3D63);
        org.jfree.chart.entity.EntityCollection entityCollection65 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo(entityCollection65);
        java.awt.geom.Rectangle2D rectangle2D67 = chartRenderingInfo66.getChartArea();
        legendItemEntity60.setArea((java.awt.Shape) rectangle2D67);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D69 = new org.jfree.chart.axis.CategoryAxis3D();
        double double70 = categoryAxis3D69.getLabelAngle();
        categoryAxis3D69.clearCategoryLabelToolTips();
        categoryAxis3D69.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str75 = categoryAxis3D69.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D76 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge79);
        org.jfree.chart.axis.AxisState axisState82 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D69.drawTickMarks(graphics2D76, (double) (byte) -1, rectangle2D78, rectangleEdge80, axisState82);
        java.util.List list84 = categoryAxis3D28.refreshTicks(graphics2D33, axisState47, rectangle2D67, rectangleEdge80);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        xYPlot17.drawAnnotations(graphics2D27, rectangle2D67, plotRenderingInfo85);
        combinedDomainXYPlot0.remove(xYPlot17);
        org.jfree.chart.plot.XYPlot xYPlot88 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis90 = xYPlot88.getRangeAxis((int) '#');
        xYPlot88.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection93 = xYPlot88.getFixedLegendItems();
        combinedDomainXYPlot0.add(xYPlot88, 36);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNull(xYURLGenerator51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(list84);
        org.junit.Assert.assertNull(valueAxis90);
        org.junit.Assert.assertNull(legendItemCollection93);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis8.setLowerBound((double) 10);
        java.util.TimeZone timeZone11 = periodAxis8.getTimeZone();
        boolean boolean12 = periodAxis8.isTickLabelsVisible();
        boolean boolean13 = periodAxis8.isNegativeArrowVisible();
        xYPlot0.setRangeAxis(1900, (org.jfree.chart.axis.ValueAxis) periodAxis8, false);
        org.jfree.chart.plot.Plot plot16 = periodAxis8.getPlot();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("April");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        double double4 = piePlot3D1.getExplodePercent((java.lang.Comparable) "");
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray13, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray16);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset17, false);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset17, false);
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange(range21);
        periodAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange22, false, false);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        periodAxis6.setAxisLineStroke(stroke26);
        piePlot3D1.setLabelOutlineStroke(stroke26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color0, color1 };
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { paint3, paint4, color5, color6, color7, color8 };
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13 };
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = null;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] { shape16 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, strokeArray14, strokeArray15, shapeArray17);
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextOutlinePaint();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean22 = periodAxis21.isAxisLineVisible();
        periodAxis21.setAutoRangeMinimumSize((double) 2, true);
        java.awt.Stroke stroke26 = periodAxis21.getMinorTickMarkStroke();
        boolean boolean27 = defaultDrawingSupplier18.equals((java.lang.Object) periodAxis21);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator9, xYURLGenerator10);
        xYAreaRenderer11.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot15.getRangeAxis((int) '#');
        xYPlot15.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot15.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder21 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str22 = seriesRenderingOrder21.toString();
        xYPlot15.setSeriesRenderingOrder(seriesRenderingOrder21);
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        java.awt.Font font27 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D(pieDataset28);
        java.lang.Object obj30 = null;
        boolean boolean31 = piePlot3D29.equals(obj30);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("", font27, (org.jfree.chart.plot.Plot) piePlot3D29, true);
        java.awt.Color color34 = java.awt.Color.PINK;
        jFreeChart33.setBorderPaint((java.awt.Paint) color34);
        org.jfree.chart.title.LegendTitle legendTitle37 = jFreeChart33.getLegend(0);
        legendTitle37.setHeight((double) (byte) 100);
        legendTitle37.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo(entityCollection45);
        java.awt.geom.Rectangle2D rectangle2D47 = chartRenderingInfo46.getChartArea();
        legendTitle37.setBounds(rectangle2D47);
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D51 = new org.jfree.chart.plot.PiePlot3D(pieDataset50);
        boolean boolean52 = piePlot3D51.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator53 = piePlot3D51.getLegendLabelToolTipGenerator();
        double double54 = piePlot3D51.getStartAngle();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D51.setLabelBackgroundPaint((java.awt.Paint) color55);
        java.awt.Color color58 = java.awt.Color.black;
        piePlot3D51.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color58);
        piePlot3D51.setIgnoreNullValues(true);
        java.awt.Paint paint62 = piePlot3D51.getLabelOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot64 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset63);
        org.jfree.chart.JFreeChart jFreeChart65 = multiplePiePlot64.getPieChart();
        java.awt.Stroke stroke66 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart65.setBorderStroke(stroke66);
        xYAreaRenderer11.drawDomainLine(graphics2D14, xYPlot15, (org.jfree.chart.axis.ValueAxis) periodAxis25, rectangle2D47, (double) 10L, paint62, stroke66);
        periodAxis1.setUpArrow((java.awt.Shape) rectangle2D47);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(seriesRenderingOrder21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str22.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(legendTitle37);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 90.0d + "'", double54 == 90.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(jFreeChart65);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.add(0.0d, (double) 10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        xYSeries1.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertNotNull(xYSeries4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getOuterSeparatorExtension();
        ringPlot0.setNoDataMessage("April");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot34.setRangeZeroBaselinePaint(paint36);
        categoryPlot34.setRangeCrosshairValue(0.08d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        double double42 = categoryAxis3D41.getLabelAngle();
        int int43 = categoryAxis3D41.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D(pieDataset44);
        boolean boolean46 = piePlot3D45.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot3D45.getLegendLabelToolTipGenerator();
        double double48 = piePlot3D45.getStartAngle();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D45.setLabelBackgroundPaint((java.awt.Paint) color49);
        categoryAxis3D41.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D45);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D41.setTickLabelFont(font52);
        categoryAxis3D41.setLabel("Range[0.0,1.0]");
        categoryPlot34.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, false);
        java.awt.Stroke stroke58 = categoryPlot34.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 90.0d + "'", double48 == 90.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean2 = piePlot0.equals((java.lang.Object) categoryAxis3D1);
        double double3 = piePlot0.getShadowYOffset();
        java.awt.Paint paint4 = piePlot0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot3.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = null;
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor9);
        xYPlot3.panDomainAxes((double) (byte) 0, plotRenderingInfo7, point2D10);
        boolean boolean12 = xYPlot3.isRangeZeroBaselineVisible();
        int int13 = xYPlot3.getDatasetCount();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = xYBarRenderer15.getSeriesURLGenerator(1);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer15.setBaseOutlineStroke(stroke18);
        xYBarRenderer15.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint23 = xYBarRenderer15.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, paint23, stroke24);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean27 = xYPlot3.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker25, layer26);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker25);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(xYURLGenerator17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot2.getPieChart();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart3.setBorderStroke(stroke4);
        boolean boolean6 = paintMap0.equals((java.lang.Object) jFreeChart3);
        java.lang.Object obj7 = jFreeChart3.clone();
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        java.awt.Paint paint6 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder7 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean10 = periodAxis9.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = periodAxis9.getStandardTickUnits();
        periodAxis9.setLowerBound((double) 97L);
        periodAxis9.setMinorTickCount(100);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        periodAxis9.setStandardTickUnits(tickUnitSource17);
        java.lang.String str19 = periodAxis9.getLabel();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DomainOrder.DESCENDING" + "'", str19.equals("DomainOrder.DESCENDING"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        double double2 = categoryAxis3D1.getLabelAngle();
        categoryAxis3D1.clearCategoryLabelToolTips();
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D();
        double double8 = categoryAxis3D7.getLabelAngle();
        categoryAxis3D7.clearCategoryLabelToolTips();
        categoryAxis3D7.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str13 = categoryAxis3D7.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.axis.AxisState axisState20 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D7.drawTickMarks(graphics2D14, (double) (byte) -1, rectangle2D16, rectangleEdge18, axisState20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer22.getSeriesURLGenerator(1);
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer22.setBaseOutlineStroke(stroke25);
        xYBarRenderer22.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer22.setBaseShape(shape31);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity(shape31);
        java.awt.Shape shape34 = legendItemEntity33.getArea();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D(pieDataset35);
        boolean boolean37 = legendItemEntity33.equals((java.lang.Object) piePlot3D36);
        org.jfree.chart.entity.EntityCollection entityCollection38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo(entityCollection38);
        java.awt.geom.Rectangle2D rectangle2D40 = chartRenderingInfo39.getChartArea();
        legendItemEntity33.setArea((java.awt.Shape) rectangle2D40);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        double double43 = categoryAxis3D42.getLabelAngle();
        categoryAxis3D42.clearCategoryLabelToolTips();
        categoryAxis3D42.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str48 = categoryAxis3D42.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
        org.jfree.chart.axis.AxisState axisState55 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D42.drawTickMarks(graphics2D49, (double) (byte) -1, rectangle2D51, rectangleEdge53, axisState55);
        java.util.List list57 = categoryAxis3D1.refreshTicks(graphics2D6, axisState20, rectangle2D40, rectangleEdge53);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets0.createOutsetRectangle(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = null;
        try {
            piePlot3D1.setLabelDistributor(abstractPieLabelDistributor14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        org.jfree.chart.plot.Plot plot5 = periodAxis1.getPlot();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        java.awt.Color color9 = java.awt.Color.PINK;
        jFreeChart8.setBorderPaint((java.awt.Paint) color9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart8.getLegend(0);
        legendTitle12.setHeight((double) (byte) 100);
        legendTitle12.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle12.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment20, (double) 1.0f, (double) 1L);
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement23);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(verticalAlignment20);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment3, (double) (short) 100, (double) (-1.0f));
        org.jfree.chart.block.Block block7 = null;
        columnArrangement6.add(block7, (java.lang.Object) 1L);
        boolean boolean10 = gradientPaintTransformType1.equals((java.lang.Object) columnArrangement6);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset11 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset11);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement6, (org.jfree.data.general.Dataset) defaultXYDataset11, (java.lang.Comparable) Double.NaN);
        legendItemBlockContainer14.clear();
        java.lang.Comparable comparable16 = legendItemBlockContainer14.getSeriesKey();
        java.awt.geom.Rectangle2D rectangle2D17 = legendItemBlockContainer14.getBounds();
        org.jfree.chart.block.Arrangement arrangement18 = legendItemBlockContainer14.getArrangement();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertEquals((double) comparable16, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(arrangement18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        double double1 = xYStepAreaRenderer0.getRangeBase();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            double double3 = xYSeriesCollection0.getStartYValue(12, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYBarRenderer39.getSeriesURLGenerator(1);
        xYBarRenderer39.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        xYBarRenderer39.setSeriesNegativeItemLabelPosition(2, itemLabelPosition45, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator49 = xYBarRenderer39.getSeriesURLGenerator(35);
        java.awt.Stroke stroke53 = xYBarRenderer39.getItemStroke((int) ' ', 0, false);
        intervalMarker38.setOutlineStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        java.awt.Color color56 = java.awt.Color.cyan;
        categoryPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color56);
        int int58 = categoryPlot34.getWeight();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot34.setRangeCrosshairStroke(stroke59);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertNull(xYURLGenerator49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        int int4 = segmentedTimeline3.getSegmentsIncluded();
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(date5);
        long long7 = segmentedTimeline3.getSegmentsGroupSize();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3492L + "'", long7 == 3492L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        double double5 = periodAxis1.getUpperMargin();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean12 = piePlot10.equals((java.lang.Object) categoryAxis3D11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.jfree.chart.plot.Plot plot17 = multiplePiePlot16.getRootPlot();
        java.awt.Paint paint18 = plot17.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint18);
        categoryAxis3D11.setTickMarkPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 3492L, (double) 3, 0.0d, paint18);
        periodAxis1.setLabelPaint(paint18);
        java.awt.Paint paint23 = periodAxis1.getMinorTickMarkPaint();
        double double24 = periodAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        double double19 = piePlot3D8.getShadowXOffset();
        org.jfree.chart.util.Rotation rotation20 = piePlot3D8.getDirection();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis22.setLowerBound((double) 10);
        java.util.TimeZone timeZone25 = periodAxis22.getTimeZone();
        periodAxis22.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean31 = range29.contains((double) (byte) 1);
        double double32 = range29.getLowerBound();
        periodAxis22.setRange(range29, false, false);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getSerialIndex();
        periodAxis22.setLast((org.jfree.data.time.RegularTimePeriod) year36);
        java.lang.Number number39 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, number39);
        java.lang.Number number41 = timeSeriesDataItem40.getValue();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray44 = new java.awt.Paint[] { color42, color43 };
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { paint45, paint46, color47, color48, color49, color50 };
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray56 = new java.awt.Stroke[] { stroke52, stroke53, stroke54, stroke55 };
        java.awt.Stroke[] strokeArray57 = new java.awt.Stroke[] {};
        java.awt.Shape shape58 = null;
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] { shape58 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray44, paintArray51, strokeArray56, strokeArray57, shapeArray59);
        java.awt.Paint paint61 = defaultDrawingSupplier60.getNextPaint();
        piePlot3D8.setSectionOutlinePaint((java.lang.Comparable) timeSeriesDataItem40, paint61);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent63 = null;
        piePlot3D8.datasetChanged(datasetChangeEvent63);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paintArray44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray56);
        org.junit.Assert.assertNotNull(strokeArray57);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.black;
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color8);
        piePlot3D1.setIgnoreNullValues(true);
        piePlot3D1.setPieIndex(15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState1.updateCrosshairX(0.0d);
        crosshairState1.updateCrosshairY((double) (short) 0);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        xYPlot12.panDomainAxes((double) (byte) 0, plotRenderingInfo16, point2D19);
        boolean boolean21 = xYPlot12.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D22 = xYPlot12.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot12.getOrientation();
        crosshairState1.updateCrosshairPoint((-5.76E7d), (double) 9223372036854775807L, (int) 'a', (int) ' ', (double) 0, (double) (-1.0f), plotOrientation23);
        crosshairState1.setAnchorY((double) 15);
        int int27 = crosshairState1.getRangeAxisIndex();
        double double28 = crosshairState1.getCrosshairY();
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            barRenderer3D2.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(3492L, 8, 2147483647);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long10 = segmentedTimeline9.getStartTime();
        java.util.List list11 = segmentedTimeline9.getExceptionSegments();
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline.getSegmentSize() is smaller than segmentSize");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot1.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D6, rectangleAnchor7);
        xYPlot1.panDomainAxes((double) (byte) 0, plotRenderingInfo5, point2D8);
        int int10 = month0.compareTo((java.lang.Object) plotRenderingInfo5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month0.next();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis2.setLowerBound((double) 10);
        java.util.TimeZone timeZone5 = periodAxis2.getTimeZone();
        boolean boolean6 = periodAxis2.isVerticalTickLabels();
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend7 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) periodAxis2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        int int10 = xYSeries9.getMaximumItemCount();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesLinesVisible(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot6.getRootPlot();
        java.awt.Shape shape8 = multiplePiePlot6.getLegendItemShape();
        xYLineAndShapeRenderer0.setLegendLine(shape8);
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis11.setLowerBound((double) 10);
        java.util.TimeZone timeZone14 = periodAxis11.getTimeZone();
        periodAxis11.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = range18.contains((double) (byte) 1);
        double double21 = range18.getLowerBound();
        periodAxis11.setRange(range18, false, false);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        periodAxis11.setLast((org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.chart.entity.AxisEntity axisEntity28 = new org.jfree.chart.entity.AxisEntity(shape8, (org.jfree.chart.axis.Axis) periodAxis11);
        org.jfree.chart.axis.Axis axis29 = axisEntity28.getAxis();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertNotNull(axis29);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double2 = xYSeriesCollection0.getDomainLowerBound(false);
        xYSeriesCollection0.removeAllSeries();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = multiplePiePlot1.getInsets();
        org.jfree.chart.util.TableOrder tableOrder4 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(tableOrder4);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        try {
            double double12 = xYSeriesCollection3.getStartYValue(2, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYBarRenderer12.getSeriesURLGenerator(1);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer12.setBaseOutlineStroke(stroke15);
        xYBarRenderer12.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint20 = xYBarRenderer12.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, paint20, stroke21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.text.TextAnchor textAnchor25 = valueMarker22.getLabelTextAnchor();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(textAnchor25);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.lang.String str7 = color5.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str7.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        java.lang.Object obj2 = defaultXYDataset0.clone();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMinorTickMarkOutsideLength(0.0f);
        double double5 = categoryAxis3D0.getLowerMargin();
        double double6 = categoryAxis3D0.getCategoryMargin();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor12);
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray17, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset21, false);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis28.setLowerBound((double) 10);
        java.util.TimeZone timeZone31 = periodAxis28.getTimeZone();
        periodAxis28.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean37 = range35.contains((double) (byte) 1);
        double double38 = range35.getLowerBound();
        periodAxis28.setRange(range35, false, false);
        periodAxis28.zoomRange(0.0d, 0.0d);
        periodAxis28.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis26, (org.jfree.chart.axis.ValueAxis) periodAxis28, categoryItemRenderer47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot48.getDomainAxisEdge();
        try {
            double double50 = categoryAxis3D0.getCategoryMiddle(255, (int) (short) 1, rectangle2D11, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 255");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean5 = xYLineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        xYLineAndShapeRenderer0.setSeriesLinesVisible(1, (java.lang.Boolean) false);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot10.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot10.drawRangeTickBands(graphics2D13, rectangle2D14, list15);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = xYBarRenderer18.getSeriesURLGenerator(1);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer18.setBaseOutlineStroke(stroke21);
        xYBarRenderer18.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint26 = xYBarRenderer18.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean28 = xYBarRenderer18.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint30 = xYBarRenderer18.getSeriesItemLabelPaint(100);
        xYBarRenderer18.setBase(0.0d);
        boolean boolean34 = xYBarRenderer18.isSeriesVisibleInLegend(35);
        xYPlot10.setRenderer(2019, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = xYBarRenderer18.getBasePositiveItemLabelPosition();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = xYBarRenderer37.getSeriesURLGenerator(1);
        java.awt.Stroke stroke40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer37.setBaseOutlineStroke(stroke40);
        xYBarRenderer37.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint45 = xYBarRenderer37.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean47 = xYBarRenderer37.isSeriesItemLabelsVisible(100);
        double double48 = xYBarRenderer37.getBarAlignmentFactor();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder50 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color49);
        xYBarRenderer37.setBasePaint((java.awt.Paint) color49, false);
        boolean boolean53 = itemLabelPosition36.equals((java.lang.Object) xYBarRenderer37);
        xYLineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition36);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(xYURLGenerator20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNull(xYURLGenerator39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-1.0d) + "'", double48 == (-1.0d));
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.setFixedDimension((double) 0);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot4);
        boolean boolean17 = xYPlot4.isDomainZoomable();
        java.awt.Stroke stroke18 = null;
        try {
            xYPlot4.setDomainMinorGridlineStroke(stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries14 = xYSeries11.createCopy((int) 'a', (int) (byte) -1);
        xYSeriesCollection3.addSeries(xYSeries14);
        try {
            double double18 = xYSeriesCollection3.getStartYValue((int) (short) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(xYSeries14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape2 = xYLineAndShapeRenderer1.getLegendLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        double double5 = xYSeriesCollection3.getDomainLowerBound(false);
        org.jfree.chart.entity.XYItemEntity xYItemEntity10 = new org.jfree.chart.entity.XYItemEntity(shape2, (org.jfree.data.xy.XYDataset) xYSeriesCollection3, 9, 0, "ClassContext", "TextAnchor.TOP_LEFT");
        double double12 = xYSeriesCollection3.getRangeUpperBound(true);
        try {
            java.lang.String str15 = standardXYToolTipGenerator0.generateLabelString((org.jfree.data.xy.XYDataset) xYSeriesCollection3, (int) (short) 1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("Other");
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) (-5.76E7d), false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getDescription();
        java.awt.Font font3 = legendItem1.getLabelFont();
        java.lang.String str4 = legendItem1.getLabel();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str4.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        long long9 = segmentedTimeline3.getExceptionSegmentCount(97L, (long) (short) 0);
        segmentedTimeline3.setStartTime((long) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long16 = segmentedTimeline15.getStartTime();
        int int17 = segmentedTimeline15.getGroupSegmentCount();
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline is not aligned");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 36 + "'", int17 == 36);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        xYSeriesCollection0.setAutoWidth(true);
        try {
            double double6 = xYSeriesCollection0.getStartXValue((int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint3 = piePlot3D1.getBaseSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getSectionOutlineStroke((java.lang.Comparable) 60000L);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = xYLineAndShapeRenderer6.getSeriesItemLabelGenerator(2958465);
        boolean boolean12 = xYLineAndShapeRenderer6.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D(pieDataset14);
        boolean boolean16 = piePlot3D15.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot3D15.getLegendLabelToolTipGenerator();
        double double18 = piePlot3D15.getStartAngle();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D15.setLabelBackgroundPaint((java.awt.Paint) color19);
        java.awt.Color color22 = java.awt.Color.black;
        piePlot3D15.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color22);
        xYLineAndShapeRenderer6.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color22, false);
        piePlot3D1.setShadowPaint((java.awt.Paint) color22);
        java.awt.Font font28 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D(pieDataset29);
        java.lang.Object obj31 = null;
        boolean boolean32 = piePlot3D30.equals(obj31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("", font28, (org.jfree.chart.plot.Plot) piePlot3D30, true);
        java.awt.Color color35 = java.awt.Color.PINK;
        jFreeChart34.setBorderPaint((java.awt.Paint) color35);
        java.awt.Paint paint37 = jFreeChart34.getBorderPaint();
        piePlot3D1.setNoDataMessagePaint(paint37);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(xYItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 90.0d + "'", double18 == 90.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("PlotOrientation.VERTICAL", graphics2D1, 0.0f, (float) (byte) -1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            double double3 = timeSeriesCollection0.getXValue(4, 175);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        double double5 = periodAxis1.getUpperMargin();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean12 = piePlot10.equals((java.lang.Object) categoryAxis3D11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.jfree.chart.plot.Plot plot17 = multiplePiePlot16.getRootPlot();
        java.awt.Paint paint18 = plot17.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint18);
        categoryAxis3D11.setTickMarkPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 3492L, (double) 3, 0.0d, paint18);
        periodAxis1.setLabelPaint(paint18);
        java.awt.Paint paint23 = periodAxis1.getMinorTickMarkPaint();
        java.awt.Font font24 = periodAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        java.lang.String str35 = categoryPlot34.getPlotType();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        xYSeries1.setMaximumItemCount((int) (byte) 100);
        xYSeries1.setNotify(false);
        int int14 = xYSeries1.getItemCount();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.Plot plot2 = multiplePiePlot1.getRootPlot();
        java.awt.Shape shape3 = multiplePiePlot1.getLegendItemShape();
        org.jfree.chart.title.Title title4 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity5 = new org.jfree.chart.entity.TitleEntity(shape3, title4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape) rectangle2D2);
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getSeriesURLGenerator(35);
        java.awt.Stroke stroke14 = xYBarRenderer0.getItemStroke((int) ' ', 0, false);
        xYBarRenderer0.setBaseSeriesVisible(true, false);
        xYBarRenderer0.setItemLabelAnchorOffset(10.0d);
        java.awt.Font font21 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYBarRenderer0.setSeriesItemLabelFont((int) (byte) 10, font21, false);
        java.awt.Stroke stroke24 = xYBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape27 = xYBarRenderer25.getSeriesShape((int) (byte) 1);
        xYBarRenderer25.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = xYBarRenderer25.getURLGenerator((int) (byte) 10, (int) (short) 0, true);
        java.awt.Font font37 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D(pieDataset38);
        java.lang.Object obj40 = null;
        boolean boolean41 = piePlot3D39.equals(obj40);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", font37, (org.jfree.chart.plot.Plot) piePlot3D39, true);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent46 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart43, (int) (byte) 100, (int) (byte) 0);
        boolean boolean47 = jFreeChart43.isNotify();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D49 = new org.jfree.chart.plot.PiePlot3D(pieDataset48);
        boolean boolean50 = piePlot3D49.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator51 = piePlot3D49.getLegendLabelToolTipGenerator();
        double double52 = piePlot3D49.getStartAngle();
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D49.setLabelBackgroundPaint((java.awt.Paint) color53);
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D56 = new org.jfree.chart.plot.PiePlot3D(pieDataset55);
        boolean boolean57 = piePlot3D56.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator58 = piePlot3D56.getLegendLabelToolTipGenerator();
        double double59 = piePlot3D56.getStartAngle();
        java.awt.Paint paint60 = piePlot3D56.getLabelPaint();
        piePlot3D49.setParent((org.jfree.chart.plot.Plot) piePlot3D56);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator62 = null;
        piePlot3D56.setToolTipGenerator(pieToolTipGenerator62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D56.setInsets(rectangleInsets64, true);
        double double67 = piePlot3D56.getShadowXOffset();
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        piePlot3D56.addChangeListener(plotChangeListener68);
        double double70 = piePlot3D56.getInteriorGap();
        java.awt.Paint paint71 = piePlot3D56.getLabelLinkPaint();
        jFreeChart43.setBorderPaint(paint71);
        xYBarRenderer0.setBaseFillPaint(paint71, false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(shape27);
        org.junit.Assert.assertNull(xYURLGenerator35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 90.0d + "'", double52 == 90.0d);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 90.0d + "'", double59 == 90.0d);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 4.0d + "'", double67 == 4.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.08d + "'", double70 == 0.08d);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(true, true);
        double double5 = piePlot3D1.getLabelGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot3D1.removeChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot3D1.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.jfree.data.xy.XYDataItem xYDataItem12 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        xYDataItem12.setSelected(true);
        java.lang.Number number15 = xYDataItem12.getY();
        java.awt.Paint paint16 = null;
        piePlot3D1.setSectionPaint((java.lang.Comparable) xYDataItem12, paint16);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertEquals((double) number15, Double.NaN, 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        boolean boolean6 = xYLineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        xYLineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(3, itemLabelPosition8, true);
        xYLineAndShapeRenderer0.setUseOutlinePaint(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator(0, xYURLGenerator14, false);
        java.awt.Shape shape17 = xYLineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = xYBarRenderer18.getSeriesURLGenerator(1);
        xYBarRenderer18.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        xYBarRenderer18.setSeriesNegativeItemLabelPosition(2, itemLabelPosition24, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYBarRenderer18.getSeriesURLGenerator(35);
        java.awt.Stroke stroke32 = xYBarRenderer18.getItemStroke((int) ' ', 0, false);
        xYBarRenderer18.setBaseSeriesVisible(true, false);
        xYBarRenderer18.setItemLabelAnchorOffset(10.0d);
        java.awt.Font font39 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYBarRenderer18.setSeriesItemLabelFont((int) (byte) 10, font39, false);
        java.awt.Stroke stroke42 = xYBarRenderer18.getBaseOutlineStroke();
        xYLineAndShapeRenderer0.setBaseStroke(stroke42, true);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNull(xYURLGenerator20);
        org.junit.Assert.assertNull(xYURLGenerator28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.lang.Object obj3 = chartRenderingInfo2.clone();
        boolean boolean4 = tickType0.equals((java.lang.Object) chartRenderingInfo2);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getTimePeriod(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint2 = textFragment1.getPaint();
        float float3 = textFragment1.getBaselineOffset();
        java.lang.String str4 = textFragment1.getText();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        java.awt.Paint paint11 = xYPlot0.getBackgroundPaint();
        xYPlot0.clearDomainMarkers();
        boolean boolean13 = xYPlot0.isRangePannable();
        boolean boolean14 = xYPlot0.isDomainMinorGridlinesVisible();
        boolean boolean15 = xYPlot0.isDomainZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot0.getRenderer();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot34.setRangeZeroBaselinePaint(paint36);
        categoryPlot34.setRangeCrosshairValue(0.08d);
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("Range[0.0,1.0]");
        int int42 = categoryPlot34.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis41);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        java.awt.Paint paint6 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYBarRenderer0.setSeriesOutlineStroke(2019, stroke8, true);
        java.lang.Boolean boolean12 = xYBarRenderer0.getSeriesItemLabelsVisible((int) '#');
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getDescription();
        java.awt.Font font3 = legendItem1.getLabelFont();
        java.lang.String str4 = legendItem1.getDescription();
        legendItem1.setToolTipText("java.awt.Color[r=0,g=0,b=0]");
        java.lang.Object obj7 = legendItem1.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesLinesVisible(2);
        boolean boolean7 = xYLineAndShapeRenderer0.getItemShapeVisible((int) (short) 100, 255);
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend2 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, valueAxis1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        legendTitle11.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = legendTitle11.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = null;
        try {
            legendTitle11.setPadding(rectangleInsets20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(verticalAlignment19);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis2.setLowerBound((double) 10);
        java.util.TimeZone timeZone5 = periodAxis2.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("", timeZone5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        int int10 = dateTickUnit9.getMinorTickCount();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot1.getRangeAxis((int) '#');
        xYPlot1.setRangeCrosshairVisible(true);
        xYPlot1.clearRangeAxes();
        java.awt.Paint paint7 = xYPlot1.getDomainTickBandPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot1.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder8);
        boolean boolean10 = xYPlot0.isSubplot();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 3, true, false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        categoryPlot34.setDomainGridlinesVisible(false);
        java.awt.Paint paint38 = categoryPlot34.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace39 = categoryPlot34.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(axisSpace39);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        categoryAxis3D6.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str12 = categoryAxis3D6.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        org.jfree.chart.axis.AxisState axisState19 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D6.drawTickMarks(graphics2D13, (double) (byte) -1, rectangle2D15, rectangleEdge17, axisState19);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYBarRenderer21.getSeriesURLGenerator(1);
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer21.setBaseOutlineStroke(stroke24);
        xYBarRenderer21.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer21.setBaseShape(shape30);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity32 = new org.jfree.chart.entity.LegendItemEntity(shape30);
        java.awt.Shape shape33 = legendItemEntity32.getArea();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        boolean boolean36 = legendItemEntity32.equals((java.lang.Object) piePlot3D35);
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        java.awt.geom.Rectangle2D rectangle2D39 = chartRenderingInfo38.getChartArea();
        legendItemEntity32.setArea((java.awt.Shape) rectangle2D39);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        double double42 = categoryAxis3D41.getLabelAngle();
        categoryAxis3D41.clearCategoryLabelToolTips();
        categoryAxis3D41.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str47 = categoryAxis3D41.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge51);
        org.jfree.chart.axis.AxisState axisState54 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D41.drawTickMarks(graphics2D48, (double) (byte) -1, rectangle2D50, rectangleEdge52, axisState54);
        java.util.List list56 = categoryAxis3D0.refreshTicks(graphics2D5, axisState19, rectangle2D39, rectangleEdge52);
        axisState19.setMax(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(xYURLGenerator23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(list56);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        double[] doubleArray5 = new double[] { 8.0d, (short) 10, 31 };
        double[] doubleArray9 = new double[] { 8.0d, (short) 10, 31 };
        double[] doubleArray13 = new double[] { 8.0d, (short) 10, 31 };
        double[] doubleArray17 = new double[] { 8.0d, (short) 10, 31 };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray0, (java.lang.Comparable[]) strArray1, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        double double3 = piePlot3D1.getStartAngle();
        piePlot3D1.setShadowXOffset((double) 13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((-5.76E7d));
        double double3 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries2.removeAgedItems((long) (-1), false);
        double double6 = timeSeries2.getMaxY();
        int int7 = timeSeriesCollection0.indexOf(timeSeries2);
        double double9 = timeSeriesCollection0.getDomainUpperBound(false);
        int int10 = timeSeriesCollection0.getSeriesCount();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawRangeTickBands(graphics2D3, rectangle2D4, list5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer8.getSeriesURLGenerator(1);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer8.setBaseOutlineStroke(stroke11);
        xYBarRenderer8.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint16 = xYBarRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean18 = xYBarRenderer8.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint20 = xYBarRenderer8.getSeriesItemLabelPaint(100);
        xYBarRenderer8.setBase(0.0d);
        boolean boolean24 = xYBarRenderer8.isSeriesVisibleInLegend(35);
        xYPlot0.setRenderer(2019, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYBarRenderer8.getBasePositiveItemLabelPosition();
        boolean boolean27 = xYBarRenderer8.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape4, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot10.getRootPlot();
        java.awt.Shape shape12 = multiplePiePlot10.getLegendItemShape();
        chartEntity8.setArea(shape12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke17);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity21 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart16, "java.awt.Color[r=255,g=0,b=0]", "hi!");
        java.lang.String str22 = jFreeChartEntity21.getShapeCoords();
        java.lang.String str23 = jFreeChartEntity21.getURLText();
        java.lang.Object obj24 = jFreeChartEntity21.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str22.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        piePlot3D8.zoom((double) 3492L);
        double double21 = piePlot3D8.getLabelGap();
        java.awt.Stroke stroke23 = null;
        piePlot3D8.setSectionOutlineStroke((java.lang.Comparable) 0.0f, stroke23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.025d + "'", double21 == 0.025d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        objectList1.set(0, (java.lang.Object) valueMarker6);
        java.lang.Object obj10 = null;
        boolean boolean11 = valueMarker6.equals(obj10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart2.setBorderStroke(stroke3);
        jFreeChart2.fireChartChanged();
        java.awt.Paint paint6 = jFreeChart2.getBorderPaint();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot7.drawRangeTickBands(graphics2D10, rectangle2D11, list12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color15, stroke16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = xYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker17, layer20);
        org.jfree.chart.text.TextAnchor textAnchor22 = valueMarker17.getLabelTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraintType.RANGE", graphics2D1, (float) (short) 10, (float) 15, textAnchor4, (double) 9, textAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str5.equals("TextAnchor.TOP_LEFT"));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot20.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer23.getSeriesURLGenerator(1);
        xYBarRenderer23.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        xYBarRenderer23.setSeriesNegativeItemLabelPosition(2, itemLabelPosition29, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = xYBarRenderer23.getSeriesURLGenerator(35);
        java.awt.Stroke stroke37 = xYBarRenderer23.getItemStroke((int) ' ', 0, false);
        xYPlot20.setDomainCrosshairStroke(stroke37);
        java.awt.Paint paint39 = xYPlot20.getBackgroundPaint();
        java.awt.Font font41 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D(pieDataset42);
        java.lang.Object obj44 = null;
        boolean boolean45 = piePlot3D43.equals(obj44);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("", font41, (org.jfree.chart.plot.Plot) piePlot3D43, true);
        xYPlot20.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart47);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNull(xYURLGenerator33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D();
        double double3 = categoryAxis3D2.getLabelAngle();
        categoryAxis3D2.clearCategoryLabelToolTips();
        categoryAxis3D2.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D();
        double double9 = categoryAxis3D8.getLabelAngle();
        categoryAxis3D8.clearCategoryLabelToolTips();
        categoryAxis3D8.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str14 = categoryAxis3D8.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge18);
        org.jfree.chart.axis.AxisState axisState21 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D8.drawTickMarks(graphics2D15, (double) (byte) -1, rectangle2D17, rectangleEdge19, axisState21);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer23.getSeriesURLGenerator(1);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer23.setBaseOutlineStroke(stroke26);
        xYBarRenderer23.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer23.setBaseShape(shape32);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity34 = new org.jfree.chart.entity.LegendItemEntity(shape32);
        java.awt.Shape shape35 = legendItemEntity34.getArea();
        org.jfree.data.general.PieDataset pieDataset36 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D(pieDataset36);
        boolean boolean38 = legendItemEntity34.equals((java.lang.Object) piePlot3D37);
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo(entityCollection39);
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo40.getChartArea();
        legendItemEntity34.setArea((java.awt.Shape) rectangle2D41);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D43 = new org.jfree.chart.axis.CategoryAxis3D();
        double double44 = categoryAxis3D43.getLabelAngle();
        categoryAxis3D43.clearCategoryLabelToolTips();
        categoryAxis3D43.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str49 = categoryAxis3D43.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        org.jfree.chart.axis.AxisState axisState56 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D43.drawTickMarks(graphics2D50, (double) (byte) -1, rectangle2D52, rectangleEdge54, axisState56);
        java.util.List list58 = categoryAxis3D2.refreshTicks(graphics2D7, axisState21, rectangle2D41, rectangleEdge54);
        boolean boolean59 = objectList1.equals((java.lang.Object) rectangle2D41);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D41, rectangleEdge60);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Color color10 = java.awt.Color.black;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color10);
        xYPlot0.clearDomainMarkers((int) (byte) 0);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace14);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        legendTitle11.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle11.getLegendItemGraphicPadding();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle11.arrange(graphics2D20);
        boolean boolean22 = legendTitle11.isVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.removeAgedItems((long) (-1), false);
        timeSeries1.setMaximumItemAge(0L);
        java.lang.Object obj7 = timeSeries1.clone();
        boolean boolean8 = timeSeries1.isEmpty();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis11.setLowerBound((double) 10);
        java.util.TimeZone timeZone14 = periodAxis11.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone14;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone14;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("", timeZone14);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1, timeZone14);
        try {
            java.lang.Number number21 = timeSeriesCollection18.getY((int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("DomainOrder.DESCENDING", font2);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!");
        textLine9.addFragment(textFragment11);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = piePlot3D4.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D4.getLegendLabelToolTipGenerator();
        double double7 = piePlot3D4.getStartAngle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D4.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D4);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D0.setTickLabelFont(font11);
        java.lang.Object obj13 = categoryAxis3D0.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long18 = segmentedTimeline17.getSegmentsGroupSize();
        segmentedTimeline17.setAdjustForDaylightSaving(false);
        long long23 = segmentedTimeline17.getExceptionSegmentCount(97L, (long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment25 = segmentedTimeline17.getSegment((long) '4');
        segment25.dec();
        segment25.inc();
        boolean boolean28 = segment25.inExcludeSegments();
        java.awt.Font font29 = categoryAxis3D0.getTickLabelFont((java.lang.Comparable) boolean28);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3492L + "'", long18 == 3492L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(segment25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        boolean boolean8 = rectangleEdge5.equals((java.lang.Object) tickUnitSource7);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        double double10 = categoryAxis3D9.getLabelAngle();
        categoryAxis3D9.clearCategoryLabelToolTips();
        categoryAxis3D9.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str15 = categoryAxis3D9.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge19);
        org.jfree.chart.axis.AxisState axisState22 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D9.drawTickMarks(graphics2D16, (double) (byte) -1, rectangle2D18, rectangleEdge20, axisState22);
        categoryAxis3D0.drawTickMarks(graphics2D2, 1.0E-5d, rectangle2D4, rectangleEdge5, axisState22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        periodAxis1.zoomRange(0.0d, 0.0d);
        double double18 = periodAxis1.getUpperMargin();
        periodAxis1.setVisible(true);
        periodAxis1.setMinorTickMarkOutsideLength((float) (short) 1);
        java.awt.Shape shape23 = periodAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("DomainOrder.DESCENDING", font2);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textFragment10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        combinedRangeXYPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = xYPlot4.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint12 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        xYBarRenderer0.setBase(0.0d);
        boolean boolean16 = xYBarRenderer0.isSeriesVisibleInLegend(35);
        boolean boolean20 = xYBarRenderer0.isItemLabelVisible((-8355585), (int) (short) -1, false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = xYBarRenderer12.getSeriesURLGenerator(1);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer12.setBaseOutlineStroke(stroke15);
        xYBarRenderer12.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint20 = xYBarRenderer12.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, paint20, stroke21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean24 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer23);
        xYPlot0.clearSelection();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(xYURLGenerator14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = piePlot3D4.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D4.getLegendLabelToolTipGenerator();
        double double7 = piePlot3D4.getStartAngle();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D4.setLabelBackgroundPaint((java.awt.Paint) color8);
        categoryAxis3D0.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D4);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D0.setTickLabelFont(font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis3D0.getTickLabelInsets();
        double double15 = rectangleInsets13.calculateRightOutset((double) 60000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        boolean boolean3 = intervalXYDelegate2.isAutoWidth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            double double6 = intervalXYDelegate3.getStartXValue(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getURLGenerator((int) (byte) 10, (int) (short) 0, true);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        java.lang.Object obj15 = null;
        boolean boolean16 = piePlot3D14.equals(obj15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) piePlot3D14, true);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart18, (int) (byte) 100, (int) (byte) 0);
        boolean boolean22 = jFreeChart18.isNotify();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D(pieDataset23);
        boolean boolean25 = piePlot3D24.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = piePlot3D24.getLegendLabelToolTipGenerator();
        double double27 = piePlot3D24.getStartAngle();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D24.setLabelBackgroundPaint((java.awt.Paint) color28);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D(pieDataset30);
        boolean boolean32 = piePlot3D31.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator33 = piePlot3D31.getLegendLabelToolTipGenerator();
        double double34 = piePlot3D31.getStartAngle();
        java.awt.Paint paint35 = piePlot3D31.getLabelPaint();
        piePlot3D24.setParent((org.jfree.chart.plot.Plot) piePlot3D31);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator37 = null;
        piePlot3D31.setToolTipGenerator(pieToolTipGenerator37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D31.setInsets(rectangleInsets39, true);
        double double42 = piePlot3D31.getShadowXOffset();
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        piePlot3D31.addChangeListener(plotChangeListener43);
        double double45 = piePlot3D31.getInteriorGap();
        java.awt.Paint paint46 = piePlot3D31.getLabelLinkPaint();
        jFreeChart18.setBorderPaint(paint46);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset48);
        org.jfree.chart.JFreeChart jFreeChart50 = multiplePiePlot49.getPieChart();
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart50.setBorderPaint((java.awt.Paint) color51);
        int int53 = color51.getBlue();
        java.awt.color.ColorSpace colorSpace54 = color51.getColorSpace();
        jFreeChart18.setBackgroundPaint((java.awt.Paint) color51);
        float float56 = jFreeChart18.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 90.0d + "'", double27 == 90.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 90.0d + "'", double34 == 90.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.08d + "'", double45 == 0.08d);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(jFreeChart50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 64 + "'", int53 == 64);
        org.junit.Assert.assertNotNull(colorSpace54);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.5f + "'", float56 == 0.5f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYBarRenderer39.getSeriesURLGenerator(1);
        xYBarRenderer39.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        xYBarRenderer39.setSeriesNegativeItemLabelPosition(2, itemLabelPosition45, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator49 = xYBarRenderer39.getSeriesURLGenerator(35);
        java.awt.Stroke stroke53 = xYBarRenderer39.getItemStroke((int) ' ', 0, false);
        intervalMarker38.setOutlineStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        java.awt.Color color56 = java.awt.Color.cyan;
        categoryPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color56);
        int int58 = categoryPlot34.getWeight();
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray65 = new java.lang.Number[][] { numberArray62, numberArray64 };
        org.jfree.data.category.CategoryDataset categoryDataset66 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray65);
        org.jfree.data.Range range68 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset66, false);
        int int69 = categoryPlot34.indexOf(categoryDataset66);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertNull(xYURLGenerator49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(categoryDataset66);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        java.lang.Object obj4 = piePlot3D1.clone();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        boolean boolean7 = piePlot3D6.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3D6.getLegendLabelToolTipGenerator();
        double double9 = piePlot3D6.getStartAngle();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D6.setLabelBackgroundPaint((java.awt.Paint) color10);
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color10);
        int int13 = piePlot3D1.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.0d + "'", double9 == 90.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer3.setBaseOutlineStroke(stroke6);
        xYBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint11 = xYBarRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = xYBarRenderer3.getBaseFillPaint();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) paint12);
        barRenderer3D2.removeAnnotations();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer3D2.setSeriesURLGenerator(8, categoryURLGenerator16);
        double double18 = barRenderer3D2.getUpperClip();
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        xYBarRenderer0.setSeriesItemLabelsVisible((int) (short) 100, (java.lang.Boolean) true, false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYBarRenderer11.getSeriesURLGenerator(1);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer11.setBaseOutlineStroke(stroke14);
        xYBarRenderer11.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint19 = xYBarRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, paint19, stroke20);
        xYBarRenderer0.setSeriesOutlineStroke(0, stroke20);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 100, xYToolTipGenerator1, xYURLGenerator2);
        xYStepAreaRenderer3.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean8 = xYStepAreaRenderer3.isSeriesVisible(9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3D6.setTickLabelFont((java.lang.Comparable) '4', font10);
        boolean boolean12 = piePlot3D1.equals((java.lang.Object) categoryAxis3D6);
        boolean boolean13 = piePlot3D1.getDarkerSides();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str6 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D0.drawTickMarks(graphics2D7, (double) (byte) -1, rectangle2D9, rectangleEdge11, axisState13);
        double double15 = axisState13.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray4, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset8, false);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis15.setLowerBound((double) 10);
        java.util.TimeZone timeZone18 = periodAxis15.getTimeZone();
        periodAxis15.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean24 = range22.contains((double) (byte) 1);
        double double25 = range22.getLowerBound();
        periodAxis15.setRange(range22, false, false);
        periodAxis15.zoomRange(0.0d, 0.0d);
        periodAxis15.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis13, (org.jfree.chart.axis.ValueAxis) periodAxis15, categoryItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot35.getDomainAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer40 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator42 = xYBarRenderer40.getSeriesURLGenerator(1);
        xYBarRenderer40.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = null;
        xYBarRenderer40.setSeriesNegativeItemLabelPosition(2, itemLabelPosition46, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = xYBarRenderer40.getSeriesURLGenerator(35);
        java.awt.Stroke stroke54 = xYBarRenderer40.getItemStroke((int) ' ', 0, false);
        intervalMarker39.setOutlineStroke(stroke54);
        categoryPlot35.setDomainGridlineStroke(stroke54);
        java.awt.Color color57 = java.awt.Color.cyan;
        categoryPlot35.setRangeZeroBaselinePaint((java.awt.Paint) color57);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color57);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(xYURLGenerator42);
        org.junit.Assert.assertNull(xYURLGenerator50);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawRangeTickBands(graphics2D3, rectangle2D4, list5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer8.getSeriesURLGenerator(1);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer8.setBaseOutlineStroke(stroke11);
        xYBarRenderer8.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint16 = xYBarRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean18 = xYBarRenderer8.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint20 = xYBarRenderer8.getSeriesItemLabelPaint(100);
        xYBarRenderer8.setBase(0.0d);
        boolean boolean24 = xYBarRenderer8.isSeriesVisibleInLegend(35);
        xYPlot0.setRenderer(2019, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer8);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D(pieDataset27);
        boolean boolean29 = piePlot3D28.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator30 = piePlot3D28.getLegendLabelToolTipGenerator();
        double double31 = piePlot3D28.getStartAngle();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D28.setLabelBackgroundPaint((java.awt.Paint) color32);
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        boolean boolean36 = piePlot3D35.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator37 = piePlot3D35.getLegendLabelToolTipGenerator();
        double double38 = piePlot3D35.getStartAngle();
        java.awt.Paint paint39 = piePlot3D35.getLabelPaint();
        piePlot3D28.setParent((org.jfree.chart.plot.Plot) piePlot3D35);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator41 = null;
        piePlot3D35.setToolTipGenerator(pieToolTipGenerator41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D35.setInsets(rectangleInsets43, true);
        java.awt.Paint paint46 = piePlot3D35.getLabelShadowPaint();
        java.awt.Paint paint47 = piePlot3D35.getShadowPaint();
        xYBarRenderer8.setLegendTextPaint(1900, paint47);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 90.0d + "'", double31 == 90.0d);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator9, true);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot13.getRangeAxis((int) '#');
        xYPlot13.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot13.getFixedLegendItems();
        java.awt.Stroke stroke19 = xYPlot13.getDomainMinorGridlineStroke();
        xYBarRenderer0.setSeriesStroke(13, stroke19, true);
        java.awt.Paint paint23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        xYBarRenderer0.setSeriesFillPaint(255, paint23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape27 = xYLineAndShapeRenderer26.getLegendLine();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection28 = new org.jfree.data.xy.XYSeriesCollection();
        double double30 = xYSeriesCollection28.getDomainLowerBound(false);
        org.jfree.chart.entity.XYItemEntity xYItemEntity35 = new org.jfree.chart.entity.XYItemEntity(shape27, (org.jfree.data.xy.XYDataset) xYSeriesCollection28, 9, 0, "ClassContext", "TextAnchor.TOP_LEFT");
        xYBarRenderer0.setLegendShape((int) (byte) 0, shape27);
        java.util.Collection collection37 = xYBarRenderer0.getAnnotations();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection37);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test451");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("DomainOrder.NONE", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getInnerSeparatorExtension();
        boolean boolean2 = ringPlot0.getAutoPopulateSectionPaint();
        java.awt.Color color3 = java.awt.Color.cyan;
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color3);
        java.awt.Stroke stroke5 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        long long9 = segmentedTimeline3.getExceptionSegmentCount(97L, (long) (short) 0);
        long long11 = segmentedTimeline3.toTimelineValue((long) 3);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline3.getSegment((long) 'a');
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3L + "'", long11 == 3L);
        org.junit.Assert.assertNotNull(segment13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, (double) (byte) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str4 = lengthAdjustmentType3.toString();
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CONTRACT" + "'", str4.equals("CONTRACT"));
        org.junit.Assert.assertNull(gradientPaintTransformer6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setDomainDescription("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        categoryAxis3D6.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        double double13 = categoryAxis3D12.getLabelAngle();
        categoryAxis3D12.clearCategoryLabelToolTips();
        categoryAxis3D12.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str18 = categoryAxis3D12.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D12.drawTickMarks(graphics2D19, (double) (byte) -1, rectangle2D21, rectangleEdge23, axisState25);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = xYBarRenderer27.getSeriesURLGenerator(1);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer27.setBaseOutlineStroke(stroke30);
        xYBarRenderer27.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer27.setBaseShape(shape36);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity(shape36);
        java.awt.Shape shape39 = legendItemEntity38.getArea();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D(pieDataset40);
        boolean boolean42 = legendItemEntity38.equals((java.lang.Object) piePlot3D41);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.geom.Rectangle2D rectangle2D45 = chartRenderingInfo44.getChartArea();
        legendItemEntity38.setArea((java.awt.Shape) rectangle2D45);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D();
        double double48 = categoryAxis3D47.getLabelAngle();
        categoryAxis3D47.clearCategoryLabelToolTips();
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str53 = categoryAxis3D47.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge57);
        org.jfree.chart.axis.AxisState axisState60 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D47.drawTickMarks(graphics2D54, (double) (byte) -1, rectangle2D56, rectangleEdge58, axisState60);
        java.util.List list62 = categoryAxis3D6.refreshTicks(graphics2D11, axisState25, rectangle2D45, rectangleEdge58);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean65 = range63.contains((double) (byte) 1);
        double double66 = range63.getLowerBound();
        org.jfree.data.Range range67 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean69 = range67.contains((double) (byte) 1);
        double double70 = range67.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = new org.jfree.chart.block.RectangleConstraint(range63, range67);
        org.jfree.data.Range range72 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint73 = rectangleConstraint71.toRangeHeight(range72);
        org.jfree.data.time.DateRange dateRange74 = new org.jfree.data.time.DateRange(range72);
        long long75 = dateRange74.getUpperMillis();
        org.jfree.data.Range range78 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange74, 4.0d, false);
        org.jfree.data.Range range80 = timeSeriesCollection5.getRangeBounds(list62, range78, true);
        try {
            java.lang.Number number83 = timeSeriesCollection5.getStartY((int) 'a', 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(xYURLGenerator29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(rectangleConstraint73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1L + "'", long75 == 1L);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNull(range80);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        java.lang.Object obj6 = intervalXYDelegate5.clone();
        double double7 = intervalXYDelegate5.getFixedIntervalWidth();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        valueMarker3.setLabel("13");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot3D8.getSectionOutlinePaint((java.lang.Comparable) 4);
        valueMarker3.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot3D8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getBaseShapesVisible();
        xYLineAndShapeRenderer1.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean6 = xYLineAndShapeRenderer1.getAutoPopulateSeriesStroke();
        xYLineAndShapeRenderer1.setSeriesLinesVisible(1, (java.lang.Boolean) false);
        boolean boolean10 = itemLabelAnchor0.equals((java.lang.Object) xYLineAndShapeRenderer1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getDescription();
        java.awt.Font font3 = legendItem1.getLabelFont();
        legendItem1.setDescription("Combined_Domain_XYPlot");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(font3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        int int10 = xYPlot0.getDatasetCount();
        boolean boolean11 = xYPlot0.canSelectByPoint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double14 = combinedRangeXYPlot13.getDomainCrosshairValue();
        java.util.List list15 = combinedRangeXYPlot13.getAnnotations();
        try {
            xYPlot0.mapDatasetToDomainAxes(2, list15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape3 = xYLineAndShapeRenderer2.getLegendLine();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = xYLineAndShapeRenderer2.getLegendItemToolTipGenerator();
        boolean boolean5 = standardPieSectionLabelGenerator1.equals((java.lang.Object) xYLineAndShapeRenderer2);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean9 = periodAxis8.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = periodAxis8.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis12.setLowerBound((double) 10);
        java.util.TimeZone timeZone15 = periodAxis12.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer16 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = xYBarRenderer16.getSeriesURLGenerator(1);
        xYBarRenderer16.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        xYBarRenderer16.setSeriesNegativeItemLabelPosition(2, itemLabelPosition22, false);
        xYBarRenderer16.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection6, (org.jfree.chart.axis.ValueAxis) periodAxis8, (org.jfree.chart.axis.ValueAxis) periodAxis12, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer16);
        boolean boolean27 = xYPlot26.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot26.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator31 = xYBarRenderer29.getSeriesURLGenerator(1);
        xYBarRenderer29.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = null;
        xYBarRenderer29.setSeriesNegativeItemLabelPosition(2, itemLabelPosition35, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = xYBarRenderer29.getSeriesURLGenerator(35);
        java.awt.Stroke stroke43 = xYBarRenderer29.getItemStroke((int) ' ', 0, false);
        xYPlot26.setDomainCrosshairStroke(stroke43);
        java.awt.Paint paint45 = xYPlot26.getBackgroundPaint();
        xYLineAndShapeRenderer2.setPlot(xYPlot26);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(xYURLGenerator18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNull(xYURLGenerator31);
        org.junit.Assert.assertNull(xYURLGenerator39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3D6.setTickLabelFont((java.lang.Comparable) '4', font10);
        boolean boolean12 = piePlot3D1.equals((java.lang.Object) categoryAxis3D6);
        java.lang.Object obj13 = categoryAxis3D6.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis15.setLowerBound((double) 10);
        java.util.TimeZone timeZone18 = periodAxis15.getTimeZone();
        periodAxis15.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean24 = range22.contains((double) (byte) 1);
        double double25 = range22.getLowerBound();
        periodAxis15.setRange(range22, false, false);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getSerialIndex();
        periodAxis15.setLast((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.Number number32 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, number32);
        int int34 = year29.getYear();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D(pieDataset35);
        boolean boolean37 = piePlot3D36.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator38 = piePlot3D36.getLegendLabelToolTipGenerator();
        double double39 = piePlot3D36.getStartAngle();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D36.setLabelBackgroundPaint((java.awt.Paint) color40);
        categoryAxis3D6.setTickLabelPaint((java.lang.Comparable) year29, (java.awt.Paint) color40);
        java.util.Calendar calendar43 = null;
        try {
            year29.peg(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Color color10 = java.awt.Color.black;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.chart.JFreeChart jFreeChart14 = multiplePiePlot13.getPieChart();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart14.setBorderPaint((java.awt.Paint) color15);
        int int17 = color15.getBlue();
        java.awt.color.ColorSpace colorSpace18 = color15.getColorSpace();
        float[] floatArray19 = null;
        float[] floatArray20 = color10.getComponents(colorSpace18, floatArray19);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(jFreeChart14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 64 + "'", int17 == 64);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        xYSeries9.clear();
        double[][] doubleArray11 = xYSeries9.toArray();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        int int5 = segmentedTimeline4.getSegmentsIncluded();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline4.getSegment(date6);
        java.util.Date date8 = dateTickUnit0.rollDate(date6);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        double double5 = periodAxis1.getUpperMargin();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean12 = piePlot10.equals((java.lang.Object) categoryAxis3D11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.jfree.chart.plot.Plot plot17 = multiplePiePlot16.getRootPlot();
        java.awt.Paint paint18 = plot17.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint18);
        categoryAxis3D11.setTickMarkPaint(paint18);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 3492L, (double) 3, 0.0d, paint18);
        periodAxis1.setLabelPaint(paint18);
        java.lang.String str23 = periodAxis1.getLabelToolTip();
        java.awt.Shape shape24 = periodAxis1.getRightArrow();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] { color0, color1 };
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { paint3, paint4, color5, color6, color7, color8 };
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13 };
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = null;
        java.awt.Shape[] shapeArray17 = new java.awt.Shape[] { shape16 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray9, strokeArray14, strokeArray15, shapeArray17);
        try {
            java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray17);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("AxisEntity: tooltip = null");
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(true, true);
        double double5 = piePlot3D1.getLabelGap();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot3D1.removeChangeListener(plotChangeListener6);
        double double8 = piePlot3D1.getDepthFactor();
        piePlot3D1.setAutoPopulateSectionOutlineStroke(false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = null;
        try {
            piePlot3D1.setLabelDistributor(abstractPieLabelDistributor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.12d + "'", double8 == 0.12d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape3 = xYLineAndShapeRenderer2.getLegendLine();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = xYLineAndShapeRenderer2.getLegendItemToolTipGenerator();
        boolean boolean5 = standardPieSectionLabelGenerator1.equals((java.lang.Object) xYLineAndShapeRenderer2);
        xYLineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (byte) 0, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        java.awt.Paint paint36 = categoryPlot34.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray12 = legendTitle11.getSources();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(legendItemSourceArray12);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        java.awt.Paint paint10 = jFreeChart7.getBorderPaint();
        java.awt.Image image11 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setAntiAlias(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str6 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D0.drawTickMarks(graphics2D7, (double) (byte) -1, rectangle2D9, rectangleEdge11, axisState13);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = xYBarRenderer15.getSeriesURLGenerator(1);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer15.setBaseOutlineStroke(stroke18);
        xYBarRenderer15.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer15.setBaseShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        java.awt.Shape shape27 = legendItemEntity26.getArea();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot28.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot28.panDomainAxes((double) (byte) 0, plotRenderingInfo32, point2D35);
        boolean boolean37 = xYPlot28.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D38 = xYPlot28.getQuadrantOrigin();
        int int39 = xYPlot28.getRangeAxisCount();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset40 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset40, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate43 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset40);
        int int44 = xYPlot28.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset40);
        legendItemEntity26.setDataset((org.jfree.data.general.Dataset) defaultXYDataset40);
        boolean boolean46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (byte) -1, (java.lang.Object) legendItemEntity26);
        java.lang.String str47 = legendItemEntity26.getToolTipText();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot48.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = null;
        java.awt.geom.Point2D point2D55 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor54);
        xYPlot48.panDomainAxes((double) (byte) 0, plotRenderingInfo52, point2D55);
        boolean boolean57 = xYPlot48.isDomainGridlinesVisible();
        boolean boolean58 = legendItemEntity26.equals((java.lang.Object) xYPlot48);
        org.jfree.chart.axis.ValueAxis valueAxis59 = xYPlot48.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(xYURLGenerator17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(valueAxis59);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        categoryPlot34.setDomainCrosshairVisible(false);
        categoryPlot34.setRangePannable(true);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer3.setBaseOutlineStroke(stroke6);
        xYBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint11 = xYBarRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = xYBarRenderer3.getBaseFillPaint();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) paint12);
        barRenderer3D2.removeAnnotations();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer3D2.setSeriesURLGenerator(8, categoryURLGenerator16);
        barRenderer3D2.setDrawBarOutline(true);
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        java.util.List list2 = combinedRangeXYPlot0.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        java.awt.Paint paint4 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getStartTime();
        int int5 = segmentedTimeline3.getSegmentsIncluded();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range4, range8);
        periodAxis1.setRangeWithMargins(range8, true, false);
        periodAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem5.setLine(shape8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot10.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot10.panDomainAxes((double) (byte) 0, plotRenderingInfo14, point2D17);
        boolean boolean19 = xYPlot10.isRangeZeroBaselineVisible();
        int int20 = xYPlot10.getDatasetCount();
        java.awt.Paint paint21 = xYPlot10.getBackgroundPaint();
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("April", "April", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "LegendItemEntity: seriesKey=null, dataset=null", shape8, paint21);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = intervalMarker25.getLabelAnchor();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, rectangleAnchor26, 0.2d, (double) (byte) 10);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str7 = seriesRenderingOrder6.toString();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder6);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis10.setLowerBound((double) 10);
        java.util.TimeZone timeZone13 = periodAxis10.getTimeZone();
        periodAxis10.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean19 = range17.contains((double) (byte) 1);
        double double20 = range17.getLowerBound();
        periodAxis10.setRange(range17, false, false);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        periodAxis10.setLast((org.jfree.data.time.RegularTimePeriod) year24);
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean29 = periodAxis28.isAxisLineVisible();
        periodAxis28.setAutoRangeMinimumSize((double) 2, true);
        org.jfree.chart.axis.PeriodAxis periodAxis34 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis34.setLowerBound((double) 10);
        java.util.TimeZone timeZone37 = periodAxis34.getTimeZone();
        double double38 = periodAxis34.getUpperMargin();
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean45 = piePlot43.equals((java.lang.Object) categoryAxis3D44);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot49 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset48);
        org.jfree.chart.plot.Plot plot50 = multiplePiePlot49.getRootPlot();
        java.awt.Paint paint51 = plot50.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint51);
        categoryAxis3D44.setTickMarkPaint(paint51);
        org.jfree.chart.block.BlockBorder blockBorder54 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 3492L, (double) 3, 0.0d, paint51);
        periodAxis34.setLabelPaint(paint51);
        org.jfree.chart.axis.PeriodAxis periodAxis57 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean58 = periodAxis57.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource59 = periodAxis57.getStandardTickUnits();
        java.awt.Color color60 = java.awt.Color.cyan;
        periodAxis57.setLabelPaint((java.awt.Paint) color60);
        org.jfree.chart.axis.PeriodAxis periodAxis63 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis63.setLowerBound((double) 10);
        java.util.TimeZone timeZone66 = periodAxis63.getTimeZone();
        boolean boolean67 = periodAxis63.isVerticalTickLabels();
        org.jfree.chart.axis.PeriodAxis periodAxis69 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis69.setLowerBound((double) 10);
        java.util.TimeZone timeZone72 = periodAxis69.getTimeZone();
        double double73 = periodAxis69.getUpperMargin();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray74 = new org.jfree.chart.axis.ValueAxis[] { periodAxis10, periodAxis28, periodAxis34, periodAxis57, periodAxis63, periodAxis69 };
        xYPlot0.setDomainAxes(valueAxisArray74);
        boolean boolean76 = xYPlot0.isRangeZoomable();
        java.awt.Stroke stroke77 = xYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str7.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(plot50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(tickUnitSource59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(valueAxisArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(stroke77);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, true);
        xYBarRenderer0.clearSeriesStrokes(false);
        org.junit.Assert.assertNull(xYURLGenerator2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        periodAxis1.zoomRange(0.0d, 0.0d);
        periodAxis1.setAxisLineVisible(true);
        org.jfree.chart.axis.TickUnits tickUnits20 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits20);
        int int22 = tickUnits20.size();
        int int23 = tickUnits20.size();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape4, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        org.jfree.chart.plot.Plot plot11 = multiplePiePlot10.getRootPlot();
        java.awt.Shape shape12 = multiplePiePlot10.getLegendItemShape();
        chartEntity8.setArea(shape12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset14);
        org.jfree.chart.JFreeChart jFreeChart16 = multiplePiePlot15.getPieChart();
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) multiplePiePlot15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = multiplePiePlot15.getDataset();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(jFreeChart16);
        org.junit.Assert.assertNull(categoryDataset18);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot20.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer23.getSeriesURLGenerator(1);
        xYBarRenderer23.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = null;
        xYBarRenderer23.setSeriesNegativeItemLabelPosition(2, itemLabelPosition29, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = xYBarRenderer23.getSeriesURLGenerator(35);
        java.awt.Stroke stroke37 = xYBarRenderer23.getItemStroke((int) ' ', 0, false);
        xYPlot20.setDomainCrosshairStroke(stroke37);
        java.awt.Paint paint39 = xYPlot20.getBackgroundPaint();
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot41.getRangeAxis((int) '#');
        xYPlot41.setRangeCrosshairVisible(true);
        xYPlot41.clearRangeAxes();
        java.awt.Paint paint47 = xYPlot41.getDomainTickBandPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder48 = xYPlot41.getDatasetRenderingOrder();
        xYPlot40.setDatasetRenderingOrder(datasetRenderingOrder48);
        xYPlot20.setDatasetRenderingOrder(datasetRenderingOrder48);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNull(xYURLGenerator33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNotNull(datasetRenderingOrder48);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Paint paint5 = piePlot3D1.getLabelPaint();
        java.lang.String str6 = piePlot3D1.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie 3D Plot" + "'", str6.equals("Pie 3D Plot"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        numberFormat1.setParseIntegerOnly(false);
        int int4 = numberFormat1.getMaximumIntegerDigits();
        logAxis0.setNumberFormatOverride(numberFormat1);
        java.text.NumberFormat numberFormat6 = logAxis0.getNumberFormatOverride();
        double double7 = logAxis0.getBase();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean14 = periodAxis13.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = periodAxis13.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis17.setLowerBound((double) 10);
        java.util.TimeZone timeZone20 = periodAxis17.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYBarRenderer21.getSeriesURLGenerator(1);
        xYBarRenderer21.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        xYBarRenderer21.setSeriesNegativeItemLabelPosition(2, itemLabelPosition27, false);
        xYBarRenderer21.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer21);
        boolean boolean32 = xYPlot31.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot31.getLegendItems();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str36 = legendItem35.getDescription();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str39 = dateTickUnit37.valueToString((double) 0L);
        legendItem35.setSeriesKey((java.lang.Comparable) 0L);
        legendItemCollection33.add(legendItem35);
        xYPlot0.setFixedLegendItems(legendItemCollection33);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot43.getRangeAxis((int) '#');
        xYPlot43.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        xYPlot43.setDomainAxis((int) '4', valueAxis49, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        double double53 = categoryAxis3D52.getLabelAngle();
        int int54 = categoryAxis3D52.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D56 = new org.jfree.chart.plot.PiePlot3D(pieDataset55);
        boolean boolean57 = piePlot3D56.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator58 = piePlot3D56.getLegendLabelToolTipGenerator();
        double double59 = piePlot3D56.getStartAngle();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D56.setLabelBackgroundPaint((java.awt.Paint) color60);
        categoryAxis3D52.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D56);
        java.awt.Font font63 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D52.setTickLabelFont(font63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = categoryAxis3D52.getTickLabelInsets();
        xYPlot43.setAxisOffset(rectangleInsets65);
        xYPlot0.setInsets(rectangleInsets65);
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis70 = xYPlot68.getRangeAxis((int) '#');
        xYPlot68.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection73 = xYPlot68.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation74 = xYPlot68.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation(axisLocation74);
        boolean boolean76 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(xYURLGenerator23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "12/31/69 4:00 PM" + "'", str39.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4 + "'", int54 == 4);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 90.0d + "'", double59 == 90.0d);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNull(valueAxis70);
        org.junit.Assert.assertNull(legendItemCollection73);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color5 = java.awt.Color.PINK;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color5, false);
        xYBarRenderer0.setShadowYOffset((double) 8);
        xYBarRenderer0.setItemLabelAnchorOffset((double) 3492L);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        xYBarRenderer0.setBaseURLGenerator(xYURLGenerator12, false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        java.awt.Font font21 = periodAxis6.getLabelFont();
        periodAxis6.setUpperMargin((double) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle11.arrange(graphics2D12);
        double double14 = size2D13.width;
        java.lang.String str15 = size2D13.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str15.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range0, 0.0d, (double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean8 = range6.contains((double) (byte) 1);
        double double9 = range6.getLowerBound();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean12 = range10.contains((double) (byte) 1);
        double double13 = range10.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range6, range10);
        boolean boolean15 = range5.intersects(range6);
        double double16 = range5.getUpperBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 33.0d + "'", double16 == 33.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        java.util.List list2 = combinedRangeXYPlot0.getAnnotations();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(xYItemRenderer6);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) 100L, 100.0d, 0.0d, (double) 8);
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries24 = xYSeries21.createCopy((int) 'a', (int) (byte) -1);
        boolean boolean25 = rectangleInsets19.equals((java.lang.Object) 'a');
        piePlot3D8.setInsets(rectangleInsets19);
        boolean boolean27 = piePlot3D8.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(xYSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }
}

