import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "Range[0.0,1.0]", "[size=1]", "DomainOrder.DESCENDING");
        basicProjectInfo4.setInfo("Range[0.0,1.0]");
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        valueMarker3.setLabel("13");
        java.awt.Font font7 = valueMarker3.getLabelFont();
        java.lang.Class class8 = null;
        try {
            java.util.EventListener[] eventListenerArray9 = valueMarker3.getListeners(class8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        double double19 = piePlot3D8.getShadowXOffset();
        org.jfree.chart.util.Rotation rotation20 = piePlot3D8.getDirection();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis22.setLowerBound((double) 10);
        java.util.TimeZone timeZone25 = periodAxis22.getTimeZone();
        periodAxis22.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean31 = range29.contains((double) (byte) 1);
        double double32 = range29.getLowerBound();
        periodAxis22.setRange(range29, false, false);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getSerialIndex();
        periodAxis22.setLast((org.jfree.data.time.RegularTimePeriod) year36);
        java.lang.Number number39 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, number39);
        java.lang.Number number41 = timeSeriesDataItem40.getValue();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray44 = new java.awt.Paint[] { color42, color43 };
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { paint45, paint46, color47, color48, color49, color50 };
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray56 = new java.awt.Stroke[] { stroke52, stroke53, stroke54, stroke55 };
        java.awt.Stroke[] strokeArray57 = new java.awt.Stroke[] {};
        java.awt.Shape shape58 = null;
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] { shape58 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray44, paintArray51, strokeArray56, strokeArray57, shapeArray59);
        java.awt.Paint paint61 = defaultDrawingSupplier60.getNextPaint();
        piePlot3D8.setSectionOutlinePaint((java.lang.Comparable) timeSeriesDataItem40, paint61);
        org.jfree.chart.util.LogFormat logFormat66 = new org.jfree.chart.util.LogFormat(8.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", false);
        org.jfree.chart.util.LogFormat logFormat72 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        org.jfree.data.Range range73 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double74 = range73.getLength();
        boolean boolean75 = logFormat72.equals((java.lang.Object) double74);
        org.jfree.chart.util.LogFormat logFormat81 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer83 = null;
        java.text.FieldPosition fieldPosition84 = null;
        java.lang.StringBuffer stringBuffer85 = logFormat81.format((long) '#', stringBuffer83, fieldPosition84);
        java.text.FieldPosition fieldPosition86 = null;
        java.lang.StringBuffer stringBuffer87 = logFormat72.format(0L, stringBuffer83, fieldPosition86);
        java.text.FieldPosition fieldPosition88 = null;
        java.lang.StringBuffer stringBuffer89 = logFormat66.format((long) (byte) 100, stringBuffer87, fieldPosition88);
        boolean boolean90 = timeSeriesDataItem40.equals((java.lang.Object) fieldPosition88);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paintArray44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray56);
        org.junit.Assert.assertNotNull(strokeArray57);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(stringBuffer85);
        org.junit.Assert.assertNotNull(stringBuffer87);
        org.junit.Assert.assertNotNull(stringBuffer89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        java.awt.Color color9 = java.awt.Color.PINK;
        jFreeChart8.setBorderPaint((java.awt.Paint) color9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart8.getLegend(0);
        legendTitle12.setHeight((double) (byte) 100);
        legendTitle12.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle12.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment20, (double) 1.0f, (double) 1L);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot24.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.util.List list29 = null;
        xYPlot24.drawRangeTickBands(graphics2D27, rectangle2D28, list29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator34 = xYBarRenderer32.getSeriesURLGenerator(1);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer32.setBaseOutlineStroke(stroke35);
        xYBarRenderer32.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint40 = xYBarRenderer32.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean42 = xYBarRenderer32.isSeriesItemLabelsVisible(100);
        java.awt.Paint paint44 = xYBarRenderer32.getSeriesItemLabelPaint(100);
        xYBarRenderer32.setBase(0.0d);
        boolean boolean48 = xYBarRenderer32.isSeriesVisibleInLegend(35);
        xYPlot24.setRenderer(2019, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer32);
        boolean boolean50 = flowArrangement23.equals((java.lang.Object) 2019);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNull(xYURLGenerator34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        double double2 = timeSeries1.getMinY();
        long long3 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9223372036854775807L + "'", long3 == 9223372036854775807L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesLinesVisible(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot6.getRootPlot();
        java.awt.Shape shape8 = multiplePiePlot6.getLegendItemShape();
        xYLineAndShapeRenderer0.setLegendLine(shape8);
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean13 = periodAxis12.isAxisLineVisible();
        periodAxis12.setAutoRangeMinimumSize((double) 2, true);
        java.awt.Stroke stroke17 = periodAxis12.getMinorTickMarkStroke();
        xYLineAndShapeRenderer0.setSeriesOutlineStroke(0, stroke17);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        java.util.List list2 = combinedRangeXYPlot0.getAnnotations();
        combinedRangeXYPlot0.setWeight(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries5.removeAgedItems((long) (-1), false);
        timeSeries5.setMaximumItemAge(0L);
        java.lang.Object obj11 = timeSeries5.clone();
        boolean boolean12 = timeSeries5.isEmpty();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis15.setLowerBound((double) 10);
        java.util.TimeZone timeZone18 = periodAxis15.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone18;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone18;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("", timeZone18);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        boolean boolean10 = xYPlot0.isRangeZoomable();
        java.awt.Paint paint11 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Font font2 = legendItem1.getLabelFont();
        org.junit.Assert.assertNull(font2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer3.setBaseOutlineStroke(stroke6);
        xYBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint11 = xYBarRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = xYBarRenderer3.getBaseFillPaint();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) paint12);
        barRenderer3D2.setMaximumBarWidth((double) 36);
        double double16 = barRenderer3D2.getMinimumBarLength();
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(8.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", false);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat(8.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", false);
        java.lang.Object obj9 = logFormat8.clone();
        org.jfree.chart.util.LogFormat logFormat15 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double17 = range16.getLength();
        boolean boolean18 = logFormat15.equals((java.lang.Object) double17);
        org.jfree.chart.util.LogFormat logFormat24 = new org.jfree.chart.util.LogFormat((double) 2147483647, "SeriesRenderingOrder.FORWARD", "", true);
        java.lang.StringBuffer stringBuffer26 = null;
        java.text.FieldPosition fieldPosition27 = null;
        java.lang.StringBuffer stringBuffer28 = logFormat24.format((long) '#', stringBuffer26, fieldPosition27);
        java.text.FieldPosition fieldPosition29 = null;
        java.lang.StringBuffer stringBuffer30 = logFormat15.format(0L, stringBuffer26, fieldPosition29);
        java.lang.StringBuffer stringBuffer32 = null;
        java.text.FieldPosition fieldPosition33 = null;
        java.lang.StringBuffer stringBuffer34 = logFormat15.format((long) (byte) 100, stringBuffer32, fieldPosition33);
        java.text.FieldPosition fieldPosition35 = null;
        java.lang.StringBuffer stringBuffer36 = logFormat8.format((long) 100, stringBuffer34, fieldPosition35);
        java.text.FieldPosition fieldPosition37 = null;
        java.lang.StringBuffer stringBuffer38 = logFormat3.format(1L, stringBuffer36, fieldPosition37);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stringBuffer28);
        org.junit.Assert.assertNotNull(stringBuffer30);
        org.junit.Assert.assertNotNull(stringBuffer34);
        org.junit.Assert.assertNotNull(stringBuffer36);
        org.junit.Assert.assertNotNull(stringBuffer38);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        xYSeries1.setMaximumItemCount((int) (byte) 100);
        xYSeries1.setNotify(true);
        double double14 = xYSeries1.getMinY();
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        periodAxis1.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        periodAxis1.setRange(range8, false, false);
        periodAxis1.zoomRange(0.0d, 0.0d);
        periodAxis1.setAxisLineVisible(true);
        org.jfree.chart.axis.TickUnits tickUnits20 = new org.jfree.chart.axis.TickUnits();
        periodAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits20);
        int int22 = tickUnits20.size();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str25 = dateTickUnit23.valueToString((double) 0L);
        java.lang.String str27 = dateTickUnit23.valueToString((double) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        boolean boolean29 = dateTickUnit23.equals((java.lang.Object) rectangleInsets28);
        try {
            org.jfree.chart.axis.TickUnit tickUnit30 = tickUnits20.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "12/31/69 4:00 PM" + "'", str25.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "12/31/69 4:00 PM" + "'", str27.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str6 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D0.drawTickMarks(graphics2D7, (double) (byte) -1, rectangle2D9, rectangleEdge11, axisState13);
        double double15 = categoryAxis3D0.getUpperMargin();
        categoryAxis3D0.setCategoryMargin(0.05d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date2, "ClassContext", "UnitType.ABSOLUTE");
        java.lang.String str6 = timeSeries5.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getMinorTickCount();
        int int2 = dateTickUnit0.getCalendarField();
        int int3 = dateTickUnit0.getMinorTickCount();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D4.equals(obj5);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) piePlot3D4, true);
        java.awt.Color color9 = java.awt.Color.PINK;
        jFreeChart8.setBorderPaint((java.awt.Paint) color9);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart8.getLegend(0);
        boolean boolean14 = legendTitle12.equals((java.lang.Object) 175);
        java.awt.Paint paint15 = legendTitle12.getItemPaint();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.data.xy.XYSeries xYSeries19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries19.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset20);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer23.getSeriesURLGenerator(1);
        xYBarRenderer23.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color28 = java.awt.Color.PINK;
        xYBarRenderer23.setBasePaint((java.awt.Paint) color28, false);
        boolean boolean31 = intervalXYDelegate22.equals((java.lang.Object) color28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape33 = xYLineAndShapeRenderer32.getLegendLine();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = xYLineAndShapeRenderer32.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = xYBarRenderer37.getSeriesURLGenerator(1);
        java.awt.Stroke stroke40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer37.setBaseOutlineStroke(stroke40);
        xYBarRenderer37.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint45 = xYBarRenderer37.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(0.0d, paint45, stroke46);
        java.awt.Stroke stroke48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        valueMarker47.setOutlineStroke(stroke48);
        xYLineAndShapeRenderer32.setSeriesStroke(7, stroke48);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 6, paint15, stroke16, (java.awt.Paint) color28, stroke48, (float) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator34);
        org.junit.Assert.assertNull(xYURLGenerator39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        int int2 = xYItemRendererState1.getLastItemIndex();
        boolean boolean3 = xYItemRendererState1.getProcessVisibleItemsOnly();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        java.lang.Class class5 = null;
        try {
            periodAxis1.setAutoRangeTimePeriodClass(class5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range4);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toRangeHeight(range9);
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean13 = range11.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint10.toRangeHeight(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedHeight();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean18 = range16.contains((double) (byte) 1);
        double double19 = range16.getLowerBound();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean22 = range20.contains((double) (byte) 1);
        double double23 = range20.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint(range16, range20);
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint24.toRangeHeight(range25);
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean29 = range27.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = rectangleConstraint26.toRangeHeight(range27);
        java.lang.String str31 = range27.toString();
        boolean boolean33 = range27.contains((double) 100.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean35 = range27.equals((java.lang.Object) rectangleEdge34);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = rectangleConstraint14.toRangeWidth(range27);
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean39 = range37.contains((double) (byte) 1);
        java.lang.String str40 = range37.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = rectangleConstraint36.toRangeWidth(range37);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Range[0.0,1.0]" + "'", str31.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Range[0.0,1.0]" + "'", str40.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint41);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        xYSeriesCollection3.setAutoWidth(false);
        double double12 = xYSeriesCollection3.getDomainUpperBound(true);
        try {
            double double15 = xYSeriesCollection3.getStartXValue(12, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        boolean boolean6 = xYLineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        xYLineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(3, itemLabelPosition8, true);
        xYLineAndShapeRenderer0.setUseOutlinePaint(true);
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Shape shape19 = xYLineAndShapeRenderer0.getItemShape(64, 5, false);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer3.setBaseOutlineStroke(stroke6);
        xYBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint11 = xYBarRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = xYBarRenderer3.getBaseFillPaint();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) paint12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = barRenderer3D2.getBaseURLGenerator();
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryURLGenerator14);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape1 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = xYLineAndShapeRenderer0.getLegendItemToolTipGenerator();
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.lang.Object obj7 = null;
        boolean boolean8 = piePlot3D6.equals(obj7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) piePlot3D6, true);
        java.awt.Color color11 = java.awt.Color.PINK;
        jFreeChart10.setBorderPaint((java.awt.Paint) color11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart10.getLegend(0);
        legendTitle14.setHeight((double) (byte) 100);
        org.jfree.chart.block.BlockContainer blockContainer17 = legendTitle14.getItemContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement22 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment18, verticalAlignment19, (double) (short) 100, (double) (-1.0f));
        columnArrangement22.clear();
        blockContainer17.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment25, verticalAlignment26, (double) (short) 100, (double) (-1.0f));
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement22, (org.jfree.chart.block.Arrangement) columnArrangement29);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(legendTitle14);
        org.junit.Assert.assertNotNull(blockContainer17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(2, itemLabelPosition6, false);
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = xYBarRenderer0.getLegendItemLabelGenerator();
        java.awt.Shape shape12 = xYBarRenderer0.lookupLegendShape(36);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("Range[0.0,1.0]");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "", true);
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        java.lang.Object obj11 = null;
        boolean boolean12 = piePlot3D10.equals(obj11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) piePlot3D10, true);
        java.awt.Color color15 = java.awt.Color.PINK;
        jFreeChart14.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart14.getLegend(0);
        rendererChangeEvent6.setChart(jFreeChart14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection21 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis23 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean24 = periodAxis23.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = periodAxis23.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis27.setLowerBound((double) 10);
        java.util.TimeZone timeZone30 = periodAxis27.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = xYBarRenderer31.getSeriesURLGenerator(1);
        xYBarRenderer31.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        xYBarRenderer31.setSeriesNegativeItemLabelPosition(2, itemLabelPosition37, false);
        xYBarRenderer31.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection21, (org.jfree.chart.axis.ValueAxis) periodAxis23, (org.jfree.chart.axis.ValueAxis) periodAxis27, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer31);
        boolean boolean42 = chartChangeEventType20.equals((java.lang.Object) xYBarRenderer31);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) year2, jFreeChart14, chartChangeEventType20);
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) year2);
        java.lang.String str45 = year2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(legendTitle18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(tickUnitSource25);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(xYURLGenerator33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart2.setBorderPaint((java.awt.Paint) color3);
        org.jfree.chart.title.TextTitle textTitle5 = jFreeChart2.getTitle();
        textTitle5.setToolTipText("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textTitle5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int3 = java.awt.Color.HSBtoRGB((float) 2147483647, (float) (short) -1, (float) 175);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-10617182) + "'", int3 == (-10617182));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYBarRenderer0.getURLGenerator((int) (byte) 10, (int) (short) 0, true);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        java.lang.Object obj15 = null;
        boolean boolean16 = piePlot3D14.equals(obj15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) piePlot3D14, true);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) true, jFreeChart18, (int) (byte) 100, (int) (byte) 0);
        org.jfree.chart.util.PaintMap paintMap22 = new org.jfree.chart.util.PaintMap();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset23);
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot24.getPieChart();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart25.setBorderStroke(stroke26);
        boolean boolean28 = paintMap22.equals((java.lang.Object) jFreeChart25);
        chartProgressEvent21.setChart(jFreeChart25);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        org.jfree.chart.JFreeChart jFreeChart32 = multiplePiePlot31.getPieChart();
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart32.setBorderPaint((java.awt.Paint) color33);
        chartProgressEvent21.setChart(jFreeChart32);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(xYURLGenerator10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(jFreeChart32);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.black;
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color8);
        piePlot3D1.setIgnoreNullValues(true);
        java.awt.Paint paint12 = piePlot3D1.getLabelOutlinePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = xYBarRenderer14.getSeriesURLGenerator(1);
        xYBarRenderer14.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = null;
        xYBarRenderer14.setSeriesNegativeItemLabelPosition(2, itemLabelPosition20, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = xYBarRenderer14.getSeriesURLGenerator(35);
        java.awt.Stroke stroke28 = xYBarRenderer14.getItemStroke((int) ' ', 0, false);
        xYBarRenderer14.setBaseSeriesVisible(true, false);
        xYBarRenderer14.setItemLabelAnchorOffset(10.0d);
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYBarRenderer14.setSeriesItemLabelFont((int) (byte) 10, font35, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = xYBarRenderer14.getNegativeItemLabelPositionFallback();
        java.awt.Color color40 = java.awt.Color.MAGENTA;
        xYBarRenderer14.setSeriesOutlinePaint(64, (java.awt.Paint) color40, false);
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) "org.jfree.data.general.SeriesChangeEvent[source=0.0]", (java.awt.Paint) color40);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(xYURLGenerator16);
        org.junit.Assert.assertNull(xYURLGenerator24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot34.setRangeZeroBaselinePaint(paint36);
        categoryPlot34.setRangeCrosshairValue(0.08d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        double double42 = categoryAxis3D41.getLabelAngle();
        int int43 = categoryAxis3D41.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D(pieDataset44);
        boolean boolean46 = piePlot3D45.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot3D45.getLegendLabelToolTipGenerator();
        double double48 = piePlot3D45.getStartAngle();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D45.setLabelBackgroundPaint((java.awt.Paint) color49);
        categoryAxis3D41.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D45);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D41.setTickLabelFont(font52);
        categoryAxis3D41.setLabel("Range[0.0,1.0]");
        categoryPlot34.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, false);
        org.jfree.data.general.PieDataset pieDataset58 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D59 = new org.jfree.chart.plot.PiePlot3D(pieDataset58);
        boolean boolean60 = piePlot3D59.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator61 = piePlot3D59.getLegendLabelToolTipGenerator();
        double double62 = piePlot3D59.getStartAngle();
        java.awt.Paint paint63 = piePlot3D59.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = piePlot3D59.getSimpleLabelOffset();
        categoryPlot34.setInsets(rectangleInsets64, true);
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot34);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 90.0d + "'", double48 == 90.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 90.0d + "'", double62 == 90.0d);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        boolean boolean6 = xYLineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        xYLineAndShapeRenderer0.setSeriesPositiveItemLabelPosition(3, itemLabelPosition8, true);
        xYLineAndShapeRenderer0.setUseOutlinePaint(true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator14 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator(0, xYURLGenerator14, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator((int) (short) 100, xYURLGenerator18, true);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setParseIntegerOnly(false);
        int int3 = numberFormat0.getMaximumFractionDigits();
        java.util.Currency currency4 = numberFormat0.getCurrency();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(currency4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setParseIntegerOnly(false);
        int int3 = numberFormat0.getMinimumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape5 = xYBarRenderer3.getSeriesShape((int) (byte) 1);
        xYBarRenderer3.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter10 = xYBarRenderer3.getBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter10);
        xYBarRenderer0.setBarPainter(xYBarPainter10);
        xYBarRenderer0.setItemLabelAnchorOffset((double) 2);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(xYBarPainter10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "Range[0.0,1.0]", "[size=1]", "DomainOrder.DESCENDING");
        basicProjectInfo4.setVersion("SeriesRenderingOrder.FORWARD");
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        xYBarRenderer0.setSeriesItemLabelsVisible((int) (short) 100, (java.lang.Boolean) true, false);
        java.lang.Boolean boolean10 = xYBarRenderer0.getSeriesVisible(0);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = combinedDomainXYPlot0.getDataset(10);
        double double3 = combinedDomainXYPlot0.getGap();
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        java.lang.String str6 = legendItem1.getLabel();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot7.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot7.drawRangeTickBands(graphics2D10, rectangle2D11, list12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color15, stroke16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = xYPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker17, layer20);
        java.awt.Paint paint22 = valueMarker17.getLabelPaint();
        legendItem1.setLinePaint(paint22);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str6.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot12.getRangeAxis((int) '#');
        xYPlot12.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot12.getLegendItems();
        java.awt.Paint paint18 = xYPlot12.getRangeCrosshairPaint();
        xYPlot0.setRangeCrosshairPaint(paint18);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) defaultKeyedValues0);
        java.lang.Number number3 = defaultPieDataset1.getValue(0);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset1);
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset1);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset) defaultPieDataset1);
        defaultPieDataset1.clear();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        java.text.NumberFormat numberFormat1 = logAxis0.getNumberFormatOverride();
        logAxis0.configure();
        double double3 = logAxis0.getSmallestValue();
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-100d + "'", double3 == 1.0E-100d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 4);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart4.setBorderStroke(stroke5);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity7 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart4);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        int int5 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        java.lang.Object obj3 = xYDataItem2.clone();
        double double4 = xYDataItem2.getYValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        java.util.Date date3 = segmentedTimeline1.getDate((long) 10);
        boolean boolean5 = segmentedTimeline1.containsDomainValue((long) 'a');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        java.util.TimeZone timeZone4 = periodAxis1.getTimeZone();
        boolean boolean5 = periodAxis1.isTickLabelsVisible();
        periodAxis1.centerRange(0.0d);
        java.lang.String str8 = periodAxis1.getLabelToolTip();
        java.awt.Shape shape9 = periodAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.removeAgedItems((long) (-1), false);
        double double5 = timeSeries1.getMaxY();
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setMaximumItemCount(4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean15 = range13.contains((double) (byte) 1);
        double double16 = range13.getLowerBound();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean19 = range17.contains((double) (byte) 1);
        double double20 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range17);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toRangeHeight(range22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean26 = range24.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint23.toRangeHeight(range24);
        org.jfree.chart.util.Size2D size2D28 = legendTitle11.arrange(graphics2D12, rectangleConstraint27);
        java.lang.Object obj29 = size2D28.clone();
        size2D28.height = 10.0f;
        size2D28.setHeight((double) (byte) 100);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean4 = periodAxis3.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = periodAxis3.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis7.setLowerBound((double) 10);
        java.util.TimeZone timeZone10 = periodAxis7.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator13 = xYBarRenderer11.getSeriesURLGenerator(1);
        xYBarRenderer11.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = null;
        xYBarRenderer11.setSeriesNegativeItemLabelPosition(2, itemLabelPosition17, false);
        xYBarRenderer11.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, (org.jfree.chart.axis.ValueAxis) periodAxis3, (org.jfree.chart.axis.ValueAxis) periodAxis7, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer11);
        boolean boolean22 = xYPlot21.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = xYPlot21.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator26 = xYBarRenderer24.getSeriesURLGenerator(1);
        xYBarRenderer24.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        xYBarRenderer24.setSeriesNegativeItemLabelPosition(2, itemLabelPosition30, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator34 = xYBarRenderer24.getSeriesURLGenerator(35);
        java.awt.Stroke stroke38 = xYBarRenderer24.getItemStroke((int) ' ', 0, false);
        xYPlot21.setDomainCrosshairStroke(stroke38);
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator40 = numberFormat0.formatToCharacterIterator((java.lang.Object) stroke38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(xYURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNull(xYURLGenerator26);
        org.junit.Assert.assertNull(xYURLGenerator34);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str2 = legendItem1.getToolTipText();
        legendItem1.setShapeVisible(true);
        java.lang.Object obj5 = legendItem1.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str8 = dateTickUnit6.valueToString((double) 0L);
        int int9 = dateTickUnit6.getMultiple();
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray18 = new float[] { 97L, 'a', 60000L, 6, (short) 1, (byte) -1 };
        float[] floatArray19 = color11.getColorComponents(floatArray18);
        float[] floatArray20 = color10.getComponents(floatArray18);
        int int21 = dateTickUnit6.compareTo((java.lang.Object) floatArray20);
        float[] floatArray22 = color1.getComponents(colorSpace5, floatArray20);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12/31/69 4:00 PM" + "'", str8.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries4.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        int int8 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
        boolean boolean10 = datasetRenderingOrder0.equals((java.lang.Object) regularTimePeriod9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str2.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setDomainAxis((int) '4', valueAxis6, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        double double10 = categoryAxis3D9.getLabelAngle();
        int int11 = categoryAxis3D9.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        boolean boolean14 = piePlot3D13.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot3D13.getLegendLabelToolTipGenerator();
        double double16 = piePlot3D13.getStartAngle();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D13.setLabelBackgroundPaint((java.awt.Paint) color17);
        categoryAxis3D9.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D13);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D9.setTickLabelFont(font20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis3D9.getTickLabelInsets();
        xYPlot0.setAxisOffset(rectangleInsets22);
        java.awt.Paint paint24 = xYPlot0.getRangeGridlinePaint();
        xYPlot0.setRangeCrosshairValue((double) 175);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 90.0d + "'", double16 == 90.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        int int5 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range6 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        try {
            org.jfree.data.xy.XYSeries xYSeries11 = xYSeriesCollection3.getSeries(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains((double) (byte) 1);
        double double4 = range1.getLowerBound();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean7 = range5.contains((double) (byte) 1);
        double double8 = range5.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range1, range5);
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toRangeHeight(range10);
        boolean boolean12 = timePeriodAnchor0.equals((java.lang.Object) rectangleConstraint11);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setDomainDescription("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        categoryAxis3D6.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D();
        double double13 = categoryAxis3D12.getLabelAngle();
        categoryAxis3D12.clearCategoryLabelToolTips();
        categoryAxis3D12.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str18 = categoryAxis3D12.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D12.drawTickMarks(graphics2D19, (double) (byte) -1, rectangle2D21, rectangleEdge23, axisState25);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = xYBarRenderer27.getSeriesURLGenerator(1);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer27.setBaseOutlineStroke(stroke30);
        xYBarRenderer27.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer27.setBaseShape(shape36);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity(shape36);
        java.awt.Shape shape39 = legendItemEntity38.getArea();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D(pieDataset40);
        boolean boolean42 = legendItemEntity38.equals((java.lang.Object) piePlot3D41);
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.geom.Rectangle2D rectangle2D45 = chartRenderingInfo44.getChartArea();
        legendItemEntity38.setArea((java.awt.Shape) rectangle2D45);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D();
        double double48 = categoryAxis3D47.getLabelAngle();
        categoryAxis3D47.clearCategoryLabelToolTips();
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str53 = categoryAxis3D47.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge57);
        org.jfree.chart.axis.AxisState axisState60 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D47.drawTickMarks(graphics2D54, (double) (byte) -1, rectangle2D56, rectangleEdge58, axisState60);
        java.util.List list62 = categoryAxis3D6.refreshTicks(graphics2D11, axisState25, rectangle2D45, rectangleEdge58);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean65 = range63.contains((double) (byte) 1);
        double double66 = range63.getLowerBound();
        org.jfree.data.Range range67 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean69 = range67.contains((double) (byte) 1);
        double double70 = range67.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = new org.jfree.chart.block.RectangleConstraint(range63, range67);
        org.jfree.data.Range range72 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint73 = rectangleConstraint71.toRangeHeight(range72);
        org.jfree.data.time.DateRange dateRange74 = new org.jfree.data.time.DateRange(range72);
        long long75 = dateRange74.getUpperMillis();
        org.jfree.data.Range range78 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange74, 4.0d, false);
        org.jfree.data.Range range80 = timeSeriesCollection5.getRangeBounds(list62, range78, true);
        try {
            double double83 = timeSeriesCollection5.getXValue(9, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(xYURLGenerator29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(rectangleConstraint73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1L + "'", long75 == 1L);
        org.junit.Assert.assertNotNull(range78);
        org.junit.Assert.assertNull(range80);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem4.setLine(shape7);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape7, "", "VerticalAlignment.CENTER");
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.chart.plot.Plot plot14 = multiplePiePlot13.getRootPlot();
        java.awt.Shape shape15 = multiplePiePlot13.getLegendItemShape();
        chartEntity11.setArea(shape15);
        xYStepAreaRenderer0.setLegendShape(2, shape15);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color20, stroke21);
        xYStepAreaRenderer0.setSeriesOutlineStroke((int) (byte) 10, stroke21);
        java.awt.Paint paint25 = xYStepAreaRenderer0.getSeriesPaint(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape3 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) xYPlot4, "", "SerialDate.weekInMonthToString(): invalid code.");
        plotEntity18.setURLText("DomainOrder.DESCENDING");
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double2 = periodAxis1.getUpperMargin();
        java.awt.Color color3 = java.awt.Color.PINK;
        int int4 = color3.getGreen();
        periodAxis1.setLabelPaint((java.awt.Paint) color3);
        periodAxis1.resizeRange(8.0d);
        java.awt.Stroke stroke8 = periodAxis1.getAxisLineStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator11, xYURLGenerator12);
        xYAreaRenderer13.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot17.getRangeAxis((int) '#');
        xYPlot17.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot17.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str24 = seriesRenderingOrder23.toString();
        xYPlot17.setSeriesRenderingOrder(seriesRenderingOrder23);
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        java.awt.Font font29 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D31 = new org.jfree.chart.plot.PiePlot3D(pieDataset30);
        java.lang.Object obj32 = null;
        boolean boolean33 = piePlot3D31.equals(obj32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("", font29, (org.jfree.chart.plot.Plot) piePlot3D31, true);
        java.awt.Color color36 = java.awt.Color.PINK;
        jFreeChart35.setBorderPaint((java.awt.Paint) color36);
        org.jfree.chart.title.LegendTitle legendTitle39 = jFreeChart35.getLegend(0);
        legendTitle39.setHeight((double) (byte) 100);
        legendTitle39.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo(entityCollection47);
        java.awt.geom.Rectangle2D rectangle2D49 = chartRenderingInfo48.getChartArea();
        legendTitle39.setBounds(rectangle2D49);
        org.jfree.data.general.PieDataset pieDataset52 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D53 = new org.jfree.chart.plot.PiePlot3D(pieDataset52);
        boolean boolean54 = piePlot3D53.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator55 = piePlot3D53.getLegendLabelToolTipGenerator();
        double double56 = piePlot3D53.getStartAngle();
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D53.setLabelBackgroundPaint((java.awt.Paint) color57);
        java.awt.Color color60 = java.awt.Color.black;
        piePlot3D53.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color60);
        piePlot3D53.setIgnoreNullValues(true);
        java.awt.Paint paint64 = piePlot3D53.getLabelOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset65 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot66 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset65);
        org.jfree.chart.JFreeChart jFreeChart67 = multiplePiePlot66.getPieChart();
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart67.setBorderStroke(stroke68);
        xYAreaRenderer13.drawDomainLine(graphics2D16, xYPlot17, (org.jfree.chart.axis.ValueAxis) periodAxis27, rectangle2D49, (double) 10L, paint64, stroke68);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D71 = new org.jfree.chart.axis.CategoryAxis3D();
        double double72 = categoryAxis3D71.getLabelAngle();
        categoryAxis3D71.clearCategoryLabelToolTips();
        categoryAxis3D71.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str77 = categoryAxis3D71.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D78 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge81);
        org.jfree.chart.axis.AxisState axisState84 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D71.drawTickMarks(graphics2D78, (double) (byte) -1, rectangle2D80, rectangleEdge82, axisState84);
        double double86 = periodAxis1.valueToJava2D((double) 100L, rectangle2D49, rectangleEdge82);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str24.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(legendTitle39);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(jFreeChart67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        boolean boolean21 = xYPlot20.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot20.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = xYBarRenderer23.getSeriesURLGenerator(1);
        xYBarRenderer23.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color28 = java.awt.Color.PINK;
        xYBarRenderer23.setBasePaint((java.awt.Paint) color28, false);
        xYPlot20.setDomainTickBandPaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(xYURLGenerator25);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        boolean boolean6 = xYLineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, (int) (short) -1, true);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        boolean boolean10 = piePlot3D9.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D9.getLegendLabelToolTipGenerator();
        double double12 = piePlot3D9.getStartAngle();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D9.setLabelBackgroundPaint((java.awt.Paint) color13);
        java.awt.Color color16 = java.awt.Color.black;
        piePlot3D9.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color16);
        xYLineAndShapeRenderer0.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color16, false);
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Color color23 = java.awt.Color.ORANGE;
        xYLineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color23);
        xYLineAndShapeRenderer0.setBaseShapesFilled(true);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        legendItem1.setLine(shape4);
        java.awt.Font font6 = legendItem1.getLabelFont();
        java.awt.Stroke stroke7 = legendItem1.getLineStroke();
        legendItem1.setLineVisible(true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(font6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairValue(Double.NaN, false);
        java.lang.String str4 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot5.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        xYPlot5.panDomainAxes((double) (byte) 0, plotRenderingInfo9, point2D12);
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot5.setDomainZeroBaselinePaint(paint14);
        combinedDomainXYPlot0.add(xYPlot5, 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot5.getInsets();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Combined_Domain_XYPlot" + "'", str4.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 10.0f, false);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        xYSeries2.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset3);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate5 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape8 = xYBarRenderer6.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYSeriesCollection9);
        int int11 = xYSeriesCollection9.getSeriesCount();
        org.jfree.data.Range range12 = xYBarRenderer6.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection9);
        defaultXYDataset3.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection9);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        barRenderer3D2.setShadowXOffset((double) 1L);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator5);
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray10, numberArray12 };
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset14, 4.0d);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset14);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset14);
        org.jfree.data.Range range20 = barRenderer3D2.findRangeBounds(categoryDataset14, true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 97.0d + "'", number17.equals(97.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        xYDataItem2.setSelected(true);
        java.lang.String str5 = xYDataItem2.toString();
        java.lang.String str6 = xYDataItem2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[6.0, NaN]" + "'", str5.equals("[6.0, NaN]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[6.0, NaN]" + "'", str6.equals("[6.0, NaN]"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        long long9 = segmentedTimeline3.getExceptionSegmentCount(97L, (long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline3.getSegment((long) '4');
        long long12 = segment11.getSegmentCount();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        barRenderer3D2.setShadowXOffset((double) 1L);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator5);
        int int7 = barRenderer3D2.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double2 = periodAxis1.getUpperMargin();
        java.awt.Color color3 = java.awt.Color.PINK;
        int int4 = color3.getGreen();
        periodAxis1.setLabelPaint((java.awt.Paint) color3);
        periodAxis1.setLabelAngle((double) 175);
        periodAxis1.setLowerBound(10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
//        timeSeries1.setMaximumItemCount((int) (byte) 1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day4);
//        long long6 = day4.getLastMillisecond();
//        int int7 = day4.getYear();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("", strArray1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        double double4 = numberTickUnit3.getSize();
        symbolAxis2.setTickUnit(numberTickUnit3, true, true);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font11 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        java.lang.Object obj14 = null;
        boolean boolean15 = piePlot3D13.equals(obj14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("", font11, (org.jfree.chart.plot.Plot) piePlot3D13, true);
        java.awt.Color color18 = java.awt.Color.PINK;
        jFreeChart17.setBorderPaint((java.awt.Paint) color18);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart17.getLegend(0);
        legendTitle21.setHeight((double) (byte) 100);
        legendTitle21.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
        java.awt.geom.Rectangle2D rectangle2D31 = chartRenderingInfo30.getChartArea();
        legendTitle21.setBounds(rectangle2D31);
        org.jfree.chart.entity.EntityCollection entityCollection33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo(entityCollection33);
        java.awt.geom.Rectangle2D rectangle2D35 = chartRenderingInfo34.getChartArea();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        double double37 = categoryAxis3D36.getLabelAngle();
        categoryAxis3D36.clearCategoryLabelToolTips();
        categoryAxis3D36.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D();
        double double43 = categoryAxis3D42.getLabelAngle();
        categoryAxis3D42.clearCategoryLabelToolTips();
        categoryAxis3D42.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str48 = categoryAxis3D42.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
        org.jfree.chart.axis.AxisState axisState55 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D42.drawTickMarks(graphics2D49, (double) (byte) -1, rectangle2D51, rectangleEdge53, axisState55);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer57 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator59 = xYBarRenderer57.getSeriesURLGenerator(1);
        java.awt.Stroke stroke60 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer57.setBaseOutlineStroke(stroke60);
        xYBarRenderer57.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape66 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer57.setBaseShape(shape66);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity68 = new org.jfree.chart.entity.LegendItemEntity(shape66);
        java.awt.Shape shape69 = legendItemEntity68.getArea();
        org.jfree.data.general.PieDataset pieDataset70 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D71 = new org.jfree.chart.plot.PiePlot3D(pieDataset70);
        boolean boolean72 = legendItemEntity68.equals((java.lang.Object) piePlot3D71);
        org.jfree.chart.entity.EntityCollection entityCollection73 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = new org.jfree.chart.ChartRenderingInfo(entityCollection73);
        java.awt.geom.Rectangle2D rectangle2D75 = chartRenderingInfo74.getChartArea();
        legendItemEntity68.setArea((java.awt.Shape) rectangle2D75);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D77 = new org.jfree.chart.axis.CategoryAxis3D();
        double double78 = categoryAxis3D77.getLabelAngle();
        categoryAxis3D77.clearCategoryLabelToolTips();
        categoryAxis3D77.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str83 = categoryAxis3D77.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D84 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge87);
        org.jfree.chart.axis.AxisState axisState90 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D77.drawTickMarks(graphics2D84, (double) (byte) -1, rectangle2D86, rectangleEdge88, axisState90);
        java.util.List list92 = categoryAxis3D36.refreshTicks(graphics2D41, axisState55, rectangle2D75, rectangleEdge88);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo93 = null;
        try {
            org.jfree.chart.axis.AxisState axisState94 = symbolAxis2.draw(graphics2D8, (double) 7, rectangle2D31, rectangle2D35, rectangleEdge88, plotRenderingInfo93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(legendTitle21);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNull(xYURLGenerator59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertNotNull(rectangleEdge88);
        org.junit.Assert.assertNotNull(list92);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getBaseShapesVisible();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYLineAndShapeRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator3);
        java.text.NumberFormat numberFormat7 = java.text.NumberFormat.getIntegerInstance();
        numberFormat7.setGroupingUsed(true);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getIntegerInstance();
        numberFormat10.setGroupingUsed(true);
        int int13 = numberFormat10.getMaximumIntegerDigits();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SeriesRenderingOrder.FORWARD", numberFormat7, numberFormat10);
        java.lang.String str15 = standardXYToolTipGenerator14.getNullYString();
        xYLineAndShapeRenderer1.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14);
        boolean boolean17 = lineBorder0.equals((java.lang.Object) standardXYToolTipGenerator14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "null" + "'", str15.equals("null"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        boolean boolean5 = xYLineAndShapeRenderer0.getAutoPopulateSeriesStroke();
        xYLineAndShapeRenderer0.setSeriesLinesVisible(1, (java.lang.Boolean) false);
        int int9 = xYLineAndShapeRenderer0.getDefaultEntityRadius();
        boolean boolean12 = xYLineAndShapeRenderer0.getItemShapeVisible((int) (byte) 1, 13);
        java.awt.Paint paint13 = xYLineAndShapeRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        int int5 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day4);
        long long6 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYBarRenderer39.getSeriesURLGenerator(1);
        xYBarRenderer39.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        xYBarRenderer39.setSeriesNegativeItemLabelPosition(2, itemLabelPosition45, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator49 = xYBarRenderer39.getSeriesURLGenerator(35);
        java.awt.Stroke stroke53 = xYBarRenderer39.getItemStroke((int) ' ', 0, false);
        intervalMarker38.setOutlineStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        java.awt.Color color56 = java.awt.Color.cyan;
        categoryPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color56);
        int int58 = categoryPlot34.getWeight();
        java.util.List list59 = categoryPlot34.getCategories();
        categoryPlot34.setAnchorValue(0.4d, true);
        org.jfree.chart.entity.EntityCollection entityCollection65 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = new org.jfree.chart.ChartRenderingInfo(entityCollection65);
        java.lang.Object obj67 = chartRenderingInfo66.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = chartRenderingInfo66.getPlotInfo();
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis71 = xYPlot69.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = null;
        java.awt.geom.Point2D point2D76 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D74, rectangleAnchor75);
        xYPlot69.panDomainAxes((double) (byte) 0, plotRenderingInfo73, point2D76);
        boolean boolean78 = xYPlot69.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D79 = xYPlot69.getQuadrantOrigin();
        try {
            categoryPlot34.zoomRangeAxes((double) (byte) 100, (double) 15, plotRenderingInfo68, point2D79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.5824E9) <= upper (1.2384E9).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertNull(xYURLGenerator49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertNotNull(plotRenderingInfo68);
        org.junit.Assert.assertNull(valueAxis71);
        org.junit.Assert.assertNotNull(point2D76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(point2D79);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        double double21 = xYPlot20.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        xYSeries1.setMaximumItemCount((int) (byte) 100);
        xYSeries1.setNotify(true);
        boolean boolean14 = xYSeries1.getNotify();
        org.jfree.data.xy.XYDataItem xYDataItem17 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        xYDataItem17.setSelected(true);
        xYSeries1.add(xYDataItem17, false);
        java.awt.Font font23 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D(pieDataset24);
        java.lang.Object obj26 = null;
        boolean boolean27 = piePlot3D25.equals(obj26);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("", font23, (org.jfree.chart.plot.Plot) piePlot3D25, true);
        java.awt.Color color30 = java.awt.Color.PINK;
        jFreeChart29.setBorderPaint((java.awt.Paint) color30);
        org.jfree.chart.title.LegendTitle legendTitle33 = jFreeChart29.getLegend(0);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean37 = range35.contains((double) (byte) 1);
        double double38 = range35.getLowerBound();
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean41 = range39.contains((double) (byte) 1);
        double double42 = range39.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint(range35, range39);
        org.jfree.data.Range range44 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = rectangleConstraint43.toRangeHeight(range44);
        org.jfree.data.Range range46 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean48 = range46.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = rectangleConstraint45.toRangeHeight(range46);
        org.jfree.chart.util.Size2D size2D50 = legendTitle33.arrange(graphics2D34, rectangleConstraint49);
        java.lang.Object obj51 = size2D50.clone();
        boolean boolean52 = xYDataItem17.equals((java.lang.Object) size2D50);
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(legendTitle33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(rectangleConstraint45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint49);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairValue(Double.NaN, false);
        java.awt.Stroke stroke4 = combinedDomainXYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        combinedRangeXYPlot0.setOutlineVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = combinedRangeXYPlot0.getDomainAxis();
        boolean boolean5 = combinedRangeXYPlot0.isDomainPannable();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        periodAxis1.setAxisLineStroke(stroke2);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        int int4 = segmentedTimeline3.getSegmentsIncluded();
        boolean boolean6 = segmentedTimeline3.containsDomainValue((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 35 + "'", int4 == 35);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        boolean boolean10 = xYBarRenderer0.isSeriesItemLabelsVisible(100);
        java.awt.Font font12 = xYBarRenderer0.lookupLegendTextFont((int) (byte) 10);
        java.awt.Shape shape16 = xYBarRenderer0.getItemShape((int) (short) 10, 0, false);
        java.awt.Paint paint18 = xYBarRenderer0.getLegendTextPaint((int) ' ');
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer0.setBaseShape(shape9);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = xYBarRenderer0.getGradientPaintTransformer();
        java.awt.Font font12 = xYBarRenderer0.getBaseItemLabelFont();
        xYBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries1.setMaximumItemAge((long) '#');
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean15 = range13.contains((double) (byte) 1);
        double double16 = range13.getLowerBound();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean19 = range17.contains((double) (byte) 1);
        double double20 = range17.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range13, range17);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toRangeHeight(range22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean26 = range24.contains((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint23.toRangeHeight(range24);
        org.jfree.chart.util.Size2D size2D28 = legendTitle11.arrange(graphics2D12, rectangleConstraint27);
        java.lang.Object obj29 = size2D28.clone();
        size2D28.height = 10.0f;
        size2D28.height = 10;
        java.lang.Object obj34 = size2D28.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment3, (double) (short) 100, (double) (-1.0f));
        org.jfree.chart.block.Block block7 = null;
        columnArrangement6.add(block7, (java.lang.Object) 1L);
        boolean boolean10 = gradientPaintTransformType1.equals((java.lang.Object) columnArrangement6);
        java.lang.String str11 = gradientPaintTransformType1.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str11.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        java.lang.String str3 = range0.toString();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range0, (double) 10.0f, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, 90.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toFixedHeight((double) 7);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[0.0,1.0]" + "'", str3.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 15);
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis3.setLowerBound((double) 10);
        java.util.TimeZone timeZone6 = periodAxis3.getTimeZone();
        boolean boolean7 = periodAxis3.isTickLabelsVisible();
        org.jfree.chart.entity.AxisEntity axisEntity9 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) periodAxis3, "ClassContext");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        boolean boolean4 = periodAxis1.isVerticalTickLabels();
        try {
            periodAxis1.setAutoRangeMinimumSize((double) (-8355585));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Category Plot");
        java.awt.Paint paint2 = standardChartTheme1.getGridBandAlternatePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer0.setBaseOutlineStroke(stroke3);
        java.awt.Stroke stroke6 = xYBarRenderer0.getSeriesStroke((int) (short) 0);
        java.awt.Stroke stroke10 = xYBarRenderer0.getItemOutlineStroke(36, 2147483647, true);
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer3.setBaseOutlineStroke(stroke6);
        xYBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint11 = xYBarRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = xYBarRenderer3.getBaseFillPaint();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) paint12);
        boolean boolean17 = barRenderer3D2.isItemLabelVisible(0, 1, false);
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        int int6 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D1.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        int int1 = timeSeriesCollection0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean3 = periodAxis2.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = periodAxis2.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis6.setLowerBound((double) 10);
        java.util.TimeZone timeZone9 = periodAxis6.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        xYBarRenderer10.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(2, itemLabelPosition16, false);
        xYBarRenderer10.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis2, (org.jfree.chart.axis.ValueAxis) periodAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer10);
        java.lang.Number number21 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertEquals((double) number21, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer0.getSeriesPositiveItemLabelPosition(0);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) 100L, 100.0d, 0.0d, (double) 8);
        org.jfree.data.xy.XYSeries xYSeries21 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries24 = xYSeries21.createCopy((int) 'a', (int) (byte) -1);
        boolean boolean25 = rectangleInsets19.equals((java.lang.Object) 'a');
        piePlot3D8.setInsets(rectangleInsets19);
        boolean boolean27 = piePlot3D8.isNotify();
        java.awt.Font font28 = piePlot3D8.getLabelFont();
        java.awt.Paint paint29 = piePlot3D8.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(xYSeries24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot34.setRangeZeroBaselinePaint(paint36);
        categoryPlot34.setRangeCrosshairValue(0.08d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        double double42 = categoryAxis3D41.getLabelAngle();
        int int43 = categoryAxis3D41.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D(pieDataset44);
        boolean boolean46 = piePlot3D45.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot3D45.getLegendLabelToolTipGenerator();
        double double48 = piePlot3D45.getStartAngle();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D45.setLabelBackgroundPaint((java.awt.Paint) color49);
        categoryAxis3D41.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D45);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D41.setTickLabelFont(font52);
        categoryAxis3D41.setLabel("Range[0.0,1.0]");
        categoryPlot34.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, false);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot61 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset60);
        org.jfree.chart.plot.Plot plot62 = multiplePiePlot61.getRootPlot();
        java.awt.Paint paint63 = plot62.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker64 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint63);
        intervalMarker64.setEndValue((double) 1.0f);
        boolean boolean67 = categoryPlot34.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker64);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 90.0d + "'", double48 == 90.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(plot62);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("Range[0.0,1.0]");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "", true);
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        java.lang.Object obj11 = null;
        boolean boolean12 = piePlot3D10.equals(obj11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) piePlot3D10, true);
        java.awt.Color color15 = java.awt.Color.PINK;
        jFreeChart14.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart14.getLegend(0);
        rendererChangeEvent6.setChart(jFreeChart14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection21 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis23 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean24 = periodAxis23.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = periodAxis23.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis27.setLowerBound((double) 10);
        java.util.TimeZone timeZone30 = periodAxis27.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = xYBarRenderer31.getSeriesURLGenerator(1);
        xYBarRenderer31.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = null;
        xYBarRenderer31.setSeriesNegativeItemLabelPosition(2, itemLabelPosition37, false);
        xYBarRenderer31.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection21, (org.jfree.chart.axis.ValueAxis) periodAxis23, (org.jfree.chart.axis.ValueAxis) periodAxis27, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer31);
        boolean boolean42 = chartChangeEventType20.equals((java.lang.Object) xYBarRenderer31);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) year2, jFreeChart14, chartChangeEventType20);
        periodAxis1.setLast((org.jfree.data.time.RegularTimePeriod) year2);
        java.awt.Paint paint45 = periodAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(legendTitle18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(tickUnitSource25);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(xYURLGenerator33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains((double) (byte) 1);
        double double3 = range0.getLowerBound();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range0, range4);
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toRangeHeight(range9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(range9);
        double double13 = dateRange11.constrain(0.08d);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange11, 2.0d, true);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.black;
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color8);
        piePlot3D1.setIgnoreNullValues(true);
        java.lang.Comparable comparable12 = null;
        java.awt.Stroke stroke13 = null;
        try {
            piePlot3D1.setSectionOutlineStroke(comparable12, stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.lang.Object obj2 = null;
        boolean boolean3 = piePlot3D1.equals(obj2);
        boolean boolean4 = piePlot3D1.getAutoPopulateSectionPaint();
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D();
        double double7 = categoryAxis3D6.getLabelAngle();
        categoryAxis3D6.clearCategoryLabelToolTips();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis3D6.setTickLabelFont((java.lang.Comparable) '4', font10);
        boolean boolean12 = piePlot3D1.equals((java.lang.Object) categoryAxis3D6);
        java.lang.Object obj13 = categoryAxis3D6.clone();
        org.jfree.chart.axis.PeriodAxis periodAxis15 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis15.setLowerBound((double) 10);
        java.util.TimeZone timeZone18 = periodAxis15.getTimeZone();
        periodAxis15.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean24 = range22.contains((double) (byte) 1);
        double double25 = range22.getLowerBound();
        periodAxis15.setRange(range22, false, false);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        long long30 = year29.getSerialIndex();
        periodAxis15.setLast((org.jfree.data.time.RegularTimePeriod) year29);
        java.lang.Number number32 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, number32);
        int int34 = year29.getYear();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D36 = new org.jfree.chart.plot.PiePlot3D(pieDataset35);
        boolean boolean37 = piePlot3D36.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator38 = piePlot3D36.getLegendLabelToolTipGenerator();
        double double39 = piePlot3D36.getStartAngle();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D36.setLabelBackgroundPaint((java.awt.Paint) color40);
        categoryAxis3D6.setTickLabelPaint((java.lang.Comparable) year29, (java.awt.Paint) color40);
        float float43 = categoryAxis3D6.getMinorTickMarkInsideLength();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis46 = xYPlot44.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = null;
        java.awt.geom.Point2D point2D51 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D49, rectangleAnchor50);
        xYPlot44.panDomainAxes((double) (byte) 0, plotRenderingInfo48, point2D51);
        boolean boolean53 = xYPlot44.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D54 = xYPlot44.getQuadrantOrigin();
        int int55 = xYPlot44.getRangeAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder56 = xYPlot44.getSeriesRenderingOrder();
        java.awt.Stroke stroke57 = xYPlot44.getRangeGridlineStroke();
        categoryAxis3D6.setTickMarkStroke(stroke57);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 90.0d + "'", double39 == 90.0d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder56);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) (-1.0f), 0.0d);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer3.getSeriesURLGenerator(1);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer3.setBaseOutlineStroke(stroke6);
        xYBarRenderer3.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint11 = xYBarRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = xYBarRenderer3.getBaseFillPaint();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) paint12);
        barRenderer3D2.setMaximumBarWidth((double) 36);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType17 = standardGradientPaintTransformer16.getType();
        barRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray22, numberArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray25);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset26, false);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset26, false);
        org.jfree.data.Range range32 = barRenderer3D2.findRangeBounds(categoryDataset26, true);
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double2 = periodAxis1.getUpperMargin();
        java.awt.Color color3 = java.awt.Color.PINK;
        int int4 = color3.getGreen();
        periodAxis1.setLabelPaint((java.awt.Paint) color3);
        periodAxis1.resizeRange(8.0d);
        periodAxis1.setMinorTickMarkInsideLength((float) 2958465);
        double double10 = periodAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 175 + "'", int4 == 175);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 'a', (int) '#', (int) (byte) 1);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        long long9 = segmentedTimeline3.getExceptionSegmentCount(97L, (long) (short) 0);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline3.getSegment((long) '4');
        segment11.dec();
        segment11.inc();
        boolean boolean14 = segment11.inExcludeSegments();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment15 = segment11.copy();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3492L + "'", long4 == 3492L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(segment15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(3492L, 8, 2147483647);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = null;
        segmentedTimeline3.setBaseTimeline(segmentedTimeline6);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        piePlot3D8.zoom((double) 3492L);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray30 = new float[] { 97L, 'a', 60000L, 6, (short) 1, (byte) -1 };
        float[] floatArray31 = color23.getColorComponents(floatArray30);
        float[] floatArray32 = color22.getComponents(floatArray30);
        piePlot3D8.setSectionOutlinePaint((java.lang.Comparable) 0.0f, (java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionOutlinePaint();
        double double3 = piePlot3D1.getStartAngle();
        piePlot3D1.setLabelLinksVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset1 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset1);
        boolean boolean3 = paintList0.equals((java.lang.Object) defaultXYDataset1);
        java.awt.Paint paint5 = paintList0.getPaint(8);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color5 = java.awt.Color.PINK;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color5, false);
        boolean boolean8 = xYBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        boolean boolean2 = borderArrangement0.equals((java.lang.Object) itemLabelAnchor1);
        borderArrangement0.clear();
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double6 = periodAxis5.getUpperMargin();
        java.awt.Color color7 = java.awt.Color.PINK;
        int int8 = color7.getGreen();
        periodAxis5.setLabelPaint((java.awt.Paint) color7);
        float float10 = periodAxis5.getMinorTickMarkOutsideLength();
        boolean boolean11 = borderArrangement0.equals((java.lang.Object) float10);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 175 + "'", int8 == 175);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getIntegerInstance();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[size=1]", numberFormat1, numberFormat2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        xYPlot4.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = xYPlot4.getLegendItems();
        java.lang.Object obj10 = legendItemCollection9.clone();
        boolean boolean11 = standardXYToolTipGenerator3.equals((java.lang.Object) legendItemCollection9);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        int int11 = xYPlot0.getRangeAxisCount();
        xYPlot0.clearAnnotations();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        textLine1.draw(graphics2D2, (float) ' ', (float) (byte) 100, textAnchor5, (float) 3, (float) 2, (double) 1.0f);
        textBlock0.addLine(textLine1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Category Plot");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset4);
        org.jfree.chart.plot.Plot plot6 = multiplePiePlot5.getRootPlot();
        java.awt.Paint paint7 = plot6.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint7);
        standardChartTheme1.setBaselinePaint(paint7);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter13 = new org.jfree.chart.renderer.category.GradientBarPainter((double) '4', 0.08d, 1.0d);
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter13);
        standardChartTheme1.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter13);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        try {
            timeSeriesCollection0.setSelected(255, (int) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (255).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) (-1.0f));
        intervalMarker14.setStartValue((double) (short) 10);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean19 = xYPlot0.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) intervalMarker14, layer17, true);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot0.getDomainMarkers(13, layer21);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "UnitType.ABSOLUTE", "Range[0.0,1.0]", image3, "{0}", "[size=1]", "Range[0.0,1.0]");
        projectInfo7.setLicenceName("");
        java.lang.String str10 = projectInfo7.getName();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance();
        numberFormat1.setParseIntegerOnly(false);
        int int4 = numberFormat1.getMaximumIntegerDigits();
        logAxis0.setNumberFormatOverride(numberFormat1);
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        logAxis0.setDownArrow(shape6);
        double double9 = logAxis0.calculateLog((double) 60000L);
        logAxis0.configure();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.778151250383643d + "'", double9 == 4.778151250383643d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(6, 0, 15);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        double double1 = combinedRangeXYPlot0.getDomainCrosshairValue();
        java.util.List list2 = combinedRangeXYPlot0.getAnnotations();
        combinedRangeXYPlot0.setWeight(0);
        combinedRangeXYPlot0.setRangeCrosshairValue((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setDomainAxis((int) '4', valueAxis6, true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D();
        double double12 = categoryAxis3D11.getLabelAngle();
        categoryAxis3D11.clearCategoryLabelToolTips();
        categoryAxis3D11.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D();
        double double18 = categoryAxis3D17.getLabelAngle();
        categoryAxis3D17.clearCategoryLabelToolTips();
        categoryAxis3D17.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str23 = categoryAxis3D17.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        org.jfree.chart.axis.AxisState axisState30 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D17.drawTickMarks(graphics2D24, (double) (byte) -1, rectangle2D26, rectangleEdge28, axisState30);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer32 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator34 = xYBarRenderer32.getSeriesURLGenerator(1);
        java.awt.Stroke stroke35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer32.setBaseOutlineStroke(stroke35);
        xYBarRenderer32.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer32.setBaseShape(shape41);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity43 = new org.jfree.chart.entity.LegendItemEntity(shape41);
        java.awt.Shape shape44 = legendItemEntity43.getArea();
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D(pieDataset45);
        boolean boolean47 = legendItemEntity43.equals((java.lang.Object) piePlot3D46);
        org.jfree.chart.entity.EntityCollection entityCollection48 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = new org.jfree.chart.ChartRenderingInfo(entityCollection48);
        java.awt.geom.Rectangle2D rectangle2D50 = chartRenderingInfo49.getChartArea();
        legendItemEntity43.setArea((java.awt.Shape) rectangle2D50);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        double double53 = categoryAxis3D52.getLabelAngle();
        categoryAxis3D52.clearCategoryLabelToolTips();
        categoryAxis3D52.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str58 = categoryAxis3D52.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        org.jfree.chart.axis.AxisState axisState65 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D52.drawTickMarks(graphics2D59, (double) (byte) -1, rectangle2D61, rectangleEdge63, axisState65);
        java.util.List list67 = categoryAxis3D11.refreshTicks(graphics2D16, axisState30, rectangle2D50, rectangleEdge63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        xYPlot0.drawAnnotations(graphics2D10, rectangle2D50, plotRenderingInfo68);
        xYPlot0.setRangeCrosshairValue((double) 2.0f, false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(xYURLGenerator34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(list67);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.util.List list5 = null;
        xYPlot0.drawRangeTickBands(graphics2D3, rectangle2D4, list5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color8, stroke9);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = valueMarker10.getLabelAnchor();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker10, layer13);
        int int15 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            double double6 = intervalXYDelegate3.getEndXValue(6, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesLinesVisible(2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot6.getRootPlot();
        java.awt.Shape shape8 = multiplePiePlot6.getLegendItemShape();
        xYLineAndShapeRenderer0.setLegendLine(shape8);
        java.lang.Boolean boolean11 = xYLineAndShapeRenderer0.getSeriesItemLabelsVisible(6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator14, xYURLGenerator15);
        xYAreaRenderer16.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot20.getRangeAxis((int) '#');
        xYPlot20.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = xYPlot20.getFixedLegendItems();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder26 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str27 = seriesRenderingOrder26.toString();
        xYPlot20.setSeriesRenderingOrder(seriesRenderingOrder26);
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        java.awt.Font font32 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D(pieDataset33);
        java.lang.Object obj35 = null;
        boolean boolean36 = piePlot3D34.equals(obj35);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("", font32, (org.jfree.chart.plot.Plot) piePlot3D34, true);
        java.awt.Color color39 = java.awt.Color.PINK;
        jFreeChart38.setBorderPaint((java.awt.Paint) color39);
        org.jfree.chart.title.LegendTitle legendTitle42 = jFreeChart38.getLegend(0);
        legendTitle42.setHeight((double) (byte) 100);
        legendTitle42.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection50 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo(entityCollection50);
        java.awt.geom.Rectangle2D rectangle2D52 = chartRenderingInfo51.getChartArea();
        legendTitle42.setBounds(rectangle2D52);
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D56 = new org.jfree.chart.plot.PiePlot3D(pieDataset55);
        boolean boolean57 = piePlot3D56.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator58 = piePlot3D56.getLegendLabelToolTipGenerator();
        double double59 = piePlot3D56.getStartAngle();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D56.setLabelBackgroundPaint((java.awt.Paint) color60);
        java.awt.Color color63 = java.awt.Color.black;
        piePlot3D56.setSectionOutlinePaint((java.lang.Comparable) "[size=1]", (java.awt.Paint) color63);
        piePlot3D56.setIgnoreNullValues(true);
        java.awt.Paint paint67 = piePlot3D56.getLabelOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot69 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset68);
        org.jfree.chart.JFreeChart jFreeChart70 = multiplePiePlot69.getPieChart();
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart70.setBorderStroke(stroke71);
        xYAreaRenderer16.drawDomainLine(graphics2D19, xYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis30, rectangle2D52, (double) 10L, paint67, stroke71);
        xYLineAndShapeRenderer0.setSeriesStroke(3, stroke71);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(seriesRenderingOrder26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str27.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(legendTitle42);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 90.0d + "'", double59 == 90.0d);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(jFreeChart70);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart2.setBorderPaint((java.awt.Paint) color3);
        org.jfree.chart.title.TextTitle textTitle5 = jFreeChart2.getTitle();
        java.awt.Paint paint6 = jFreeChart2.getBackgroundPaint();
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D(pieDataset9);
        java.lang.Object obj11 = null;
        boolean boolean12 = piePlot3D10.equals(obj11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font8, (org.jfree.chart.plot.Plot) piePlot3D10, true);
        java.awt.Color color15 = java.awt.Color.PINK;
        jFreeChart14.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart14.getLegend(0);
        legendTitle18.setHeight((double) (byte) 100);
        legendTitle18.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle18.getLegendItemGraphicPadding();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = legendTitle18.arrange(graphics2D27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.LEFT;
        legendTitle18.setLegendItemGraphicEdge(rectangleEdge29);
        jFreeChart2.addSubtitle((org.jfree.chart.title.Title) legendTitle18);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textTitle5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(legendTitle18);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Color color10 = java.awt.Color.black;
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color10);
        xYPlot0.setDomainMinorGridlinesVisible(false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) "", true);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        java.lang.Object obj7 = null;
        boolean boolean8 = piePlot3D6.equals(obj7);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", font4, (org.jfree.chart.plot.Plot) piePlot3D6, true);
        java.awt.Color color11 = java.awt.Color.PINK;
        jFreeChart10.setBorderPaint((java.awt.Paint) color11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart10.getLegend(0);
        rendererChangeEvent2.setChart(jFreeChart10);
        jFreeChart10.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(legendTitle14);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        boolean boolean13 = legendTitle11.equals((java.lang.Object) 175);
        java.lang.Number[] numberArray17 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray17, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset21, false);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset21, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis28.setLowerBound((double) 10);
        java.util.TimeZone timeZone31 = periodAxis28.getTimeZone();
        periodAxis28.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean37 = range35.contains((double) (byte) 1);
        double double38 = range35.getLowerBound();
        periodAxis28.setRange(range35, false, false);
        periodAxis28.zoomRange(0.0d, 0.0d);
        periodAxis28.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis26, (org.jfree.chart.axis.ValueAxis) periodAxis28, categoryItemRenderer47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot48.getDomainAxisEdge();
        legendTitle11.setPosition(rectangleEdge49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        legendTitle11.setItemPaint((java.awt.Paint) color51);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Pie 3D Plot", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Shape shape2 = xYBarRenderer0.getSeriesShape((int) (byte) 1);
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter7 = xYBarRenderer0.getBarPainter();
        org.jfree.chart.LegendItem legendItem10 = xYBarRenderer0.getLegendItem((int) (short) 0, (int) ' ');
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation13 = null;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(xYBarPainter7);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNotNull(layer14);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot34.setRangeZeroBaselinePaint(paint36);
        categoryPlot34.setRangeCrosshairValue(0.08d);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D();
        double double42 = categoryAxis3D41.getLabelAngle();
        int int43 = categoryAxis3D41.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D(pieDataset44);
        boolean boolean46 = piePlot3D45.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot3D45.getLegendLabelToolTipGenerator();
        double double48 = piePlot3D45.getStartAngle();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D45.setLabelBackgroundPaint((java.awt.Paint) color49);
        categoryAxis3D41.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D45);
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D41.setTickLabelFont(font52);
        categoryAxis3D41.setLabel("Range[0.0,1.0]");
        categoryPlot34.setDomainAxis((int) '#', (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, false);
        categoryAxis3D41.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 90.0d + "'", double48 == 90.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(font52);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        java.awt.Color color5 = java.awt.Color.PINK;
        xYBarRenderer0.setBasePaint((java.awt.Paint) color5, false);
        xYBarRenderer0.setShadowYOffset((double) 8);
        java.lang.Object obj10 = xYBarRenderer0.clone();
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        java.lang.Object obj2 = timeSeries1.clone();
        timeSeries1.setDomainDescription("java.awt.Color[r=0,g=0,b=0]");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 15, (float) (byte) 100, (double) 36, (float) 100L, 0.0f);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.Plot plot7 = multiplePiePlot6.getRootPlot();
        boolean boolean8 = xYBarRenderer0.hasListener((java.util.EventListener) plot7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        try {
            xYBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(8.0d, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", false);
        java.lang.String str5 = logFormat3.format((long) (-133));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "�" + "'", str5.equals("�"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
        timeSeries2.removeAgedItems((long) (-1), false);
        double double6 = timeSeries2.getMaxY();
        int int7 = timeSeriesCollection0.indexOf(timeSeries2);
        java.util.List list8 = timeSeriesCollection0.getSeries();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.RenderingSource renderingSource2 = chartRenderingInfo1.getRenderingSource();
        org.junit.Assert.assertNull(renderingSource2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        categoryAxis3D0.clearCategoryLabelToolTips();
        categoryAxis3D0.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        java.lang.String str6 = categoryAxis3D0.getCategoryLabelToolTip((java.lang.Comparable) 100.0f);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        categoryAxis3D0.drawTickMarks(graphics2D7, (double) (byte) -1, rectangle2D9, rectangleEdge11, axisState13);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = xYBarRenderer15.getSeriesURLGenerator(1);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer15.setBaseOutlineStroke(stroke18);
        xYBarRenderer15.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer15.setBaseShape(shape24);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        java.awt.Shape shape27 = legendItemEntity26.getArea();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot28.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot28.panDomainAxes((double) (byte) 0, plotRenderingInfo32, point2D35);
        boolean boolean37 = xYPlot28.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D38 = xYPlot28.getQuadrantOrigin();
        int int39 = xYPlot28.getRangeAxisCount();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset40 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset40, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate43 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset40);
        int int44 = xYPlot28.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset40);
        legendItemEntity26.setDataset((org.jfree.data.general.Dataset) defaultXYDataset40);
        boolean boolean46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (byte) -1, (java.lang.Object) legendItemEntity26);
        java.lang.String str47 = legendItemEntity26.getToolTipText();
        java.lang.String str48 = legendItemEntity26.getShapeType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(xYURLGenerator17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "poly" + "'", str48.equals("poly"));
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test160");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
//        timeSeries1.setMaximumItemCount((int) (byte) 1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        int int5 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.previous();
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("WMAP_Plot");
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis2.setLowerBound((double) 10);
        java.util.TimeZone timeZone5 = periodAxis2.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("", timeZone5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        dateAxis8.configure();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.Object obj0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot2.getPieChart();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart3.getTitle();
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent9 = new org.jfree.chart.event.ChartProgressEvent(obj0, jFreeChart3, (int) '#', 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = xYBarRenderer0.getSeriesURLGenerator(1);
        xYBarRenderer0.setShadowVisible(false);
        java.awt.Paint paint6 = xYBarRenderer0.getSeriesItemLabelPaint(100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        try {
            xYBarRenderer0.setSeriesURLGenerator((-1), xYURLGenerator8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYURLGenerator2);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray4, numberArray6 };
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset8, false);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset8, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str14 = lengthConstraintType13.toString();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean18 = periodAxis17.isAxisLineVisible();
        periodAxis17.setAutoRangeMinimumSize((double) 2, true);
        double double22 = periodAxis17.getFixedDimension();
        org.jfree.data.Range range23 = periodAxis17.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Paint paint25 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        boolean boolean26 = lengthConstraintType24.equals((java.lang.Object) paint25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) 7, range12, lengthConstraintType13, (double) 13, range23, lengthConstraintType24);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LengthConstraintType.NONE" + "'", str14.equals("LengthConstraintType.NONE"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        double double1 = categoryAxis3D0.getLabelAngle();
        int int2 = categoryAxis3D0.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D();
        double double4 = categoryAxis3D3.getLabelAngle();
        int int5 = categoryAxis3D3.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis3D3.getCategoryLabelPositions();
        categoryAxis3D0.setCategoryLabelPositions(categoryLabelPositions6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis1.setLowerBound((double) 10);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean6 = range4.contains((double) (byte) 1);
        double double7 = range4.getLowerBound();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean10 = range8.contains((double) (byte) 1);
        double double11 = range8.getLowerBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range4, range8);
        periodAxis1.setRangeWithMargins(range8, true, false);
        double double17 = range8.constrain(97.0d);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries6 = xYSeries3.createCopy((int) 'a', (int) (byte) -1);
        xYSeries3.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries3.createCopy(10, 1);
        xYSeries3.clear();
        boolean boolean13 = tickUnits1.equals((java.lang.Object) xYSeries3);
        xYSeriesCollection0.removeSeries(xYSeries3);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean18 = periodAxis17.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = periodAxis17.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis21.setLowerBound((double) 10);
        java.util.TimeZone timeZone24 = periodAxis21.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator27 = xYBarRenderer25.getSeriesURLGenerator(1);
        xYBarRenderer25.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        xYBarRenderer25.setSeriesNegativeItemLabelPosition(2, itemLabelPosition31, false);
        xYBarRenderer25.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection15, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.axis.ValueAxis) periodAxis21, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer25);
        org.jfree.chart.axis.PeriodAxis periodAxis37 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis37.setLowerBound((double) 10);
        java.util.TimeZone timeZone40 = periodAxis37.getTimeZone();
        periodAxis37.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range44 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean46 = range44.contains((double) (byte) 1);
        double double47 = range44.getLowerBound();
        periodAxis37.setRange(range44, false, false);
        periodAxis37.zoomRange(0.0d, 0.0d);
        double double54 = periodAxis37.getUpperMargin();
        periodAxis37.setVisible(true);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator58 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator59 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer60 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator58, xYURLGenerator59);
        xYAreaRenderer60.setUseFillPaint(false);
        xYAreaRenderer60.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.axis.ValueAxis) periodAxis37, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer60);
        xYSeriesCollection0.setIntervalPositionFactor(0.4d);
        org.junit.Assert.assertNotNull(xYSeries6);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(xYURLGenerator27);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) rectangleAnchor7);
        valueMarker3.setLabelAnchor(rectangleAnchor7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYBarRenderer10.getSeriesURLGenerator(1);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        xYBarRenderer10.setBaseFillPaint((java.awt.Paint) color13, false);
        valueMarker3.setPaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = valueMarker3.getLabelOffset();
        double double18 = rectangleInsets17.getTop();
        double double19 = rectangleInsets17.getTop();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        java.lang.Object obj4 = null;
        boolean boolean5 = piePlot3D3.equals(obj4);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3D3, true);
        java.awt.Color color8 = java.awt.Color.PINK;
        jFreeChart7.setBorderPaint((java.awt.Paint) color8);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend(0);
        legendTitle11.setHeight((double) (byte) 100);
        legendTitle11.setMargin(0.025d, (double) 1.0f, 0.0d, (double) ' ');
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        legendTitle11.setBounds(rectangle2D21);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis3.setLowerBound((double) 10);
        java.util.TimeZone timeZone6 = periodAxis3.getTimeZone();
        double double7 = periodAxis3.getUpperMargin();
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean14 = piePlot12.equals((java.lang.Object) categoryAxis3D13);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.plot.Plot plot19 = multiplePiePlot18.getRootPlot();
        java.awt.Paint paint20 = plot19.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) (byte) 1, paint20);
        categoryAxis3D13.setTickMarkPaint(paint20);
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) 3492L, (double) 3, 0.0d, paint20);
        periodAxis3.setLabelPaint(paint20);
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Paint paint27 = textFragment26.getPaint();
        periodAxis3.setMinorTickMarkPaint(paint27);
        categoryAxis3D0.setTickLabelPaint((java.lang.Comparable) (short) -1, paint27);
        float float30 = categoryAxis3D0.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D();
        boolean boolean37 = piePlot35.equals((java.lang.Object) categoryAxis3D36);
        double double38 = categoryAxis3D36.getLabelAngle();
        categoryAxis3D36.setLabelAngle((double) (-2208960000000L));
        categoryPlot34.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D36);
        boolean boolean42 = categoryPlot34.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, xYToolTipGenerator1, xYURLGenerator2);
        xYAreaRenderer3.setUseFillPaint(false);
        boolean boolean6 = xYAreaRenderer3.getUseFillPaint();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        double double10 = periodAxis9.getUpperMargin();
        java.awt.Stroke stroke11 = periodAxis9.getMinorTickMarkStroke();
        xYAreaRenderer3.setSeriesOutlineStroke(100, stroke11);
        xYAreaRenderer3.setSeriesVisibleInLegend(13, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        xYPlot0.setDomainAxis((int) '4', valueAxis6, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D();
        double double10 = categoryAxis3D9.getLabelAngle();
        int int11 = categoryAxis3D9.getCategoryLabelPositionOffset();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        boolean boolean14 = piePlot3D13.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot3D13.getLegendLabelToolTipGenerator();
        double double16 = piePlot3D13.getStartAngle();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D13.setLabelBackgroundPaint((java.awt.Paint) color17);
        categoryAxis3D9.addChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D13);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis3D9.setTickLabelFont(font20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis3D9.getTickLabelInsets();
        xYPlot0.setAxisOffset(rectangleInsets22);
        java.lang.String str24 = xYPlot0.getPlotType();
        xYPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 90.0d + "'", double16 == 90.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "XY Plot" + "'", str24.equals("XY Plot"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) 10);
        axisState1.cursorRight((double) (byte) 100);
        axisState1.setCursor((-5.76E7d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("{0}: ({1}, {2})");
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 97L };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 97L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray3, numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_LEFT", "{0}", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.PeriodAxis periodAxis14 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis14.setLowerBound((double) 10);
        java.util.TimeZone timeZone17 = periodAxis14.getTimeZone();
        periodAxis14.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean23 = range21.contains((double) (byte) 1);
        double double24 = range21.getLowerBound();
        periodAxis14.setRange(range21, false, false);
        periodAxis14.zoomRange(0.0d, 0.0d);
        periodAxis14.setAxisLineVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis12, (org.jfree.chart.axis.ValueAxis) periodAxis14, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot34.getDomainAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) (-1));
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer39 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator41 = xYBarRenderer39.getSeriesURLGenerator(1);
        xYBarRenderer39.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = null;
        xYBarRenderer39.setSeriesNegativeItemLabelPosition(2, itemLabelPosition45, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator49 = xYBarRenderer39.getSeriesURLGenerator(35);
        java.awt.Stroke stroke53 = xYBarRenderer39.getItemStroke((int) ' ', 0, false);
        intervalMarker38.setOutlineStroke(stroke53);
        categoryPlot34.setDomainGridlineStroke(stroke53);
        java.awt.Color color56 = java.awt.Color.cyan;
        categoryPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color56);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot34.getRangeAxisLocation(13);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot34.getRangeAxisEdge(0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(xYURLGenerator41);
        org.junit.Assert.assertNull(xYURLGenerator49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(35);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        int int9 = xYPlot0.getBackgroundImageAlignment();
        xYPlot0.setDomainMinorGridlinesVisible(true);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.axis.PeriodAxis periodAxis2 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis2.setLowerBound((double) 10);
        java.util.TimeZone timeZone5 = periodAxis2.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone5;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("", timeZone5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis8.getTickUnit();
        dateAxis8.setAutoTickUnitSelection(false, true);
        org.jfree.chart.axis.Timeline timeline13 = dateAxis8.getTimeline();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(timeline13);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment2, verticalAlignment3, (double) (short) 100, (double) (-1.0f));
        org.jfree.chart.block.Block block7 = null;
        columnArrangement6.add(block7, (java.lang.Object) 1L);
        boolean boolean10 = gradientPaintTransformType1.equals((java.lang.Object) columnArrangement6);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer11 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (short) 10);
        org.jfree.data.xy.XYSeries xYSeries4 = xYSeries1.createCopy((int) 'a', (int) (byte) -1);
        xYSeries1.setNotify(false);
        org.jfree.data.xy.XYSeries xYSeries9 = xYSeries1.createCopy(10, 1);
        double double10 = xYSeries1.getMaxY();
        boolean boolean11 = xYSeries1.getAllowDuplicateXValues();
        org.jfree.data.xy.XYDataItem xYDataItem14 = xYSeries1.addOrUpdate(0.05d, (double) (-2208960000000L));
        org.jfree.data.xy.XYDataItem xYDataItem17 = new org.jfree.data.xy.XYDataItem((double) 6, Double.NaN);
        org.jfree.data.xy.XYDataItem xYDataItem18 = xYSeries1.addOrUpdate(xYDataItem17);
        org.junit.Assert.assertNotNull(xYSeries4);
        org.junit.Assert.assertNotNull(xYSeries9);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(xYDataItem14);
        org.junit.Assert.assertNull(xYDataItem18);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        java.lang.String str3 = timePeriodAnchor1.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TimePeriodAnchor.MIDDLE" + "'", str3.equals("TimePeriodAnchor.MIDDLE"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Shape shape3 = xYLineAndShapeRenderer2.getLegendLine();
        int int4 = xYLineAndShapeRenderer2.getPassCount();
        java.awt.Font font8 = xYLineAndShapeRenderer2.getItemLabelFont(2147483647, (int) (byte) 10, false);
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("LengthConstraintType.NONE", font8);
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font8);
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        java.lang.Object obj15 = null;
        boolean boolean16 = piePlot3D14.equals(obj15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font12, (org.jfree.chart.plot.Plot) piePlot3D14, true);
        labelBlock10.setFont(font12);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2958465);
        java.awt.Shape shape3 = xYLineAndShapeRenderer0.getLegendLine();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot4.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        xYPlot4.panDomainAxes((double) (byte) 0, plotRenderingInfo8, point2D11);
        boolean boolean13 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D14 = xYPlot4.getQuadrantOrigin();
        int int15 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) xYPlot4, "", "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str19 = plotEntity18.getShapeCoords();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-7,0,7,0" + "'", str19.equals("-7,0,7,0"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = xYBarRenderer4.getSeriesURLGenerator(1);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer4.setBaseOutlineStroke(stroke7);
        xYBarRenderer4.setAutoPopulateSeriesFillPaint(true);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 100L);
        xYBarRenderer4.setBaseShape(shape13);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        java.awt.Shape shape16 = legendItemEntity15.getArea();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D(pieDataset17);
        boolean boolean19 = legendItemEntity15.equals((java.lang.Object) piePlot3D18);
        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
        java.awt.geom.Rectangle2D rectangle2D22 = chartRenderingInfo21.getChartArea();
        legendItemEntity15.setArea((java.awt.Shape) rectangle2D22);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean27 = periodAxis26.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = periodAxis26.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis30.setLowerBound((double) 10);
        java.util.TimeZone timeZone33 = periodAxis30.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator36 = xYBarRenderer34.getSeriesURLGenerator(1);
        xYBarRenderer34.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = null;
        xYBarRenderer34.setSeriesNegativeItemLabelPosition(2, itemLabelPosition40, false);
        xYBarRenderer34.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection24, (org.jfree.chart.axis.ValueAxis) periodAxis26, (org.jfree.chart.axis.ValueAxis) periodAxis30, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer34);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot44.setRangeMinorGridlineStroke(stroke45);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = xYBarRenderer48.getSeriesURLGenerator(1);
        java.awt.Stroke stroke51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        xYBarRenderer48.setBaseOutlineStroke(stroke51);
        xYBarRenderer48.setAutoPopulateSeriesFillPaint(true);
        java.awt.Paint paint56 = xYBarRenderer48.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(0.0d, paint56, stroke57);
        org.jfree.data.general.PieDataset pieDataset59 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D60 = new org.jfree.chart.plot.PiePlot3D(pieDataset59);
        boolean boolean61 = piePlot3D60.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator62 = piePlot3D60.getLegendLabelToolTipGenerator();
        double double63 = piePlot3D60.getStartAngle();
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D60.setLabelBackgroundPaint((java.awt.Paint) color64);
        org.jfree.data.general.PieDataset pieDataset66 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D67 = new org.jfree.chart.plot.PiePlot3D(pieDataset66);
        boolean boolean68 = piePlot3D67.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator69 = piePlot3D67.getLegendLabelToolTipGenerator();
        double double70 = piePlot3D67.getStartAngle();
        java.awt.Paint paint71 = piePlot3D67.getLabelPaint();
        piePlot3D60.setParent((org.jfree.chart.plot.Plot) piePlot3D67);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator73 = null;
        piePlot3D67.setToolTipGenerator(pieToolTipGenerator73);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D67.setInsets(rectangleInsets75, true);
        java.awt.Paint paint78 = piePlot3D67.getLabelShadowPaint();
        java.awt.Paint paint79 = piePlot3D67.getShadowPaint();
        valueMarker58.setPaint(paint79);
        org.jfree.chart.LegendItem legendItem81 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "DomainOrder.NONE", "Category Plot", "", (java.awt.Shape) rectangle2D22, stroke45, paint79);
        org.junit.Assert.assertNull(xYURLGenerator6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(tickUnitSource28);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(xYURLGenerator36);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(xYURLGenerator50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 90.0d + "'", double63 == 90.0d);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 90.0d + "'", double70 == 90.0d);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint79);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        java.util.Locale locale4 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        combinedDomainXYPlot0.setDomainCrosshairValue(Double.NaN, false);
        java.lang.String str4 = combinedDomainXYPlot0.getPlotType();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot5.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        xYPlot5.panDomainAxes((double) (byte) 0, plotRenderingInfo9, point2D12);
        java.awt.Paint paint14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot5.setDomainZeroBaselinePaint(paint14);
        combinedDomainXYPlot0.add(xYPlot5, 10);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = combinedDomainXYPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Combined_Domain_XYPlot" + "'", str4.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(legendItemCollection18);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = xYPlot0.getRangeAxis((int) '#');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        xYPlot0.panDomainAxes((double) (byte) 0, plotRenderingInfo4, point2D7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D10 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        boolean boolean14 = periodAxis13.isAxisLineVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = periodAxis13.getStandardTickUnits();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis17.setLowerBound((double) 10);
        java.util.TimeZone timeZone20 = periodAxis17.getTimeZone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYBarRenderer21.getSeriesURLGenerator(1);
        xYBarRenderer21.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = null;
        xYBarRenderer21.setSeriesNegativeItemLabelPosition(2, itemLabelPosition27, false);
        xYBarRenderer21.removeAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection11, (org.jfree.chart.axis.ValueAxis) periodAxis13, (org.jfree.chart.axis.ValueAxis) periodAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer21);
        boolean boolean32 = xYPlot31.canSelectByPoint();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot31.getLegendItems();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("SeriesRenderingOrder.FORWARD");
        java.lang.String str36 = legendItem35.getDescription();
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str39 = dateTickUnit37.valueToString((double) 0L);
        legendItem35.setSeriesKey((java.lang.Comparable) 0L);
        legendItemCollection33.add(legendItem35);
        xYPlot0.setFixedLegendItems(legendItemCollection33);
        xYPlot0.setNoDataMessage("Range[97.0,97.0]");
        org.jfree.chart.util.ObjectList objectList46 = new org.jfree.chart.util.ObjectList((int) 'a');
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color49, stroke50);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent52 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker51);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent53 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker51);
        objectList46.set(0, (java.lang.Object) valueMarker51);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker51);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(tickUnitSource15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(xYURLGenerator23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(legendItemCollection33);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "12/31/69 4:00 PM" + "'", str39.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot2.getPieChart();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        jFreeChart3.setBorderPaint((java.awt.Paint) color4);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart3.getTitle();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity8 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart3, "PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D1.getLegendLabelToolTipGenerator();
        double double4 = piePlot3D1.getStartAngle();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D1.setLabelBackgroundPaint((java.awt.Paint) color5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        boolean boolean9 = piePlot3D8.getIgnoreZeroValues();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D8.getLegendLabelToolTipGenerator();
        double double11 = piePlot3D8.getStartAngle();
        java.awt.Paint paint12 = piePlot3D8.getLabelPaint();
        piePlot3D1.setParent((org.jfree.chart.plot.Plot) piePlot3D8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot3D8.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot3D8.setInsets(rectangleInsets16, true);
        double double19 = piePlot3D8.getShadowXOffset();
        org.jfree.chart.util.Rotation rotation20 = piePlot3D8.getDirection();
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.DESCENDING");
        periodAxis22.setLowerBound((double) 10);
        java.util.TimeZone timeZone25 = periodAxis22.getTimeZone();
        periodAxis22.setRangeWithMargins((double) 1.0f, (double) 10.0f);
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean31 = range29.contains((double) (byte) 1);
        double double32 = range29.getLowerBound();
        periodAxis22.setRange(range29, false, false);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getSerialIndex();
        periodAxis22.setLast((org.jfree.data.time.RegularTimePeriod) year36);
        java.lang.Number number39 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, number39);
        java.lang.Number number41 = timeSeriesDataItem40.getValue();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray44 = new java.awt.Paint[] { color42, color43 };
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Paint[] paintArray51 = new java.awt.Paint[] { paint45, paint46, color47, color48, color49, color50 };
        java.awt.Stroke stroke52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray56 = new java.awt.Stroke[] { stroke52, stroke53, stroke54, stroke55 };
        java.awt.Stroke[] strokeArray57 = new java.awt.Stroke[] {};
        java.awt.Shape shape58 = null;
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] { shape58 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray44, paintArray51, strokeArray56, strokeArray57, shapeArray59);
        java.awt.Paint paint61 = defaultDrawingSupplier60.getNextPaint();
        piePlot3D8.setSectionOutlinePaint((java.lang.Comparable) timeSeriesDataItem40, paint61);
        double double63 = piePlot3D8.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(rotation20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paintArray44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(paintArray51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(strokeArray56);
        org.junit.Assert.assertNotNull(strokeArray57);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.14d + "'", double63 == 0.14d);
    }
}

